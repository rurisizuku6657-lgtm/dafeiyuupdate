"""在旧面板退出后安装或重启，等待新版窗口就绪，失败时恢复。"""

import ctypes
from ctypes import wintypes
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


STABLE_EXE = "大肥鱼standby.exe"
HANDOFF_EXIT = 10


def panel_ready(version):
    marker = os.environ.get("DFY_UPDATE_READY")
    if marker and str(version) == os.environ.get("DFY_UPDATE_VERSION"):
        path = Path(marker)
        path.with_suffix(".tmp").write_text(str(version), encoding="utf-8")
        os.replace(path.with_suffix(".tmp"), path)


def install_stable_entry(program):
    """从校验过的 ZIP 安装固定入口，保留旧版有版本号的文件。"""
    current = os.environ.get("DFY_EXE_PATH")
    if os.name != "nt" or not current:
        return
    old = Path(current)
    target = old.with_name(STABLE_EXE)
    source = Path(program) / "启动器" / STABLE_EXE
    if old == target or target.exists() or not old.is_file() or not source.is_file():
        return
    fd, name = tempfile.mkstemp(prefix=".dfy-", suffix=".new", dir=old.parent)
    os.close(fd)
    stage = Path(name)
    try:
        shutil.copyfile(source, stage)
        os.rename(stage, target)  # Windows 上目标已存在时失败，不覆盖另一份安装。
        os.environ["DFY_EXE_PATH"] = str(target)
    finally:
        stage.unlink(missing_ok=True)


def launch_env():
    env = {k: v for k, v in os.environ.items() if not k.startswith("DFY_UPDATE_")}
    env["PYINSTALLER_RESET_ENVIRONMENT"] = "1"
    env["PYTHONIOENCODING"] = "utf-8:backslashreplace"
    return env


def _kernel():
    api = ctypes.WinDLL("kernel32", use_last_error=True)
    api.OpenProcess.argtypes = (wintypes.DWORD, wintypes.BOOL, wintypes.DWORD)
    api.OpenProcess.restype = wintypes.HANDLE
    api.WaitForSingleObject.argtypes = (wintypes.HANDLE, wintypes.DWORD)
    api.WaitForSingleObject.restype = wintypes.DWORD
    api.CloseHandle.argtypes = (wintypes.HANDLE,)
    return api


def start_handoff(job):
    directory = Path(tempfile.mkdtemp(prefix="交接_", dir=job["work"]))
    job_path = directory / "job.json"
    job_path.write_text(json.dumps(job, ensure_ascii=False), encoding="utf-8")
    # 交接脚本保存在独立位置，应用目录回滚时仍可继续执行。
    helper = directory / "helper.py"
    shutil.copy2(__file__, helper)
    with (directory / "更新日志.txt").open("ab") as log:
        process = subprocess.Popen(
            [sys.executable, str(helper), str(job_path)], cwd=job["base"],
            stdin=subprocess.DEVNULL, stdout=log, stderr=log,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0)
            | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0),
        )
    for _ in range(80):
        if process.poll() is not None:
            break
        if (directory / "owner-ready").is_file():
            return
        time.sleep(0.05)
    if process.poll() is None:
        process.terminate()
    raise RuntimeError(f"更新交接未就绪，详情见 {directory / '更新日志.txt'}")


def _replace(source, target):
    for attempt in range(20):
        try:
            os.replace(source, target)
            return
        except PermissionError:
            if attempt == 19:
                raise
            time.sleep(0.25)


def stage_exe(download, current):
    current = Path(current).resolve(strict=True)
    target = current.with_name(STABLE_EXE)
    same_target = os.path.normcase(str(target)) == os.path.normcase(str(current))
    if not same_target and target.exists():
        raise FileExistsError(f"同目录已有 {target.name}，无法确认它属于当前安装")
    fd, name = tempfile.mkstemp(prefix=".dfy-", suffix=".new", dir=target.parent)
    os.close(fd)
    stage = Path(name)
    try:
        shutil.copyfile(download, stage)
        backup = stage.with_suffix(".previous.exe")
        shutil.copy2(current, backup)
        return stage, target, backup, same_target
    except BaseException:
        stage.unlink(missing_ok=True)
        raise


def _start_panel(job, directory):
    env = launch_env()
    env["DFY_UPDATE_READY"] = str(directory / "window-ready")
    env["DFY_UPDATE_VERSION"] = job["version"]
    command = job["new_command"]
    with (directory / "新版启动日志.txt").open("ab") as log:
        process = subprocess.Popen(command, cwd=job["base"], env=env, stdin=subprocess.DEVNULL,
                                   stdout=log, stderr=log)
    pid_file = directory / "panel.pid"
    deadline = time.monotonic() + 120
    child_handle = None
    api = _kernel()
    try:
        while time.monotonic() < deadline:
            if (directory / "window-ready").is_file():
                return
            if child_handle is None and pid_file.is_file():
                child_handle = api.OpenProcess(0x00100001, False, int(pid_file.read_text()))
            if child_handle and api.WaitForSingleObject(child_handle, 0) == 0:
                break
            if process.poll() is not None and (process.returncode or not job.get("exe")):
                break
            time.sleep(0.15)
        if child_handle and api.WaitForSingleObject(child_handle, 0) == 258:
            api.TerminateProcess.argtypes = (wintypes.HANDLE, wintypes.UINT)
            api.TerminateProcess(child_handle, 1)
            api.WaitForSingleObject(child_handle, 5000)
        if process.poll() is None:
            process.terminate()
            process.wait(timeout=5)
        raise RuntimeError("新版窗口未报告就绪")
    finally:
        if child_handle:
            api.CloseHandle(child_handle)


def restore_program(backups):
    for original, backup in reversed(backups):
        original = Path(original)
        with tempfile.TemporaryDirectory(prefix=".dfy-restore-", dir=original.parent) as folder:
            folder = Path(folder)
            previous, failed = folder / "previous", folder / "failed"
            if backup:
                shutil.copytree(backup, previous)
            moved = original.exists()
            if moved:
                _replace(original, failed)
            if backup:
                try:
                    _replace(previous, original)
                except OSError:
                    if moved:
                        _replace(failed, original)
                    raise


def finish(job_path):
    directory = job_path.parent
    job = json.loads(job_path.read_text(encoding="utf-8"))
    api = _kernel()
    owner = api.OpenProcess(0x00100000, False, job["owner"])
    if not owner:
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        (directory / "owner-ready").touch()
        exited = api.WaitForSingleObject(owner, 30000) == 0
    finally:
        api.CloseHandle(owner)
    if not exited:
        detail = "旧窗口未退出，已取消更新"
        try:
            if not job.get("exe"):
                restore_program(job["program_backups"])
        except OSError as error:
            detail += f"，程序恢复失败：{error}"
        _report(f"{detail}。详情见 {directory}")
        return 3

    exe = job.get("exe")
    installed = False
    try:
        if exe:
            stage, target, backup, same_target = exe
            if not same_target and Path(target).exists():
                raise FileExistsError(target)
            # 同一目录替换：任何失败都不会先移走旧入口。
            if same_target:
                _replace(stage, target)
            else:
                os.rename(stage, target)
            installed = True
        _start_panel(job, directory)
        print("新版窗口已就绪", flush=True)
        return 0
    except Exception as error:
        print(f"更新失败：{error}", flush=True)
        problems = []
        try:
            if installed and backup:
                shutil.copy2(backup, stage)
                _replace(stage, target)
        except OSError as recovery_error:
            problems.append(f"启动器恢复失败，备份位于 {backup}：{recovery_error}")
        try:
            restore_program(job["program_backups"])
        except OSError as recovery_error:
            problems.append(f"程序文件恢复失败：{recovery_error}")
        try:
            old_command = [backup] if problems and installed and backup else job["old_command"]
            subprocess.Popen(old_command, cwd=job["base"], env=launch_env())
        except OSError as restart_error:
            problems.append(f"旧版自动启动失败：{restart_error}")
        detail = "\n".join(problems) if problems else "已恢复并尝试重新打开旧版。"
        _report(f"更新失败：{error}\n{detail}\n详情见 {directory}")
        return 3


def _report(message):
    print(message, flush=True)
    ctypes.windll.user32.MessageBoxW(None, message, "大肥鱼standby 更新失败", 0x10)


if __name__ == "__main__":
    sys.exit(finish(Path(sys.argv[1])))
