# -*- coding: utf-8 -*-
"""出价策略实测监控 —— 旁路盯 试验记录.jsonl，发现出价链路的异常就记一条。

为什么要这个东西
----------------
挂机的时候，出价算错了你是看不见的：日志两兆多，翻到最后也找不出来。
这个脚本不参与任何决策，只把「出价链路自己跟自己矛盾」的地方挑出来 ——
比如最终价低于保底、超过上限、提交的价和算出来的价不是一个数、
道具在出价之后才生效……全都当场写进一条独立的异常文件。

它只读，不改记录、不碰游戏窗口，随时可以停。

参考自 EvilNte 的 strategy_live_audit.py，字段按本项目的记录格式重写了：
- 那边 post_scan_estimate  → 这边 instrument_estimate_stable（final 字段）
- 那边 exit_low_value      → 这边同名，字段一致
- 那边 bid_submitted 带 round → 这边没有，用上一轮回合兜底
- 那边 rounds_played 必须等于 len(rounds) → 这边常常不等（没出价的回合不进明细），
  所以这条规则没有搬过来，搬了必然天天误报
- 那边靠 high_value/cap_exception 两个字段判，这边没有，改成看 adjusts 里的中文说明
"""

from __future__ import annotations

import atexit
import datetime as dt
import msvcrt
import threading
import traceback
import json
import re
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
EVENT_PATH = BASE / "记录" / "试验记录.jsonl"
MAIN_PATH = BASE / "程序" / "paimai.py"
OUT_DIR = BASE / "记录"
OUT_DIR.mkdir(parents=True, exist_ok=True)

STARTED_AT = dt.datetime.now()
REPORT_PATH = OUT_DIR / ("出价策略实测监控_%s.log" % STARTED_AT.strftime("%Y%m%d_%H%M%S"))
ANOMALY_PATH = OUT_DIR / ("出价策略实测异常_%s.jsonl" % STARTED_AT.strftime("%Y%m%d_%H%M%S"))

# 只认这些类型，其他行连 json 都不解析（记录文件很大，省点力气）
WATCH_TYPES = {
    "session_start",
    "auction_start",
    "round_start",
    "round_detected",
    "instrument_start",
    "instrument_used",
    "instrument_estimate_stable",
    "estimate_ready",
    "piece_bonus",
    "bid_decision",
    "bid_submitted",
    "bid_fail",
    "exit_low_value",
    "exit_small_gap",
    "auction_end",
}
WATCH_TOKENS = tuple(('"%s"' % t).encode("utf-8") for t in WATCH_TYPES)

# 两次心跳之间至少隔这么久（秒）
HEARTBEAT_IDLE_SEC = 20.0


def now_text():
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def as_int(value, default=0):
    """把记录里的数掰成整数。

    出价金额常常是 "599,999" 这种带逗号的字符串，也可能是 52 万这样的中文写法，
    所以先抽数字再认 M/K 后缀 —— 宁可读不出来用默认值，也不要抛异常中断监控。
    """
    if value is None or value == "":
        return int(default)
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value).strip().replace(",", "")
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        return int(default)
    number = float(match.group(0))
    upper = text.upper()
    if "M" in upper:
        number *= 1_000_000
    elif "K" in upper:
        number *= 1_000
    return int(number)


def event_time(event):
    """记录里没有毫秒，解析失败就返回 None（当它是在本次监控开始后发生的）。"""
    try:
        return dt.datetime.strptime(str(event.get("ts") or ""), "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None


def source_number(name, default):
    """从 paimai.py 里读常量的当前值。

    这样参数一改，监控跟着改，不用在两个地方各维护一份。
    读不到就用默认值 —— 监控不能因为读不到参数就罢工。
    """
    try:
        source = MAIN_PATH.read_text(encoding="utf-8")
        match = re.search(
            r"^%s\s*=\s*([-+]?\d+(?:\.\d+)?)" % re.escape(name), source, re.M
        )
        if not match:
            return default
        return float(match.group(1))
    except Exception:
        return default


class 出价监控:
    """逐条吃事件的审计器。每一局、每一回合各留一份状态。"""

    def __init__(self, console=True):
        self.console = console
        self.runs = {}
        self.current_run_id = ""
        self.sequence = 0
        self.anomaly_keys = set()
        self.anomaly_count = 0
        self.decision_count = 0
        self.submit_count = 0
        self.auction_count = 0
        self.last_event_at = time.time()
        self.exit_line = int(source_number("EXIT_BELOW_PRICE", 500_000))
        self.instrument_round = {
            round_no: int(source_number("TOOL_R%d" % round_no, 0))
            for round_no in range(1, 6)
        }
        self.log_file = open(REPORT_PATH, "a", encoding="utf-8", buffering=1)

    # ---------- 输出 ----------

    def close(self):
        try:
            self.write(
                "STOP %s | 局=%d 决策=%d 提交=%d 异常=%d"
                % (
                    now_text(), self.auction_count, self.decision_count,
                    self.submit_count, self.anomaly_count,
                )
            )
            self.log_file.close()
        except Exception:
            pass

    def write(self, text, echo=False):
        line = "%s %s" % (now_text(), text)
        try:
            self.log_file.write(line + "\n")
        except Exception:
            pass
        if echo and self.console:
            print(line, flush=True)

    def alert(self, event, code, message, severity="WARN"):
        """同一条异常只报一次（按 类型+局+回合+内容 去重）。"""
        run_id = str(event.get("run_id") or "")
        auction_id = str(event.get("auction_uid") or event.get("auction_no") or "")
        round_no = str(event.get("round") or event.get("current_round") or "")
        key = (code, run_id, auction_id, round_no, message)
        if key in self.anomaly_keys:
            return
        self.anomaly_keys.add(key)
        self.anomaly_count += 1
        payload = {
            "detected_at": now_text(),
            "severity": severity,
            "code": code,
            "message": message,
            "event": event,
        }
        try:
            with open(ANOMALY_PATH, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(payload, ensure_ascii=False) + "\n")
        except Exception:
            pass
        self.write(
            "ANOMALY [%s] %s | run=%s 局=%s 回合=%s | %s"
            % (
                severity, code, run_id,
                event.get("auction_no", "—"),
                round_no or "—", message,
            ),
            echo=True,
        )

    # ---------- 状态 ----------

    def run_state(self, event):
        run_id = str(event.get("run_id") or self.current_run_id or "unknown")
        if run_id != self.current_run_id:
            self.current_run_id = run_id
        return self.runs.setdefault(run_id, {"auctions": {}})

    def auction_state(self, event):
        run = self.run_state(event)
        auction_id = str(
            event.get("auction_uid")
            or "%s:%s" % (self.current_run_id, event.get("auction_no") or "unknown")
        )
        return run["auctions"].setdefault(
            auction_id,
            {
                "auction_no": event.get("auction_no"),
                "rounds": {},
                "last_bid": 0,
                "last_round": 0,
                "ended": False,
            },
        )

    def round_state(self, event):
        auction = self.auction_state(event)
        round_no = as_int(event.get("round") or event.get("current_round"), 0)
        # bid_submitted 这条记录里没有 round 字段，用本局见过的最大回合兜底
        if round_no <= 0:
            round_no = max(1, int(auction.get("last_round") or 1))
        auction["last_round"] = max(int(auction.get("last_round") or 0), round_no)
        return auction["rounds"].setdefault(
            round_no,
            {
                "instrument_start": None,
                "instrument_used": None,
                "instrument_name": "",
                "post_scan": None,
                "bonus": None,
                "decision": None,
                "submitted": None,
            },
        )

    # ---------- 事件分发 ----------

    def consume(self, event, live=True):
        self.sequence += 1
        event = dict(event or {})
        event["_seq"] = self.sequence
        event_type = str(event.get("type") or "")
        if event_type not in WATCH_TYPES:
            return
        self.last_event_at = time.time()

        if event_type == "session_start":
            if live:
                self.write(
                    "START 新挂机会话 run=%s" % str(event.get("run_id") or ""),
                    echo=True,
                )
            return

        if event_type == "auction_end":
            self.finish_auction(event, live=live)
            return

        if event_type in ("exit_low_value", "exit_small_gap"):
            if live:
                self.write(
                    "EXIT 第%s回合 估价%s 低于退出线%s（%s）"
                    % (
                        event.get("round", "—"),
                        as_int(event.get("estimate")),
                        as_int(event.get("exit_line") or self.exit_line),
                        event_type,
                    ),
                    echo=True,
                )
            return

        if event_type in ("round_start", "round_detected"):
            self.round_state(event)
            if live:
                self.write(
                    "ROUND 第%s回合"
                    % (event.get("round") or event.get("current_round") or "—")
                )
            return

        if event_type == "instrument_start":
            state = self.round_state(event)
            state["instrument_start"] = event
            state["instrument_name"] = event.get("instrument_name") or ""
            if live:
                self.write(
                    "INSTRUMENT_START 第%s回合 %s"
                    % (
                        event.get("round", "—"),
                        state["instrument_name"] or event.get("instrument", "—"),
                    )
                )
            return

        if event_type == "instrument_used":
            state = self.round_state(event)
            state["instrument_used"] = event
            state["instrument_name"] = (
                event.get("instrument_name") or state["instrument_name"]
            )
            decision = state.get("decision")
            submitted = state.get("submitted")
            # 这里本来要报「出价算完了道具才生效」，但记录是异步写的，
            # 写入顺序不等于真实执行顺序，照搬必误报（实测 39 局里 19 局中招）。
            # 真要看道具有没有生效，下面「决策时 post_scan 在不在」那条更准。
            _ = (decision, submitted)
            if live:
                self.write(
                    "INSTRUMENT_USED 第%s回合 %s 花费%s"
                    % (
                        event.get("round", "—"),
                        state["instrument_name"] or event.get("instrument", "—"),
                        as_int(event.get("cost")),
                    )
                )
            return

        # 本项目里「仪器用完之后重新读稳定的那个估价」就是这条
        if event_type in ("instrument_estimate_stable", "estimate_ready"):
            state = self.round_state(event)
            state["post_scan"] = event
            if live:
                self.write(
                    "SCAN 第%s回合最终估价%s（%s，%ss）"
                    % (
                        event.get("round", "—"),
                        as_int(event.get("final")),
                        "仪器后" if event_type == "instrument_estimate_stable" else "进场",
                        event.get("elapsed_ms", "?"),
                    )
                )
            return

        if event_type == "bid_decision":
            self.check_decision(event, live=live)
            return

        # 金红块加价：出价算完之后还会按仓里红/金块数往上加一笔，
        # 所以「提交的价」本来就比「决策的价」高，不能直接比。
        if event_type == "piece_bonus":
            state = self.round_state(event)
            state["bonus"] = event
            if live:
                self.write(
                    "BONUS 第%s回合 红%s块 金%s块 → %s"
                    % (
                        event.get("round", "—"),
                        as_int(event.get("red")),
                        as_int(event.get("gold")),
                        as_int(event.get("price")),
                    )
                )
            return

        if event_type == "bid_submitted":
            self.check_submission(event, live=live)
            return

        if event_type == "bid_fail":
            if live:
                self.alert(
                    event, "bid_fail",
                    "出价流程失败：%s"
                    % str(event.get("human") or event.get("stage") or ""),
                    severity="CRITICAL",
                )
            return

    # ---------- 出价决策检查 ----------

    def check_decision(self, event, live=True):
        state = self.round_state(event)
        previous = state.get("decision")
        state["decision"] = event
        self.decision_count += 1

        round_no = as_int(event.get("round"), 0)
        final_price = as_int(event.get("price") or event.get("final_price"))
        strategy_price = as_int(event.get("engine_price") or event.get("strategy_price"))
        estimate = as_int(event.get("estimate") or event.get("strategy_estimate"))
        cap = as_int(event.get("cap") or event.get("p75_cap"))
        floor_bid = as_int(event.get("floor_bid"))
        no_exit_target = as_int(event.get("no_exit_target"))
        no_exit = bool(event.get("no_exit"))
        adjusts_text = " ".join(str(x) for x in (event.get("adjusts") or []))
        reason = str(event.get("reason") or "")

        # 本项目的每一条调整都会写进 adjusts，所以这里反过来用：
        # 只要 adjusts 已经解释了「为什么这个价看着不对」，就不算异常。
        # 这些词对上去的都是策略里明写的规则，不是兜底。
        # 「贴整」是策略自己把价往上贴成整千/整百，会让最终价略高于上限，
        # 属于设计内动作；cap 现在不再跟着最终价一起抬高，所以必须在这里豁免。
        EXPLAINED_CAP = ("不降价", "保底链", "保底", "不受上限", "贴整")
        EXPLAINED_FLOOR = ("硬顶", "压回", "不降价")
        explained_cap = any(word in adjusts_text for word in EXPLAINED_CAP)
        explained_floor = any(word in adjusts_text for word in EXPLAINED_FLOOR)

        if live:
            self.write(
                "DECISION 局%s 第%s回合 估价=%s 最终=%s 保底=%s 上限=%s "
                "不退出=%s 规则=%s"
                % (
                    event.get("auction_no", "—"), round_no or "—", estimate,
                    final_price, floor_bid, cap, no_exit, reason or "—",
                ),
                echo=True,
            )

        if not live:
            return

        # 1) 同一回合多次决策
        #    本项目的出价是「先按档位算一版，再被硬顶 / 对手溢价闸 / 保底链一层层压」，
        #    每压一次都记一条 bid_decision，所以同回合多条是设计如此，不报。
        _ = previous

        # 2) 组成项出现负数（算错了才会这样）
        #    先查这个再查最终价，否则 final_price<=0 一 return 就永远查不到了
        if any(value < 0 for value in
               (strategy_price, floor_bid, no_exit_target, cap)):
            self.alert(
                event, "negative_component",
                "策略金额出现负数：引擎=%s 保底=%s 不退出目标=%s 上限=%s"
                % (strategy_price, floor_bid, no_exit_target, cap),
                severity="CRITICAL",
            )

        # 2.5) 最终价不是正数
        if final_price <= 0:
            self.alert(
                event, "invalid_final_price",
                "最终出价不是有效正数：%s" % final_price,
                severity="CRITICAL",
            )
            return

        # 3) 低于保底
        #    两种豁免：上限比保底还小（算法把价压到上限）、adjusts 里写了压回的原因
        if floor_bid > 0 and final_price + 1 < floor_bid:
            if (cap <= 0 or cap >= floor_bid) and not explained_floor:
                self.alert(
                    event, "below_floor",
                    "最终出价 %s 低于本回合保底 %s" % (final_price, floor_bid),
                    severity="CRITICAL",
                )

        # 4) 超过上限
        #    adjusts 里写着「不受上限约束」「保底链要求不降价」的是策略本身，跳过
        if cap > 0 and not explained_cap:
            allowed = max(cap, floor_bid)
            if final_price > allowed + 999:
                self.alert(
                    event, "cap_exceeded",
                    "最终出价 %s 超过允许上限 %s" % (final_price, allowed),
                    severity="CRITICAL",
                )

        # 6) 最终价高于所有组成项 —— 说明中间有一步把价抬到了不该有的高度
        max_component = max(0, strategy_price, floor_bid, no_exit_target)
        if final_price > max_component + 1500 and "补到" not in adjusts_text:
            self.alert(
                event, "final_exceeds_components",
                "最终出价 %s 高于所有策略组成值，最大值为 %s"
                % (final_price, max_component),
            )

        # 7) 不退出模式下出价反而一轮比一轮低
        #    只在同一局内比（第 1 回合的「上一轮」是上一局，不能比），
        #    降超过 5% 才算真的掉了；「硬顶」压回估价 1.5 倍以内是策略自己的动作
        auction = self.auction_state(event)
        last_bid = as_int(auction.get("last_bid"))
        if (round_no >= 2 and no_exit and last_bid > 0
                and final_price < last_bid * 0.95
                and not any(w in adjusts_text for w in ("硬顶", "压回", "溢价闸"))):
            self.alert(
                event, "no_exit_price_drop",
                "不退出模式下本回合出价 %s 比上一轮 %s 低了 %.0f%%"
                % (final_price, last_bid, (1 - final_price / float(last_bid)) * 100),
            )

        # 8) 该退出没退出
        #    退出线只在「没有信息差」时才看，所以 adjusts 里提到信息差就放过
        if (not no_exit and round_no >= 3 and 0 < estimate < self.exit_line
                and "信息差" not in adjusts_text):
            self.alert(
                event, "missed_exit",
                "第%d回合估价 %s 低于退出线 %s，但仍生成了出价"
                % (round_no, estimate, self.exit_line),
            )

        # 9) 道具没确认生效就出价了
        instrument_start = state.get("instrument_start")
        instrument_used = state.get("instrument_used")
        if instrument_start is not None and instrument_used is None:
            self.alert(
                event, "instrument_not_confirmed",
                "已开始使用道具但未看到生效确认，随后已进入出价计算",
            )

        # 10) 道具生效了，但没看到之后重新读的那个估价
        if instrument_used is not None:
            post_scan = state.get("post_scan")
            if post_scan is None or post_scan["_seq"] < instrument_used["_seq"]:
                self.alert(
                    event, "post_scan_missing_after_instrument",
                    "道具生效后未看到扫描后的最终估价，已进入出价计算",
                )
        # 11) 这回合本来该用道具，却一次都没记录
        elif round_no >= 2 and self.instrument_round.get(round_no, 0) > 0:
            self.alert(
                event, "instrument_missing",
                "第%d回合未记录任何道具使用，已直接进入出价计算" % round_no,
            )

    # ---------- 提交检查 ----------

    def check_submission(self, event, live=True):
        state = self.round_state(event)
        state["submitted"] = event
        self.submit_count += 1
        price = as_int(event.get("price_raw") or event.get("price"))
        decision = state.get("decision")
        auction = self.auction_state(event)
        auction["last_bid"] = price
        if not live:
            return
        self.write(
            "SUBMIT 局%s 第%s回合 %s"
            % (event.get("auction_no", "—"), event.get("round", "—"), price),
            echo=True,
        )
        # 12) 实际点进去的价，和算出来的价不是同一个数
        #     注意：决策之后还有一步「金红块加价」，所以有 piece_bonus 就认它的价
        if decision is not None:
            expected = as_int(decision.get("price") or decision.get("final_price"))
            bonus = state.get("bonus")
            if bonus is not None and bonus["_seq"] > decision["_seq"]:
                expected = as_int(bonus.get("price"))
            if expected > 0 and abs(price - expected) > 1:
                self.alert(
                    event, "submitted_price_mismatch",
                    "实际提交 %s 与策略最终价 %s 不一致" % (price, expected),
                    severity="CRITICAL",
                )

    # ---------- 结算检查 ----------

    def finish_auction(self, event, live=True):
        auction = self.auction_state(event)
        auction["ended"] = True
        if not live:
            return
        self.auction_count += 1
        rounds = event.get("rounds") or []
        played = as_int(event.get("rounds_played"), len(rounds))

        seen_rounds = set()
        for row in rounds:
            round_no = as_int(row.get("round"))
            # 13) 明细里同一个回合出现两次
            if round_no in seen_rounds:
                self.alert(
                    event, "duplicate_end_round",
                    "结算明细重复出现第%s回合" % round_no,
                    severity="CRITICAL",
                )
            seen_rounds.add(round_no)
            bid = as_int(row.get("bid"))
            cap = as_int(row.get("cap"))
            floor_bid = as_int(row.get("required_floor") or row.get("floor_bid"))
            row_adjusts = " ".join(str(x) for x in (row.get("adjusts") or []))
            # 14) 明细里的出价远超上限
            #     放宽到 2 倍，并且 adjusts 解释过就跳过：
            #     明细里的 bid 是「金红块加过价」的，cap 是加价之前的上限。
            if (cap > 0 and bid > max(cap, floor_bid) * 2
                    and not any(w in row_adjusts for w in ("保底", "不受上限", "不降价"))):
                self.alert(
                    event, "end_round_cap_exceeded",
                    "结算明细第%s回合出价 %s 超过上限 %s 两倍以上"
                    % (round_no, bid, max(cap, floor_bid)),
                    severity="CRITICAL",
                )

        # 15) 明细里出过价的回合比记录的总回合还多（不可能的事）
        if rounds and played < len(rounds):
            self.alert(
                event, "rounds_played_too_small",
                "回合数 %s 比明细里的 %d 条还少" % (played, len(rounds)),
                severity="CRITICAL",
            )

        result = {
            "won": "我拍到",
            "lost": "他人拍走",
            "quit": "中途退出",
        }.get(str(event.get("result") or ""), str(event.get("result") or "结束"))
        self.write(
            "AUCTION_END 局%s %s 回合=%s 成交=%s 净收益=%s"
            % (
                event.get("auction_no", "—"),
                result,
                played,
                as_int(event.get("final_price")),
                as_int(event.get("net_profit")),
            ),
            echo=True,
        )

    def heartbeat(self):
        if self.console and time.time() - self.last_event_at >= HEARTBEAT_IDLE_SEC:
            active_runs = sum(
                1 for state in self.runs.values()
                if any(not a.get("ended") for a in state["auctions"].values())
            )
            print(
                "%s HEARTBEAT 活跃会话=%d 局=%d 决策=%d 提交=%d 异常=%d"
                % (
                    now_text(), active_runs, self.auction_count,
                    self.decision_count, self.submit_count, self.anomaly_count,
                ),
                flush=True,
            )
            self.last_event_at = time.time()


# ---------- 读记录文件 ----------

def iter_events(path: Path, offset: int):
    """从 offset 开始读新增的完整行（半行留着下次读）。"""
    try:
        stat = path.stat()
    except Exception:
        return offset, []
    if stat.st_size < offset:
        offset = 0
    if stat.st_size <= offset:
        return offset, []
    try:
        with open(path, "rb") as fp:
            fp.seek(offset)
            chunk = fp.read()
    except Exception:
        return offset, []
    if not chunk:
        return offset, []
    last_newline = chunk.rfind(b"\n")
    if last_newline < 0:
        return offset, []
    complete = chunk[: last_newline + 1]
    offset = offset + len(complete)
    events = []
    for raw in complete.splitlines():
        if not raw or not any(token in raw for token in WATCH_TOKENS):
            continue
        try:
            event = json.loads(raw.decode("utf-8", errors="ignore"))
        except Exception:
            continue
        events.append(event)
    return offset, events


def 监控日志(path, stop=None, start_offset=None):
    audit = 出价监控(console=stop is None)
    try:
        offset = start_offset
        if offset is None:
            # 手动运行时补当前局上下文，回放后从最后一条完整记录继续。
            size = path.stat().st_size if path.exists() else 0
            seed_offset = max(0, size - 4 * 1024 * 1024)
            if seed_offset:
                with path.open("rb") as fp:
                    fp.seek(seed_offset - 1)
                    fp.readline()
                    seed_offset = fp.tell()
            offset, seed_events = iter_events(path, seed_offset)
            for event in seed_events:
                audit.consume(event, live=False)
        audit.write(f"READY 监控开始 | event={path} | report={REPORT_PATH}", echo=True)

        while True:
            offset, events = iter_events(path, offset)
            for event in events:
                audit.consume(event, live=True)
            if stop is not None:
                if stop.is_set():
                    break
                stop.wait(1.0)
            else:
                audit.heartbeat()
                time.sleep(1.0)
    finally:
        audit.close()


def 停止旧版监控():
    """退出升级前由旧面板启动、仍在重复读取本目录的独立进程。"""
    try:
        import psutil
    except ImportError:
        return
    script = Path(__file__).resolve()
    updated_at = script.stat().st_mtime
    for process in psutil.process_iter(("name", "cmdline", "create_time")):
        info = process.info
        argv = info["cmdline"] or []
        if len(argv) != 2 or (info["name"] or "").lower() not in ("python.exe", "pythonw.exe"):
            continue
        try:
            candidate = Path(argv[1])
            if (info["create_time"] is not None and info["create_time"] < updated_at
                    and candidate.is_absolute() and candidate.resolve() == script):
                process.terminate()
                print(f"ℹ️ 已停止旧版出价监控（PID {process.pid}）")
        except psutil.NoSuchProcess:
            continue
        except (OSError, psutil.AccessDenied) as exc:
            print(f"⚠️ 停止旧版出价监控失败（PID {process.pid}）：{exc}")


def main(path=EVENT_PATH, stop=None, start_offset=None):
    # Windows 文件锁按记录目录隔离，同一目录的第二个监控退出。
    lock_path = path.parent / "_出价策略监控.lock"
    with lock_path.open("a+b") as lock:
        lock.seek(0)
        try:
            msvcrt.locking(lock.fileno(), msvcrt.LK_NBLCK, 1)
        except OSError as exc:
            if exc.errno != 13:
                raise
            print("ℹ️ 已有出价监控在读取此目录")
            return
        try:
            if stop is not None:
                停止旧版监控()
            监控日志(path, stop, start_offset)
        finally:
            lock.seek(0)
            msvcrt.locking(lock.fileno(), msvcrt.LK_UNLCK, 1)


def 启动出价监控(event_path):
    path = Path(event_path).resolve()
    start_offset = path.stat().st_size if path.exists() else 0
    stop = threading.Event()

    def worker():
        try:
            main(path, stop, start_offset)
        except Exception:
            message = "出价监控运行失败：\n" + traceback.format_exc()
            print(message, flush=True)
            with (path.parent / "出价监控错误.log").open("a", encoding="utf-8") as fp:
                fp.write(f"{now_text()} {message}\n")

    thread = threading.Thread(target=worker, name="出价监控", daemon=True)
    thread.start()

    def finish():
        stop.set()
        thread.join(timeout=2)

    atexit.register(finish)


if __name__ == "__main__":
    main()