# -*- coding: utf-8 -*-
"""版本号、历史更新说明和跨版本升级记录。"""

import json
import os
import re
from pathlib import Path


APP_VERSION = '0.58'
APP_DISPLAY = "大肥鱼standby" + str(APP_VERSION)
RELEASE_NOTES = ['修复鼠标让行误暂停：明显移动或点击其他窗口时暂缓输入，停手后重新识别并继续。',
 '恢复出价前重新核对回合和金额，确认状态不明时避免重复提交。',
 '清仓先扫完整仓，复用未变化页面并合并跨页重复；出售前复核物品和价格，确认全部售出后再一键整理。']
RELEASE_HISTORY = {'0.41beta': ['紧迫危机提速：用场地判定+剩余<16秒三重判断决定节奏；第1回合停等缩短、仪器点击/关页超时压短'],
 '0.42beta': ['修仪器补充流程：剩余数量≥2直接匹配、数量读失败重试、购买/使用后关页面、补全判定放宽、紧迫判定改三重'],
 '0.43beta': ['0.43beta：新增「不进入仓库出售藏品」开关'],
 '0.44beta': ['0.44beta：修复结算≥阈值时仍点红点的矛盾（补 skip_red_dot=True）'],
 '0.45beta': ['0.45beta：修复清仓执行顺序（先卖再出仓库），之前自动清仓卖 0 件'],
 '0.4beta': ['结算完全不再扫仓：对局中识别过就按对局结果判定；没触发过识别也直接判未命中（省 10~20 秒）'],
 '0.51beta': ['慢机器省时模式改为开关直控：开启即跳过查举报/数品质（不再看抓帧速度）'],
 '0.52': ['修复特殊藏品首轮价：不同档位分别首见，第2回合涨到更高档按该档首轮价出（不再误按上一档R2倍率）'],
 '0.53': ['修复清仓到底后空滚；有名字的藏品不再因跨页截断保留（含没勾保留的特殊藏品）'],
 '0.54': ['统计范围新增全部统计',
          'F10/F11/F12全局热键改到面板进程，任意页面都能触发',
          '清理仓库拖到底立即停滚',
          '清理仓库有名字的藏品都会卖（含没勾保留的特殊藏品）',
          '删除守望者/永恒之心/乐园巧克力三档出价改为保留藏品',
          '普通倍率新增两段；保留藏品横排并新增烟云盏/古旧手提箱',
          '在线更新会覆盖ui图片；exe版没有exe地址时自动退回zip更新'],
 '0.5beta': ['R2~R5改为链式：R3=R2价格×倍率，依次类推'],
 '0.55': ['修复结算回合数、最高估价与估价识别日志',
          '出价监控单实例运行，随挂机进程退出',
          '第 3、4 回合估价优先用双帧模板复核，结算金额优先用模板',
          '修正玩家列表等级读取区域，并记录触发开局保底价时的估价倍数'],
 '0.56': ['后台模式新增鼠标让行，入场与出价均等待游戏画面确认',
          '参数草稿可跨筛选保留，整批校验后一次保存',
          '重写关键设置说明，合并仓库视觉开关并整理主题底板',
          '面板后台加载统计，日志按需增量刷新'],
 '0.57': ['恢复原来的面板外观、快捷区和参数布局。',
          '调整高价值藏品设置标题，移除大仓总门槛输入和保留藏品的括号说明。',
          '首次打开更新弹窗时，按升级前版本列出这次跨过的各版说明。',
          '参数区卡片底色随界面透明度变化，高价值藏品分组标题统一为原有样式。'],
 '0.58': ['修复鼠标让行误暂停：明显移动或点击其他窗口时暂缓输入，停手后重新识别并继续。',
          '恢复出价前重新核对回合和金额，确认状态不明时避免重复提交。',
          '清仓先扫完整仓，复用未变化页面并合并跨页重复；出售前复核物品和价格，确认全部售出后再一键整理。']}


def release_order(version):
    """Recognize this project's numeric releases and beta suffixes."""
    match = re.fullmatch(r"[vV]?(\d+)\.(\d+)(?:\.(\d+))?(beta(\d*)?)?",
                         str(version or "").strip(), re.IGNORECASE)
    if not match:
        return None
    major, minor, patch, beta, beta_number = match.groups()
    # 0.4beta / 0.5beta precede the 0.41beta / 0.51beta series.
    series = int(minor) * 10 if major == "0" and len(minor) == 1 and patch is None else int(minor)
    return int(major), series, int(patch or 0), 0 if beta else 1, int(beta_number or 0)


def release_notes_between(previous, current=None):
    current = APP_VERSION if current is None else str(current)
    origin, destination = release_order(previous), release_order(current)
    if destination is None or (origin is not None and origin >= destination):
        return []
    catalog = dict(RELEASE_HISTORY)
    catalog[APP_VERSION] = RELEASE_NOTES
    editions = []
    for version, notes in catalog.items():
        version_key = release_order(version)
        if (version_key is not None and version_key <= destination and notes
                and (origin < version_key if origin is not None else version_key == destination)):
            editions.append((version_key, version, list(notes)))
    return [(version, notes) for _, version, notes in sorted(editions)]


def write_upgrade_origin(path, previous, current):
    origin, destination = release_order(previous), release_order(current)
    if origin is None or destination is None or origin >= destination:
        return
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f"{path.name}.{os.getpid()}.tmp")
    temporary.write_text(json.dumps({"from": str(previous), "to": str(current)},
                                    ensure_ascii=False), encoding="utf-8")
    try:
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def previous_upgrade_version(path, current):
    try:
        record = json.loads(Path(path).read_text(encoding="utf-8"))
        previous = str(record.get("from", ""))
        if (release_order(record.get("to")) == release_order(current)
                and release_order(previous) is not None):
            return previous
    except (OSError, ValueError, AttributeError, TypeError):
        pass
    return ""
