"""下载并应用更新 —— 会改文件的只有这一步，所以每一步都先备份、能还原。

用法：
    python 更新下载.py --apply          下载最新版并覆盖（界面调用这个）
    python 更新下载.py --apply --no-keep 覆盖后把备份删掉（省空间，但出问题没法还原）
    python 更新下载.py --check-only     只下载+校验+解压，不覆盖

设计原则：
  1. 先下载到临时目录，sha256 对不上就不往下走
  2. 解压只允许落在临时目录里（防 zip slip）
  3. 覆盖之前把 程序\\ 整个备份成 程序_备份_<时间戳>\\
  4. 覆盖之后逐个校验关键文件，缺一个就自动还原
  5. 只碰 程序\\ 和 素材\\，绝不碰 python\\、记录\\、参数配置.json

退出码：
    0  成功
    1  网络/清单问题
    2  校验失败（sha256 或包内容不对）
    3  覆盖失败（已经自动还原）
    4  挂机脚本还在运行 → 拒绝更新（什么都没动）
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = HERE
for _d in (HERE, os.path.dirname(HERE)):
    if os.path.isdir(os.path.join(_d, "python")):
        BASE = _d
        break

UPDATE_DIR = os.path.join(BASE, "记录", "更新")
STAGE_DIR = os.path.join(UPDATE_DIR, "staging")
DOWNLOAD_DIR = os.path.join(UPDATE_DIR, "download")

TIMEOUT = 90.0
CHUNK = 256 * 1024
USER_AGENT = "NTE-Updater/1.0 (+anjin-auction)"

# 覆盖之后必须存在的文件；少一个就认为包不完整，直接还原
REQUIRED = (
    os.path.join("程序", "paimai.py"),
    os.path.join("程序", "界面.py"),
    os.path.join("程序", "版本.py"),
)

# 覆盖这三层，别的一个都不许动。（ui 是下拉箭头/开关图片，0.3 那会儿还没有，
# 老用户升级时必须一起带上，否则下拉框没有箭头。）
ALLOWED_TOP = ("程序", "素材", "ui")


def _log(msg):
    print(msg, flush=True)


def _record_upgrade_origin(previous, current):
    try:
        from 版本 import write_upgrade_origin

        write_upgrade_origin(os.path.join(UPDATE_DIR, "升级版本.json"), previous, current)
    except (OSError, ImportError, ValueError) as exc:
        _log(f"⚠️ 无法记录升级前版本，将沿用面板上次记录：{exc}")


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def _inside(root, target):
    """target 是不是真的在 root 里面（防 .. 和绝对路径逃逸）。"""
    root = os.path.abspath(root)
    target = os.path.abspath(target)
    try:
        return os.path.commonpath([root, target]) == root
    except Exception:
        return False


def _rm(path):
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _read_manifest():
    cfg_path = os.path.join(HERE, "更新地址.json")
    if not os.path.isfile(cfg_path):
        return None, "找不到 程序\\更新地址.json"
    try:
        # utf-8-sig：Windows 记事本保存的 JSON 常带 BOM，普通 utf-8 会直接报
        # 「Unexpected UTF-8 BOM」，群友手动改地址就废了。
        with open(cfg_path, encoding="utf-8-sig") as fp:
            cfg = json.load(fp)
        urls = []
        for _k in ("manifest_urls", "manifest_url"):
            _v = cfg.get(_k)
            if isinstance(_v, str) and _v.strip():
                urls.append(_v.strip())
            elif isinstance(_v, (list, tuple)):
                for _x in _v:
                    if isinstance(_x, str) and _x.strip():
                        urls.append(_x.strip())
    except Exception as e:
        return None, f"更新地址.json 读不了：{e}"
    _seen_u = set()
    urls = [u for u in urls if not (u in _seen_u or _seen_u.add(u))]
    if not urls:
        return None, "更新地址.json 里的 manifest_url(s) 是空的"
    url = urls[0]
    data = None
    last_err = ""
    for _u in urls:
        req = urllib.request.Request(_u, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read(1024 * 1024)
        except urllib.error.HTTPError as e:
            last_err = f"清单地址返回 {e.code}（{_u}）"
            continue
        except urllib.error.URLError as e:
            last_err = f"连不上清单地址：{getattr(e, 'reason', e)}（{_u}）"
            continue
        except Exception as e:
            last_err = f"拉清单出错：{e}（{_u}）"
            continue
        try:
            data = json.loads(raw.decode("utf-8-sig"))
        except Exception as e:
            last_err = f"清单不是合法 JSON：{e}（{_u}）"
            data = None
            continue
        if not isinstance(data, dict):
            last_err = f"清单不是键值对（{_u}）"
            data = None
            continue
        break
    if data is None:
        return None, last_err or "拉清单失败"
    if len(urls) > 1:
        _log(f"   （清单有 {len(urls)} 个地址，使用可用的那个）")
    return data, ""


def _probe_one(url, timeout=2.5):
    """探一下这个源通不通、多快。返回 (可不可达, 秒数)。

    只用 HEAD（拿不到就退化成 Range 取 1 字节），不下载整个包。
    """
    import time as _t

    t0 = _t.time()
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=timeout):
            pass
        return True, _t.time() - t0
    except Exception:
        pass
    try:
        req = urllib.request.Request(
            url, headers={"User-Agent": USER_AGENT, "Range": "bytes=0-0"}
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            resp.read(1)
        return True, _t.time() - t0
    except Exception:
        return False, _t.time() - t0


def _order_sources(urls, total_wait=3.0, grace_after_first=0.8):
    """并发测速，快的排前面；测不通的排到最后（探测可能误判，仍会再试一次）。

    这样国内用户自然走 Gitee、海外用户自然走 GitHub，不用查 IP、也不依赖任何外部服务。
    不会死等慢源：只要有一个源测通了，再等 grace 秒就收工，剩下的排后面。
    """
    urls = list(urls)
    if len(urls) <= 1:
        return urls
    import threading
    import time as _t

    results = {}

    def _work(u):
        try:
            results[u] = _probe_one(u)
        except Exception:
            results[u] = (False, 9.99)

    threads = [threading.Thread(target=_work, args=(u,), daemon=True) for u in urls]
    for t in threads:
        t.start()
    t0 = _t.time()
    first_ok_at = None
    while True:
        alive = sum(1 for t in threads if t.is_alive())
        elapsed = _t.time() - t0
        if first_ok_at is None and any(results.get(u, (False,))[0] for u in urls):
            first_ok_at = elapsed
        if alive == 0:
            break
        if first_ok_at is not None and elapsed - first_ok_at > grace_after_first:
            break
        if elapsed > total_wait:
            break
        _t.sleep(0.05)
    good = sorted([u for u in urls if results.get(u, (False,))[0]], key=lambda u: results[u][1])
    bad = [u for u in urls if u not in good]
    try:
        _log("   🔍 测速：" + ("，".join(
            "%s %.0fms" % (u.split("/")[2], results[u][1] * 1000) for u in good
        ) or "没有源响应") + (("；未响应 %d 个（放最后再试）" % len(bad)) if bad else ""))
    except Exception:
        pass
    return good + bad


def _download(url, target, expected_size=0):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    os.makedirs(os.path.dirname(target), exist_ok=True)
    part = target + ".part"
    _rm(part)
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp, open(part, "wb") as fp:
            try:
                _want = int(resp.headers.get("Content-Length") or 0)
            except Exception:
                _want = 0
            if not _want:
                _want = int(expected_size or 0)
            _next_pct = 10
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                fp.write(chunk)
                total += len(chunk)
                if _want:
                    pct = int(total * 100 / _want)
                    if pct >= _next_pct and _next_pct <= 100:
                        _log(f"   … 已下载 {min(pct, 100)}%（{total}/{_want} 字节）")
                        _next_pct = min(100, (pct // 10 + 1) * 10)
        if expected_size and total != expected_size:
            _rm(part)
            return 0, f"文件大小不对：期望 {expected_size} 字节，实际 {total} 字节"
        os.replace(part, target)
        return total, ""
    except urllib.error.HTTPError as e:
        _rm(part)
        return 0, f"下载失败，服务器返回 {e.code}"
    except urllib.error.URLError as e:
        _rm(part)
        return 0, f"下载失败，连不上：{getattr(e, 'reason', e)}"
    except Exception as e:
        _rm(part)
        return 0, f"下载失败：{e}"


def _safe_extract(archive, destination):
    """解压到 destination，任何一条越界的路径都直接拒绝。"""
    _rm(destination)
    os.makedirs(destination, exist_ok=True)
    bad = []
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            name = info.filename
            if name.endswith("/"):
                continue
            target = os.path.join(destination, name)
            if not _inside(destination, target):
                bad.append(name)
    if bad:
        return f"压缩包里有 {len(bad)} 个越界路径，已拒绝解压（比如 {bad[0]}）"
    try:
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(destination)
    except Exception as e:
        return f"解压失败：{e}"
    return ""


def _find_package_root(stage):
    """包内一般是 即可落槌_爱音版\\程序\\...，把那一层找出来。"""
    if os.path.isdir(os.path.join(stage, "程序")):
        return stage
    for name in sorted(os.listdir(stage)):
        cand = os.path.join(stage, name)
        if os.path.isdir(cand) and os.path.isdir(os.path.join(cand, "程序")):
            return cand
    return None


def _copy_tree(src, dst, skip_rel=()):
    """把 src 里的东西覆盖到 dst（按文件覆盖，不删 dst 多出来的旧文件）。

    skip_rel：要跳过的相对路径（统一用 / 分隔），比如用户自己的参数文件 ——
    覆盖更新绝不能把用户改过的参数改回默认值。
    """
    skip = {str(s).replace("\\", "/").strip("/").lower() for s in skip_rel if s}
    count = 0
    skipped = []
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        rel_posix = "" if rel == "." else rel.replace("\\", "/")
        # 顺手跳过解释器缓存
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        target_root = dst if not rel_posix else os.path.join(dst, *rel_posix.split("/"))
        os.makedirs(target_root, exist_ok=True)
        for name in files:
            if name.lower().endswith((".pyc", ".pyo")):
                continue
            file_rel = (rel_posix + "/" + name) if rel_posix else name
            if file_rel.lower() in skip:
                skipped.append(file_rel)
                continue
            s = os.path.join(root, name)
            d = os.path.join(target_root, name)
            try:
                shutil.copy2(s, d)
                count += 1
            except Exception as e:
                raise RuntimeError(f"复制 {name} 失败：{e}")
    if skipped:
        _log("   … 保留用户自己的文件：" + "、".join(sorted(set(skipped))))
    return count


def _bot_processes():
    """正在跑 paimai.py 的进程 pid 列表（更新期间绝不能被覆盖）。

    只认「命令行里作为独立参数出现的 paimai.py」——避免把
    fake_paimai.py、_monitor_paimai.py 这种脚本误判成挂机进程。
    """
    try:
        import psutil
    except Exception:
        return []
    import re as _re

    pat = _re.compile(r"(?:^|[\\/\s\"'])paimai\.py(?:$|[\s\"'])", _re.I)
    me = os.getpid()
    out = []
    try:
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                pid = proc.info.get("pid")
                if pid == me:
                    continue
                name = str(proc.info.get("name") or "").lower()
                if not name.startswith("python"):
                    continue
                cmd = " ".join(proc.info.get("cmdline") or [])
                if pat.search(cmd):
                    out.append(pid)
            except Exception:
                continue
    except Exception:
        return out
    return out


def _exe_mode_path():
    """这次是从单文件 exe 启动的吗？是则返回 exe 路径。"""
    p = (os.environ.get("DFY_EXE_PATH") or "").strip()
    try:
        return p if (p and os.path.isfile(p)) else ""
    except Exception:
        return ""


def _exe_update_dir():
    import os as _os
    d = _os.path.join(_os.environ.get("DFY_DATA_ROOT") or r"C:\大肥鱼standby", "_update")
    _os.makedirs(d, exist_ok=True)
    return d


def apply_exe_update():
    """单文件 exe 模式：下载新 exe → 批处理替换自己 → 3 秒后自动重启。

    返回 (成功与否, 人话说明, 退出码)，和 apply_update 一致。
    """
    exe = _exe_mode_path()
    if not exe:
        return False, "不是 exe 启动，走普通更新。", 9
    data, err = _read_manifest()
    if err:
        return False, err, 1
    remote = str(data.get("version") or "").strip()
    urls = []
    for _k in ("exe_urls", "exe_url", "package_urls", "package_url"):
        _v = data.get(_k)
        if isinstance(_v, str) and _v.strip().lower().endswith(".exe"):
            urls.append(_v.strip())
        elif isinstance(_v, (list, tuple)):
            for _x in _v:
                if isinstance(_x, str) and _x.strip().lower().endswith(".exe"):
                    urls.append(_x.strip())
    if not urls:
        # 退出码 8 = "没有 exe 地址"，交给 apply_update 退回 zip 更新（不改 exe 外壳）
        return False, "清单里没有 .exe 下载地址（exe 版需要 exe_url / exe_urls）。", 8
    try:
        from 版本 import APP_VERSION
    except Exception:
        APP_VERSION = "?"
    if remote and str(remote) == str(APP_VERSION):
        return True, "已经是最新版本（%s）。" % APP_VERSION, 0
    want_sha = str(data.get("exe_sha256") or data.get("sha256") or "").strip().upper()
    dst = os.path.join(_exe_update_dir(), "大肥鱼standby_new.exe")
    last = ""
    ok = False
    for url in urls:
        try:
            _download(url, dst, 0)
            if want_sha and _sha256(dst).upper() != want_sha:
                last = "校验失败"
                continue
            ok = True
            break
        except Exception as exc:
            last = str(exc)
            continue
    if not ok:
        return False, "新 exe 下载失败：%s" % (last or "未知原因"), 2
    bat = os.path.join(_exe_update_dir(), "_swap.bat")
    try:
        _panel_pid = int(os.getppid() or 0)
    except Exception:
        _panel_pid = 0
    body = (
        "@echo off\r\n"
        "chcp 65001 >nul\r\n"
        "timeout /t 3 /nobreak >nul\r\n"
        + (("taskkill /f /pid %d >nul 2>&1\r\n" % _panel_pid) if _panel_pid else "")
        + "timeout /t 2 /nobreak >nul\r\n"
        "for /l %%i in (1,1,20) do (\r\n"
        "  move /y \"%s\" \"%s\" >nul 2>&1 && goto DONE\r\n"
        "  timeout /t 1 /nobreak >nul\r\n"
        ")\r\n"
        "exit /b 1\r\n"
        ":DONE\r\n"
        "start \"\" \"%s\"\r\n"
        "del \"%%~f0\"\r\n"
    ) % (dst, exe, exe)
    try:
        with io.open(bat, "w", encoding="utf-8", newline="") as fh:
            fh.write(body)
        _record_upgrade_origin(APP_VERSION, remote)
        subprocess.Popen(["cmd", "/c", bat],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                         close_fds=True)
    except Exception as exc:
        return False, "替换脚本启动失败：%s" % exc, 3
    return (True,
            "新版本 %s 已下载，3 秒后自动替换并重启面板（若杀毒拦了替换，手动运行 %s）。"
            % (remote or "?", bat), 0)


def apply_update(keep_backup=True):
    """返回 (成功与否, 人话说明, 退出码)。"""
    if _exe_mode_path():
        _ok, _msg, _code = apply_exe_update()
        if _code != 8:
            return _ok, _msg, _code
        # 清单没给 exe 下载地址（GitHub raw 放不下 388MB 的 exe）→ 退回用 zip
        # 更新 _app 里的 程序/素材/ui：代码照样升到新版，只是 exe 外壳不换。
        print("ℹ️ 清单里没有 exe 地址，改用 zip 更新程序文件（exe 外壳保持不变）…")
    # 硬闸门：挂机进程还在跑就绝不覆盖（否则会把正在读取的 .py 换掉）
    _running = _bot_processes()
    if _running:
        return (
            False,
            "挂机脚本还在运行（进程 %s），不能更新。\n\n"
            "请先在面板点【⏹ 彻底关掉脚本】，等挂机窗口消失、"
            "确认没有 paimai 进程之后再点更新。\n"
            "（现在什么都没动，随时可以重试）" % "、".join(str(p) for p in _running),
            4,
        )

    data, err = _read_manifest()
    if err:
        return False, err, 1

    remote = str(data.get("version") or "").strip()
    # 支持多个下载源：package_urls（数组，按顺序回退）优先，其次 package_url
    _pkg_list = []
    for _key in ("package_urls", "package_url"):
        _v = data.get(_key)
        if isinstance(_v, str) and _v.strip():
            _pkg_list.append(_v.strip())
        elif isinstance(_v, (list, tuple)):
            for _x in _v:
                if isinstance(_x, str) and _x.strip():
                    _pkg_list.append(_x.strip())
    _seen_pkg = set()
    _pkg_list = [p for p in _pkg_list if not (p in _seen_pkg or _seen_pkg.add(p))]
    want_sha = str(data.get("sha256") or "").strip().upper()
    want_size = int(data.get("size") or 0)

    if not _pkg_list:
        return False, "清单里没有 package_url —— 作者还没把安装包传上去", 1
    for _p in _pkg_list:
        if not _p.lower().startswith(("http://", "https://")):
            return False, f"下载地址不是 http(s)：{_p}", 1

    try:
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        from 版本 import APP_VERSION

        local = str(APP_VERSION)
    except Exception:
        local = "?"

    _log(f"📦 准备更新：v{local} → v{remote or '?'}")
    if len(_pkg_list) > 1:
        _log(f"   共 {len(_pkg_list)} 个下载源，先测速选最快的，失败自动换下一个")
        _pkg_list = _order_sources(_pkg_list)

    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    zip_path = os.path.join(DOWNLOAD_DIR, "update.zip")
    _log("⬇️ 正在下载…")
    _ok_dl = False
    _last_err = ""
    for _idx, _pkg in enumerate(_pkg_list, 1):
        _log(f"   源 {_idx}/{len(_pkg_list)}：{_pkg}")
        size, err = _download(_pkg, zip_path, want_size)
        if err:
            _last_err = err
            _log(f"   ❌ {err}")
            continue
        if want_sha:
            _log("🔐 校验 sha256…")
            got = _sha256(zip_path)
            if got != want_sha:
                _last_err = (
                    "下载的文件和清单里记的 sha256 对不上（这个源的文件可能没传完整）。\n"
                    f"清单：{want_sha}\n实际：{got}"
                )
                _rm(zip_path)
                _log("   ❌ sha256 对不上，换下一个源")
                continue
            _log("   sha256 一致")
        else:
            _log("   ⚠️ 清单里没写 sha256，跳过校验")
        _ok_dl = True
        break
    if not _ok_dl:
        return False, "所有下载源都失败了。\n\n最后一个错误：" + (_last_err or "未知"), 1
    _log(f"   下载完成，{size} 字节")

    _log("📂 解压…")
    err = _safe_extract(zip_path, STAGE_DIR)
    if err:
        return False, err, 2

    root = _find_package_root(STAGE_DIR)
    if root is None:
        return False, "压缩包里找不到「程序」文件夹，这不像是个更新包", 2
    for rel in REQUIRED:
        if not os.path.isfile(os.path.join(root, rel)):
            return False, f"更新包里缺少 {rel}，包不完整，没敢覆盖", 2
    _log("   包内容检查通过")

    # 覆盖前再查一次：下载/解压这几十秒里用户可能又把挂机开起来了
    _running2 = _bot_processes()
    if _running2:
        _rm(STAGE_DIR)
        _rm(zip_path)
        return (
            False,
            "准备覆盖时发现挂机脚本又跑起来了（进程 %s），已中止，什么都没改。\n\n"
            "请先【⏹ 彻底关掉脚本】再重试更新。" % "、".join(str(p) for p in _running2),
            4,
        )

    # ---- 备份 ----
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backups = []
    for top in ALLOWED_TOP:
        src = os.path.join(BASE, top)
        if not os.path.isdir(src):
            continue
        if top != "程序":
            continue  # 素材太大，不备份；坏了重下全包
        dst = os.path.join(BASE, f"{top}_备份_{stamp}")
        _log(f"💾 备份 {top} → {os.path.basename(dst)}")
        try:
            # 跳过 __pycache__ 和 .pyc：那是解释器缓存，删了会自己重建，
            # 而且正在被占用时 copytree 会抛 WinError 5，把整个备份搞失败。
            shutil.copytree(
                src,
                dst,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
            )
            backups.append((dst, src))
        except Exception as e:
            _rm(dst)  # 别留半截备份目录
            return False, f"备份 {top} 失败，为了安全没敢动文件：{e}", 3

    # ---- 覆盖 ----
    try:
        for top in ALLOWED_TOP:
            src = os.path.join(root, top)
            if not os.path.isdir(src):
                continue
            dst = os.path.join(BASE, top)
            # 用户的参数文件必须留存：包里的 参数配置.json 只是默认值
            _skip = ("参数配置.json",) if top == "程序" else ()
            n = _copy_tree(src, dst, skip_rel=_skip)
            _log(f"✅ {top}：覆盖了 {n} 个文件")
    except Exception as e:
        _log(f"❌ 覆盖出错：{e}，正在还原…")
        ok_restore, why = _restore(backups)
        if ok_restore:
            return False, f"覆盖失败（{e}），已经还原到更新前的状态。", 3
        return False, f"覆盖失败（{e}），还原也失败了：{why}\n请手动把 {backups[0][0]} 改回 程序 目录。", 3

    # ---- 覆盖后自检 ----
    missing = [rel for rel in REQUIRED if not os.path.isfile(os.path.join(BASE, rel))]
    if missing:
        _log(f"❌ 覆盖后缺少 {missing}，正在还原…")
        ok_restore, why = _restore(backups)
        if ok_restore:
            return False, f"覆盖完发现缺少 {missing[0]}，已经还原。", 3
        return False, f"覆盖完缺少 {missing[0]}，还原也失败了：{why}", 3

    if not keep_backup:
        for dst, _src in backups:
            _rm(dst)

    _rm(STAGE_DIR)
    _rm(zip_path)

    try:
        # utf-8-sig：万一 版本.py 被人用记事本另存过带了 BOM，
        # 第一行就不是以 APP_VERSION 开头了，这里统一吃掉 BOM。
        with open(os.path.join(BASE, "程序", "版本.py"), encoding="utf-8-sig") as fp:
            new_ver = fp.read()
        for line in new_ver.splitlines():
            if line.startswith("APP_VERSION"):
                new_ver = line.split("=", 1)[1].split("#")[0].strip().strip('"').strip("'")
                break
    except Exception:
        new_ver = remote or "?"

    _record_upgrade_origin(local, new_ver)
    keep = [os.path.basename(d) for d, _s in backups]
    tip = f"\n旧版本备份在：{', '.join(keep)}（确认没问题可以删掉）" if keep else ""
    return True, f"v{local} → v{new_ver} 更新完成。\n重启面板后生效。{tip}", 0


def _restore(backups):
    try:
        for dst, src in backups:
            if os.path.isdir(src):
                shutil.rmtree(src, ignore_errors=True)
            if os.path.isdir(dst):
                shutil.copytree(dst, src)
        return True, ""
    except Exception as e:
        return False, str(e)


def main(argv):
    apply = "--apply" in argv
    check_only = "--check-only" in argv
    # 默认保留备份：更新出问题时要能一键还原。
    # 以前这里写反了（不传 --keep 就把备份删掉），等于「以为有备份，其实没有」。
    keep_backup = "--no-keep" not in argv

    if not apply and not check_only:
        print(__doc__)
        return 0

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if check_only:
        data, err = _read_manifest()
        if err:
            print(f"❌ {err}")
            return 1
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    ok, msg, code = apply_update(keep_backup=keep_backup)
    print(("✅ " if ok else "❌ ") + msg)
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
