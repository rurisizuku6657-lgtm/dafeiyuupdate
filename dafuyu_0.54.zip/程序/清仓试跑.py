# -*- coding: utf-8 -*-
"""清仓试跑（干跑）：只扫描整仓 + 出「卖/留」计划，不点任何东西。

用法：
    1. 游戏停在【藏品仓库】页（不是拍卖大厅）
    2. 双击本文件（或 v3\python\python.exe 清仓试跑.py）
    3. 结果写到 记录\日志\<日期>\清仓调试\清仓计划_*.json，并在控制台打印摘要

判定规则（和面板上 10 个「保留藏品」开关对应）：
    · 认不出名字 / 被截断 / 只露出一部分 → 一律保留
    · 名字命中某个打开了的「保留」档位 → 保留
    · 其余进出售计划（真卖时会逐件点开，弹窗价值 < AUTO_CLEAN_MAX_VALUE 才卖）
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import paimai  # noqa: E402

if __name__ == "__main__":
    print("=" * 60)
    print("清仓试跑（干跑：只出计划，不会卖任何东西）")
    print("=" * 60)
    plan = paimai.清仓_扫描并出计划(dry_run=True)
    if plan:
        print("-" * 60)
        print(
            "合计：认出 %d 块 → 计划卖 %d 件 / 保留 %d 件"
            % (plan["total_blocks"], plan["sell_count"], plan["keep_count"])
        )
        print("保留名单：%s" % ("、".join(plan["keep_names"]) or "（空）"))
    else:
        print("没拿到计划（看上面的报错）")
    try:
        input("\n按回车退出…")
    except Exception:
        pass