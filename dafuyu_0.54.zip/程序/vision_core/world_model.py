# -*- coding: utf-8 -*-
"""世界模型：把多次识别（不同滚动位置、不同回合）累积成一份 10x25 的箱子已知信息。
规则：
  1. 被截断(truncated)的物品不采用其尺寸，但会留作“占位”，等完整出现后再替换；
  2. 同一绝对位置(x,y,w,h)重复识别 -> 取信息更完整/分数更高的一次（颜色 < 具体物品）；
  3. 新识别到的完整物品与旧记录重叠 -> 旧占位会被替换；但低分碎片不能覆盖
     另一页已经完整识别出的高置信大件；
  4. 信息只升不降：已识别出的具体物品不会被后来一次识别失败(item=None)覆盖。
  5. 跨页拼接：一个大件正好被两页的接缝切开(第1页只看到上半、第2页只看到下半，哪一页都不完整)时，
     把“上半(下边被截)”和“下半(上边被截)”按位置接起来，得到完整的位置和高度；
     颜色和形状已知，物品库里该形状只有一种物品时直接认出是哪一件。
"""


def _overlap(a, b):
    return not (a['x'] + a['w'] <= b['x'] or b['x'] + b['w'] <= a['x'] or
                a['y'] + a['h'] <= b['y'] or b['y'] + b['h'] <= a['y'])


def _area(row):
    return max(1, int(row.get('w') or 1)) * max(
        1, int(row.get('h') or 1)
    )


def _strong_complete_item(row):
    return bool(
        row.get('item')
        and not row.get('partial')
        and not row.get('no_shape')
        and float(row.get('score') or 0.0) >= 0.85
    )


class WorldModel:
    def __init__(self):
        self.items = []          # list[dict]
        self.trunc = []          # 被页缝截断的观察：dict(x,y,w,h,color,cut)，用于跨页拼接

    def clear(self):
        self.items = []
        self.trunc = []

    def export_state(self):
        """Return a JSON-safe snapshot of the cross-round recognition state."""
        return {
            "items": [dict(item) for item in self.items],
            "trunc": [dict(item) for item in self.trunc],
        }

    def restore_state(self, state):
        """Restore a snapshot produced by export_state()."""
        if not isinstance(state, dict):
            return False
        try:
            self.items = [
                dict(item) for item in (state.get("items") or [])
                if isinstance(item, dict)
            ]
            self.trunc = [
                dict(item) for item in (state.get("trunc") or [])
                if isinstance(item, dict)
            ]
            return True
        except Exception:
            self.clear()
            return False

    def _remember_trunc(self, r):
        o = dict(x=r.x, y=r.y, w=r.w, h=r.h, color=r.color, cut=r.cut)
        self.trunc = [t for t in self.trunc if not (t['x'] == o['x'] and t['w'] == o['w'] and t['cut'] == o['cut']
                                                    and t['color'] == o['color'] and _overlap(t, o))]
        self.trunc.append(o)

    def _stitch(self, db):
        """把“下边被截”(第1页，已知真实顶边) 和 “上边被截”(第2页，已知真实底边) 的两半拼成完整物品。"""
        if db is None or not self.trunc:
            return False
        changed = False
        tops = [t for t in self.trunc if t['cut'] == 'bottom']       # 下半没看到 -> 上半
        bots = [t for t in self.trunc if t['cut'] == 'top']          # 上半没看到 -> 下半
        for a in tops:
            for b in bots:
                if a['x'] != b['x'] or a['w'] != b['w'] or a['color'] != b['color']:
                    continue
                top, bottom = a['y'], b['y'] + b['h']
                if not (a['y'] <= b['y'] <= a['y'] + a['h'] and bottom > a['y'] + a['h']):
                    continue                       # 两半必须在行上接得上(接触或重叠)，且下半要真的往下延伸
                h = bottom - top
                cands = db.candidates(a['color'], a['w'], h)
                if not cands:
                    continue                       # 拼出来的形状在物品库里不存在 -> 不可信
                new = dict(x=a['x'], y=top, w=a['w'], h=h, color=a['color'],
                           item=cands[0].name if len(cands) == 1 else None,
                           score=0.5 if len(cands) == 1 else 0.0, partial=len(cands) == 1,
                           no_shape=False, template_attempted=False,
                           candidate_count=len(cands), second_score=0.0)
                olds = [o for o in self.items if _overlap(o, new)]
                if any(o['item'] and not o.get('partial') for o in olds):
                    continue                       # 那里已经有完整识别出的物品，不覆盖
                for o in olds:
                    self.items.remove(o)
                self.items.append(new)
                self.trunc = [t for t in self.trunc if t is not a and t is not b]
                changed = True
                break
        return changed

    def update(self, recognized, db=None):
        """recognized: list[RecognizedItem]。返回 True 表示模型有变化。db 用于跨页拼接时校验形状。"""
        changed = False
        for r in recognized:
            if r.truncated:
                if r.color and r.cut in ('top', 'bottom'):
                    self._remember_trunc(r)
                continue        # 形状不可信，等下次滚动到完整可见时再记录
            new = dict(
                x=r.x, y=r.y, w=r.w, h=r.h, color=r.color,
                item=r.item_name, score=r.score, partial=r.partial,
                no_shape=r.no_shape,
                template_attempted=bool(r.template_attempted),
                candidate_count=int(r.candidate_count or 0),
                second_score=float(r.second_score or 0.0),
                click_x=int(getattr(r, "click_x", 0) or 0),
                click_y=int(getattr(r, "click_y", 0) or 0),
                source_page=int(getattr(r, "source_page", -1)),
            )
            same = [o for o in self.items if (o['x'], o['y'], o['w'], o['h']) == (new['x'], new['y'], new['w'], new['h'])]
            if same:
                o = same[0]
                # 完整匹配永远优先于局部匹配；同类匹配则要明显更高分才替换，避免来回抖动
                better = (not o['item']) or (o.get('partial') and not new['partial']) or \
                         (bool(o.get('partial')) == bool(new['partial']) and new['score'] > o['score'] + 0.05)
                if new['item'] and better and not (new['partial'] and o['item'] and not o.get('partial')):
                    o.update(
                        item=new['item'], score=new['score'],
                        color=new['color'], partial=new['partial'],
                        no_shape=False,
                        template_attempted=new['template_attempted'],
                        candidate_count=new['candidate_count'],
                        second_score=new['second_score'],
                        click_x=new['click_x'],
                        click_y=new['click_y'],
                        source_page=new['source_page'],
                    )
                    changed = True
                elif o.get('no_shape') and not new['no_shape']:
                    o['no_shape'] = False
                    o['template_attempted'] = new['template_attempted']
                    o['candidate_count'] = new['candidate_count']
                    o['second_score'] = new['second_score']
                    o['click_x'] = new['click_x']
                    o['click_y'] = new['click_y']
                    o['source_page'] = new['source_page']
                    changed = True   # 从“仅知道位置/颜色”升级为“形状已确认”
                elif new['color'] is not None and o['color'] != new['color'] and not o['item']:
                    o['color'] = new['color']
                    o['template_attempted'] = new['template_attempted']
                    o['candidate_count'] = new['candidate_count']
                    o['second_score'] = new['second_score']
                    o['click_x'] = new['click_x']
                    o['click_y'] = new['click_y']
                    o['source_page'] = new['source_page']
                    changed = True
                continue
            # 与旧记录部分重叠：认为新的更准确（完整揭示）-> 替换
            olds = [o for o in self.items if _overlap(o, new)]
            protected = [
                old for old in olds
                if (
                    _strong_complete_item(old)
                    and _area(old) >= _area(new)
                    and float(new.get('score') or 0.0)
                    < float(old.get('score') or 0.0) - 0.15
                )
            ]
            if protected:
                # A low-confidence fragment from a shifted page must not erase
                # a larger, high-confidence item seen completely on another page.
                continue
            for o in olds:
                self.items.remove(o)
            self.items.append(new)
            changed = True
        # 新出现的完整物品覆盖了的截断观察不再需要
        self.trunc = [t for t in self.trunc if not any(_overlap(o, t) and not o.get('partial') and o['item'] for o in self.items)]
        if self._stitch(db):
            changed = True
        return changed

    def export(self):
        """导出给计算器 gpImportRects 的列表。"""
        return [dict(
                    x=o['x'], y=o['y'], w=o['w'], h=o['h'],
                    color=o['color'], item=o['item'],
                    noShape=o.get('no_shape', False),
                    score=float(o.get('score') or 0.0),
                    secondScore=float(o.get('second_score') or 0.0),
                    templateAttempted=bool(o.get('template_attempted', False)),
                    candidateCount=int(o.get('candidate_count') or 0),
                    click_x=int(o.get('click_x') or 0),
                    click_y=int(o.get('click_y') or 0),
                    source_page=int(o.get('source_page', -1)),
                )
                for o in sorted(self.items, key=lambda o: (o['y'], o['x']))]
