# -*- coding: utf-8 -*-
"""
即刻落槌 - 箱子物品识别核心引擎
不依赖 GUI / 截屏 / 热键，纯粹的"给一张 1920x1080 截图 -> 输出识别到的物品列表"的逻辑。
方便单独测试、单独复用。
"""
import os
import re
import json
import math
import colorsys
from dataclasses import dataclass

import numpy as np
from PIL import Image
import cv2
try:
    import openpyxl            # 只用来读 items.xlsx；没装也能运行（改读 items_cache.json）
except ImportError:
    openpyxl = None

# ------------------------------------------------------------------
# 基准分辨率下的网格标定参数（1920x1080 全屏）
# ------------------------------------------------------------------
BASE_W, BASE_H = 1920, 1080
GRID_ORIGIN_X = 1313.86    # 网格左上角 x（最小二乘拟合值）
GRID_ORIGIN_Y = 212.25     # 网格左上角 y（最小二乘拟合值）
CELL_SIZE = 56.29          # 每个格子边长（像素，最小二乘拟合值）
COLS = 10                  # 箱子宽度（列数），与计算器 COLS 常量一致
TOTAL_ROWS = 25            # 箱子高度（行数），与计算器 ROWS 常量一致
VIEW_ROWS = 10             # 客户端一次最多显示多少行（可视窗口）

DARK_THRESH = 45            # 判定"格子分隔线/未揭示"的暗度阈值（0-255，取三通道最大值）


# ------------------------------------------------------------------
# 颜色（稀有度）分类：根据背景色的 HSV 判断白/绿/蓝/紫/金/红
# 这些阈值是从实际截图里量出来的，如果游戏更新美术风格需要重新采样校准。
# ------------------------------------------------------------------

def classify_color(rgb):
    r, g, b = [c / 255.0 for c in rgb]
    h, s, v = colorsys.rgb_to_hsv(r, g, b)
    h_deg = h * 360.0
    # 灰色轮廓框（只揭示形状）的填充色约 59/255 (v≈0.23)，边缘更亮 (77~114)。
    # 小框的采样点会碰到亮边缘所以能过 v>=0.30，但 4x4/4x5/5x5 的大框采样点全落在填充区，
    # 以前被下面的“太暗”提前判成空格而整块丢失。所以低饱和的灰色要先于“太暗”判断。
    if s < 0.15 and 0.20 <= v < 0.30:
        return "轮廓"
    if v < 0.30:
        return None          # 太暗：未揭示格/空格
    if s < 0.15:
        # 白色物品卡片边缘亮度约 134~149；只揭示了形状的“灰色轮廓框”约 86~101，明显更暗
        return "白色" if v >= 0.45 else ("轮廓" if v >= 0.20 else None)
    if s < 0.55:
        return None          # 半透明背景透出的杂色（如空格里透出的红绒绳），不是稀有度卡片
    if 70 <= h_deg <= 145:
        return "绿色"
    if 170 <= h_deg <= 235:
        return "蓝色"
    if 255 <= h_deg <= 315:
        return "紫色"
    if 18 <= h_deg <= 60:
        return "金色"
    if (h_deg >= 330 or h_deg <= 8) and s > 0.75:
        return "红色"
    return None




# ------------------------------------------------------------------
# 物品数据库：从 Excel 读取 颜色/类型/名称/价格/尺寸，并关联模板图标
# ------------------------------------------------------------------


@dataclass
class ItemDef:
    name: str
    color: str
    category: str
    price: float
    w: int
    h: int
    template_path: str = None
    template_rgba: np.ndarray = None  # BGRA, uint8
    template_cell: float = 56.29      # 这张模板所属分辨率文件夹对应的“格子原始边长”(1080p=56.29；1440p/2160p 按比例放大)


def match_color(color):
    """识别用的“卡片颜色”。特殊红色(碧波天垂/超级储存盘/Pendragon模型/金锦鲤雕像/翠刃/夜光杯)的卡片底色
    和普通红色一样，画面里分不出来，所以识别时把它们当作普通红色：和红色物品一起参与模板匹配；
    识别结果的 color 仍是“红色”，具体是哪件由物品名决定（计算器按物品名判定是否特殊红色）。"""
    return "红色" if color == "特殊红色" else color


def parse_set_base(name):
    """从模板文件夹名里读出它的分辨率基准（界面高度，像素）；读不出返回 None。支持：
      1440p / 1600P / 1440p备用 / 我的_900p     -> 名字里写的“数字+p”
      2560x1440 / 3440*1440 / 2560×1440          -> 宽x高，按界面缩放 1080*min(宽/1920,高/1080) 换算（超宽屏按高度算）
      2k / 4k / 8k                                -> 1440 / 2160 / 4320
      1080（整个名字就是一个 3~4 位数字）          -> 当作高度"""
    n = str(name).strip().lower()
    base = None
    m = re.search(r'(?<!\d)(\d{3,5})\s*[x×*]\s*(\d{3,5})(?!\d)', n)
    if m:
        w, h = int(m.group(1)), int(m.group(2))
        base = int(round(1080.0 * min(w / 1920.0, h / 1080.0)))
    if base is None:
        m = re.search(r'(?<!\d)(\d{3,4})\s*p(?![a-z])', n)
        if m:
            base = int(m.group(1))
    if base is None:
        m = re.search(r'(?<![\da-z])([248])\s*k(?![a-z])', n)
        if m:
            base = {2: 1440, 4: 2160, 8: 4320}[int(m.group(1))]
    if base is None and re.fullmatch(r'\d{3,4}', n):
        base = int(n)
    return base if base and 240 <= base <= 8640 else None


class ItemDatabase:
    def __init__(self, excel_path, templates_dir):
        self.items = []          # list[ItemDef]
        self.by_color_size = {}  # (color, w, h) -> list[ItemDef]
        self._load_excel(excel_path)
        self._load_templates(templates_dir)

    def _load_excel(self, excel_path):
        """优先读 items.xlsx（需要 openpyxl），并顺手刷新 items_cache.json；
        没装 openpyxl 或 xlsx 读不了时，读 items_cache.json（和 xlsx 同目录）。"""
        cache_path = os.path.join(os.path.dirname(excel_path), "items_cache.json")
        rows = None
        if openpyxl is not None and os.path.exists(excel_path):
            try:
                wb = openpyxl.load_workbook(excel_path, data_only=True)
                rows = [list(r[:5]) for r in wb.active.iter_rows(min_row=2, values_only=True)]
                try:
                    with open(cache_path, "w", encoding="utf-8") as f:
                        json.dump(rows, f, ensure_ascii=False)
                except OSError:
                    pass
            except Exception as e:
                print("读取 items.xlsx 失败（%s），改用 items_cache.json" % e)
        if rows is None:
            if not os.path.exists(cache_path):
                raise RuntimeError("读不到物品表：请安装 openpyxl（python -m pip install openpyxl），或补上 items_cache.json")
            if (os.path.exists(excel_path) and os.path.getmtime(excel_path) > os.path.getmtime(cache_path) + 1):
                print("[提示] items.xlsx 比 items_cache.json 新，但没装 openpyxl，仍在使用旧缓存；"
                      "安装 openpyxl 后物品表修改才会生效。")
            with open(cache_path, encoding="utf-8") as f:
                rows = json.load(f)
        for row in rows:
            if not row or len(row) < 5 or not row[2]:
                continue
            color, cat, name, price, sizestr = row[:5]
            if not sizestr:
                continue
            name = str(name).strip()
            sizestr = str(sizestr).strip()
            try:
                w_s, h_s = sizestr.lower().split("x")
                w, h = int(w_s), int(h_s)
            except Exception:
                continue
            it = ItemDef(name=name, color=str(color).strip(), category=str(cat).strip(),
                         price=float(price) if price is not None else 0.0, w=w, h=h)
            self.items.append(it)

    def _load_templates(self, templates_dir):
        """模板按“分辨率文件夹”存放：templates/1080p、templates/1440p、templates/2160p（文件夹名=这批模板的分辨率基准，
        即游戏界面高度为这个像素数时图标的原始大小）。每个文件夹里：模板文件名全部用 ASCII（t000.png…），
        物品名放在该文件夹的 manifest.json 里，避免 Windows 解压 zip 时中文文件名乱码导致一张模板都读不到。
        兼容旧版：templates 根目录下直接放的 png 视为 1080p。
        这里只“发现”各文件夹里有哪些模板；真正生效的是 use_set() 选中的那一套（识别前由引擎按游戏分辨率选择）。"""
        self.template_sets = {}      # 文件夹名 -> {"base": 界面高度, "files": {物品名: 路径}}
        self._img_cache = {}
        self.active_set = None
        self.active_info = (0, 0)    # (取自所选文件夹的张数, 缺失而借用其它文件夹缩放的张数)
        self.n_templates = 0
        name_to_item = {it.name: it for it in self.items}
        for it in self.items:
            self.by_color_size.setdefault((match_color(it.color), it.w, it.h), []).append(it)
        if not os.path.isdir(templates_dir):
            return

        def scan(folder):
            manifest = {}
            mp = os.path.join(folder, "manifest.json")
            if os.path.exists(mp):
                try:
                    manifest = json.load(open(mp, encoding="utf-8"))
                except Exception:
                    manifest = {}
            files = {}
            for fname in sorted(os.listdir(folder)):
                if not fname.lower().endswith(".png"):
                    continue
                item_name = manifest.get(fname, fname[:-4])
                if item_name in name_to_item:
                    files[item_name] = os.path.join(folder, fname)
            return files

        self.ignored_dirs = []       # 里面有模板、但文件夹名里读不出分辨率的文件夹
        for sub in sorted(os.listdir(templates_dir)):
            full = os.path.join(templates_dir, sub)
            if not os.path.isdir(full):
                continue
            base = parse_set_base(sub)
            if base:
                self.template_sets[sub.lower()] = {"base": base, "files": scan(full), "dir": sub}
            elif any(f.lower().endswith(".png") for f in os.listdir(full)):
                self.ignored_dirs.append(sub)
        legacy = scan(templates_dir)                       # 旧版：根目录直接放 png => 1080p
        if legacy:
            s = self.template_sets.setdefault("1080p", {"base": 1080, "files": {}, "dir": "(templates 根目录)"})
            for k, v in legacy.items():
                s["files"].setdefault(k, v)
        default = self.pick_set(1080)
        if default:
            self.use_set(default)

    def set_counts(self):
        """{文件夹名: 模板张数}，按分辨率从小到大。"""
        return {n: len(s["files"]) for n, s in sorted(self.template_sets.items(), key=lambda kv: kv[1]["base"])}

    def ideal_set(self, equiv_h):
        """最接近 equiv_h 的模板文件夹（不管里面有没有模板）。按“比例”比远近：1800 离 2160 比离 1440 近。"""
        c = [(abs(math.log(s["base"] / float(equiv_h))), s["base"], n) for n, s in self.template_sets.items()]
        return min(c)[2] if c else None

    def pick_set(self, equiv_h):
        """最接近 equiv_h 且里面确实有模板的文件夹；都没有模板返回 None。"""
        c = [(abs(math.log(s["base"] / float(equiv_h))), s["base"], n) for n, s in self.template_sets.items() if s["files"]]
        return min(c)[2] if c else None

    def _read_template(self, path):
        img = self._img_cache.get(path)
        if img is None:
            img = cv2.imdecode(np.fromfile(path, dtype=np.uint8), cv2.IMREAD_UNCHANGED)  # BGRA（兼容中文路径）
            if img is None:
                return None
            if img.ndim == 2:
                img = cv2.cvtColor(img, cv2.COLOR_GRAY2BGRA)
            elif img.shape[2] == 3:
                img = np.dstack([img, np.full(img.shape[:2], 255, dtype=np.uint8)])
            self._img_cache[path] = img
        return img

    def use_set(self, name):
        """切换到某个分辨率文件夹的模板。该文件夹里缺的物品，改用其它文件夹里最接近的那套（识别时按各自的基准缩放），
        所以文件夹没放全/是空的也不会让识别变差到完全认不出。"""
        if name not in self.template_sets:
            return False
        base = self.template_sets[name]["base"]
        order = sorted(((abs(math.log(s["base"] / float(base))), s["base"], n)
                        for n, s in self.template_sets.items() if s["files"]))
        order = [n for _, _, n in order]
        if name in order:
            order.remove(name)
            order.insert(0, name)
        own = borrowed = 0
        for it in self.items:
            it.template_rgba = None
            it.template_path = None
            it.template_cell = NATIVE_CELL
            for sname in order:
                p = self.template_sets[sname]["files"].get(it.name)
                if not p:
                    continue
                img = self._read_template(p)
                if img is None:
                    continue
                it.template_path = p
                it.template_rgba = img
                it.template_cell = NATIVE_CELL * self.template_sets[sname]["base"] / 1080.0
                if self.template_sets[sname]["base"] == base:
                    own += 1
                else:
                    borrowed += 1
                break
        self.active_set = name
        self.active_info = (own, borrowed)
        self.n_templates = own + borrowed
        return True

    def candidates(self, color, w, h):
        return [it for it in self.by_color_size.get((color, w, h), []) if it.template_rgba is not None]

    def candidates_by_size(self, w, h):
        """All templates with one shape, regardless of a failed color read."""
        return [
            it for it in self.items
            if it.w == w and it.h == h and it.template_rgba is not None
        ]

    def candidates_all_sizes(self, color):
        return [it for it in self.items if match_color(it.color) == color and it.template_rgba is not None]


# ------------------------------------------------------------------
# 网格分割：基于"分隔线"而不是通用连通域，避免图标内部深色像素干扰
# ------------------------------------------------------------------
@dataclass
class Region:
    col: int
    row: int          # 相对当前可视窗口的行号（0..VIEW_ROWS-1）
    w: int
    h: int
    px0: int
    py0: int
    px1: int
    py1: int




# ------------------------------------------------------------------
# 网格自动标定 / 逐帧微调
# 原理：卡片之间有一条很窄的暗缝，整个网格的暗缝构成间距为 cell_size 的“梳子”。
#       把画面里每一列/每一行的“暗度”累加成一维曲线，再用 11 齿的梳子去套，
#       梳齿处越暗、齿间(格子内部)越亮，得分越高 —— 得分最高的 (起点, 格子边长) 就是真实网格。
# 这样不管分辨率/宽高比/小数边长(比如 74.86)，都不用手改常量；单格边长差 1% 也能自己拟合出来。
# ------------------------------------------------------------------
_DARK_SOFT = 70.0


def _dark_map(rgb):
    m = rgb.max(axis=2).astype(np.float32)
    return np.clip((_DARK_SOFT - m) / _DARK_SOFT, 0.0, 1.0)


def _bright_maps(rgb, cs=75.0):
    """HDR / 压暗画面：空格子比格线还暗，格线反而是一条“亮细线”。这里按 横/竖 各做一次“细亮线”顶帽响应
    (像素比左右两侧 k 像素处的均值亮多少)，和暗线地图一起参与标定。返回 (竖线响应图, 横线响应图)，值域 0..1。"""
    m = rgb.max(axis=2).astype(np.float32)
    k = max(3, int(round(0.07 * cs)))
    bx = np.zeros_like(m); by = np.zeros_like(m)
    bx[:, k:-k] = m[:, k:-k] - 0.5 * (m[:, :-2 * k] + m[:, 2 * k:])
    by[k:-k, :] = m[k:-k, :] - 0.5 * (m[:-2 * k, :] + m[2 * k:, :])
    return np.clip(bx / 40.0, 0.0, 1.0), np.clip(by / 40.0, 0.0, 1.0)


def _comb_scores(profile, x0s, cs, n_lines=11, pen_lo=1.0, pen_hi=0.0):
    """profile: 一维暗度曲线；x0s: 一组候选起点；返回每个起点的梳子得分。
    梳子整体平移一格得分几乎不变(周期性歧义)，所以对“网格外侧紧挨着的那一条线”扣分：
    真实网格的外面不应该还有一条同样的格缝。pen_lo=起点前一条线的扣分权重，pen_hi=终点后一条线的权重。"""
    n = len(profile)
    x0s = np.asarray(x0s, dtype=np.float64)
    ks = np.arange(-1, n_lines + 1, dtype=np.float64) * cs
    centers = x0s[:, None] + ks[None, :]
    inside = 0.32 * cs

    def at(idx):
        i = np.clip(np.round(idx).astype(np.int64), 0, n - 1)
        return profile[i]

    line = np.maximum.reduce([at(centers - 1), at(centers), at(centers + 1)])
    side = 0.5 * (at(centers - inside) + at(centers + inside))
    contrib = np.maximum(line - side, 0.0)
    ok = (centers >= 1) & (centers <= n - 2)
    contrib = contrib * ok
    return contrib[:, 1:-1].sum(axis=1) - pen_lo * contrib[:, 0] - pen_hi * contrib[:, -1]


def _fit_axis(profile, x0_prior, cs_prior, cs_rel, shift, cs_step_rel=0.0015, n_lines=11, px_step=0.5, pen_hi=0.0):
    """围绕先验搜索 (起点, 边长)。以网格中心为锚，避免边长变化时两端互相拖累。
    返回 {cs: (best_x0, best_score)} 以便两条轴共用同一个边长。"""
    out = {}
    half = (n_lines - 1) / 2.0
    xc = x0_prior + half * cs_prior
    rels = np.arange(-cs_rel, cs_rel + 1e-9, cs_step_rel)
    dxs = np.arange(-shift, shift + 1e-9, px_step)
    for rel in rels:
        cs = cs_prior * (1.0 + rel)
        x0s = xc + dxs - half * cs
        sc = _comb_scores(profile, x0s, cs, n_lines, pen_hi=pen_hi)
        j = int(np.argmax(sc))
        out[round(float(cs), 4)] = (float(x0s[j]), float(sc[j]))
    return out


def fit_grid(dk, ox, oy, cs, cs_rel=0.012, shift_x=3.0, shift_y=3.0, fit_y=True, rows=VIEW_ROWS, cols=COLS, iters=2):
    """在先验 (ox, oy, cs) 附近拟合真实网格。dk: _dark_map 的结果(整幅画面)。
    fit_y=False(滚动到中间、行相位未知)时只用竖线拟合 x 与边长，y 保持先验。
    返回 (ox, oy, cs, score)。"""
    dkx, dky = dk if isinstance(dk, tuple) else (dk, dk)
    H, W = dkx.shape
    cur_ox, cur_oy, cur_cs = float(ox), float(oy), float(cs)
    score = 0.0
    for _ in range(iters):
        ya = int(max(0, round(cur_oy - 0.1 * cur_cs))); yb = int(min(H, round(cur_oy + (rows + 0.1) * cur_cs)))
        xa = int(max(0, round(cur_ox - 0.1 * cur_cs))); xb = int(min(W, round(cur_ox + (cols + 0.1) * cur_cs)))
        if yb - ya < 4 or xb - xa < 4:
            return cur_ox, cur_oy, cur_cs, 0.0
        P = dkx[ya:yb, :].mean(axis=0)
        fx = _fit_axis(P, cur_ox, cur_cs, cs_rel, shift_x, n_lines=cols + 1, pen_hi=1.0)   # 右侧是滚动条，不该再有格缝
        if fit_y:
            Q = dky[:, xa:xb].mean(axis=1)
            fy = _fit_axis(Q, cur_oy, cur_cs, cs_rel, shift_y, n_lines=rows + 1)
            best = max(fx, key=lambda c: fx[c][1] + fy.get(c, (0, 0))[1])
            cur_oy = fy[best][0]
            score = fx[best][1] + fy[best][1]
        else:
            best = max(fx, key=lambda c: fx[c][1])
            score = fx[best][1]
        cur_ox, cur_cs = fx[best][0], best
    return cur_ox, cur_oy, cur_cs, score


def candidate_layouts(w, h):
    """没有任何历史信息时，按“游戏界面的缩放方式”猜几种可能的 (ox, oy, cs)。
    1920x1080 的基准标定值乘以不同的缩放/对齐方式：拉伸、按宽等比、按高等比，居中或贴顶。"""
    sx, sy = w / BASE_W, h / BASE_H
    c = []
    c.append((GRID_ORIGIN_X * sx, GRID_ORIGIN_Y * sy, CELL_SIZE * (sx + sy) / 2.0))        # 两个方向各自拉伸(旧算法)
    for s in sorted({sx, sy, min(sx, sy)}):
        tx_c = (w - BASE_W * s) / 2.0
        ty_c = (h - BASE_H * s) / 2.0
        tx_r, ty_b = w - BASE_W * s, h - BASE_H * s           # 贴右/贴底：超宽窗口里仓库网格贴右边(实测 1792x762)，中央文字却是居中的
        for tx, ty in ((tx_c, ty_c), (tx_c, 0.0), (0.0, ty_c), (0.0, 0.0), (tx_r, ty_c), (tx_r, 0.0), (tx_r, ty_b), (tx_c, ty_b)):
            c.append((tx + GRID_ORIGIN_X * s, ty + GRID_ORIGIN_Y * s, CELL_SIZE * s))
    uniq = []
    for ox, oy, cs in c:
        if not any(abs(ox - u[0]) < 2 and abs(oy - u[1]) < 2 and abs(cs - u[2]) < 0.3 for u in uniq):
            uniq.append((ox, oy, cs))
    return uniq


CALIB_CONFIDENT = 3.8      # 标定得分达到这个值认为可信（正确网格约 5~6；错位半格约 2~3；乱猜<1.2）


def _grid_quality(img, db, fit):
    """拿一个候选网格真的跑一遍识别：正确的网格能认出很多具体物品；错位一行的网格只会得到一堆认不出的碎块。"""
    try:
        res, _ = recognize_frame(img, db, grid=(fit["ox"], fit["oy"], fit["cs"]), refine=False)
    except Exception:
        return -1.0
    return sum(1.0 + r.score for r in res if r.item_name and not r.truncated)


def calibrate_grid(pil_or_rgb, db=None):
    """从一张“第1段/第3段”截图自动标定网格。返回 dict(ox, oy, cs, score, scale, confident, mode) 或 None。
    scale = cs / 基准边长，即界面相对 1920x1080 的缩放倍数；用它可以把 1080p 基准坐标(滚轮点/去勾点)换算到屏幕。
    两阶段：① 先在各种已知缩放方式(拉伸/按宽/按高、居中/贴顶)预测的位置附近小范围精调，得分够高就采用；
            ② 预测都不准(窗口化、特殊布局)才放大搜索范围——放大后整体平移一格的歧义更多，所以放在后面。
    格缝梳子对“整体错一行”不敏感(16:10 的上下黑边恰好约一行，居中/贴顶两种候选得分相近)，
    传入 db 时，得分接近的几个候选会真的跑一遍识别，选认出具体物品最多的那个。"""
    img = pil_or_rgb if hasattr(pil_or_rgb, "convert") else Image.fromarray(pil_or_rgb)
    rgb = np.array(img.convert("RGB"))
    H, W = rgb.shape[:2]
    dk = _dark_map(rgb)
    priors = candidate_layouts(W, H)

    def pack(fit, mode):
        ox_, oy_, cs_, sc_ = fit
        return dict(ox=ox_, oy=oy_, cs=cs_, score=sc_, scale=cs_ / CELL_SIZE, confident=sc_ >= CALIB_CONFIDENT, mode=mode)

    def pick(fits):
        fits = sorted(fits, key=lambda f: -f["score"])
        if not fits:
            return None
        top = fits[0]
        if db is None:
            return top
        contenders = [top]
        for f in fits[1:]:
            if f["score"] >= 0.8 * top["score"] and all(abs(f["oy"] - c["oy"]) > 0.3 * top["cs"] or abs(f["ox"] - c["ox"]) > 0.3 * top["cs"]
                                                          for c in contenders):
                contenders.append(f)
        if len(contenders) == 1:
            return top
        return max(contenders[:4], key=lambda f: (_grid_quality(img, db, f), f["score"]))

    # 两种极性：暗线(正常画面，格缝比卡片暗) 和 亮线(HDR/压暗画面，空格子比格线还暗)。
    # 亮线得分量级约为暗线的 2.6 倍，乘 BRIGHT_SCALE 归一后可与 CALIB_CONFIDENT 直接比较。
    BRIGHT_SCALE = 0.38
    br = _bright_maps(rgb, CELL_SIZE * (W / BASE_W + H / BASE_H) / 2.0)
    polarities = [(dk, 1.0, "dark"), (br, BRIGHT_SCALE, "bright")]

    def run(maps, k, tag, wide_stage):
        out = []
        for ox, oy, cs in priors:
            if not wide_stage:
                f = fit_grid(maps, ox, oy, cs, cs_rel=0.025, shift_x=0.1 * cs, shift_y=0.1 * cs, iters=2)
            else:
                f = fit_grid(maps, ox, oy, cs, cs_rel=0.06, shift_x=0.6 * cs, shift_y=0.6 * cs, iters=3)
                f = fit_grid(maps, f[0], f[1], f[2], cs_rel=0.012, shift_x=3.0, shift_y=3.0, iters=2)
            d = pack((f[0], f[1], f[2], f[3] * k), tag if not wide_stage else "wide-" + tag)
            # 离先验越远越可疑：偏离 >0.15 格(宽搜索里很常见的“错位一格”歧义)按比例扣分，
            # 正确网格几乎总是落在“按分辨率缩放的基准标定值”附近。
            dev = max(abs(f[0] - ox), abs(f[1] - oy)) / cs
            if dev > 0.15:
                d["score"] *= max(0.3, 1.0 - 1.2 * (dev - 0.15))
                d["confident"] = d["score"] >= CALIB_CONFIDENT
            out.append(d)
        return out

    fits = []
    for maps, k, tag in polarities:
        fits += run(maps, k, tag, False)
    best = pick(fits)
    if best and best["confident"]:
        return best
    wide = []
    for maps, k, tag in polarities:
        wide += run(maps, k, tag, True)
    return pick(fits + wide)


def estimate_vertical_shift(view_rgb, cell_size, cols=COLS, rows=VIEW_ROWS, origin_x=0):
    """连续滚动时，网格线相对可视窗口顶部会上移 shift 像素（0<=shift<cell_size）。
    通过统计每个 y 上“暗线像素”的数量，找使各水平网格线处暗像素总和最大的相位。"""
    H = view_rgb.shape[0]
    x0 = int(origin_x); x1 = int(origin_x + cols * cell_size)
    dark = (view_rgb[:, x0:x1].max(axis=2) < DARK_THRESH).sum(axis=1).astype(np.float64)
    def score_at(sh):
        tot = 0.0
        for k in range(0, rows + 1):
            y = int(round(k * cell_size - sh))
            if 2 <= y < H - 2:
                tot += dark[y - 1:y + 2].sum()
        return tot
    s0 = score_at(0.0)
    best, best_s = 0.0, s0
    for sh10 in range(5, int(cell_size * 10)):
        sh = sh10 / 10.0
        sc = score_at(sh)
        if sc > best_s * 1.08:      # 必须明显优于“无偏移”才认定有偏移，避免稀疏网格误判
            best_s, best = sc, sh
    if best > cell_size - 2.0:
        best = 0.0
    return 0.0 if best < 2.0 else best


def segment_grid(view_rgb, cell_size=CELL_SIZE, cols=COLS, rows=VIEW_ROWS,
                 origin_x=0, origin_y=0):
    """view_rgb: 只包含网格可视窗口(高约 rows*cell_size)的画面；origin_y 通常为 -shift(<=0)。
    返回 Region 列表；row 为相对窗口的行号（0 行可能只露出一部分；如果 shift>0 会有 rows+1 行）。"""
    arr = view_rgb.astype(np.int32)
    H, W = arr.shape[:2]
    nrows = rows + (1 if origin_y < -1.5 else 0)

    def row_top(r): return origin_y + r * cell_size

    def dark_ratio(pts):
        pts = [(x, y) for (x, y) in pts if 0 <= x < W and 0 <= y < H]
        if not pts:
            return 0.0
        return sum(1 for (x, y) in pts if arr[y, x].max() < DARK_THRESH) / len(pts)

    # ---- “图标内部大片黑色”防误判（例如液晶视屏的黑屏）----
    # 真正的分隔线是两个卡片之间一条很窄的暗缝：缝的至少一侧是卡片底色(亮)。
    # 如果一条“暗线”两侧各 ~0.18 格远的地方也都是暗的，说明它不是缝，而是一大块深色图标内部，不能当墙。
    # （相邻的两个空白暗格因此会被合并成一个暗区域，但暗区域的颜色判定为“无”，识别时会被直接跳过，没有副作用。）
    # 分隔线搜索半宽：网格起点/边长有几像素偏差时，两个相邻物品之间那条只有 2~3px 的暗缝会落在 ±2px 之外而漏检，
    # 漏检的墙会把相邻物品连成非矩形的组，整组被打散成 1x1（例如灰色 3x1 被切成 3 个）。
    # 所以按格子大小放宽到约 ±0.12 格（47px 的格子≈±6px，56px≈±7px）。
    WALL_SEARCH = max(2, int(round(cell_size * 0.12)))
    side_d = max(6, int(round(cell_size * 0.18)))
    SIDE_DARK = 0.6

    def inside_dark_blob(mk_a, mk_b):
        # mk_a/mk_b(d)：生成“距分隔线 d 像素”的探测点。每一侧在三个相邻距离(相差3px)上都要暗，才算“大片深色图标内部”。
        # 只探一个距离会被图标边缘/卡片内框那种 2px 宽的深色细线骗过(网格偏 1~2px 时刚好踩上)，
        # 把真正的分隔线误当“图标内部的黑”抹掉，导致物品和下面/旁边的空格并成一块而丢失。
        offs = (side_d - 3, side_d, side_d + 3)
        return all(dark_ratio(mk_a(d)) >= SIDE_DARK and dark_ratio(mk_b(d)) >= SIDE_DARK for d in offs)

    vwalls, hwalls = {}, {}
    for r in range(nrows):
        y0 = int(max(0, row_top(r)) + 8); y1 = int(min(H, row_top(r + 1)) - 8)
        if y1 <= y0:
            y0, y1 = int(max(0, row_top(r))), int(min(H, row_top(r + 1)))
        for c in range(1, cols):
            x = int(round(origin_x + c * cell_size))
            # 在 ±2px 范围内逐列检查，只要有一列(=分隔线中心线)几乎全暗，就认为有墙；
            # 比“三列平均”更耐亚像素偏移（连续滚动/分辨率缩放时线的位置会落在小数像素上）
            ratios_v = [dark_ratio([(xx, y) for y in range(y0, y1, 2)]) for xx in range(x - WALL_SEARCH, x + WALL_SEARCH + 1)]
            # 真实的分隔线在附近5列里通常不止1列很暗；如果只有孤零零1列暗，可能只是图标内部的
            # 一条深色细节（比如黑色主机、阴影）恰好落在格线位置，要求更苛刻的暗度才采信，
            # 减少这类“误判分隔线→把一个大物品切成好几块”的情况。
            vwalls[(r, c)] = (sum(x_ > 0.6 for x_ in ratios_v) >= 2) or (max(ratios_v) > 0.92)
            if vwalls[(r, c)] and inside_dark_blob(lambda d: [(x - d, y) for y in range(y0, y1, 2)],
                                                   lambda d: [(x + d, y) for y in range(y0, y1, 2)]):
                vwalls[(r, c)] = False
    for c in range(cols):
        x0 = int(origin_x + c * cell_size) + 8; x1 = int(origin_x + (c + 1) * cell_size) - 8
        for r in range(1, nrows):
            y = int(round(row_top(r)))
            ratios_h = [dark_ratio([(x, yy) for x in range(x0, x1, 2)]) for yy in range(y - WALL_SEARCH, y + WALL_SEARCH + 1)]
            hwalls[(r, c)] = (sum(x_ > 0.6 for x_ in ratios_h) >= 2) or (max(ratios_h) > 0.92)
            if hwalls[(r, c)] and inside_dark_blob(lambda d: [(x_, y - d) for x_ in range(x0, x1, 2)],
                                                   lambda d: [(x_, y + d) for x_ in range(x0, x1, 2)]):
                hwalls[(r, c)] = False

    parent = {(r, c): (r, c) for r in range(nrows) for c in range(cols)}

    def find(a):
        while parent[a] != a:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra != rb:
            parent[ra] = rb

    # ---- 空格判定：整格(内缩 EMPTY_INSET px)几乎全暗 = 没有卡片 ----
    # 关键修复：空格永远不与非空格合并。以前如果卡片某一侧的分隔线因网格偏差几像素而漏检，
    # 卡片会和旁边一大片相邻空白暗格连成一个非矩形的组，最后整组被打散成 n 个 1x1。
    # （周围塞满物品时没有大片空白暗区，所以几乎不触发；周围空旷时概率明显上升。）
    EMPTY_INSET = max(4, int(round(cell_size * 0.09)))
    empty = {}
    for r in range(nrows):
        for c in range(cols):
            ya = int(max(0, row_top(r)) + EMPTY_INSET); yb = int(min(H, row_top(r + 1)) - EMPTY_INSET)
            xa = int(origin_x + c * cell_size) + EMPTY_INSET; xb = int(origin_x + (c + 1) * cell_size) - EMPTY_INSET
            if yb - ya < 4 or xb - xa < 4:
                empty[(r, c)] = False      # 被视窗边缘截得太窄，无法判断，按原有墙判定处理
                continue
            patch = arr[ya:yb:2, xa:xb:2].max(axis=2)
            # A real empty tile can still contain a few bright anti-aliased
            # pixels from the neighbouring card border.  At 98.5% those tiles
            # remained "occupied", joined the item above, and changed a 1x3
            # item into a different 1x4 template.  Fully dark empty cells sit
            # near 100%, while real card interiors are far below 90%.
            empty[(r, c)] = float((patch < DARK_THRESH).mean()) >= 0.90

    # ---- 被卡片完全包围的暗区 = 卡片内部(例如液晶视屏的黑屏)，不是空格 ----
    # 上面“空格不与非空格合并”会把卡片中央的纯黑格误当空格而把大件切碎。
    # 找出相连的“空格”暗区；若它四周(上下左右邻格)全都在视窗内且全是非空格，则它被卡片包住，
    # 改按非空格处理，由分隔线(墙)决定是否合并。贴着视窗边缘/箱子边界/其它空格的暗区保持原判。
    seen = set()
    for r0 in range(nrows):
        for c0 in range(cols):
            if not empty[(r0, c0)] or (r0, c0) in seen:
                continue
            comp, stack, enclosed = [], [(r0, c0)], True
            seen.add((r0, c0))
            while stack:
                r, c = stack.pop()
                comp.append((r, c))
                for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    rr, cc = r + dr, c + dc
                    if not (0 <= rr < nrows and 0 <= cc < cols):
                        enclosed = False       # 贴着边界：可能只是箱子空位
                    elif empty[(rr, cc)]:
                        if (rr, cc) not in seen:
                            seen.add((rr, cc)); stack.append((rr, cc))
            if enclosed and len(comp) <= 6:
                for k in comp:
                    empty[k] = False

    for r in range(nrows):
        for c in range(1, cols):
            if empty[(r, c - 1)] != empty[(r, c)]:
                continue
            if not vwalls[(r, c)]:
                union((r, c - 1), (r, c))
    for r in range(1, nrows):
        for c in range(cols):
            if empty[(r - 1, c)] != empty[(r, c)]:
                continue
            if not hwalls[(r, c)]:
                union((r - 1, c), (r, c))

    groups = {}
    for r in range(nrows):
        for c in range(cols):
            groups.setdefault(find((r, c)), []).append((r, c))

    def mk(x0, y0, w, h):
        px0 = int(round(origin_x + x0 * cell_size)); px1 = int(round(origin_x + (x0 + w) * cell_size))
        py0 = int(round(row_top(y0))); py1 = int(round(row_top(y0 + h)))
        return Region(x0, y0, w, h, px0, max(0, py0), px1, min(H, py1))

    regions = []
    for cells in groups.values():
        rs = [c[0] for c in cells]; cs_ = [c[1] for c in cells]
        y0, y1, x0, x1 = min(rs), max(rs), min(cs_), max(cs_)
        w, h = x1 - x0 + 1, y1 - y0 + 1
        if w * h != len(cells):
            for (rr, cc) in cells:
                regions.append(mk(cc, rr, 1, 1))
        else:
            regions.append(mk(x0, y0, w, h))
    return regions


def perimeter_median_color(rgb_arr, px0, py0, px1, py1, inset=6, step=4):
    H, W = rgb_arr.shape[:2]
    px0 = max(0, px0); py0 = max(0, py0)
    px1 = min(W - 1, px1); py1 = min(H - 1, py1)
    pts = []
    for x in range(px0, px1, step):
        yy0 = min(py0 + inset, py1 - 1)
        yy1 = max(py1 - inset, py0 + 1)
        pts.append(rgb_arr[yy0, x])
        pts.append(rgb_arr[yy1, x])
    for y in range(py0, py1, step):
        xx0 = min(px0 + inset, px1 - 1)
        xx1 = max(px1 - inset, px0 + 1)
        pts.append(rgb_arr[y, xx0])
        pts.append(rgb_arr[y, xx1])
    if not pts:
        return (0, 0, 0)
    pts = np.array(pts)
    return tuple(np.median(pts, axis=0).astype(int))


GLINT_RING_WIDTH = 3        # 闪光边缘出现在格子内侧 3px 以内
GLINT_BRIGHT_THRESH = 215   # 边缘环上像素亮度(RGB最大通道)超过这个值才算闪光的一部分
GLINT_MIN_PIXELS = 40       # 边缘环上至少要有这么多够亮的像素，才认定真的有闪光（避免单个噪点像素误判）


def has_glint_edge(rgb_arr, px0, py0, px1, py1):
    """检测 1x1 格子内侧 3px 的边缘环上，是否存在“颜色确定+形状确定”时特有的、
    随时间绕格子旋转的高亮边缘（同色调但明显更亮，接近甚至达到 255）。
    只用于区分：① 颜色和形状都确定的 1x1 物品（有这个高亮边缘）
             ② 只知道颜色、不知道形状的 1x1 位置标记（没有这个边缘，只是纯色方块）。
    做法：亮度阈值定得比正常卡片渐变边缘的亮度上限（实测约 170）明显高（195），
    且要求达到阈值的像素数量足够多（15个以上），排除偶发的单点噪声/压缩伪影。"""
    H, W = rgb_arr.shape[:2]
    x0, y0 = max(0, px0), max(0, py0)
    x1, y1 = min(W, px1), min(H, py1)
    if x1 - x0 < 6 or y1 - y0 < 6:
        return False
    w_ = GLINT_RING_WIDTH
    count = 0
    for y in range(y0, y1):
        d_row = min(y - y0, y1 - 1 - y)
        for x in range(x0, x1):
            d_col = min(x - x0, x1 - 1 - x)
            if min(d_row, d_col) < w_:
                if int(rgb_arr[y, x].max()) > GLINT_BRIGHT_THRESH:
                    count += 1
                    if count >= GLINT_MIN_PIXELS:
                        return True
    return False


def region_has_icon_art(rgb_arr, px0, py0, px1, py1, inset=10):
    """粗略判断这一块区域内是不是画了完整图标（而不是纯色/带渐变的空卡片）。
    用局部颜色方差来判断：图标通常有更丰富的色彩/纹理。"""
    H, W = rgb_arr.shape[:2]
    x0 = max(0, px0 + inset); y0 = max(0, py0 + inset)
    x1 = min(W, px1 - inset); y1 = min(H, py1 - inset)
    if x1 <= x0 or y1 <= y0:
        return False
    patch = rgb_arr[y0:y1, x0:x1].astype(np.float32)
    std = patch.reshape(-1, 3).std(axis=0).mean()
    return std > 18.0  # 经验阈值，纯色渐变卡片 std 明显更低


def _masked_ncc(patch_bgr, tmpl_bgr, mask_bool):
    """手写的“遮罩归一化互相关”：只在模板非透明像素（mask_bool=True）的位置比较，
    并且把 B/G/R 三个通道拼在一起统一去均值、统一归一化，
    这样图标的“形状 + 配色”会一起参与打分，比 OpenCV 自带的 TM_CCOEFF_NORMED
    （官方文档说明其实不完整支持 mask）更适合小图标这种颜色占比重的场景。"""
    if mask_bool.sum() < 8:
        return -1.0
    p = patch_bgr[mask_bool].astype(np.float64).reshape(-1)
    t = tmpl_bgr[mask_bool].astype(np.float64).reshape(-1)
    p = p - p.mean()
    t = t - t.mean()
    denom = np.sqrt((p * p).sum() * (t * t).sum())
    if denom < 1e-6:
        return -1.0
    return float((p * t).sum() / denom)


def _hue_hist_similarity(patch_bgr, tmpl_bgr, mask_u8):
    """色相直方图相似度，作为形状匹配之外的辅助信号（对小图标尤其有帮助）。"""
    try:
        p_hsv = cv2.cvtColor(patch_bgr, cv2.COLOR_BGR2HSV)
        t_hsv = cv2.cvtColor(tmpl_bgr, cv2.COLOR_BGR2HSV)
        hp = cv2.calcHist([p_hsv], [0], mask_u8, [24], [0, 180])
        ht = cv2.calcHist([t_hsv], [0], mask_u8, [24], [0, 180])
        cv2.normalize(hp, hp)
        cv2.normalize(ht, ht)
        return float(cv2.compareHist(hp, ht, cv2.HISTCMP_CORREL))
    except cv2.error:
        return 0.0


ICON_SCALES = (1.0,)          # 实验用：相对“模板原始像素尺寸”的缩放倍率候选
NATIVE_CELL = 56.29           # 模板是在 1080p 下截取的，原始像素尺寸 = 屏幕上实际显示尺寸


def _prep_template(it, scale):
    """把模板缩放到“屏幕上实际显示的大小”。
    关键点：模板原图比 w*格子边长 略小（如 1x1 图标 52px，而格子 56px），
    游戏里图标是居中显示、四周留白的。之前把模板拉伸到整格大小，
    1x1 小图标会被放大约 8%，与真实画面对不上——这正是小图标识别率低的主因。"""
    t = it.template_rgba
    th0, tw0 = t.shape[:2]
    tw = max(4, int(round(tw0 * scale))); th = max(4, int(round(th0 * scale)))
    if (tw, th) == (tw0, th0):
        tb, ta = t[:, :, :3], t[:, :, 3]
    else:
        tb = cv2.resize(t[:, :, :3], (tw, th), interpolation=cv2.INTER_AREA)
        ta = cv2.resize(t[:, :, 3], (tw, th), interpolation=cv2.INTER_AREA)
    return tb, ta, tw, th


def match_item(rgb_arr, px0, py0, px1, py1, candidates, min_score=0.40,
               cell_size=CELL_SIZE, search_radius=3, pad=6, scales=None):
    """在候选物品模板中找最相似的一个。candidates: list[ItemDef]（已按颜色+尺寸过滤）。
    打分 = 0.75 * 遮罩归一化互相关(颜色+形状) + 0.25 * 色相直方图相似度；
    模板按屏幕实际显示尺寸(原图像素 * 分辨率缩放)居中摆放，并允许小范围平移 / 微缩放搜索。
    返回 (ItemDef|None, 最佳分数, 第二名分数)"""
    if not candidates:
        return None, 0.0, -1.0
    H, W = rgb_arr.shape[:2]
    x0, y0 = max(0, px0 - pad), max(0, py0 - pad)
    x1, y1 = min(W, px1 + pad), min(H, py1 + pad)
    roi = rgb_arr[y0:y1, x0:x1]
    if roi.size == 0:
        return None, 0.0, -1.0
    roi_bgr = cv2.cvtColor(roi.astype(np.uint8), cv2.COLOR_RGB2BGR)
    roi_h, roi_w = roi_bgr.shape[:2]
    # 区域在 ROI 中的位置（用于居中）
    cx = ((px0 + px1) / 2.0) - x0
    cy = ((py0 + py1) / 2.0) - y0

    scores = []
    for it in candidates:
        local_best = -1.0
        res_scale = cell_size / (getattr(it, 'template_cell', None) or NATIVE_CELL)   # 模板所属文件夹的基准不同(1080p/1440p/2160p)，缩放也不同
        for sc in (scales or ICON_SCALES):
            tb, ta, tw, th = _prep_template(it, res_scale * sc)
            mask_bool = ta > 200
            if mask_bool.sum() < 8:
                continue
            mask_u8 = mask_bool.astype(np.uint8) * 255
            base_x = int(round(cx - tw / 2.0)); base_y = int(round(cy - th / 2.0))
            for dy in range(-search_radius, search_radius + 1):
                for dx in range(-search_radius, search_radius + 1):
                    sx, sy = base_x + dx, base_y + dy
                    if sx < 0 or sy < 0 or sx + tw > roi_w or sy + th > roi_h:
                        continue
                    patch = roi_bgr[sy:sy + th, sx:sx + tw]
                    ncc = _masked_ncc(patch, tb, mask_bool)
                    if ncc < local_best - 0.15:
                        continue
                    score = 0.75 * ncc + 0.25 * _hue_hist_similarity(patch, tb, mask_u8)
                    if score > local_best:
                        local_best = score
        scores.append((local_best, it))
    scores.sort(key=lambda p: -p[0])
    best_score, best_item = scores[0]
    second = scores[1][0] if len(scores) > 1 else -1.0
    if best_score >= min_score:
        return best_item, best_score, second
    return None, best_score, second


OUTLINE_TEMPLATE_MIN_SCORE = 0.72
OUTLINE_TEMPLATE_MIN_MARGIN = 0.025
FULL_TEMPLATE_OVERRIDE_MARGIN = 0.05


def choose_unknown_shape_match(outline_obj, outline_score, outline_second,
                               full_obj, full_score, full_second):
    """Choose between the strict outline match and the full-icon fallback.

    The outline pass uses a higher threshold and requires a minimum margin, so
    it remains the safer default.  The full-icon pass may only replace it when
    the same-size candidate scores clearly better; otherwise a merely accepted
    low-threshold full match could silently overwrite a stronger outline match.
    """
    if full_obj is None:
        return outline_obj, outline_score, outline_second
    if outline_obj is None:
        return full_obj, full_score, full_second
    if full_score >= outline_score + FULL_TEMPLATE_OVERRIDE_MARGIN:
        return full_obj, full_score, full_second
    return outline_obj, outline_score, outline_second


def match_outline_item(rgb_arr, reg, candidates, cell_size,
                       min_score=OUTLINE_TEMPLATE_MIN_SCORE,
                       min_margin=OUTLINE_TEMPLATE_MIN_MARGIN):
    """Recover a revealed item when only its grey outline was detected.

    Colour detection is intentionally conservative, but a fully revealed large
    item can have a grey perimeter while its icon is still unambiguous.  Match
    only within the already-detected shape.  Correctness takes priority over a
    hard candidate cap; the largest same-size pool is still finite and the
    stricter score/margin keeps colour-only cards from being guessed.
    """
    candidates = list(candidates or [])
    if not candidates:
        return None, 0.0, -1.0
    obj, score, second = match_item(
        rgb_arr, reg.px0, reg.py0, reg.px1, reg.py1, candidates,
        min_score=min_score, cell_size=cell_size,
    )
    if obj is None:
        return None, score, second
    if len(candidates) > 1 and second >= 0 and score - second < float(min_margin):
        return None, score, second
    return obj, score, second


# ------------------------------------------------------------------
# 被视窗边缘截断的物品：用物品库反推完整形状
# ------------------------------------------------------------------
@dataclass
class CompleteRegionMatch:
    item_name: str = None
    score: float = 0.0
    color: str = None
    second_score: float = -1.0
    candidate_count: int = 0
    template_attempted: bool = False


def match_complete_icon_region(rgb_arr, reg, db, min_match_score=0.60,
                               cell_size=CELL_SIZE):
    """Match one fully visible icon with the normal full candidate database."""
    if not region_has_icon_art(
        rgb_arr, reg.px0, reg.py0, reg.px1, reg.py1
    ):
        return CompleteRegionMatch()
    color = classify_color(perimeter_median_color(
        rgb_arr, reg.px0, reg.py0, reg.px1, reg.py1
    ))

    if color is None or color == "轮廓":
        candidates = db.candidates_by_size(reg.w, reg.h)
        outline_obj, outline_score, outline_second = match_outline_item(
            rgb_arr, reg, candidates, cell_size
        )
        full_obj = None
        full_score = 0.0
        full_second = -1.0
        if reg.w * reg.h >= 4:
            full_obj, full_score, full_second = match_item(
                rgb_arr, reg.px0, reg.py0, reg.px1, reg.py1,
                candidates, min_score=min_match_score, cell_size=cell_size,
            )
        chosen, score, second = choose_unknown_shape_match(
            outline_obj, outline_score, outline_second,
            full_obj, full_score, full_second,
        )
        return CompleteRegionMatch(
            item_name=chosen.name if chosen is not None else None,
            score=score,
            color=match_color(chosen.color) if chosen is not None else color,
            second_score=second,
            candidate_count=len(candidates),
            template_attempted=True,
        )

    exact_candidates = db.candidates(color, reg.w, reg.h)
    obj, exact_score, exact_second = match_item(
        rgb_arr, reg.px0, reg.py0, reg.px1, reg.py1,
        exact_candidates, min_score=min_match_score, cell_size=cell_size,
    )
    exact_ids = {id(item) for item in exact_candidates}
    fallback_candidates = [
        item for item in db.candidates_by_size(reg.w, reg.h)
        if id(item) not in exact_ids
    ]
    outline_obj, outline_score, outline_second = match_outline_item(
        rgb_arr, reg, fallback_candidates, cell_size
    )
    score = max(exact_score, outline_score)
    second = max(exact_second, outline_second)
    use_fallback = bool(
        outline_obj is not None
        and (obj is None or outline_score >= exact_score + 0.05)
    )
    chosen = outline_obj if use_fallback else obj
    return CompleteRegionMatch(
        item_name=chosen.name if chosen is not None else None,
        score=score,
        color=match_color(chosen.color) if chosen is not None else color,
        second_score=second,
        candidate_count=len(exact_candidates) + len(fallback_candidates),
        template_attempted=True,
    )


def infer_truncated_shape(db, color, width, visible_rows):
    """被视窗边缘截断、认不出具体物品时，用“物品库里该宽度(及颜色)存在哪些高度”反推完整高度。
    例如宽度为 5 的物品只有 5x1 和 5x5 两种：只要露出 2 行以上，就必然是 5x5。
    返回唯一确定的高度，否则返回 None。"""
    hs = {it.h for it in db.items
          if it.w == width and it.h >= visible_rows and (color is None or match_color(it.color) == color)}
    return hs.pop() if len(hs) == 1 else None


def unique_truncated_item(db, color, width, visible_rows):
    """被视窗边缘截断、局部匹配也认不出时：如果物品库里“同颜色、同宽度、高度>=已露出行数”的物品只有 1 件，
    那它就只可能是这一件（例如蓝色宽度 5 只有「绝对是亲手钓的鱼」5x5），直接给出。否则返回 None。"""
    cands = [it for it in db.items
             if it.w == width and it.h >= visible_rows and match_color(it.color) == color]
    return cands[0] if len(cands) == 1 else None


def match_partial(rgb_arr, reg, candidates, cell_size, top_cut, bot_cut,
                  min_score=0.62, search_radius=3, pad=6):
    """被视窗上/下边缘截断的大件物品：只拿“露出来的那一部分”去和候选模板的对应部分比。
    bot_cut(下半截被切掉) -> 比模板的上半部分；top_cut(上半截被切掉) -> 比模板的下半部分。
    候选限定：同颜色、同宽度、高度 >= 已露出的格数。返回 (ItemDef|None, score)。"""
    H, W = rgb_arr.shape[:2]
    vis_h = reg.py1 - reg.py0
    if vis_h < 1.4 * cell_size or (top_cut and bot_cut):
        return None, 0.0     # 只露出一条边时信息太少，容易张冠李戴，宁可不认
    x0r, x1r = max(0, reg.px0 - pad), min(W, reg.px1 + pad)
    y0r, y1r = max(0, reg.py0 - pad), min(H, reg.py1 + pad)
    roi_bgr = cv2.cvtColor(rgb_arr[y0r:y1r, x0r:x1r].astype(np.uint8), cv2.COLOR_RGB2BGR)
    best_item, best_score = None, -1.0
    for it in candidates:
        if it.h < reg.h:
            continue
        tw = max(4, int(round(it.w * cell_size))); th = max(4, int(round(it.h * cell_size)))
        vh = min(th, vis_h)
        tb = cv2.resize(it.template_rgba[:, :, :3], (tw, th), interpolation=cv2.INTER_AREA)
        ta = cv2.resize(it.template_rgba[:, :, 3], (tw, th), interpolation=cv2.INTER_AREA)
        if bot_cut:
            tb, ta = tb[:vh], ta[:vh]
        else:
            tb, ta = tb[th - vh:], ta[th - vh:]
        mask = ta > 200
        if mask.sum() < 40:
            continue
        mask_u8 = mask.astype(np.uint8) * 255
        base_x = (reg.px0 + reg.px1) // 2 - tw // 2 - x0r
        base_y = (reg.py0 - y0r) if bot_cut else (reg.py1 - y0r - vh)
        local = -1.0
        for dy in range(-search_radius, search_radius + 1):
            for dx in range(-search_radius, search_radius + 1):
                sx_, sy_ = base_x + dx, base_y + dy
                if sx_ < 0 or sy_ < 0 or sx_ + tw > roi_bgr.shape[1] or sy_ + vh > roi_bgr.shape[0]:
                    continue
                patch = roi_bgr[sy_:sy_ + vh, sx_:sx_ + tw]
                ncc = _masked_ncc(patch, tb, mask)
                if ncc < local - 0.15:
                    continue
                sc = 0.75 * ncc + 0.25 * _hue_hist_similarity(patch, tb, mask_u8)
                local = max(local, sc)
        if local > best_score:
            best_score, best_item = local, it
    if best_item is not None and best_score >= min_score:
        return best_item, best_score
    return None, best_score


# ------------------------------------------------------------------
# 主流程：给一张 (可能是任意分辨率, 会被缩放到1920x1080基准) 截图，输出识别结果
# ------------------------------------------------------------------
@dataclass
class RecognizedItem:
    x: int          # 绝对列 0..COLS-1
    y: int          # 绝对行 0..TOTAL_ROWS-1（= 窗口首行 row_offset + 窗口内行号）
    w: int
    h: int
    color: str or None
    item_name: str or None
    score: float = 0.0
    truncated: bool = False   # 是否因为滚动截断而被跳过/不完整
    partial: bool = False     # 由“只露出一部分”的局部匹配得出，可信度低于完整匹配
    no_shape: bool = False    # 1x1 且没有检测到闪光边缘：只是颜色+位置标记，真实形状未知
    cut: str = ""             # truncated 时被截掉的是哪一边：'top'(上半被截) / 'bottom'(下半被截) / 'both'；用于跨页拼接
    template_attempted: bool = False
    candidate_count: int = 0
    second_score: float = 0.0
    click_x: int = 0       # 当前原始页面内的点击 x；识别时一次确定
    click_y: int = 0       # 当前原始页面内的点击 y；不经过全局行号反推
    source_page: int = -1  # 藏品仓库扫描页序号；其它场景保持 -1


def recognize_frame(pil_image, db: ItemDatabase, min_match_score=0.60, known=None,
                    row_offset=0, check_phase=False, grid=None, refine=True, rows=None,
                    top_edge_complete=False, bottom_edge_complete=False,
                    total_rows=None, scroll_start=None):
    """pil_image: 截图（任意分辨率，会按比例换算坐标）。
    row_offset: 这张截图可视窗口的首行对应的绝对行号（0=第1行）。不再读取滚动条，由三段式截图直接给定：
                第1段=0（第1-10行）、第2段=8（第9-18行）、第3段=15（第16-25行）。
    check_phase: 仅第2段（滚轮滚到中间）打开——用画面网格线相位检查实际滚动是否正好落在整行上；
                 第1/3段在滚动条两端，必然对齐，不需要检查。
    grid: (ox, oy, cell_size) 网格先验(屏幕像素)；None=按 1920x1080 基准标定值乘以缩放比例(旧行为)。
    refine: 逐帧用画面里真实的格缝对 (起点, 边长) 做 ±0.1 格(≈±6px) / ±2.5% 的微调，所以先验有一点点偏差(比如边长差 1%)也不用手改常量。
    total_rows: 当前网格总行数。拍卖箱默认 25 行，藏品仓库传 60 行。
    scroll_start: 已知的实际滚动行号（可带小数）；传入后不再重复猜相位。
    返回 (list[RecognizedItem], scroll_rows)。truncated=True 的物品被滚动/视窗边缘截断，
    形状不可信，world_model 不会采用其尺寸。"""
    VR = int(rows or VIEW_ROWS)       # 可视行数；拼合后的整仓长图传 25
    img = pil_image.convert("RGB")
    w0, h0 = img.size
    sx, sy = w0 / BASE_W, h0 / BASE_H
    full = np.array(img)
    if grid is not None:
        ox, oy, cs = (float(v) for v in grid)
    else:
        cs = CELL_SIZE * (sx + sy) / 2.0
        ox = GRID_ORIGIN_X * sx
        oy = GRID_ORIGIN_Y * sy
    if refine:
        fo, fy, fc, fscore = fit_grid(_dark_map(full), ox, oy, cs, cs_rel=0.025, shift_x=0.1 * cs, shift_y=0.1 * cs,
                                      fit_y=(not check_phase and scroll_start is None),
                                      iters=2)
        if fscore >= 1.5:          # 画面里格缝太少(几乎全是空格)时，微调不可靠，保持先验
            ox, cs = fo, fc
            if not check_phase and scroll_start is None:
                oy = fy

    vy0 = int(round(oy)); vy1 = min(full.shape[0], int(round(oy + VR * cs)))
    vx1 = min(full.shape[1], int(round(ox + COLS * cs)) + 2)
    view = full[vy0:vy1, :vx1]
    grid_total_rows = max(VR, int(total_rows or TOTAL_ROWS))
    max_int = grid_total_rows - VR
    row_offset = max(0, min(max_int, int(row_offset)))
    if scroll_start is not None:
        scroll_rows = max(
            0.0, min(float(max_int), float(scroll_start))
        )
        int_part = int(scroll_rows)
        frac = scroll_rows - int_part
        shift = frac * cs
    else:
        # 默认认定网格与窗口顶部对齐（shift=0）。只有中间段才用网格线相位找小数行偏移，
        # 且偏移后的实际首行取“离设定首行最近”的那个（正好在中间时取较小的一个）。
        shift = estimate_vertical_shift(view, cs, origin_x=ox) if check_phase else 0.0
        if shift / cs < 0.12 or shift / cs > 0.88:   # 离整行很近：认定对齐（避免稀疏画面下相位估计的小误判）
            shift = 0.0
        frac = shift / cs
        if shift > 0:
            # 实际首行 = k + frac，k 取使它离设定首行最近的整数；frac≈0.5 正好两边等距，
            # 画面相位估计有一点点误差就会跳边，所以 ≥0.45 一律按“比设定少滚了不到一行”处理。
            int_part = max(0, min(max_int, row_offset - 1 if frac >= 0.45 else row_offset))
        else:
            int_part = row_offset
        scroll_rows = int_part + frac
    at_top = (int_part == 0 and shift == 0)

    regions = segment_grid(view, cell_size=cs, cols=COLS, rows=VR,
                           origin_x=ox, origin_y=-shift)
    view_h = view.shape[0]
    results = []
    for reg in regions:
        top_cut = (
            reg.py0 <= 1 and not at_top and not top_edge_complete
        )
        bot_cut = (
            reg.py1 >= view_h - 1
            and not (int_part >= max_int)
            and not bottom_edge_complete
        )
        truncated = bool(top_cut or bot_cut)
        cut_side = 'both' if (top_cut and bot_cut) else ('top' if top_cut else ('bottom' if bot_cut else ''))

        has_icon = region_has_icon_art(
            view, reg.px0, reg.py0, reg.px1, reg.py1
        )
        med = perimeter_median_color(view, reg.px0, reg.py0, reg.px1, reg.py1)
        color = classify_color(med)

        # Colour is evidence for ranking candidates only.  It must never decide
        # whether a visible icon gets a template attempt: a grey perimeter or a
        # wrong rarity read previously skipped a perfectly clear item icon.
        if color is None or color == "轮廓":
            attempted = bool(has_icon and not truncated)
            candidate_count = 0
            best_score = 0.0
            second_score = -1.0
            if attempted:
                outline_candidates = db.candidates_by_size(reg.w, reg.h)
                candidate_count = len(outline_candidates)
                outline_obj, outline_score, outline_second = match_outline_item(
                    view, reg, outline_candidates, cs
                )
                # A failed colour/outline read must not prevent a clear
                # large template from being compared.  High-value special
                # red items (for example 4x4 金锦鲤雕像) often have a grey
                # perimeter in a mid-auction round, while their full icon is
                # already visible.  Keep the 1x1 candidate pools on the cheap
                # outline path; only larger, much smaller pools get this
                # full-template fallback.
                full_obj = None
                full_score = 0.0
                full_second = -1.0
                if reg.w * reg.h >= 4:
                    full_obj, full_score, full_second = match_item(
                        view, reg.px0, reg.py0, reg.px1, reg.py1,
                        outline_candidates, min_score=min_match_score,
                        cell_size=cs,
                    )
                chosen, best_score, second_score = choose_unknown_shape_match(
                    outline_obj, outline_score, outline_second,
                    full_obj, full_score, full_second,
                )
                if chosen is not None:
                    results.append(RecognizedItem(
                        x=reg.col, y=int_part + reg.row,
                        w=reg.w, h=reg.h,
                        color=match_color(chosen.color),
                        item_name=chosen.name,
                        score=best_score, truncated=False,
                        template_attempted=True,
                        candidate_count=candidate_count,
                        second_score=second_score,
                    ))
                    continue

            # No icon, or the stricter colour-independent match was ambiguous:
            # keep the honest shape-only state instead of inventing a name.
            if truncated:
                hh = infer_truncated_shape(db, None, reg.w, reg.h)
                if hh is not None:
                    y_abs = (
                        int_part + reg.row if bot_cut
                        else int_part + reg.row + reg.h - hh
                    )
                    results.append(RecognizedItem(
                        x=reg.col, y=y_abs, w=reg.w, h=hh, color=None,
                        item_name=None, score=best_score, truncated=False,
                        template_attempted=attempted,
                        candidate_count=candidate_count,
                        second_score=second_score,
                    ))
                    continue
            if color == "轮廓" or has_icon:
                results.append(RecognizedItem(
                    x=reg.col, y=int_part + reg.row,
                    w=reg.w, h=reg.h, color=None,
                    item_name=None, score=best_score,
                    truncated=truncated,
                    template_attempted=attempted,
                    candidate_count=candidate_count,
                    second_score=second_score,
                ))
            continue

        if truncated:
            # 露出一部分也尽量认：认出后尺寸/位置由物品库反推，就不再是“截断”了
            cands = [i for i in db.candidates_all_sizes(color) if i.w == reg.w]
            obj, score = match_partial(view, reg, cands, cs, top_cut, bot_cut)
            if obj is not None:
                y_abs = int_part + reg.row if bot_cut else int_part + reg.row + reg.h - obj.h
                results.append(RecognizedItem(x=reg.col, y=y_abs, w=obj.w, h=obj.h, color=color,
                                              item_name=obj.name, score=score, truncated=False,
                                              partial=True, template_attempted=True,
                                              candidate_count=len(cands)))
            else:
                uniq = unique_truncated_item(db, color, reg.w, reg.h)
                hh = uniq.h if uniq is not None else infer_truncated_shape(db, color, reg.w, reg.h)
                if hh is not None:
                    y_abs = int_part + reg.row if bot_cut else int_part + reg.row + reg.h - hh
                    # 唯一候选 -> 直接给出物品名（partial=True：之后完整可见时的精确匹配会覆盖它）
                    results.append(RecognizedItem(x=reg.col, y=y_abs, w=reg.w, h=hh, color=color,
                                                  item_name=uniq.name if uniq is not None else None,
                                                  score=0.5 if uniq is not None else 0.0, truncated=False,
                                                  partial=uniq is not None,
                                                  template_attempted=True,
                                                  candidate_count=len(cands)))
                else:
                    results.append(RecognizedItem(x=reg.col, y=int_part + reg.row, w=reg.w, h=reg.h,
                                                  color=color, item_name=None, score=0.0, truncated=True,
                                                  cut=cut_side,
                                                  template_attempted=True,
                                                  candidate_count=len(cands)))
            continue

        item_name, score, no_shape = None, 0.0, False
        final_color = color
        template_attempted = False
        candidate_count = 0
        second_score = -1.0
        if reg.w == 1 and reg.h == 1 and not has_icon and not has_glint_edge(view, reg.px0, reg.py0, reg.px1, reg.py1):
            # 1x1、还没显示具体图标（纯色卡片）、也没有闪光边缘：
            # 这是“只知道颜色和位置”的标记，真实形状未知（可能是更大物品的一角）。
            # 注意：一旦图标已经画出来（region_has_icon_art=True），说明形状肯定已确认，
            # 不再需要看闪光边缘——结算界面等完全揭示的画面本来就不会再显示闪光效果。
            no_shape = True
        else:
            kn = (known or {}).get((reg.col, int_part + reg.row, reg.w, reg.h))
            if kn and kn[1] == color:
                item_name, score = kn[0], 1.0      # 已识别过的同位置同尺寸同颜色物品，跳过重复匹配（提速）
            elif has_icon:
                template_attempted = True
                exact_candidates = db.candidates(color, reg.w, reg.h)
                candidate_count = len(exact_candidates)
                obj, score, second_score = match_item(
                    view, reg.px0, reg.py0, reg.px1, reg.py1,
                    exact_candidates, min_score=min_match_score,
                    cell_size=cs,
                )
                # The rarity read can be one of the border pixels rather than
                # the card colour.  Always compare the rest of the shape pool
                # as well; otherwise a mediocre wrong-colour match could hide a
                # much clearer correct template.
                exact_ids = {id(it) for it in exact_candidates}
                fallback_candidates = [
                    it for it in db.candidates_by_size(reg.w, reg.h)
                    if id(it) not in exact_ids
                ]
                candidate_count += len(fallback_candidates)
                exact_score = score
                obj2, score2, second2 = match_outline_item(
                    view, reg, fallback_candidates, cs
                )
                if score2 > score:
                    score = score2
                if second2 > second_score:
                    second_score = second2
                use_fallback = bool(
                    obj2 is not None
                    and (
                        obj is None
                        or score2 >= exact_score + 0.05
                    )
                )
                if use_fallback:
                    item_name = obj2.name
                    final_color = match_color(obj2.color)
                elif obj is not None:
                    item_name = obj.name
        results.append(RecognizedItem(x=reg.col, y=int_part + reg.row, w=reg.w, h=reg.h,
                                      color=final_color, item_name=item_name, score=score,
                                      truncated=False, no_shape=no_shape,
                                      template_attempted=template_attempted,
                                      candidate_count=candidate_count,
                                      second_score=second_score))
    # Keep the click point in the exact viewport where the item was recognized.
    # This avoids reconstructing it later from a merged global row and a page
    # start that may differ by a fractional scroll phase.
    region_by_key = {
        (int_part + reg.row, reg.col, reg.w, reg.h): reg
        for reg in regions
    }
    for item in results:
        reg = region_by_key.get((item.y, item.x, item.w, item.h))
        if reg is None:
            continue
        item.click_x = int(round((reg.px0 + reg.px1 - 1) / 2.0))
        item.click_y = int(round((reg.py0 + reg.py1 - 1) / 2.0))
    return results, scroll_rows



# ------------------------------------------------------------------
# 三页拼合：F1 一次截 3 张(滚到顶/下滚15格/下滚到底)，对齐后拼成一张 25 行的长图再整体识别。
# 好处：① 跨页的大物品(4x4/4x5/5x5 灰框等)在长图里是完整的，不再有“只露出上半”；
#       ② 每一行都取自它在页内最靠中间的那一页，第1页最底下一行(常常显示不全)不再参与识别。
# ------------------------------------------------------------------
def register_pages(a_img, b_img, ox, oy, cs, expect_px, search=0.75):
    """b 页相对 a 页内容上移了 d 像素（b 的 y 处 == a 的 y+d 处）。以 expect_px 为先验，在 ±search 格内
    用“暗图”(空格/格缝=暗，卡片=亮)的逐像素差异最小来确定 d。返回 (d, 差异占比 0..1, 先验处差异占比)。
    差异占比是整个重叠区的暗/亮不一致比例；两页本来就几乎一样(滚轮没动)或重叠区太小时返回的占比会很大/先验被采用。"""
    x0 = max(0, int(ox)); x1 = int(ox + COLS * cs)
    y0 = int(oy); y1 = int(oy + VIEW_ROWS * cs)
    A = (np.array(a_img.convert("RGB"))[y0:y1, x0:x1].max(axis=2) < DARK_THRESH)
    B = (np.array(b_img.convert("RGB"))[y0:y1, x0:x1].max(axis=2) < DARK_THRESH)
    H = A.shape[0]
    best = None
    scores = {}
    lo = int(round(expect_px - search * cs)); hi = int(round(expect_px + search * cs))
    for d in range(max(1, lo), min(H - 8, hi) + 1):
        n = H - d
        # 只比较重叠区；b 页的最顶行/a 页最底行可能被裁切，各让开 1/4 格
        m = int(cs * 0.25)
        if n - m <= int(cs * 0.6):
            continue
        diff = (A[d + m:H - 0 - 0][:n - m] != B[m:n]).mean()
        pen = 0.02 * abs(d - expect_px) / cs        # 先验：同样好时取最接近预期的
        scores[d] = float(diff)
        sc = diff + pen
        if best is None or sc < best[0]:
            best = (sc, d)
    if best is None:
        return int(round(expect_px)), 1.0, 1.0
    d = best[1]
    de = int(round(expect_px))
    return d, scores[d], scores.get(de, scores[d])


def refine_offset(a_img, b_img, ox, oy, cs, d0, radius=None):
    """在 d0 附近(±radius 像素，默认 0.15 格)用灰度图逐像素差异精修 b 页相对 a 页的偏移，返回 (d, 差异@d, 差异@d0)。
    register_pages 用的是“暗/亮”二值图，对几个像素的偏差不敏感(稀疏画面里差异占比不到 3%)，所以滚到底的第 3 页
    被吸附到“恰好 15 行”后，真实偏移如果多出几个像素(实测约 4px)就发现不了：接缝处格缝被吃掉，上下两件物品粘在一起
    (3x3 红色被拉成 3x4)，下面的格线整体偏上 4px。灰度图能看到卡片边缘/图标细节，几个像素的错位差异很明显。
    只有精修后的差异明显更小(<0.9×先验处)才采用，否则维持 d0。"""
    x0 = max(0, int(ox)); x1 = int(ox + COLS * cs)
    y0 = int(oy); y1 = int(oy + VIEW_ROWS * cs)
    A = np.array(a_img.convert("L"))[y0:y1, x0:x1].astype(np.float32)
    B = np.array(b_img.convert("L"))[y0:y1, x0:x1].astype(np.float32)
    H = A.shape[0]
    m = int(cs * 0.25)
    radius = int(round(cs * 0.15)) if radius is None else int(radius)

    def score(d):
        n = H - d
        if n - 2 * m <= int(cs * 0.6):
            return None
        return float(np.abs(A[d + m:H - m] [:n - 2 * m] - B[m:n - m]).mean())

    d0 = int(round(d0))
    s0 = score(d0)
    if s0 is None:
        return d0, 0.0, 0.0
    best_d, best_s = d0, s0
    for d in range(max(1, d0 - radius), d0 + radius + 1):
        sc = score(d)
        if sc is not None and sc < best_s:
            best_d, best_s = d, sc
    if best_d != d0 and best_s < 0.9 * s0:
        return best_d, best_s, s0
    return d0, s0, s0


def stitch_pages(pages, ox, oy, cs, expect_abs_rows=(0, 8, 15)):
    """pages: [P1,P2,P3] (PIL RGB，同尺寸，分别是滚到顶/中/底)。返回 (canvas PIL, info dict)。
    canvas 的网格起点仍是 (ox, oy)，往下共 25 行；之后直接 recognize_frame(canvas, grid=(ox,oy,cs), rows=25)。"""
    P = [pg.convert("RGB") for pg in pages]
    d = [0.0]
    quality = []
    for i in (1, 2):
        e_abs = expect_abs_rows[i] * cs
        e_rel = e_abs - d[i - 1]
        # 第3页滚到了仓库最底部(滚动被到底截停)，绝对偏移必然正好是 15 行；第2页也只会有小偏差。
        # 以前两页都允许 ±0.75 格漂移，稀疏画面(底部大片空格)里“暗/亮图”几乎处处吻合，
        # 容易配到错的偏移，整段被拉长/压扁(5x5 变 5x6)。第3页改成窄搜索 + 吸附到整行。
        dd, q, q_exp = register_pages(P[i - 1], P[i], ox, oy, cs, e_rel, search=0.75 if i == 1 else 0.3)
        if i == 2:
            tgt = expect_abs_rows[2] * cs
            if abs(d[1] + dd - tgt) <= 0.3 * cs and q <= q_exp + 0.03:
                dd = tgt - d[1]          # 吸附到到底后的精确整行偏移
                q = min(q, q_exp)
        if i == 2:
            # 吸附只是先验：滚动到底的真实偏移可能比整 15 行多出几个像素，用灰度图再精修一次
            dd2, _s_best, _s0 = refine_offset(P[1], P[2], ox, oy, cs, dd)
            if dd2 != int(round(dd)):
                dd = float(dd2)
        d.append(d[i - 1] + dd)
        quality.append((dd, q, q_exp))
    W, Hh = P[0].size
    cvs_h = int(round(oy + TOTAL_ROWS * cs)) + 2
    cv = np.zeros((cvs_h, W, 3), dtype=np.uint8)
    arrs = [np.array(p) for p in P]
    cv[:int(oy)] = arrs[0][:int(oy)]
    # 接缝(世界坐标，单位像素，落在格线上)：第1页用到第9行底，第2页用到第16行底，其余第3页
    seam1 = max(9 * cs, np.ceil(d[1] / cs) * cs)
    seam2 = min(max(16 * cs, np.ceil(d[2] / cs) * cs), d[1] + 9 * cs)
    seam2 = max(seam2, seam1 + cs)
    bounds = [(0.0, seam1, 0), (seam1, seam2, 1), (seam2, TOTAL_ROWS * cs, 2)]
    for a, b, i in bounds:
        wy0 = int(round(a)); wy1 = int(round(b))
        for w in range(wy0, wy1):
            sy_ = int(round(oy + w - d[i]))
            if 0 <= sy_ < Hh and 0 <= int(round(oy + w)) < cvs_h:
                cv[int(round(oy + w))] = arrs[i][sy_]
    info = {"d": d, "quality": quality, "seam": (seam1 / cs, seam2 / cs)}
    return Image.fromarray(cv), info


def recognize_pages(pages, db: "ItemDatabase", min_match_score=0.60, known=None, grid=None):
    """三页(滚到顶/中/底)拼合后整体识别。返回 (results, info)。grid=(ox,oy,cs) 屏幕像素先验，None=按 1920x1080 标定值缩放。
    网格用第1页(顶部，无滚动偏移)做一次微调，之后整个长图都用这组网格。"""
    img0 = pages[0].convert("RGB")
    w0, h0 = img0.size
    sx, sy = w0 / BASE_W, h0 / BASE_H
    if grid is not None:
        ox, oy, cs = (float(v) for v in grid)
    else:
        cs = CELL_SIZE * (sx + sy) / 2.0
        ox, oy = GRID_ORIGIN_X * sx, GRID_ORIGIN_Y * sy
    if grid is None:
        # 没有标定值时才在第1页上微调一次。已有标定网格(grid)就直接用：fit_grid 在物品稀少的画面上
        # 会把格子边长拟合偏(实测 47px 被拟成 46px)，10 列累积偏移近 10px，整张长图都会被切碎。
        # 1920x1080 原生分辨率时标定常量(CELL_SIZE)本身就是准的，只微调原点、边长固定：
        # 第1页只有 10 行，拟合出的边长误差(实测 56.29 被拟成 56.01，差 0.28px)被 25 行长图放大，
        # 到第 16 行就偏 4~5px、第 24 行偏 7px：格缝被吃掉，下方物品被拉长(3x3 变 3x4)，第3页偏移也被带歪。
        native = abs(sx - 1.0) < 1e-6 and abs(sy - 1.0) < 1e-6
        fo, fy, fc, fscore = fit_grid(_dark_map(np.array(img0)), ox, oy, cs, cs_rel=0.0 if native else 0.025,
                                      shift_x=0.1 * cs, shift_y=0.1 * cs, fit_y=True, iters=2)
        if fscore >= 2.5:
            ox, oy, cs = fo, fy, fc
    canvas, info = stitch_pages(pages, ox, oy, cs)
    res, _ = recognize_frame(canvas, db, min_match_score=min_match_score, known=known, row_offset=0,
                             check_phase=False, grid=(ox, oy, cs), refine=False, rows=TOTAL_ROWS)
    info["grid"] = (ox, oy, cs)
    info["canvas"] = canvas
    return res, info


def load_default_db(base_dir=None):
    base_dir = base_dir or os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(base_dir, "items.xlsx")
    templates_dir = os.path.join(base_dir, "templates")
    return ItemDatabase(excel_path, templates_dir)
