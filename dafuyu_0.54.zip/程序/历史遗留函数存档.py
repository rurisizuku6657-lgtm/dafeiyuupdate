"""历史遗留函数存档 —— 这些函数已经没有调用点，2026-11-14 从主程序里挪到这里。

保留而不是删掉的原因：万一以后想找回旧逻辑，不用去翻备份目录。

⚠️ 注意：
  · 这些函数引用的是 paimai.py 里的全局变量和函数，**直接 import 本文件是跑不起来的**。
  · 真要复用，把需要的函数体复制回 paimai.py 对应位置，或者给它补齐依赖。
  · 挪出来之前已确认：全项目 32 个 .py 里，它们只有 def 那一行，没有任何调用点。

清单：
  numeric_reader.py    available_styles       原 L457
  paimai.py            数红块                    原 L1123
  paimai.py            关仪器页_按坐标               原 L6861
  paimai.py            流程图匹配                  原 L7459
  paimai.py            低价档首次价                 原 L9228
  paimai.py            记第二高历史                 原 L9886
  paimai.py            这回合赢了吗                 原 L9893
  paimai.py            跟对手价                   原 L10082
  paimai.py            图鉴估值                   原 L10139
  warehouse_vision.py  _weighted_quantiles    原 L85
  界面.py                today_stats            原 L1320
  界面.py                scaled_qss             原 L2533
  界面.py                show_shot_path         原 L5503

"""


# ======================================================================
# 来自 numeric_reader.py 第 457 行
# ======================================================================
def available_styles(template_root):
    root = Path(template_root)
    if not root.is_dir():
        return []
    return sorted(
        child.name for child in root.iterdir()
        if child.is_dir() and (child / "manifest.json").is_file()
    )


# ======================================================================
# 来自 paimai.py 第 1123 行
# ======================================================================
def 数红块(img=None):
    """整仓红色块的数量（大仓会自动往下滚着数）。"""
    return 数整仓品质块(img).get("红", 0)


# ======================================================================
# 来自 paimai.py 第 6861 行
# ======================================================================
def 关仪器页_按坐标(left, top):
    """兜底版：不看模板，直接点右上角那个 ×。正常流程用 关仪器页(quiet=)。

    以前这个也叫 关仪器页，后来真名被下面的模板版占了，旧签名就成了死代码，
    还有调用点按老签名传两个参数 → TypeError。现在改名，两个版本互不干扰。
    """
    print(f"📍 [状态] 点击关闭仪器组页面 ({CLOSE_INSTRUMENT_X}, {CLOSE_INSTRUMENT_Y})")
    安全点击(left + CLOSE_INSTRUMENT_X, top + CLOSE_INSTRUMENT_Y)
    if not 歇一下(1):
        return False
    return True


# ======================================================================
# 来自 paimai.py 第 7459 行
# ======================================================================
def 流程图匹配(img_bgr, image_name, box=None, threshold=None):
    """在已经截好的一帧里匹配模板。box 按 1920x1080 客户区坐标。"""
    try:
        target = img_bgr
        if box is not None:
            x, y, w, h = [int(v) for v in box]
            if y < 0 or x < 0 or y + h > target.shape[0] or x + w > target.shape[1]:
                return False
            target = target[y : y + h, x : x + w]
        return bool(
            截图里有这个模板吗(
                target, image_name, THRESHOLD if threshold is None else threshold
            )
            >= (THRESHOLD if threshold is None else threshold)
        )
    except Exception:
        return False


# ======================================================================
# 来自 paimai.py 第 9228 行
# ======================================================================
def 低价档首次价(value):
    return int(LOW_TIER_OPEN)


# ======================================================================
# 来自 paimai.py 第 9886 行
# ======================================================================
def 记第二高历史(opponent_bids: list[int]) -> int:
    if not opponent_bids:
        return 0
    ordered = sorted(opponent_bids, reverse=True)
    return ordered[1] if len(ordered) >= 2 else ordered[0]


# ======================================================================
# 来自 paimai.py 第 9893 行
# ======================================================================
def 这回合赢了吗(my_bid: int, all_bids: list[int], round_index: int) -> bool:
    if my_bid <= 0:
        return False
    ordered = sorted(all_bids, reverse=True)
    top = ordered[0]
    second = ordered[1] if len(ordered) >= 2 else 0
    if my_bid != top:
        return False
    k = ROUND_K[min(round_index, len(ROUND_K) - 1)]
    return my_bid > k * second


# ======================================================================
# 来自 paimai.py 第 10082 行
# ======================================================================
def 跟对手价(value, round_num):
    if OPPONENT_MAX_SEEN <= 0:
        return None
    k = _ROUND_K[min(round_num - 1, len(_ROUND_K) - 1)]
    second_pred = 预测下一轮第二()
    if second_pred <= 0:
        second_pred = int(OPPONENT_MAX_SEEN * 0.8)
    win_need = k * second_pred
    block_need = OPPONENT_MAX_SEEN / k
    target = int(max(win_need, block_need) * (1.0 + RIVAL_MARGIN))
    cap = int(value * RIVAL_CAP_RATIO) if value else 0
    if cap > 0:
        target = min(target, cap)
    return target


# ======================================================================
# 来自 paimai.py 第 10139 行
# ======================================================================
def 图鉴估值(qualities=None):
    """按仓里各档品质的块数，估这一仓大概值多少钱。

    图鉴模式（CATALOG_MODE）已经撤掉了，出价不再走这条路；
    函数留着是因为日志/分析脚本偶尔还拿它当个粗估参照。
    """
    try:
        q = qualities if qualities is not None else 数这一局的仓()
    except Exception:
        q = {}
    if not isinstance(q, dict) or not q:
        return 0
    med = 图鉴中位数()
    if not med:
        return 0
    total = 0
    for name, cnt in q.items():
        total += int(med.get(str(name), 0)) * int(cnt or 0)
    return int(total)


# ======================================================================
# 来自 warehouse_vision.py 第 85 行
# ======================================================================
def _weighted_quantiles(pairs, samples=QUANTILE_SAMPLES, seed=0):
    """Sample summed candidate uncertainty and return stable value quantiles."""
    vals = [
        (float(price), max(1e-9, float(weight)))
        for price, weight in pairs
        if price is not None and float(price) >= 0
    ]
    if not vals:
        return {"p10": 0, "p50": 0, "p75": 0, "p90": 0}
    if len(vals) == 1:
        value = int(round(vals[0][0]))
        return {"p10": value, "p50": value, "p75": value, "p90": value}
    rng = random.Random(int(seed) & 0xFFFFFFFF)
    prices = [v[0] for v in vals]
    cumulative = []
    running = 0.0
    for _, weight in vals:
        running += weight
        cumulative.append(running)
    draws = rng.choices(prices, cum_weights=cumulative, k=int(samples))
    draws.sort()

    def pick(frac):
        return draws[min(len(draws) - 1, max(0, int(frac * len(draws))))]

    return {
        "p10": int(round(pick(0.10))),
        "p50": int(round(pick(0.50))),
        "p75": int(round(pick(0.75))),
        "p90": int(round(pick(0.90))),
    }


# ======================================================================
# 来自 界面.py 第 1320 行
# ======================================================================
def today_stats(day=None):
    day = day or datetime.date.today().strftime("%Y-%m-%d")
    st = {"auctions": 0, "won": 0, "lost": 0, "quit": 0, "cost": 0, "net_profit": 0, "profit": 0}
    try:
        if not os.path.exists(JSONL):
            return st, day
        with open(JSONL, encoding="utf-8", errors="ignore") as fp:
            for line in fp:
                if '"auction_end"' not in line:
                    continue
                try:
                    d = json.loads(line)
                except Exception:
                    continue
                if not str(d.get("ts") or "").startswith(day):
                    continue
                st["auctions"] += 1
                r = d.get("result")
                if r in ("won", "lost", "quit"):
                    st[r] += 1
                try:
                    st["cost"] += int(d.get("cost") or 0)
                    st["net_profit"] += int(d.get("net_profit") or 0)
                    st["profit"] += int(d.get("my_profit") or 0)
                except Exception:
                    pass
    except Exception:
        pass
    return st, day


# ======================================================================
# 来自 界面.py 第 2533 行
# ======================================================================
def scaled_qss(font_size, theme="anon"):
    return build_qss(theme, font_size)


# ======================================================================
# 来自 界面.py 第 5503 行
# ======================================================================
    def show_shot_path(self, path):
        try:
            pm = QPixmap(path)
            if pm.isNull():
                return
            d = QDialog(self)
            d.setWindowTitle(os.path.basename(path))
            lay = QVBoxLayout(d)
            lab = QLabel()
            scr = QApplication.primaryScreen().size()
            lab.setPixmap(
                pm.scaled(
                    scr.width() - 120,
                    scr.height() - 160,
                    Qt.KeepAspectRatio,
                    Qt.SmoothTransformation,
                )
            )
            lay.addWidget(lab)
            d.exec_()
        except Exception:
            pass
