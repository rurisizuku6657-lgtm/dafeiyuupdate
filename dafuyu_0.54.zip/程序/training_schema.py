from __future__ import annotations

import math
from typing import Any, Iterable


TRAINING_SCHEMA_VERSION = 5
FEATURE_SCHEMA_VERSION = 2
INVENTORY_FEATURE_VERSION = 1

INVENTORY_FEATURE_NAMES = (
    "exact_value_sum",
    "unknown_value_mean",
    "unknown_value_low",
    "unknown_value_high",
    "unknown_value_span",
    "unknown_value_span_ratio",
    "unknown_block_ratio",
    "no_data_block_ratio",
    "top1_value_share",
    "top3_value_share",
    "top5_value_share",
    "effective_item_count",
    "red_gold_item_ratio",
    "red_gold_value_share",
    "named_area_ratio",
    "catalog_to_game_ratio",
    "p75_to_game_ratio",
)

HIGH_VALUE_COLORS = {"红色", "金色"}


def _number(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _ratio(numerator: float, denominator: float) -> float:
    if denominator <= 0:
        return 0.0
    return max(0.0, float(numerator) / float(denominator))


def _candidate_prices(row: dict[str, Any]) -> list[float]:
    prices = []
    for candidate in row.get("candidate_top") or []:
        if not isinstance(candidate, dict):
            continue
        price = _number(candidate.get("price"), -1.0)
        if price >= 0:
            prices.append(price)
    if not prices:
        mean = _number(row.get("mean"), -1.0)
        if mean >= 0:
            prices.append(mean)
    return prices


def build_inventory_features(
    items: Iterable[dict[str, Any]],
    game_estimate: int | float = 0,
    p75_total: int | float = 0,
    block_count: int | None = None,
) -> dict[str, Any]:
    rows = [row for row in items or [] if isinstance(row, dict)]
    actual_blocks = max(0, int(block_count or 0), len(rows))
    exact_value_sum = 0.0
    unknown_value_mean = 0.0
    unknown_value_low = 0.0
    unknown_value_high = 0.0
    item_values: list[float] = []
    unknown_blocks = 0
    no_data_blocks = 0
    red_gold_count = 0
    red_gold_value = 0.0
    area_total = 0.0
    named_area = 0.0

    for row in rows:
        area = max(
            1.0,
            _number(row.get("w"), 1.0) * _number(row.get("h"), 1.0),
        )
        area_total += area
        value = max(0.0, _number(row.get("mean"), 0.0))
        item_values.append(value)
        source = str(row.get("source") or "")
        if source.startswith("no-shape"):
            source = "no-shape"
        elif source.startswith("shape"):
            source = "shape"
        elif source.startswith("exact"):
            source = "exact"
        elif source == "no-data":
            source = "no-data"

        prices = _candidate_prices(row)
        low = min(prices) if prices else 0.0
        high = max(prices) if prices else value
        if source == "exact":
            exact_value_sum += value
        else:
            unknown_blocks += 1
            unknown_value_mean += value
            unknown_value_low += low
            unknown_value_high += high
            if source == "no-data":
                no_data_blocks += 1

        if str(row.get("item") or ""):
            named_area += area
        color = str(row.get("color") or "")
        if color in HIGH_VALUE_COLORS:
            red_gold_count += 1
            red_gold_value += value

    total_value = sum(item_values)
    top_values = sorted(item_values, reverse=True)
    squared = sum(value * value for value in item_values)
    effective_item_count = (
        (total_value * total_value / squared) if squared > 0 else 0.0
    )
    unknown_span = max(0.0, unknown_value_high - unknown_value_low)
    game = max(0.0, _number(game_estimate))
    p75 = max(0.0, _number(p75_total))
    named_count = sum(1 for row in rows if row.get("item"))
    features = {
        "exact_value_sum": round(exact_value_sum, 3),
        "unknown_value_mean": round(unknown_value_mean, 3),
        "unknown_value_low": round(unknown_value_low, 3),
        "unknown_value_high": round(unknown_value_high, 3),
        "unknown_value_span": round(unknown_span, 3),
        "unknown_value_span_ratio": round(
            _ratio(unknown_span, total_value), 6
        ),
        "unknown_block_ratio": round(
            _ratio(unknown_blocks, actual_blocks), 6
        ),
        "no_data_block_ratio": round(
            _ratio(no_data_blocks, actual_blocks), 6
        ),
        "top1_value_share": round(
            _ratio(top_values[0] if top_values else 0.0, total_value), 6
        ),
        "top3_value_share": round(
            _ratio(sum(top_values[:3]), total_value), 6
        ),
        "top5_value_share": round(
            _ratio(sum(top_values[:5]), total_value), 6
        ),
        "effective_item_count": round(effective_item_count, 4),
        "red_gold_item_ratio": round(
            _ratio(red_gold_count, actual_blocks), 6
        ),
        "red_gold_value_share": round(
            _ratio(red_gold_value, total_value), 6
        ),
        "named_area_ratio": round(_ratio(named_area, area_total), 6),
        "catalog_to_game_ratio": round(_ratio(total_value, game), 6),
        "p75_to_game_ratio": round(_ratio(p75, game), 6),
    }
    features["_meta"] = {
        "feature_version": INVENTORY_FEATURE_VERSION,
        "block_count": actual_blocks,
        "item_count": len(rows),
        "named_count": named_count,
        "total_value": round(total_value, 3),
        "complete": bool(rows and actual_blocks > 0),
    }
    return features


def model_feature_values(features: dict[str, Any]) -> list[float]:
    return [
        _number(features.get(name), 0.0)
        for name in INVENTORY_FEATURE_NAMES
    ]


def sample_quality(
    checksum_ok: bool,
    inventory_features: dict[str, Any] | None,
    image_present: bool = True,
) -> dict[str, Any]:
    features = inventory_features or {}
    complete = bool((features.get("_meta") or {}).get("complete"))
    if not image_present or not complete:
        status = "rejected"
    elif checksum_ok:
        status = "primary"
    else:
        status = "auxiliary"
    return {
        "round_checksum_ok": bool(checksum_ok),
        "inventory_features_complete": complete,
        "image_present": bool(image_present),
        "training_status": status,
    }


def auction_quality(
    actual_value: int | float,
    samples: Iterable[dict[str, Any]],
    final_image_present: bool,
) -> dict[str, Any]:
    rows = [row for row in samples or [] if isinstance(row, dict)]
    checksum_ok_count = sum(
        bool((row.get("quality") or {}).get("round_checksum_ok"))
        if isinstance(row.get("quality"), dict)
        else bool(row.get("checksum_ok"))
        for row in rows
    )
    all_checksum_ok = bool(rows) and checksum_ok_count == len(rows)
    has_value = _number(actual_value) > 0
    if not has_value:
        status = "rejected"
    elif all_checksum_ok:
        status = "primary"
    else:
        status = "auxiliary"
    return {
        "aggregate_value_present": has_value,
        "all_rounds_checksum_ok": all_checksum_ok,
        "checksum_ok_count": checksum_ok_count,
        "sample_count": len(rows),
        "final_image_present": bool(final_image_present),
        "final_image_status": (
            "primary" if final_image_present else "missing"
        ),
        "training_status": status,
    }
