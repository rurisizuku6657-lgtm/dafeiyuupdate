# -*- coding: utf-8 -*-
"""清仓试跑（干跑）：只扫描整仓 + 出「卖/留」计划，不点任何东西。

用法：
    1. 游戏停在【藏品仓库】页（不是拍卖大厅）
    2. 双击本文件（或 v3\python\python.exe 清仓试跑.py）
    3. 结果写到 记录\日志\<日期>\清仓调试\清仓计划_*.json，并在控制台打印摘要

判定规则（和面板上 10 个「保留藏品」开关对应）：
    · 认不出名字 / 被截断 / 只露出一部分 → 一律保留
    · 名字命中某个打开了的「保留」档位 → 保留
    · 其余进出售计划（真卖时会逐件点开，弹窗价值 < AUTO_CLEAN_MAX_VALUE 才卖）
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import paimai  # noqa: E402

def _dump_client_frame():
    """先把当前客户端整屏存一张，方便离线标定藏品仓库的网格/滚动条。"""
    import datetime as _dt
    import os as _os
    try:
        out_dir = getattr(paimai, "CLEANUP_DEBUG_DIR", None) or _os.path.join(
            _os.path.dirname(_os.path.abspath(__file__)), "_清仓调试"
        )
        _os.makedirs(out_dir, exist_ok=True)
        shot = paimai.抓一帧()
        if shot is None:
            print("⚠️ 客户端截图失败（游戏窗口没开？）")
            return None
        p = _os.path.join(out_dir, "客户端_%s.png" % _dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        shot.save(p)
        print("📸 已存客户端整屏截图：%s（%dx%d）" % (p, shot.size[0], shot.size[1]))
        return p
    except Exception as exc:
        print(f"⚠️ 存客户端截图失败：{exc}")
        return None


if __name__ == "__main__":
    print("=" * 60)
    print("清仓试跑（干跑：只出计划，不会卖任何东西）")
    print("=" * 60)
    _dump_client_frame()
    plan = paimai.清仓_扫描并出计划(dry_run=True)
    if plan:
        print("-" * 60)
        print(
            "合计：认出 %d 块 → 计划卖 %d 件 / 保留 %d 件"
            % (plan["total_blocks"], plan["sell_count"], plan["keep_count"])
        )
        print("保留名单：%s" % ("、".join(plan["keep_names"]) or "（空）"))
    else:
        print("没拿到计划（看上面的报错）")
    try:
        input("\n按回车退出…")
    except Exception:
        pass