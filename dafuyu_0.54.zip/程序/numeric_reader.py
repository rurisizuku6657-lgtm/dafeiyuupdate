# -*- coding: utf-8 -*-
"""确定性的、可扩展的数字识别。

运行时路径刻意保持很窄：

    区域 → 前景掩码 → 连通域 → 数字串
    → 归一化字形 → 与 0-9 模板比对 → 业务约束

这里不依赖 OCR。OCR 只提供候选值或期望位数，
高风险数值必须由本模块确认字形后才采纳。
数字库可以不改代码就扩充：
编辑 素材/数字模板/<style>/manifest.json 并加入 PNG 样本即可。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal, InvalidOperation
from collections import OrderedDict
import hashlib
import json
import os
from pathlib import Path
import re
from typing import Iterable

import cv2
import numpy as np


DEFAULT_THRESHOLDS = (190, 180, 200, 170, 150, 210)
DEFAULT_MIN_SCORE = 0.72
DEFAULT_MIN_MARGIN = 0.025
DEFAULT_SEARCH_RADIUS = 1
FULLWIDTH_DIGITS = str.maketrans("０１２３４５６７８９", "0123456789")


@dataclass
class GlyphDecision:
    digit: str
    score: float
    second_digit: str
    second_score: float
    box: tuple

    @property
    def margin(self):
        return float(self.score - self.second_score)


@dataclass
class NumberDecision:
    digits: str = ""
    score: float = 0.0
    min_score: float = 0.0
    min_margin: float = 0.0
    expected: bool | None = None
    glyphs: list[GlyphDecision] = field(default_factory=list)
    threshold: int = 0
    reason: str = ""
    accepted: bool = False

    @property
    def ok(self):
        return bool(self.accepted and self.digits)

    @property
    def value(self):
        try:
            return int(self.digits)
        except (TypeError, ValueError):
            return 0


@dataclass
class ParsedNumber:
    ok: bool
    value: int | Decimal | None = None
    digits: str = ""
    sign: int = 1
    scale: int = 1
    reason: str = ""


def parse_numeric_text(text, syntax="amount"):
    """Parse OCR text containing one numeric value.

    Supported forms include ``1,314,520``, ``-36,352``, ``520.52K``,
    ``1.25万`` and full-width digits.  The returned integer is canonical when
    multiplication produces no fractional part; otherwise a Decimal is used.
    """
    raw = str(text or "").strip()
    if not raw:
        return ParsedNumber(False, reason="empty")
    raw = raw.translate(FULLWIDTH_DIGITS).upper()
    raw = re.sub(r"[\s\u00a0]", "", raw)
    raw = raw.replace("，", ",").replace("’", "'")
    raw = raw.replace("O", "0").replace("o", "0")
    raw = raw.replace("I", "1").replace("l", "1").replace("|", "1")
    match = re.search(
        r"([+\-]?)\s*(\d[\d,'’_]*)(?:\.(\d+))?\s*(K|M|B|W|万|亿)?",
        raw,
    )
    if not match:
        return ParsedNumber(False, reason="no numeric token")
    sign = -1 if match.group(1) == "-" else 1
    whole = re.sub(r"\D", "", match.group(2) or "")
    frac = re.sub(r"\D", "", match.group(3) or "")
    unit = match.group(4) or ""
    if not whole:
        return ParsedNumber(False, reason="no digits")
    scales = {"": 1, "K": 1000, "W": 10000, "万": 10000,
              "M": 1000000, "B": 1000000000, "亿": 100000000}
    scale = scales.get(unit, 1)
    decimal_text = whole + (("." + frac) if frac else "")
    try:
        value = Decimal(decimal_text) * scale * sign
    except InvalidOperation:
        return ParsedNumber(False, reason="invalid decimal")
    if value == value.to_integral_value():
        value = int(value)
        digits = str(abs(value))
    else:
        digits = decimal_text
    if syntax in ("integer", "amount", "signed_integer") and isinstance(value, Decimal):
        return ParsedNumber(False, digits=digits, sign=sign, scale=scale,
                            reason="integer syntax required")
    return ParsedNumber(True, value=value, digits=digits, sign=sign, scale=scale)


class DigitTemplateBank:
    """Load an editable digit-template pack from ``素材/数字模板``."""

    def __init__(self, root, style="white"):
        self.root = Path(root)
        self.style = str(style)
        self.pack_dir = self.root / self.style
        manifest_path = self.pack_dir / "manifest.json"
        if not manifest_path.is_file():
            raise FileNotFoundError(
                f"digit template manifest not found: {manifest_path}"
            )
        with manifest_path.open(encoding="utf-8") as fp:
            self.manifest = json.load(fp)
        self.canvas = tuple(int(v) for v in self.manifest.get("canvas", (32, 48)))
        self.threshold = int(self.manifest.get("threshold", 190))
        recognition = self.manifest.get("recognition", {})
        self.search_radius = max(
            0, int(recognition.get("search_radius", DEFAULT_SEARCH_RADIUS))
        )
        self.templates = {}
        for digit, names in self.manifest.get("digits", {}).items():
            values = []
            for name in names:
                path = self.pack_dir / name
                try:
                    raw = np.fromfile(str(path), dtype=np.uint8)
                    image = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
                except Exception:
                    image = None
                if image is not None:
                    values.append(image)
            if values:
                self.templates[str(digit)] = values
        missing = sorted(set("0123456789") - set(self.templates))
        if missing:
            raise ValueError(
                f"digit template pack is incomplete: missing {''.join(missing)}"
            )

    @staticmethod
    def _dice_score(glyph, template, search_radius=DEFAULT_SEARCH_RADIUS):
        a = glyph > 127
        b = template > 127
        sa, sb = int(a.sum()), int(b.sum())
        if sa == 0 or sb == 0:
            return 0.0
        best = 0.0
        radius = max(0, int(search_radius))
        for dy in range(-radius, radius + 1):
            for dx in range(-radius, radius + 1):
                shifted = np.roll(np.roll(b, dy, axis=0), dx, axis=1)
                inter = int(np.logical_and(a, shifted).sum())
                score = 2.0 * inter / float(sa + sb)
                if score > best:
                    best = score
        return best

    def classify(self, glyph):
        scores = {}
        for digit, templates in self.templates.items():
            scores[digit] = max(
                self._dice_score(glyph, item, self.search_radius)
                for item in templates
            )
        ordered = sorted(scores.items(), key=lambda item: item[1], reverse=True)
        return ordered[0][0], float(ordered[0][1]), ordered[1][0], float(ordered[1][1])


class VisualNumericReader:
    """Segment and identify a numeric run without relying on OCR."""

    def __init__(self, template_root, style="white"):
        self.bank = DigitTemplateBank(template_root, style=style)
        config = self.bank.manifest.get("recognition", {})
        self.thresholds = tuple(
            int(v) for v in config.get("thresholds", DEFAULT_THRESHOLDS)
        )
        self.default_min_score = float(
            config.get("min_score", DEFAULT_MIN_SCORE)
        )
        self.default_min_margin = float(
            config.get("min_margin", DEFAULT_MIN_MARGIN)
        )
        self.cache_entries = max(0, int(config.get("cache_entries", 96)))
        self._decision_cache = OrderedDict()
        self.cache_hits = 0
        self.cache_misses = 0

    @staticmethod
    def _foreground_gray(image):
        arr = np.asarray(image)
        if arr.ndim == 2:
            return arr
        if arr.shape[2] >= 3:
            return arr[:, :, :3].max(axis=2)
        return arr[:, :, 0]

    def _normalize_glyph(self, mask, bbox):
        x, y, w, h = bbox
        glyph = mask[y:y + h, x:x + w]
        target_w, target_h = self.bank.canvas
        scale = min((target_w - 4) / max(w, 1),
                    (target_h - 4) / max(h, 1))
        nw = max(1, int(round(w * scale)))
        nh = max(1, int(round(h * scale)))
        glyph = cv2.resize(glyph, (nw, nh), interpolation=cv2.INTER_NEAREST)
        out = np.zeros((target_h, target_w), dtype=np.uint8)
        ox = (target_w - nw) // 2
        oy = (target_h - nh) // 2
        out[oy:oy + nh, ox:ox + nw] = glyph
        return out

    @staticmethod
    def _components(mask):
        count, _labels, stats, _centroids = cv2.connectedComponentsWithStats(mask, 8)
        comps = []
        for index in range(1, count):
            x, y, w, h, area = map(int, stats[index])
            if area < 10 or h < 8 or w < 2:
                continue
            # Currency icons and Chinese label fragments are generally wider
            # than an Arabic digit.  Punctuation is rejected later by height.
            if float(w) / max(float(h), 1.0) > 1.15:
                continue
            comps.append((x, y, w, h, area))
        return comps

    @staticmethod
    def _digit_groups(comps):
        """Group components into rows and horizontally adjacent digit runs."""
        rows = []
        for comp in sorted(comps, key=lambda item: (item[1] + item[3] / 2.0, item[0])):
            center_y = comp[1] + comp[3] / 2.0
            target = None
            for row in rows:
                avg_y = sum(item[1] + item[3] / 2.0 for item in row) / len(row)
                avg_h = sum(item[3] for item in row) / len(row)
                if abs(center_y - avg_y) <= max(5.0, avg_h * 0.42):
                    target = row
                    break
            if target is None:
                rows.append([comp])
            else:
                target.append(comp)

        groups = []
        for row in rows:
            if not row:
                continue
            max_h = max(item[3] for item in row)
            # Drop commas, dots, thin borders and tiny label fragments.  The
            # remaining items are full-height glyph candidates.
            row = [item for item in row if item[3] >= max_h * 0.50]
            if not row:
                continue
            row.sort(key=lambda item: item[0])
            run = [row[0]]
            for comp in row[1:]:
                prev = run[-1]
                gap = comp[0] - (prev[0] + prev[2])
                avg_h = (prev[3] + comp[3]) / 2.0
                if gap > max(9.0, avg_h * 0.72):
                    groups.append(run)
                    run = [comp]
                else:
                    run.append(comp)
            groups.append(run)
        return groups

    @staticmethod
    def _canonical_expected(expected_value):
        if expected_value is None:
            return None
        parsed = parse_numeric_text(expected_value, syntax="amount")
        if parsed.ok and parsed.value is not None:
            return str(abs(int(parsed.value)))
        return re.sub(r"\D", "", str(expected_value))

    def recognize(self, image, expected_count=None, expected_value=None,
                  min_score=None, min_margin=None, thresholds=None,
                  min_digits=None, max_digits=None):
        """Read one numeric line.

        ``expected_value`` is the strongest constraint and is intended for
        input-box verification.  ``expected_count`` disambiguates candidate
        runs when the expected value itself is not known.  A returned decision
        is accepted only when every glyph clears both confidence limits and
        any supplied expected value matches exactly.
        """
        arr = np.asarray(image)
        if arr.size == 0:
            return NumberDecision(reason="empty image")
        wanted = self._canonical_expected(expected_value)
        if wanted:
            expected_count = len(wanted)
        min_score = (self.default_min_score if min_score is None
                     else float(min_score))
        min_margin = (self.default_min_margin if min_margin is None
                      else float(min_margin))
        min_digits = (None if min_digits is None else int(min_digits))
        max_digits = (None if max_digits is None else int(max_digits))
        threshold_values = tuple(
            int(v) for v in (thresholds if thresholds is not None
                             else self.thresholds)
        )
        digest = hashlib.blake2b(
            np.ascontiguousarray(arr).tobytes(), digest_size=16
        ).hexdigest()
        key = (
            digest, tuple(arr.shape), str(arr.dtype), expected_count, wanted,
            min_score, min_margin, threshold_values, min_digits, max_digits,
        )
        cached = self._decision_cache.get(key)
        if cached is not None:
            self.cache_hits += 1
            self._decision_cache.move_to_end(key)
            return cached
        self.cache_misses += 1
        result = self._recognize_uncached(
            arr,
            expected_count=expected_count,
            wanted=wanted,
            min_score=min_score,
            min_margin=min_margin,
            threshold_values=threshold_values,
            min_digits=min_digits,
            max_digits=max_digits,
        )
        if self.cache_entries > 0:
            self._decision_cache[key] = result
            self._decision_cache.move_to_end(key)
            while len(self._decision_cache) > self.cache_entries:
                self._decision_cache.popitem(last=False)
        return result

    def _recognize_uncached(self, image, expected_count, wanted,
                            min_score, min_margin, threshold_values,
                            min_digits=None, max_digits=None):
        gray = self._foreground_gray(image)
        if gray.size == 0:
            return NumberDecision(reason="empty image")
        attempts = []
        for threshold in threshold_values:
            mask = np.where(gray > threshold, 255, 0).astype(np.uint8)
            comps = self._components(mask)
            if not comps:
                continue
            groups = self._digit_groups(comps)
            if expected_count is not None:
                groups = [group for group in groups
                          if len(group) == int(expected_count)]
            else:
                groups = [
                    group for group in groups
                    if (min_digits is None or len(group) >= min_digits)
                    and (max_digits is None or len(group) <= max_digits)
                ]
            for digits in groups:
                if not digits:
                    continue
                glyphs = []
                for comp in digits:
                    normalized = self._normalize_glyph(mask, comp[:4])
                    digit, score, second, second_score = self.bank.classify(normalized)
                    glyphs.append(GlyphDecision(
                        digit=digit,
                        score=score,
                        second_digit=second,
                        second_score=second_score,
                        box=comp[:4],
                    ))
                result = NumberDecision(
                    digits="".join(item.digit for item in glyphs),
                    score=sum(item.score for item in glyphs) / len(glyphs),
                    min_score=min(item.score for item in glyphs),
                    min_margin=min(item.margin for item in glyphs),
                    glyphs=glyphs,
                    threshold=threshold,
                    reason="template match",
                )
                result.accepted = bool(
                    result.digits
                    and result.min_score >= min_score
                    and result.min_margin >= min_margin
                    and (wanted is None or result.digits == wanted)
                )
                result.expected = None if wanted is None else result.digits == wanted
                attempts.append(result)
                if result.accepted:
                    return result

        if attempts:
            result = max(
                attempts,
                key=lambda item: (
                    item.expected is True,
                    item.min_score,
                    item.min_margin,
                    item.score,
                ),
            )
            result.accepted = False
            result.expected = False if wanted is not None else None
            result.reason = "template confidence or expected value rejected"
            return result
        return NumberDecision(
            expected=False if wanted is not None else None,
            reason="no segmented digit line",
        )

    def clear_cache(self):
        self._decision_cache.clear()

    def verify(self, image, expected_value, **kwargs):
        decision = self.recognize(
            image,
            expected_value=expected_value,
            **kwargs,
        )
        return decision.ok, decision


def default_template_root(script_dir):
    return os.path.join(script_dir, "素材", "数字模板")


