# -*- coding: utf-8 -*-
"""把视觉记录导出成训练样本 —— 每格一条，带它周围的情况。

为什么这么导
  识别器最容易错的不是「完全不认识」，是「颜色对、尺寸对、但拿不准是哪一件」。
  这种格子如果要改进，需要知道它四周摆着什么 —— 相邻的件经常成套出现。
  所以每条样本不只记这一格，也记上它上下左右是什么。

数据从哪来
  试验记录.jsonl 里 warehouse_vision 的 items。同一局扫了好几回合的，
  默认只取最后一回合（认得最全的那次），--all-rounds 可以全留。

导出什么
  训练数据\\visual_samples.jsonl   每格一条
  训练数据\\auction_index.csv      每局一行，方便一眼看全局
  训练数据\\manifest.json          导出时间、条数、来源
  训练数据\\README.txt             给未来的自己看

用法
  python training_export.py                    # 全量导出
  python training_export.py --only-uncertain   # 只导不确定的格子
  python training_export.py --all-rounds       # 每个回合都留
"""

import argparse
import csv
import io
import json
import os
import sys
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RECORD = HERE.parent / "记录" / "试验记录.jsonl"
DEFAULT_OUT = HERE.parent / "训练数据"

COLS = 10
ROWS = 25


def _iter_jsonl(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except (ValueError, TypeError):
                continue


def _num(v, default=0.0):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _neighbors(item, grid):
    """这一格上下左右最近的是什么件。中间隔着空格就一直往那个方向找。"""
    try:
        cx = int(item.get("x") or 0) + max(1, int(item.get("w") or 1)) // 2
        cy = int(item.get("y") or 0) + max(1, int(item.get("h") or 1)) // 2
    except (TypeError, ValueError):
        return {}

    def pick(dx, dy):
        for step in range(1, 4):
            x = cx + dx * step
            y = cy + dy * step
            if 0 <= x < COLS and 0 <= y < ROWS:
                got = grid[y][x]
                if got:
                    return got
        return ""

    return {"up": pick(0, -1), "down": pick(0, 1),
            "left": pick(-1, 0), "right": pick(1, 0)}


def _grid_of(items):
    grid = [["" for _ in range(COLS)] for _ in range(ROWS)]
    for it in items:
        try:
            x0 = int(it.get("x") or 0)
            y0 = int(it.get("y") or 0)
            w = max(1, int(it.get("w") or 1))
            h = max(1, int(it.get("h") or 1))
        except (TypeError, ValueError):
            continue
        name = str(it.get("item") or "")
        for dx in range(w):
            for dy in range(h):
                gx, gy = x0 + dx, y0 + dy
                if 0 <= gx < COLS and 0 <= gy < ROWS:
                    grid[gy][gx] = name
    return grid


def collect(path, all_rounds=False):
    """按局号攒：最后一次（或每回合）的识别结果 + 这一局的结局。"""
    per_auction = {}
    ends = {}
    for ev in _iter_jsonl(path):
        kind = ev.get("type")
        try:
            no = int(ev.get("auction_no") or 0)
        except (TypeError, ValueError):
            continue
        if kind == "auction_end":
            ends[no] = ev
            continue
        if kind != "warehouse_vision":
            continue
        items = ev.get("items") or []
        if not items:
            continue
        per_auction.setdefault(no, []).append(ev)

    picked = []
    for no, events in per_auction.items():
        events.sort(key=lambda e: (int(_num(e.get("round"), 0)),
                                   str(e.get("ts") or "")))
        chosen = events if all_rounds else events[-1:]
        for ev in chosen:
            picked.append((no, ev, ends.get(no)))
    picked.sort(key=lambda t: (t[0], str(t[1].get("ts") or "")))
    return picked


def sample_rows(no, ev, end, only_uncertain=False):
    items = ev.get("items") or []
    grid = _grid_of(items)
    blocks = int(_num(ev.get("block_count"), 0))
    named = int(_num(ev.get("named_count"), 0))
    named_ratio = (named / float(blocks)) if blocks > 0 else 0.0
    head = {
        "auction_no": no,
        "round": int(_num(ev.get("round"), 0)),
        "ts": str(ev.get("ts") or ""),
        "game_estimate": int(_num(ev.get("game_estimate"), 0)),
        "mean_total": int(_num(ev.get("mean_total"), 0)),
        "min_total": int(_num(ev.get("min_total"), 0)),
        "p75_total": int(_num(ev.get("p75_total"), 0)),
        "checksum_ok": bool(ev.get("checksum_ok")),
        "named_ratio": round(named_ratio, 4),
        "capture_coverage": round(_num(ev.get("capture_coverage"), 0), 4),
    }
    if end is not None:
        head["actual_value"] = int(_num(end.get("actual_value"), 0))
        head["final_price"] = int(_num(end.get("final_price"), 0))
        head["result"] = str(end.get("result") or "")

    out = []
    for it in items:
        conf = it.get("top_candidate_confidence")
        try:
            conf = float(conf) if conf is not None else None
        except (TypeError, ValueError):
            conf = None
        if only_uncertain and (conf is None or conf >= 0.99):
            continue
        row = dict(head)
        row.update({
            "x": int(_num(it.get("x"), 0)),
            "y": int(_num(it.get("y"), 0)),
            "w": max(1, int(_num(it.get("w"), 1))),
            "h": max(1, int(_num(it.get("h"), 1))),
            "color": str(it.get("color") or ""),
            "item": str(it.get("item") or ""),
            "source": str(it.get("source") or ""),
            "confidence": round(conf, 4) if conf is not None else None,
            "candidates": [str(c.get("name") or "")
                           for c in (it.get("candidate_top") or [])[:4]],
            "neighbors": _neighbors(it, grid),
        })
        out.append(row)
    return out, head


def write_outputs(out_dir, samples, head_rows, source_path):
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    jsonl = out_dir / "visual_samples.jsonl"
    with open(jsonl, "w", encoding="utf-8", newline="\n") as fp:
        for row in samples:
            fp.write(json.dumps(row, ensure_ascii=False,
                                separators=(",", ":")) + "\n")

    index = out_dir / "auction_index.csv"
    with open(index, "w", encoding="utf-8-sig", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["局号", "回合", "时间", "件数", "认出比", "均值",
                         "估价", "P75", "校验", "实际值", "成交价", "结果"])
        for head in head_rows:
            writer.writerow([
                head["auction_no"], head["round"], head["ts"],
                len([s for s in samples if s["auction_no"] == head["auction_no"]
                     and s["round"] == head["round"]]),
                "%.0f%%" % (head["named_ratio"] * 100),
                head["mean_total"], head["game_estimate"], head["p75_total"],
                "通过" if head["checksum_ok"] else "未通过",
                head.get("actual_value", ""), head.get("final_price", ""),
                head.get("result", ""),
            ])

    manifest = {
        "version": 1,
        "exported_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": str(source_path),
        "source_bytes": os.path.getsize(source_path)
        if os.path.isfile(source_path) else 0,
        "auctions": len(head_rows),
        "samples": len(samples),
        "uncertain": sum(1 for s in samples
                         if s.get("confidence") is None
                         or s["confidence"] < 0.99),
        "files": ["visual_samples.jsonl", "auction_index.csv"],
    }
    with open(out_dir / "manifest.json", "w", encoding="utf-8",
              newline="\n") as fp:
        json.dump(manifest, fp, ensure_ascii=False, indent=2)
        fp.write("\n")

    readme = out_dir / "README.txt"
    readme.write_text(
        "训练数据\n"
        "========================================================\n\n"
        "这几个文件是 training_export.py 从 记录\\试验记录.jsonl 导出来的。\n"
        "换个号、多挂几局之后重跑一次就行，会整个覆盖。\n\n"
        "visual_samples.jsonl   每格一条，一行一个 JSON\n"
        "   局号 / 回合 / 时间           哪次扫的\n"
        "   x y w h                      格子位置和尺寸\n"
        "   color / item / source        颜色、认成什么、怎么认的\n"
        "   confidence                   这次认得有多稳（0~1，null=没算）\n"
        "   candidates                   候选名字，第一个就是认的那个\n"
        "   neighbors                    上下左右最近的是什么件\n"
        "   game_estimate / mean_total   这局的游戏估价、视觉均值\n"
        "   actual_value / final_price   最后这仓实际值多少、成交多少\n\n"
        "auction_index.csv      每局一行，扫一眼就知道哪几局有问题\n\n"
        "manifest.json          导出时间、多少局多少条、源文件多大\n\n"
        "怎么用\n"
        "  普通看到「认错的件」：打开 visual_samples.jsonl，\n"
        "  按 confidence 排序，最低的那几条就是最可疑的。\n"
        "  想训练：拿 color + w + h + neighbors 当输入，item 当标签。\n\n"
        "注意\n"
        "  confidence 是 null 说明那次扫描没算置信（老记录），不是 0。\n"
        "  item 为空 = 这一格根本没认出来。别删，这正好是「认不出的长什么样」\n"
        "  的样本，将来补模板就靠它。\n"
        "  actual_value 只有拍完的局才有，中途退出的局这列是空的。\n",
        encoding="utf-8", newline="\n")
    return jsonl, index, manifest


def main(argv=None):
    parser = argparse.ArgumentParser(description="导出视觉训练样本")
    parser.add_argument("--records", default=str(DEFAULT_RECORD))
    parser.add_argument("--out", default=str(DEFAULT_OUT))
    parser.add_argument("--only-uncertain", action="store_true",
                        help="只导置信 < 99% 的格子")
    parser.add_argument("--all-rounds", action="store_true",
                        help="同一局每个回合都留（默认只留最后一回合）")
    args = parser.parse_args(argv)

    src = Path(args.records)
    if not src.is_file():
        print("找不到记录文件：%s" % src)
        return 2

    picked = collect(src, all_rounds=args.all_rounds)
    if not picked:
        print("记录里还没有带 items 的视觉事件，没东西可导。")
        print("先跑几局（或者点几次「扫一次仓」）再来。")
        return 1

    samples = []
    heads = []
    for no, ev, end in picked:
        rows, head = sample_rows(no, ev, end,
                                 only_uncertain=args.only_uncertain)
        samples.extend(rows)
        heads.append(head)

    if not samples:
        print("有 %d 次扫描，但没有符合条件的格子（--only-uncertain 太严？）"
              % len(heads))
        return 1

    jsonl, index, manifest = write_outputs(args.out, samples, heads, src)
    print("导出完成：%d 局 / %d 次扫描 / %d 条样本" % (
        len({h["auction_no"] for h in heads}), len(heads), manifest["samples"]))
    print("  其中认不准的 %d 条" % manifest["uncertain"])
    print("  %s" % jsonl)
    print("  %s" % index)
    print("  %s" % (Path(args.out) / "manifest.json"))
    return 0


if __name__ == "__main__":
    sys.exit(main())