# -*- coding: utf-8 -*-
"""离线分析脚本：把试验记录和报错日志汇总成纯文本报告。

不参与挂机主流程，只读记录目录、写分析报告与报错汇总。
"""
from __future__ import annotations

import datetime as dt
import json
import os
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = HERE
for _d in (HERE, os.path.dirname(HERE)):
    if os.path.isdir(os.path.join(_d, "python")) or os.path.isdir(os.path.join(_d, "素材")):
        BASE = _d
        break
JSONL = os.path.join(BASE, "记录", "试验记录.jsonl")
SHOT_DIR = os.path.join(BASE, "记录", "截图")
REPORT = os.path.join(BASE, "记录", "分析报告.txt")
ERROR_TXT = os.path.join(BASE, "记录", "报错日志.txt")
ERROR_JSONL = os.path.join(BASE, "记录", "报错日志.jsonl")
ERROR_SHOT_DIR = os.path.join(BASE, "记录", "报错截图")

COST_ENTRY = 20000
COST_INSTRUMENT_R1 = 10000
COST_INSTRUMENT_R2 = 50000

def load_records(path):
    if not os.path.exists(path):
        return []
    out = []
    with open(path, "r", encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                continue
    return out

def fmt(n):
    try:
        return f"{int(n):,}"
    except Exception:
        return str(n)

def wan(n):
    try:
        return f"{int(n) / 10000:.1f}万"
    except Exception:
        return str(n)

def mean(seq):
    return sum(seq) / len(seq) if seq else 0.0

def parse_ts(s):
    try:
        return dt.datetime.strptime(s, "%Y-%m-%d %H:%M:%S")
    except Exception:
        return None

def my_profit_of(r):
    if r.get("my_profit") is not None:
        return int(r["my_profit"])
    if r.get("result") == "won":
        return int(r.get("profit", 0) or 0)
    wp = r.get("profit", 0) or 0
    return int(-wp * 0.1) if wp < 0 else 0

def cost_of(r):
    if r.get("cost") is not None:
        return int(r["cost"]), False
    n = int(r.get("rounds_played", 0) or 0)
    c = COST_ENTRY
    if n >= 1:
        c += COST_INSTRUMENT_R1
    if n >= 2:
        c += COST_INSTRUMENT_R2
    return c, True

def collect(records):
    g = {k: [r for r in records if r.get("type") == k] for k in (
        "session_start", "session_end", "auction_start", "auction_end",
        "bid_decision", "bid_submitted", "bid_fail", "round_start", "round_fail",
        "step_timeout", "crash", "alarm", "funds_stop", "shot", "heartbeat",
        "settle_step")}
    g["starts_by_no"] = {r.get("auction_no"): r for r in g["auction_start"]}
    g["all"] = records
    return g

def section_overview(g, p):
    ends = g["auction_end"]
    won = [r for r in ends if r.get("result") == "won"]
    lost = [r for r in ends if r.get("result") == "lost"]
    quit_ = [r for r in ends if r.get("result") == "quit"]
    losing = [r for r in won if r.get("profit", 0) < 0]
    my_total = sum(my_profit_of(r) for r in ends)
    win_profit = sum(r.get("profit", 0) for r in won)
    bonus_total = sum(my_profit_of(r) for r in ends if r.get("result") != "won")
    winner_total = sum(r.get("profit", 0) for r in ends if r.get("result") != "won")
    costs = [(cost_of(r)[0], cost_of(r)[1]) for r in ends]
    total_cost = sum(c for c, _ in costs)
    net_total = my_total - total_cost
    est_count = sum(1 for _, est in costs if est)
    r1_count = sum(1 for r in ends if int(r.get("rounds_played", 0) or 0) >= 1)
    r2_count = sum(1 for r in ends if int(r.get("rounds_played", 0) or 0) >= 2)

    p("-" * 78)
    p("一、总览")
    p("-" * 78)
    if g["session_start"]:
        s = g["session_start"][-1]
        p("本次参数：智能出价={}  上限={}x估价  加价余量={}  最小估价={}".format(
            s.get("smart_bidding"), s.get("cap_ratio"), s.get("margin"),
            fmt(s.get("min_estimate"))))
    if not ends:
        p("还没有完整对局记录。")
        return None
    p(f"对局数        {len(ends)}")
    p(f"我拍到        {len(won)}   ({len(won) / len(ends):.1%})")
    p(f"他人拍走      {len(lost)}     中途退出 {len(quit_)}")
    p(f"我的总收益    {fmt(my_total)} 金贝铢   （成交赚 {fmt(win_profit)} + 他人亏损分成 {fmt(bonus_total)}）")
    p(f"平均每局      {fmt(my_total / len(ends))}")
    p("")
    p(f"总成本        {fmt(total_cost)}   （入场费 {len(ends):,}×{COST_ENTRY:,}"
      f" + 第1回合仪器 {r1_count:,}×{COST_INSTRUMENT_R1:,}"
      f" + 巨物 {r2_count:,}×{COST_INSTRUMENT_R2:,}）"
      + (f"  ⚠️ 其中 {est_count} 局是按回合数估算的（老记录没有 cost 字段）" if est_count else ""))
    p(f"净收益        {fmt(net_total)}   （总收益 − 总成本）")
    p(f"平均每局净收益 {fmt(net_total / len(ends))}"
      f"{'   ✅ 赚钱' if net_total > 0 else '   ❌ 亏钱'}")
    p(f"每局成本口径   入场费 {COST_ENTRY:,} + 第1回合仪器 {COST_INSTRUMENT_R1:,} + 巨物 {COST_INSTRUMENT_R2:,}"
      f"（没打到第2回合就只有 {COST_ENTRY + COST_INSTRUMENT_R1:,}）")
    if won:
        p(f"对局赢家合计  {fmt(winner_total)}（别人拍走的那些局里，赢家的总盈亏）")
    if won:
        p(f"成交单        盈利 {len(won) - len(losing)} / 亏损 {len(losing)}"
          f"   亏损率 {len(losing) / len(won):.1%}")
        p(f"平均成交价    {fmt(mean([r.get('final_price', 0) for r in won]))}")
        p(f"平均实际价值  {fmt(mean([r.get('actual_value', 0) for r in won]))}")
        p(f"平均每单收益  {fmt(mean([r.get('profit', 0) for r in won]))}")
        ratios = [r["final_price"] / r["rounds"][0]["estimate"] for r in won
                  if r.get("rounds") and r["rounds"][0].get("estimate")]
        if ratios:
            p(f"成交价/首回合估价   {mean(ratios):.3f}"
              f"（{min(ratios):.3f} ~ {max(ratios):.3f}）")

    durs = []
    for r in ends:
        st = g["starts_by_no"].get(r.get("auction_no"))
        a, b = (parse_ts(st["ts"]) if st else None), parse_ts(r.get("ts"))
        if a and b:
            d = (b - a).total_seconds()
            if 0 < d < 3600:
                durs.append(d)
    if durs:
        p(f"单局耗时      平均 {mean(durs):.1f}s（{min(durs):.0f} ~ {max(durs):.0f}s）")
    return dict(ends=ends, won=won, lost=lost, quit=quit_, losing=losing,
                total=my_total, durs=durs, bonus_total=bonus_total,
                total_cost=total_cost, net_total=net_total, costs=costs)

def section_diagnosis(g, ov, p):
    p("")
    p("-" * 78)
    p("二、自动诊断（本次实测告诉我该怎么调）")
    p("-" * 78)
    if not ov:
        return
    ends, won, losing, durs = ov["ends"], ov["won"], ov["losing"], ov["durs"]
    tips = []
    mode = ""
    if g["session_start"]:
        mode = str(g["session_start"][-1].get("price_mode") or "")

    if won:
        lr = len(losing) / len(won)
        if lr > 0.02:
            tips.append(f"⚠️ 亏损率 {lr:.1%}：说明买贵了。跟价模式下看这几局的「出价/估价」是不是贴到 1.30 顶格了。")
        else:
            tips.append(f"✅ 亏损率 {lr:.1%}，上限保护有效（估价是价值下限，压住就不会亏）。")
        wr = len(won) / len(ends)
        if wr < 0.15:
            if mode == "opponent":
                tips.append(f"ℹ️ 胜率 {wr:.1%} 偏低是**预期内**的：跟价模式故意只比对手高一点点，"
                            f"抢不到就说明对手已经出到接近估价，那种仓本来就没有信息差可赚。"
                            f"不要为了胜率去抬价——赚钱靠信息差，不是靠抢。")
            else:
                tips.append(f"⚠️ 胜率仅 {wr:.1%}：出价贴得比较死；可小幅放宽（例如 +3%~5%），"
                            f"但注意亏损率会跟着涨。")
        elif wr > 0.60:
            tips.append(f"ℹ️ 胜率 {wr:.1%} 偏高，可考虑把上限降到 0.95 用更低价格赢（提高单均利润）。")
    if ov.get("bonus_total"):
        share = ov["bonus_total"] / max(1, ov["total"])
        tips.append(f"💰 其中「他人亏损分成」贡献 {ov['bonus_total']:,}（占总收益 {share:.0%}）—— "
                    f"对手越爱乱出价，这部分越可观；说明不必为了抢而抬高自己的出价。")

    total_cost = ov.get("total_cost", 0)
    net_total = ov.get("net_total", 0)
    if ends and total_cost:
        quit_cost = sum(cost_of(r)[0] for r in ov["quit"])
        won_cost = sum(cost_of(r)[0] for r in ov["won"])
        lost_cost = sum(cost_of(r)[0] for r in ov["lost"])
        full_cost = COST_ENTRY + COST_INSTRUMENT_R1 + COST_INSTRUMENT_R2
        tips.append(f"💸 成本 {total_cost:,}【入场费 {COST_ENTRY:,}/局 + 第1回合仪器 {COST_INSTRUMENT_R1:,}"
                    f" + 巨物 {COST_INSTRUMENT_R2:,}，没打到第2回合只花 {COST_ENTRY + COST_INSTRUMENT_R1:,}】："
                    f"中途退出 {quit_cost:,}（{len(ov['quit'])} 局·纯支出）／"
                    f"我拍到 {won_cost:,}／他人拍走 {lost_cost:,}。")
        tips.append(f"🎯 回本线：打满回合的一局成本 {full_cost:,}，所以「每局平均净收益 > 0」才算真的赚；"
                    f"本次平均每局净收益 {net_total / len(ends):+,.0f}。")
        if net_total < 0:
            tips.append("❌ 净收益为负：赚的那点差价覆盖不了空跑成本。两条路——"
                        "①少跑局（收紧 SMART_BID_EXIT_MIN_ESTIMATE / 信息差闸门，只打有把握的仓）；"
                        "②提高单局利润。优先试 ①。")
        elif quit_cost > net_total:
            tips.append(f"⚠️ 退出局花掉 {quit_cost:,}，比净收益 {net_total:,} 还多——"
                        f"空跑是当前最大的成本项，值得收紧退出条件或减少无效局。")
        else:
            tips.append(f"✅ 净收益 {net_total:,} 覆盖了全部成本，当前闸门设置是划算的。")

    tos = Counter(r.get("step") for r in g["step_timeout"])
    if tos:
        top = "、".join(f"{k}({v}次)" for k, v in tos.most_common(3))
        tips.append(f"⚠️ 主要卡点：{top} —— 看 记录/截图/ 里对应的「超时_xxx.jpg」，"
                    f"多半是那一步的界面没认出来或 UI 变慢了。")
    if g["round_fail"]:
        tips.append(f"⚠️ 有 {len(g['round_fail'])} 次估价识别失败导致退出本局，"
                    f"看记录里的 ocr.value_raw 原文判断是 OCR 读错还是界面没加载完。")
    if g["crash"]:
        tips.append(f"❌ 主循环异常 {len(g['crash'])} 次，记录里有 traceback_text 和崩溃截图。")
    if durs and mean(durs) > 120:
        tips.append(f"ℹ️ 单局平均 {mean(durs):.0f} 秒偏长，建议看截图确认是否某步在空等。")
    if not tos and not g["round_fail"] and not g["crash"]:
        tips.append("✅ 没有超时、没有识别失败、没有异常 —— 流程本身是稳的，剩下的只是策略调参。")

    for t in tips:
        p("• " + t)

def section_bidding(g, p):
    p("")
    p("-" * 78)
    p("三、出价行为（引擎是否按规则走）")
    p("-" * 78)
    decisions = g["bid_decision"]
    p(f"出价决策 {len(decisions)} 次，实际提交 {len(g['bid_submitted'])} 次，"
      f"提交失败 {len(g['bid_fail'])} 次")
    by_round = {}
    for d in decisions:
        by_round.setdefault(d.get("round"), []).append(d)
    if by_round:
        p("")
        p(f"{'回合':>4}{'次数':>8}{'平均出价/估价':>16}{'平均上限/估价':>16}{'规则倍数':>10}")
        for rnd in sorted(k for k in by_round if isinstance(k, int)):
            items = by_round[rnd]
            ratios = [i["price"] / i["estimate"] for i in items
                      if i.get("price") and i.get("estimate")]
            caps = [i["cap"] / i["estimate"] for i in items
                    if i.get("cap") and i.get("estimate")]
            ks = [i.get("k", 0) for i in items]
            p(f"{rnd:>4}{len(items):>8}{mean(ratios):>16.3f}{mean(caps):>16.3f}{mean(ks):>10.2f}")
        p("")
        p("注：第 1、2 回合的「出价/估价」偏高是**故意的**——那两回合走硬保底价，")
        p("    小仓的估价可能只有几万，出价却会按随机保底托高，目的是不让对手低价拿走、撑到第 3 回合看信息。")
    floor = 0
    cap_ratio = 1.0
    if g["session_start"]:
        try:
            _s = g["session_start"][-1]
            floor = int(_s.get("floor_bid") or 0)
            cap_ratio = float(_s.get("cap_ratio") or 1.0)
        except Exception:
            pass
    limit = cap_ratio + 0.02
    def _decision_floor(d):
        try:
            return int(d.get("floor_bid") or floor or 0)
        except Exception:
            return floor
    is_floor = lambda d: (int(d.get("round", 0) or 0) <= 2
                          and _decision_floor(d) > 0
                          and int(d.get("price") or 0) == _decision_floor(d))
    over = [d for d in decisions if d.get("price") and d.get("estimate")
            and d["price"] > d["estimate"] * limit and not is_floor(d)]
    premium = [d for d in decisions if d.get("price") and d.get("estimate")
               and d["estimate"] * 1.0001 < d["price"] <= d["estimate"] * limit
               and not is_floor(d)]
    p("")
    p(f"{'⚠️ 有 ' + str(len(over)) + ' 次出价超过了估价 ×' + f'{cap_ratio:.2f}' + '（上限没生效！）' if over else '✅ 没有一次出价超过「估价 ×' + f'{cap_ratio:.2f}' + '」的上限，保护生效'}")
    if premium:
        p(f"ℹ️ 有 {len(premium)} 次出价落在估价的 1.00~{cap_ratio:.2f} 倍之间（{min(d['price']/d['estimate'] for d in premium):.2f}~"
          f"{max(d['price']/d['estimate'] for d in premium):.2f} 倍）—— 这是第 3 回合起**故意**的「控制亏损的溢价」，不是 bug。")
    if floor:
        nf = sum(1 for d in decisions if is_floor(d))
        p(f"ℹ️ 另有 {nf} 次是前两回合的随机硬保底（故意高于小仓估价、逼对手不能低价拿仓，不算越权）")

def section_health(g, p):
    p("")
    p("-" * 78)
    p("四、运行健康度（无人值守时判断有没有卡死/中断）")
    p("-" * 78)
    all_ts = [parse_ts(r.get("ts")) for r in g["all"]]
    all_ts = [t for t in all_ts if t]
    if all_ts:
        p(f"记录时间跨度    {min(all_ts).strftime('%m-%d %H:%M:%S')} ~ "
          f"{max(all_ts).strftime('%m-%d %H:%M:%S')}")
    p(f"心跳次数        {len(g['heartbeat'])}（正常约每 5 分钟一次；心跳停止=脚本已退出或卡死）")
    if g["heartbeat"]:
        last_hb = parse_ts(g["heartbeat"][-1].get("ts"))
        if last_hb and all_ts:
            gap = (max(all_ts) - last_hb).total_seconds()
            p(f"末次心跳距最后一条记录 {gap:.0f} 秒")
    p(f"会话开始/结束   {len(g['session_start'])} / {len(g['session_end'])}")
    if g["session_end"]:
        p("结束原因        " + str(g["session_end"][-1].get("reason")))
    else:
        p("结束原因        没有 session_end —— 进程是被强制关闭的（关窗口/断电）")
    p(f"卡点(超时)      {len(g['step_timeout'])} 次")
    p(f"识别失败        {len(g['round_fail'])} 次")
    p(f"主循环异常      {len(g['crash'])} 次")
    p(f"警报/资金停止   {len(g['alarm'])} / {len(g['funds_stop'])} 次")

def section_recent(g, p):
    ends = g["auction_end"]
    p("")
    p("-" * 78)
    p("五、最近 15 局明细")
    p("-" * 78)
    p(f"{'局号':>6}{'结果':>9}{'回合':>5}{'最高估价':>11}{'成交价':>11}"
      f"{'实际价值':>11}{'我的收益':>11}{'成本':>8}{'净收益':>11}")
    for r in ends[-15:]:
        res = {"won": "我拍到", "lost": "他人拍走", "quit": "退出"}.get(r.get("result"), "?")
        c, est = cost_of(r)
        myp = my_profit_of(r)
        p(f"{str(r.get('auction_no')):>6}{res:>9}{str(r.get('rounds_played', 0)):>5}"
          f"{wan(r.get('max_estimate', 0)):>11}{wan(r.get('final_price', 0)):>11}"
          f"{wan(r.get('actual_value', 0)):>11}{wan(myp):>11}"
          f"{wan(c) + ('*' if est else ''):>8}{wan(myp - c):>11}")
    p("（金额单位：万；* = 老记录没有 cost 字段，按回合数估算）")

    rounds_hist = Counter(len(r.get("rounds") or []) for r in ends)
    if rounds_hist:
        p("")
        p("本局出价回合数分布：" + "，".join(f"{k}回合×{v}局" for k, v in sorted(rounds_hist.items())))
    losing = [r for r in ends if r.get("result") == "won" and r.get("profit", 0) < 0]
    if losing:
        p("")
        p("亏损单：")
        for r in losing[:10]:
            p(f"  第 {r.get('auction_no')} 局：成交 {fmt(r.get('final_price'))}"
              f" / 实际 {fmt(r.get('actual_value'))} / 收益 {fmt(r.get('profit'))}")

def section_timing(g, p):
    p("")
    p("-" * 78)
    p("六、结算 & 退出耗时（每秒都是挂机时间，这里看哪里能省）")
    p("-" * 78)
    steps = g["settle_step"]
    if not steps:
        p("（本批还没有分步计时记录 —— 下一批开始会自动记）")
        return
    by = {}
    for s in steps:
        by.setdefault(s.get("step"), []).append((s.get("ms") or 0) / 1000.0)
    p(f"{'步骤':<22}{'次数':>6}{'平均':>10}{'最大':>10}")
    order = {"skip_anim": 1, "wait_stable": 2, "sell": 3, "recognize": 4,
             "recognize_others": 4, "exit_to_hall": 5, "exit_flow_B": 5, "total": 9}
    for k, v in sorted(by.items(), key=lambda kv: order.get(kv[0], 6)):
        p(f"{str(k):<22}{len(v):>6}{mean(v):>9.1f}s{max(v):>9.1f}s")
    tot = by.get("total", [])
    if tot:
        p("")
        p(f"结算回大厅：平均 {mean(tot):.1f}s，最长 {max(tot):.1f}s"
          + ("    ⚠️ 有超过 45 秒的局，看上面的分步就知道卡在哪一段" if max(tot) > 45 else ""))

def section_shots(g, p):
    p("")
    p("-" * 78)
    p("七、截图索引（我复盘主要看这些）")
    p("-" * 78)
    shots = g["shot"]
    if not shots:
        p("没有截图记录。")
        return
    by_tag = {}
    for s in shots:
        by_tag.setdefault(s.get("tag", "?"), []).append(s.get("file"))
    p(f"截图总数 {len(shots)}，目录：{SHOT_DIR}")
    p("")
    p(f"{'用途':<28}{'张数':>8}   最近一张")
    for tag, files in sorted(by_tag.items(), key=lambda kv: -len(kv[1])):
        p(f"{str(tag):<28}{len(files):>8}   {files[-1]}")
    p("")
    p("重点看这几类：")
    p("  · bid_panel / roundN_before_bid —— 出价面板 + 左侧对手出价历史（用来核对我的预测模型）")
    p("  · bid_input —— 脚本输入的金额（核对是否输错）")
    p("  · settlement / settlement_data —— 结算界面的成交价/实际价值/收益（核对 OCR 准不准）")
    p("  · 超时_xxx —— 卡在哪一步，画面就是当时的样子")
    p("  · crash —— 崩溃现场")

def build_report(records):
    def section_errors(p):
        p("")
        p("-" * 78)
        p("八、报错日志（记录\\报错日志.txt / .jsonl）")
        p("-" * 78)
        if not os.path.exists(ERROR_JSONL):
            p("还没有报错日志（脚本还没写过，或者这批一次报错都没出）。")
            return
        rows = []
        for line in open(ERROR_JSONL, encoding="utf-8"):
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except Exception:
                continue
        if not rows:
            p("报错日志是空的 —— 这批运行很干净。")
            return
        cnt = Counter(r.get("kind", "?") for r in rows)
        p(f"报错总数 {len(rows)} 条，按类型：")
        for k, v in cnt.most_common():
            p(f"    {k:<24}{v:>5} 次")
        p("")
        p("最近 8 条（时间戳 / 类型 / 内容 / 截图）：")
        for r in rows[-8:]:
            ctx = r.get("context") or {}
            pos = "第%s局" % r.get("auction_no", "?")
            if ctx.get("round"):
                pos += " 第%s回合" % ctx["round"]
            p(f"    [{r.get('ts','')}] {r.get('kind','')} {pos}｜{str(r.get('message',''))[:70]}"
              + (f"｜截图 {r.get('screenshot')}" if r.get("screenshot") else ""))
        p("")
        p(f"报错截图目录：{ERROR_SHOT_DIR}")
        p("排查顺序建议：先看报错类型最多的那一类 → 按时间戳找同名截图 → 对照上面第 4/5 节的卡点。")

    g = collect(records)
    lines = []

    def p(s=""):
        lines.append(s)

    p("=" * 78)
    p("即刻落槌 实测复盘报告")
    p("=" * 78)
    p(f"记录条数 {len(records)}   目录 {BASE}")
    p("")

    ov = section_overview(g, p)
    if ov is None:
        p("")
        p("跑几局之后再运行本脚本即可；跑之前请确认 自检.bat 是通过的。")
        return "\n".join(lines)

    section_diagnosis(g, ov, p)
    section_bidding(g, p)
    section_health(g, p)
    section_recent(g, p)
    section_timing(g, p)
    section_shots(g, p)
    section_errors(p)

    p("")
    p("=" * 78)
    p("把 记录 这个文件夹整体发我（或让我直接读路径），我就能做完整的复盘。")
    p("=" * 78)
    return "\n".join(lines)

def main():
    records = load_records(JSONL)
    report = build_report(records)
    print(report)
    try:
        os.makedirs(os.path.dirname(REPORT), exist_ok=True)
        with open(REPORT, "w", encoding="utf-8") as fp:
            fp.write(report + "\n")
        print(f"\n（报告已保存到 {REPORT}）")
    except Exception as e:
        print(f"⚠️ 报告保存失败: {e}")

if __name__ == "__main__":
    main()
