# -*- coding: utf-8 -*-
"""数字模板包检查与扩样工具。

示例：
  1. 检查全部模板：
     python 数字模板工具.py check

  2. 把一张单个数字截图加入 white 样式：
     python 数字模板工具.py add 新样本.png 3 --style white

新样本最好只包含一个完整数字，亮字深底；工具会自动二值化、裁边并缩放到
32x48。加入后重启脚本即可生效。
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import cv2
import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from numeric_reader import DigitTemplateBank, VisualNumericReader

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass


APP = Path(__file__).resolve().parent.parent
ROOT = APP / "素材" / "数字模板"


def image_read(path):
    raw = np.fromfile(str(path), dtype=np.uint8)
    return cv2.imdecode(raw, cv2.IMREAD_COLOR)


def write_unicode(path, image):
    ok, encoded = cv2.imencode(".png", image)
    if not ok:
        raise RuntimeError(f"无法编码 {path}")
    encoded.tofile(str(path))


def normalize_new_sample(path, style):
    image = image_read(path)
    if image is None:
        raise ValueError(f"无法读取图片：{path}")
    gray = image[:, :, :3].max(axis=2) if image.ndim == 3 else image
    mask = np.where(gray > 190, 255, 0).astype(np.uint8)
    count, _labels, stats, _centroids = cv2.connectedComponentsWithStats(mask, 8)
    boxes = []
    for index in range(1, count):
        x, y, w, h, area = map(int, stats[index])
        if area >= 10 and h >= 8 and w >= 2:
            boxes.append((x, y, w, h, area))
    if not boxes:
        raise ValueError("没有找到亮色数字；目前工具只支持亮字深底")
    x0 = min(item[0] for item in boxes)
    y0 = min(item[1] for item in boxes)
    x1 = max(item[0] + item[2] for item in boxes)
    y1 = max(item[1] + item[3] for item in boxes)
    reader = VisualNumericReader(ROOT, style=style)
    return reader._normalize_glyph(mask, (x0, y0, x1 - x0, y1 - y0))


def check_pack(style):
    bank = DigitTemplateBank(ROOT, style=style)
    bad = []
    rows = []
    for digit in "0123456789":
        names = bank.manifest["digits"].get(digit, [])
        rows.append(f"{digit}: {len(names)} 张")
        for name in names:
            raw = np.fromfile(str(bank.pack_dir / name), dtype=np.uint8)
            image = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
            if image is None:
                bad.append(f"{digit}/{name}: 无法读取")
                continue
            expected_shape = (bank.canvas[1], bank.canvas[0])
            if image.shape != expected_shape:
                bad.append(f"{digit}/{name}: 尺寸 {image.shape} != {bank.canvas}")
                continue
            observed, score, second, second_score = bank.classify(image)
            if observed != digit:
                bad.append(
                    f"{digit}/{name}: 被判成 {observed}，"
                    f"{score:.4f}/{second}:{second_score:.4f}"
                )
    print(f"模板样式 {style}：")
    for row in rows:
        print("  " + row)
    if bad:
        print("失败：")
        for item in bad:
            print("  " + item)
        return False
    print("检查通过：0-9 完整，所有模板都能通过自身分类。")
    return True


def add_sample(path, digit, style):
    if digit not in "0123456789":
        raise ValueError("digit 必须是 0-9 的单个数字")
    pack = ROOT / style
    manifest_path = pack / "manifest.json"
    with manifest_path.open(encoding="utf-8") as fp:
        manifest = json.load(fp)
    sample = normalize_new_sample(Path(path), style)
    digest = hashlib.sha1(sample.tobytes()).hexdigest()
    for name in manifest["digits"].get(digit, []):
        raw = np.fromfile(str(pack / name), dtype=np.uint8)
        old = cv2.imdecode(raw, cv2.IMREAD_GRAYSCALE)
        if old is not None and hashlib.sha1(old.tobytes()).hexdigest() == digest:
            print("这个样本已经在模板库中，未重复添加。")
            return
    existing = {name for names in manifest["digits"].values() for name in names}
    index = 1
    while f"digit_{digit}_{index:02d}.png" in existing:
        index += 1
    name = f"digit_{digit}_{index:02d}.png"
    write_unicode(pack / name, sample)
    manifest.setdefault("digits", {}).setdefault(digit, []).append(name)
    tmp = manifest_path.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(manifest, ensure_ascii=False, indent=2),
                   encoding="utf-8")
    tmp.replace(manifest_path)
    print(f"已加入 {style}/{name}；重启脚本后生效。")


def main():
    parser = argparse.ArgumentParser(description="数字模板包检查与扩样工具")
    sub = parser.add_subparsers(dest="command", required=True)
    check_parser = sub.add_parser("check", help="检查指定模板样式")
    check_parser.add_argument("--style", default="white")
    add_parser = sub.add_parser("add", help="添加一个单数字样本")
    add_parser.add_argument("image")
    add_parser.add_argument("digit")
    add_parser.add_argument("--style", default="white")
    args = parser.parse_args()
    if args.command == "check":
        raise SystemExit(0 if check_pack(args.style) else 1)
    if args.command == "add":
        add_sample(args.image, args.digit, args.style)


if __name__ == "__main__":
    main()
