# -*- coding: utf-8 -*-
"""视觉靠谱度 —— 把历史仓库视觉事件汇总成一张报告。

回答一个问题：**现在敢不敢让视觉插嘴出价**。

三件事一起看：
  1. 校验过不过（视觉算的总值 vs 画面估价）
  2. 认出率（多少格认出了名字）
  3. 视觉均值比游戏估价高还是低 —— 高了说明游戏估得保守，有便宜占

手动扫仓的记录**不参与校验统计**：那会儿不在拍卖界面，没有估价可比，
checksum 必然 false，混进去会把通过率算废。
"""

import json
import os
import time

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

EVENT_TYPE = "warehouse_vision"
# 样本少于这个数，任何结论都别当真
MIN_SAMPLES = 10
# 判断「可以开风控」的线
GOOD_CHECK = 0.95
GOOD_NAMED = 0.85


def _fmt(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "—"
    if v >= 10000:
        return "%.1f万" % (v / 10000.0)
    return "%d" % int(v)


def _pct(v):
    try:
        return "%d%%" % round(float(v) * 100)
    except (TypeError, ValueError):
        return "—"


def _format_event(e):
    """一条事件摊成人能读的样子：上面是全字段，下面是每件一行。"""
    ev = {k: v for k, v in e.items() if not k.startswith("_")}
    items = ev.pop("items", []) or []
    out = [json.dumps(ev, ensure_ascii=False, indent=2, sort_keys=True)]
    out.append("")
    out.append("items（%d 件）：" % len(items))
    for it in items:
        try:
            conf = it.get("top_candidate_confidence")
            conf = "%d%%" % round(float(conf) * 100) if conf is not None else "—"
        except (TypeError, ValueError):
            conf = "—"
        try:
            price = _fmt(it.get("median") or it.get("mean"))
        except (TypeError, ValueError):
            price = "—"
        names = []
        for c in (it.get("candidate_top") or [])[:4]:
            names.append(str(c.get("name") or "?"))
        out.append(
            "  (%d,%d) %dx%d %-4s %-12s %-8s %-4s %s%s"
            % (int(it.get("x") or 0), int(it.get("y") or 0),
               int(it.get("w") or 1), int(it.get("h") or 1),
               str(it.get("color") or "?"), str(it.get("item") or "没认出"),
               price, str(it.get("source") or "?"), conf,
               (" 候选：" + " / ".join(names)) if len(names) > 1 else ""))
    return "\n".join(out)


def _quantile(values, q):
    if not values:
        return None
    data = sorted(values)
    if len(data) == 1:
        return data[0]
    pos = (len(data) - 1) * max(0.0, min(1.0, q))
    lo = int(pos)
    hi = min(lo + 1, len(data) - 1)
    frac = pos - lo
    return data[lo] * (1.0 - frac) + data[hi] * frac


def 读视觉事件(path):
    """只要视觉事件的老入口，留给别处调用。"""
    return 读记录(path)[0]


def 读记录(path):
    """一遍扫完：视觉事件 + 每回合的出价决定 + 每局结局。

    分开扫三遍没意义，这文件已经几十兆了，扫一遍大约 0.1 秒。
    出价的 key 是 (局号, 回合) —— 同一回合重试会写好几条，留最后那条。
    """
    rows = []
    bids = {}
    ends = {}
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as fp:
            for line in fp:
                if EVENT_TYPE in line:
                    try:
                        ev = json.loads(line)
                    except (ValueError, TypeError):
                        continue
                    if ev.get("type") == EVENT_TYPE:
                        rows.append(ev)
                elif '"bid_decision"' in line:
                    try:
                        ev = json.loads(line)
                    except (ValueError, TypeError):
                        continue
                    if ev.get("type") != "bid_decision":
                        continue
                    try:
                        key = (int(ev.get("auction_no") or 0),
                               int(ev.get("round") or 0))
                    except (TypeError, ValueError):
                        continue
                    bids[key] = ev
                elif '"auction_end"' in line:
                    try:
                        ev = json.loads(line)
                    except (ValueError, TypeError):
                        continue
                    if ev.get("type") != "auction_end":
                        continue
                    try:
                        ends[int(ev.get("auction_no") or 0)] = ev
                    except (TypeError, ValueError):
                        continue
    except OSError:
        return [], {}, {}
    return rows, bids, ends


def 统计(rows, bids=None, ends=None):
    total = len(rows)
    manual = sum(1 for e in rows if str(e.get("scan_mode") or "") == "manual")

    # 有游戏估价的样本才能比校验、比偏差
    priced = []
    for e in rows:
        try:
            if int(e.get("game_estimate") or 0) > 0:
                priced.append(e)
        except (TypeError, ValueError):
            continue

    checks_ok = sum(1 for e in priced if e.get("checksum_ok"))

    named_ratios = []
    for e in rows:
        try:
            blocks = int(e.get("block_count") or 0)
            named = int(e.get("named_count") or 0)
        except (TypeError, ValueError):
            continue
        if blocks > 0:
            named_ratios.append(named / float(blocks))

    devs = []
    for e in priced:
        try:
            est = float(e.get("game_estimate") or 0)
            mean = float(e.get("mean_total") or 0)
        except (TypeError, ValueError):
            continue
        if est > 0 and mean > 0:
            devs.append((mean - est) / est)

    elapsed = []
    for e in rows:
        try:
            ms = int(e.get("elapsed_ms") or 0)
        except (TypeError, ValueError):
            continue
        if ms > 0:
            elapsed.append(ms)

    # 按回合分组
    by_round = {}
    for e in rows:
        try:
            rnd = int(e.get("round") or 0)
        except (TypeError, ValueError):
            rnd = 0
        slot = by_round.setdefault(
            rnd, {"n": 0, "named": [], "dev": [], "check": 0, "priced": 0})
        slot["n"] += 1
        try:
            blocks = int(e.get("block_count") or 0)
            named = int(e.get("named_count") or 0)
            if blocks > 0:
                slot["named"].append(named / float(blocks))
        except (TypeError, ValueError):
            pass
        try:
            est = float(e.get("game_estimate") or 0)
            mean = float(e.get("mean_total") or 0)
            if est > 0 and mean > 0:
                slot["priced"] += 1
                slot["dev"].append((mean - est) / est)
                if e.get("checksum_ok"):
                    slot["check"] += 1
        except (TypeError, ValueError):
            pass

    tl_no, tl_rows = _timeline_of(rows, bids, ends)
    return {
        "total": total,
        "manual": manual,
        "auto": total - manual,
        "priced": len(priced),
        "check_ok": checks_ok,
        "check_rate": (checks_ok / float(len(priced))) if priced else None,
        "named_median": _quantile(named_ratios, 0.5),
        "named_p10": _quantile(named_ratios, 0.1),
        "named_p90": _quantile(named_ratios, 0.9),
        "dev_median": _quantile(devs, 0.5),
        "dev_p10": _quantile(devs, 0.1),
        "dev_p90": _quantile(devs, 0.9),
        "dev_up": sum(1 for d in devs if d > 0.02),
        "dev_down": sum(1 for d in devs if d < -0.02),
        "dev_n": len(devs),
        "elapsed_median": _quantile(elapsed, 0.5),
        "by_round": by_round,
        # 最近几次，新的在前 —— 样本少的时候靠它撑住页面，也能看走势
        "recent": rows[-10:][::-1],
        # 最近一局的逐回合时间线：优先挑真正跑过多回合的那局
        "timeline": tl_rows,
        "timeline_no": tl_no,
        "timeline_count": len(tl_rows),
    }


def _timeline_of(rows, bids=None, ends=None):
    """挑最近一局，把它各回合按顺序排出来。

    手动扫仓只有一个 round=1 的孤点，攒不出时间线，所以优先选回合数 >= 2
    的那局；都不够就退而求其次，给最近一局的单点。

    每行顺手挂上这回合实际出了多少钱、为什么这么出 —— 这是复盘的关键：
    光看估值涨没涨没用，得看它「当时怎么想的」。
    """
    bids = bids or {}
    ends = ends or {}
    groups = {}
    for e in rows:
        try:
            _no = int(e.get("auction_no") or 0)
        except (TypeError, ValueError):
            _no = 0
        # 局号只在一次运行内唯一：脚本重启会从 1 重数，光按局号分组会把
        # 不同时段的「局 89」串成同一局（实测 12:28 和 16:21 撞号）。
        # 有 run_id 就用它，老数据没有就退回按天分。
        _run = str(e.get("run_id") or "") or str(e.get("ts") or "")[:10]
        groups.setdefault((_run, _no), []).append(e)
    if not groups:
        return None, []

    def _last_ts(es):
        stamps = [str(e.get("ts") or "") for e in es]
        return max(stamps) if stamps else ""

    # 按这局最后一次扫描的时间倒序，挑最新的一局
    keys = sorted(groups, key=lambda k: _last_ts(groups[k]), reverse=True)
    picked_key = next((k for k in keys if len(groups[k]) >= 2), keys[0])
    picked = picked_key[1]
    rows_of = sorted(groups[picked_key],
                     key=lambda x: (int(x.get("round") or 0),
                                    str(x.get("ts") or "")))
    out = []
    for e in rows_of:
        try:
            rnd = int(e.get("round") or 0)
        except (TypeError, ValueError):
            rnd = 0
        item = dict(e)
        item["_bid"] = bids.get((picked, rnd))
        out.append(item)
    out_end = ends.get(picked)
    if out and out_end:
        out[-1] = dict(out[-1])
        out[-1]["_end"] = out_end
    return picked, out


def 结论(st):
    """按统计给出三句话的判断，别让用户自己读数字。"""
    out = []
    if st["total"] <= 0:
        return ["还没有任何仓库视觉记录。",
                "先点【拍卖辅助】页的「扫一次仓」，或者挂机时把【仓库视觉】打开。"]
    if st["total"] < MIN_SAMPLES:
        out.append("样本只有 %d 条，少于 %d 条 —— 下面这些数先当热闹看，别据此动风控。"
                   % (st["total"], MIN_SAMPLES))

    rate = st["check_rate"]
    if rate is None:
        out.append("没有一条带游戏估价，校验和偏差都算不了。"
                   "要这些数得挂机跑：手动扫仓时不在拍卖界面，没估价可读。")
    elif rate >= GOOD_CHECK:
        out.append("校验通过率 %s，很稳 —— 视觉认的总值跟画面估价基本对得上。"
                   % _pct(rate))
    elif rate >= 0.8:
        out.append("校验通过率 %s，凑合 —— 偶有算偏，动风控前再多挂几局看看。"
                   % _pct(rate))
    else:
        out.append("校验通过率只有 %s，偏低 —— 它算的总值跟画面估价经常对不上，"
                   "这时候让它改估价很危险。" % _pct(rate))

    nm = st["named_median"]
    if nm is not None:
        if nm >= GOOD_NAMED:
            out.append("认出率中位 %s，认得挺全。" % _pct(nm))
        elif nm >= 0.6:
            out.append("认出率中位 %s，有一小半格子没认出来 —— 估值会偏低，"
                       "偏低对出价是安全的方向。" % _pct(nm))
        else:
            out.append("认出率中位只有 %s，一多半认不出来，这个估值不能用来加价。"
                       % _pct(nm))

    med = st["dev_median"]
    if med is not None and st["dev_n"] >= 3:
        if med >= 0.10:
            out.append("视觉均值比游戏估价中位高 %s —— 游戏估得偏保守，"
                       "有便宜可占；开风控前先确认这是持续的，不是某几局的偶然。"
                       % _pct(med))
        elif med >= -0.05:
            out.append("视觉均值跟游戏估价中位差 %s，基本一致 —— 那它加价也加不出"
                       "多少空间，开不开风控意义不大。" % _pct(med))
        else:
            out.append("视觉均值比游戏估价中位低 %s —— 它比游戏还悲观，"
                       "让它改估价只会让你更保守。" % _pct(med))
    return out


class 视觉报告页(QWidget):
    """第 8 页：跨局汇总，看这套视觉到底靠不靠谱。"""

    def __init__(self, jsonl_path, colors=None, parent=None):
        super().__init__(parent)
        self._jsonl = jsonl_path
        self._colors = dict(colors or {})
        self._stamp = None
        self._build()
        self.refresh()

    # ---------- 界面 ----------

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 14, 18, 12)
        root.setSpacing(10)

        head = QHBoxLayout()
        head.setSpacing(12)
        self.title_lab = QLabel("视觉靠谱度")
        self.title_lab.setObjectName("big")
        self.sub_lab = QLabel("")
        self.sub_lab.setObjectName("cap")
        head.addWidget(self.title_lab)
        head.addWidget(self.sub_lab, 1)
        self.refresh_btn = QPushButton("↻  重新统计")
        self.refresh_btn.setObjectName("blue")
        self.refresh_btn.setFixedHeight(34)
        self.refresh_btn.setMinimumWidth(110)
        self.refresh_btn.clicked.connect(self.refresh)
        head.addWidget(self.refresh_btn)
        self.raw_btn = QPushButton("📄  原始明细")
        self.raw_btn.setFixedHeight(34)
        self.raw_btn.setMinimumWidth(110)
        self.raw_btn.setToolTip("把最近一局每回合的原始字段摊开，想看它到底算了什么")
        self.raw_btn.clicked.connect(self._open_raw)
        head.addWidget(self.raw_btn)
        self.export_btn = QPushButton("📤  导出训练")
        self.export_btn.setFixedHeight(34)
        self.export_btn.setMinimumWidth(110)
        self.export_btn.setToolTip("把认过的格子导成训练样本，放到 训练数据\\ 里")
        self.export_btn.clicked.connect(self._export_training)
        head.addWidget(self.export_btn)
        root.addLayout(head)

        cards = QGridLayout()
        cards.setSpacing(10)
        specs = [
            ("total", "样本数"),
            ("check", "校验通过率"),
            ("named", "认出率中位"),
            ("elapsed", "平均耗时"),
        ]
        self.card_vals = {}
        for col, (key, label) in enumerate(specs):
            v = QLabel("—")
            v.setObjectName("big")
            c = QLabel(label)
            c.setObjectName("cap")
            box = QVBoxLayout()
            box.setContentsMargins(14, 10, 14, 10)
            box.setSpacing(2)
            box.addWidget(v)
            box.addWidget(c)
            holder = QWidget()
            holder.setObjectName("statCard")
            holder.setLayout(box)
            cards.addWidget(holder, 0, col)
            self.card_vals[key] = v
        root.addLayout(cards)

        self.dev_lab = QLabel("")
        self.dev_lab.setWordWrap(True)
        self.dev_lab.setMinimumHeight(20)
        self.dev_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(self.dev_lab)

        # 按回合拆开看：越到后面认不认得出来、估得准不准
        self.round_box = QVBoxLayout()
        self.round_box.setSpacing(2)
        root.addLayout(self.round_box)

        self.recent_box = QVBoxLayout()
        self.recent_box.setSpacing(2)
        root.addLayout(self.recent_box)

        self.timeline_box = QVBoxLayout()
        self.timeline_box.setSpacing(2)
        root.addLayout(self.timeline_box)

        self.verdict_lab = QLabel("")
        self.verdict_lab.setWordWrap(True)
        self.verdict_lab.setObjectName("hint")
        self.verdict_lab.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.verdict_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(self.verdict_lab, 1)

    # ---------- 数据 ----------

    def refresh(self):
        # 只在真的显示时才去啃那个几十兆的文件
        if hasattr(self, "isVisible") and not self.isVisible():
            return
        try:
            st_size = os.path.getsize(self._jsonl)
            stamp = (st_size, os.path.getmtime(self._jsonl))
        except OSError:
            self._show_empty("还没有试验记录")
            return
        if self._stamp == stamp and self._stamp is not None:
            return
        self._stamp = stamp
        started = time.time()
        rows, bids, ends = 读记录(self._jsonl)
        st = 统计(rows, bids, ends)
        self._apply(st, time.time() - started)

    def _show_empty(self, message):
        self.sub_lab.setText(message)
        for v in self.card_vals.values():
            v.setText("—")
        self.dev_lab.setText("")
        self._clear_rounds()
        self.verdict_lab.setText("")

    def _clear_rounds(self):
        for box in (self.round_box, self.recent_box, self.timeline_box):
            while box.count():
                item = box.takeAt(0)
                w = item.widget()
                if w is not None:
                    w.setParent(None)
                    w.deleteLater()

    def _row(self, box, cells, head=False):
        """一行表格文字。head=True 时用淡色并抬高一点，跟上面那块分开。"""
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(0, 8 if head else 0, 0, 0)
        rl.setSpacing(8)
        for text, width, color in cells:
            lab = QLabel(text)
            lab.setFixedWidth(width)
            use = color or (self._hint() if head else None)
            lab.setStyleSheet(
                "font-size:12px;" + ("color:%s;" % use if use else ""))
            rl.addWidget(lab)
        rl.addStretch(1)
        box.addWidget(row)

    def _fill_recent(self, st):
        rows = st.get("recent") or []
        if not rows:
            return
        self._row(self.recent_box, [("最近几次扫仓（新的在上）", 300, self._hint())])
        self.recent_box.addSpacing(3)
        self._row(self.recent_box, [
            ("时间", 100, None), ("件数", 52, None),
            ("认出", 52, None), ("均值", 76, None), ("校验", 52, None)], head=True)
        for e in rows:
            ts = str(e.get("ts") or "")
            mode = "手动" if str(e.get("scan_mode") or "") == "manual" else "回合%s" % (
                e.get("round") or "?")
            try:
                blocks = int(e.get("block_count") or 0)
                named = int(e.get("named_count") or 0)
            except (TypeError, ValueError):
                blocks = named = 0
            try:
                est = int(e.get("game_estimate") or 0)
            except (TypeError, ValueError):
                est = 0
            if not est:
                check, color = "—", None
            elif e.get("checksum_ok"):
                check, color = "✓", self._colors.get("up")
            else:
                check, color = "✗", self._colors.get("down")
            where = "%s %s" % (ts[11:19] if len(ts) >= 19 else ts, mode)
            self._row(self.recent_box, [
                (where, 100, self._hint()),
                ("%d件" % blocks, 52, None),
                ("%d件" % named, 52, None),
                (_fmt(e.get("mean_total")), 76, None),
                (check, 52, color)])

    def _fill_timeline(self, st):
        rows = st.get("timeline") or []
        if not rows:
            return
        no = st.get("timeline_no")
        title = "最近一局" + (" #%s" % no if no else "") + " 的回合"
        self._row(self.timeline_box, [(title, 300, self._hint())])
        self.timeline_box.addSpacing(3)
        self._row(self.timeline_box, [
            ("回合", 118, None), ("件数", 52, None), ("认出", 52, None),
            ("覆盖", 52, None), ("均值", 76, None), ("估价", 76, None),
            ("比估价", 68, None), ("出价", 78, None),
            ("为什么这么出", 182, None), ("校验", 52, None)], head=True)
        if len(rows) < 2:
            self._row(self.timeline_box, [
                ("只有一次扫描，攒不出逐回合的变化", 380, self._hint())])
            return
        for e in rows:
            try:
                blocks = int(e.get("block_count") or 0)
                named = int(e.get("named_count") or 0)
            except (TypeError, ValueError):
                blocks = named = 0
            try:
                est = float(e.get("game_estimate") or 0)
                mean = float(e.get("mean_total") or 0)
            except (TypeError, ValueError):
                est = mean = 0.0
            dev = ((mean - est) / est) if est > 0 and mean > 0 else None
            if not est:
                check, ccolor = "—", None
            elif e.get("checksum_ok"):
                check, ccolor = "✓", self._colors.get("up")
            else:
                check, ccolor = "✗", self._colors.get("down")
            bid = e.get("_bid") or {}
            try:
                paid = float(bid.get("price") or 0)
            except (TypeError, ValueError):
                paid = 0.0
            why = str(bid.get("reason") or "")
            if len(why) > 12:
                why = why[:11] + "…"
            try:
                cov = float(e.get("capture_coverage") or 0)
            except (TypeError, ValueError):
                cov = 0.0
            # 覆盖不够整仓，格子坐标就会整体偏移，这时候数字别信
            cov_text = "%d%%" % round(cov * 100) if cov > 0 else "—"
            cov_color = (self._colors.get("down")
                         if 0 < cov < 0.90 else None)
            self._row(self.timeline_box, [
                ("第%s回合" % (e.get("round") or "?"), 118, None),
                ("%d件" % blocks, 52, None),
                ("%d件" % named, 52, None),
                (cov_text, 52, cov_color),
                (_fmt(mean), 76, None),
                (_fmt(est) if est else "—", 76, None),
                ("%+.0f%%" % (dev * 100) if dev is not None else "—", 68,
                 self._colors.get("up") if (dev or 0) > 0.02 else
                 self._colors.get("down") if (dev or 0) < -0.02 else None),
                (_fmt(paid) if paid else "—", 78, None),
                (why or "—", 182, self._hint()),
                (check, 52, ccolor)])
        self._fill_timeline_end(rows[-1].get("_end") if rows else None)

    def _fill_timeline_end(self, end):
        """这一局最后怎么了。输了也写，才看得出策略值不值。"""
        if not end:
            return
        result = str(end.get("result") or "")
        word = {"won": "赢了", "lost": "输了", "quit": "退出"}.get(result, result or "—")
        color = (self._colors.get("up") if result == "won"
                 else self._colors.get("down") if result == "lost" else None)
        try:
            final = float(end.get("final_price") or 0)
        except (TypeError, ValueError):
            final = 0.0
        try:
            profit = float(end.get("net_profit") or 0)
        except (TypeError, ValueError):
            profit = 0.0
        parts = ["结局 " + word]
        if final:
            parts.append("成交 %s" % _fmt(final))
        if profit:
            parts.append("盈亏 %+.1f万" % (profit / 10000.0))
        rounds = end.get("rounds_played")
        if rounds:
            parts.append("打了 %s 回合" % rounds)
        self._row(self.timeline_box, [(" · ".join(parts), 700, color)])

    def _raw_text(self):
        """原始明细的正文。单独抽出来方便测，也不用为了看一眼就开窗。"""
        st = getattr(self, "_last_st", None) or {}
        rows = st.get("timeline") or []
        if not rows:
            return ""
        no = st.get("timeline_no")
        body = ["最近一局 #%s，共 %d 个回合的原始记录" % (no, len(rows)),
                "=" * 64, ""]
        for e in rows:
            body.append(_format_event(e))
            body.append("")
        return "\n".join(body)

    def _open_raw(self):
        """把最近一局每回合的原始字段摊开。

        表格里只放得下几列，剩下的（影子估价、P10/P90、capture_ms、
        每件候选）都在这里，想追「它到底怎么算出来的」就看这个。
        """
        text_body = self._raw_text()
        if not text_body:
            self.sub_lab.setText("还没有可摊开的记录")
            return
        no = (getattr(self, "_last_st", None) or {}).get("timeline_no")
        dlg = QDialog(self)
        dlg.setWindowTitle("原始明细 · 局 #%s" % (no,))
        dlg.resize(780, 660)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(10, 10, 10, 10)
        text = QPlainTextEdit()
        text.setReadOnly(True)
        text.setLineWrapMode(QPlainTextEdit.NoWrap)
        text.setPlainText(text_body)
        lay.addWidget(text, 1)
        btn = QPushButton("关掉")
        btn.clicked.connect(dlg.accept)
        lay.addWidget(btn, 0, Qt.AlignRight)
        dlg.exec_()

    def _export_training(self):
        """把认过的格子导成训练样本，丢进 训练数据\\。

        现在样本少，导出来主要是给人看的：按 confidence 排一下，
        最低那几条就是「最可疑的认法」，回头好核对。
        """
        try:
            import training_export as te
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "导不出来", "找不到 training_export.py：\n%s" % exc)
            return
        src = self._jsonl
        try:
            picked = te.collect(src)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "读记录失败", str(exc))
            return
        if not picked:
            QMessageBox.information(
                self, "还没有样本",
                "记录里还没有带明细的视觉事件。\n先点几次「扫一次仓」，或者挂着跑几局。")
            return
        samples = []
        heads = []
        for no, ev, end in picked:
            rows, head = te.sample_rows(no, ev, end)
            samples.extend(rows)
            heads.append(head)
        if not samples:
            QMessageBox.information(self, "没有样本", "这几局的明细是空的，导不出东西。")
            return
        try:
            jsonl, index, manifest = te.write_outputs(
                te.DEFAULT_OUT, samples, heads, src)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, "写文件失败", str(exc))
            return
        QMessageBox.information(
            self, "导出好了",
            "%d 局 / %d 次扫描 / %d 条样本\n其中认不准的 %d 条\n\n放在：\n%s"
            % (len({h["auction_no"] for h in heads}), len(heads),
               manifest["samples"], manifest["uncertain"], te.DEFAULT_OUT))

    def _apply(self, st, scan_seconds):
        self._last_st = st
        if not st["total"]:
            self._show_empty("还没有仓库视觉记录")
            self.verdict_lab.setText("\n".join(结论(st)))
            return

        self.sub_lab.setText(
            "挂机 %d 条 · 手动 %d 条 · 扫了 %.1f 秒"
            % (st["auto"], st["manual"], scan_seconds)
        )
        self.card_vals["total"].setText(str(st["total"]))
        rate = st["check_rate"]
        self.card_vals["check"].setText(_pct(rate) if rate is not None else "—")
        self.card_vals["check"].setToolTip(
            "只看有游戏估价的 %d 条；手动扫仓没有估价，不参与" % st["priced"])
        self.card_vals["named"].setText(
            _pct(st["named_median"]) if st["named_median"] is not None else "—")
        self.card_vals["elapsed"].setText(
            "%.1f 秒" % (st["elapsed_median"] / 1000.0)
            if st["elapsed_median"] is not None else "—")

        # 偏差那一条
        if st["dev_median"] is None:
            self.dev_lab.setText(
                '<span style="font-size:13px;color:%s;">'
                '视觉 vs 估价：还没有带游戏估价的样本，比不了</span>'
                % self._hint())
        else:
            med = st["dev_median"]
            color = (self._colors.get("up") if med > 0.02 else
                     self._colors.get("down") if med < -0.02 else self._hint())
            self.dev_lab.setText(
                '<span style="font-size:13px;">视觉均值 vs 游戏估价　'
                '<b style="color:%s;">中位 %+.0f%%</b>　'
                'P10 %+.0f%%　P90 %+.0f%%　'
                '<span style="font-size:12px;color:%s;">'
                '（%d 条里 %d 条更高、%d 条更低）</span></span>'
                % (color, med * 100, (st["dev_p10"] or 0) * 100,
                   (st["dev_p90"] or 0) * 100, self._hint(),
                   st["dev_n"], st["dev_up"], st["dev_down"]))

        self._fill_rounds(st)
        self._fill_recent(st)
        self._fill_timeline(st)
        self.verdict_lab.setText("\n".join("· " + line for line in 结论(st)))

    def _fill_rounds(self, st):
        self._clear_rounds()
        rounds = sorted(st["by_round"].items())
        if not rounds:
            return
        self._row(self.round_box, [("各回合认得怎么样", 300, self._hint())])
        self.round_box.addSpacing(3)
        head = QWidget()
        hl = QHBoxLayout(head)
        hl.setContentsMargins(0, 0, 0, 0)
        hl.setSpacing(8)
        for text, width in (("回合", 60), ("样本", 52), ("认出率", 68), ("比估价", 76), ("校验", 52)):
            lab = QLabel(text)
            lab.setObjectName("cap")
            lab.setFixedWidth(width)
            hl.addWidget(lab)
        hl.addStretch(1)
        self.round_box.addWidget(head)

        for rnd, slot in rounds:
            row = QWidget()
            rl = QHBoxLayout(row)
            rl.setContentsMargins(0, 0, 0, 0)
            rl.setSpacing(8)
            name = "手动" if rnd <= 0 else "第%d回合" % rnd
            dev = _quantile(slot["dev"], 0.5)
            vals = [
                (name, 60, None),
                (str(slot["n"]), 52, None),
                (_pct(_quantile(slot["named"], 0.5)), 68, None),
                ("%+.0f%%" % (dev * 100) if dev is not None else "—", 76,
                 self._colors.get("up") if (dev or 0) > 0.02 else
                 self._colors.get("down") if (dev or 0) < -0.02 else None),
                (_pct(slot["check"] / float(slot["priced"])) if slot["priced"] else "—",
                 52, None),
            ]
            for text, width, color in vals:
                lab = QLabel(text)
                lab.setFixedWidth(width)
                lab.setStyleSheet(
                    "font-size:12px;" + ("color:%s;" % color if color else ""))
                rl.addWidget(lab)
            rl.addStretch(1)
            self.round_box.addWidget(row)

    # ---------- 主题 ----------

    def _hint(self):
        return str(self._colors.get("hint_fg") or "#8b93a5")

    def apply_colors(self, colors):
        self._colors = dict(colors or {})
        self.refresh()