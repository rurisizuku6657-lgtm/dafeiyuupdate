# -*- coding: utf-8 -*-
"""独立生成一张完整仓库图，不启动挂机主循环。"""
import os
import sys
import traceback
import json
import time
from datetime import datetime


HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for stream in self.streams:
            try:
                stream.write(text)
                stream.flush()
            except Exception:
                pass
        return len(text)

    def flush(self):
        for stream in self.streams:
            try:
                stream.flush()
            except Exception:
                pass


def main():
    root = HERE
    for candidate in (HERE, os.path.dirname(HERE)):
        if os.path.isdir(os.path.join(candidate, "素材")):
            root = candidate
            break
    log_dir = os.path.join(root, "记录")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "狗叫图生成_最后运行.txt")
    status_path = (os.environ.get("EVILNTE_DOG_STATUS")
                   or os.path.join(log_dir, "狗叫图生成_最后状态.json"))
    started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def write_status(ok=False, path="", error="", state="finished"):
        payload = {
            "ok": bool(ok),
            "state": state,
            "path": str(path or ""),
            "error": str(error or ""),
            "started_at": started_at,
            "finished_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "pid": os.getpid(),
        }
        try:
            if path and os.path.isfile(path):
                payload["bytes"] = int(os.path.getsize(path))
            tmp = status_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fp:
                json.dump(payload, fp, ensure_ascii=False, indent=2)
            os.replace(tmp, status_path)
        except Exception:
            pass

    original_stdout = sys.stdout
    original_stderr = sys.stderr
    result_path = ""
    result_ok = False
    write_status(ok=False, state="running")
    try:
        with open(log_path, "w", encoding="utf-8") as log:
            sys.stdout = _Tee(original_stdout, log)
            sys.stderr = _Tee(original_stderr, log)
            print("炫耀家底开始：%s" % started_at)
            import paimai
            result_path = paimai.generate_dog_bark_grid_image() or ""
            result_ok = bool(result_path and os.path.isfile(result_path)
                             and os.path.getsize(result_path) > 0)
            if result_ok:
                # ASCII marker survives codepage mistakes and is easy for the UI to parse.
                print("EVILNTE_DOG_OK=%s" % result_path)
            print("炫耀家底结束：%s" % ("成功" if result_ok else "失败"))
            if not result_ok:
                write_status(ok=False, state="failed", error="未生成有效图片")
            return 0 if result_ok else 1
    except Exception as e:
        traceback.print_exc()
        error = "%s: %s" % (type(e).__name__, e)
        print("炫耀家底失败，请把上面的错误信息发给开发者。")
        write_status(ok=False, path=result_path, error=error, state="failed")
        return 1
    finally:
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        if result_ok:
            write_status(ok=True, path=result_path)
        elif os.path.exists(status_path):
            try:
                with open(status_path, encoding="utf-8") as fp:
                    state = json.load(fp).get("state")
            except Exception:
                state = ""
            if state != "failed":
                write_status(ok=False, path=result_path,
                             error="未生成有效图片")


if __name__ == "__main__":
    raise SystemExit(main())
