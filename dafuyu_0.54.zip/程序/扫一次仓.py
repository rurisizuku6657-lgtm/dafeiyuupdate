# -*- coding: utf-8 -*-
"""不挂机扫一次整仓：抓图 → 识别 → 往 记录\\试验记录.jsonl 写一条。

给「拍卖辅助」页那个【扫一次仓】按钮用。不开挂机、不进对局，
只要游戏停在藏品仓库页就行。跟 狗叫图生成.py 一个套路：
界面起这个子进程，子进程干完写一份状态 json 给界面看。
"""
import json
import os
import sys
import traceback
from datetime import datetime


HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)


class _Tee:
    def __init__(self, *streams):
        self.streams = streams

    def write(self, text):
        for stream in self.streams:
            try:
                stream.write(text)
                stream.flush()
            except Exception:
                pass
        return len(text)

    def flush(self):
        for stream in self.streams:
            try:
                stream.flush()
            except Exception:
                pass


def _tail_lines(path, n=3):
    """把日志最后几句捞出来 —— 面板上要显示人话，不能只说「看日志」。"""
    try:
        with open(path, encoding="utf-8", errors="replace") as fp:
            lines = [ln.strip() for ln in fp if ln.strip()]
        keep = [ln for ln in lines if not ln.startswith(("✅", "⏳", "⚙️"))]
        picked = (keep or lines)[-n:]
        return " / ".join(picked)
    except Exception:
        return ""


def main():
    root = HERE
    for candidate in (HERE, os.path.dirname(HERE)):
        if os.path.isdir(os.path.join(candidate, "素材")):
            root = candidate
            break
    log_dir = os.path.join(root, "记录")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "扫一次仓_最后运行.txt")
    status_path = (os.environ.get("EVILNTE_SCAN_STATUS")
                   or os.path.join(log_dir, "扫一次仓_最后状态.json"))
    started_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def write_status(ok=False, error="", state="finished", summary=None):
        payload = {
            "ok": bool(ok),
            "state": state,
            "error": str(error or ""),
            "summary": summary or {},
            "started_at": started_at,
            "finished_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "pid": os.getpid(),
        }
        try:
            tmp = status_path + ".tmp"
            with open(tmp, "w", encoding="utf-8") as fp:
                json.dump(payload, fp, ensure_ascii=False, indent=2)
            os.replace(tmp, status_path)
        except Exception:
            pass

    original_stdout = sys.stdout
    original_stderr = sys.stderr
    write_status(ok=False, state="running")
    try:
        with open(log_path, "w", encoding="utf-8") as log:
            sys.stdout = _Tee(original_stdout, log)
            sys.stderr = _Tee(original_stderr, log)
            print("扫一次仓开始：%s" % started_at)
            import paimai
            result = paimai.仓库视觉扫一次()
            if not result:
                print("扫一次仓失败：没有拿到结果")
                write_status(ok=False, state="failed",
                             error=_tail_lines(log_path) or "没拿到结果")
                return 1
            summary = {
                "round": int(result.get("round") or 0),
                "min_total": int(result.get("min_total") or 0),
                "mean_total": int(result.get("mean_total") or 0),
                "p75_total": int(result.get("p75_total") or 0),
                "block_count": int(result.get("block_count") or 0),
                "named_count": int(result.get("named_count") or 0),
                "checksum_ok": bool(result.get("checksum_ok")),
            }
            print("EVILNTE_SCAN_OK=1")
            print("扫一次仓结束：成功（%d 件，认出 %d）" % (
                summary["block_count"], summary["named_count"]))
            write_status(ok=True, summary=summary)
            return 0
    except Exception as e:
        traceback.print_exc()
        error = "%s: %s" % (type(e).__name__, e)
        print("扫一次仓失败，请把上面的错误信息发给开发者。")
        write_status(ok=False, state="failed", error=error)
        return 1
    finally:
        sys.stdout = original_stdout
        sys.stderr = original_stderr


if __name__ == "__main__":
    raise SystemExit(main())