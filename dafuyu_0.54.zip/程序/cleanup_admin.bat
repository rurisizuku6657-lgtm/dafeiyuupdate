@echo off
setlocal
cd /d "%~dp0.."
fltmc >nul 2>&1
if not errorlevel 1 goto RUN
echo Asking for administrator rights (needed to capture the game window)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
if errorlevel 1 echo [ERROR] Administrator rights were refused.
exit /b 0
:RUN
set PYTHONIOENCODING=utf-8
"%~dp0..\python\python.exe" "%~dp0cleanup_dryrun.py"
if errorlevel 1 echo [ERROR] script exited with code %errorlevel%
pause
