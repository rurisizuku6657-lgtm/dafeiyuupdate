# -*- coding: utf-8 -*-
"""Runtime adapter for the Schema 6 ordinary-value residual candidate."""
from __future__ import annotations

import hashlib
import json
import math
import os

import numpy as np

from training_schema import INVENTORY_FEATURE_NAMES


MONETARY_FEATURES = {
    "exact_value_sum",
    "unknown_value_mean",
    "unknown_value_low",
    "unknown_value_high",
    "unknown_value_span",
}
RATIO_FEATURES = {
    "unknown_value_span_ratio",
    "unknown_block_ratio",
    "no_data_block_ratio",
    "top1_value_share",
    "top3_value_share",
    "top5_value_share",
    "red_gold_item_ratio",
    "red_gold_value_share",
    "named_area_ratio",
    "catalog_to_game_ratio",
    "p75_to_game_ratio",
}
LOW_VALUE_BLEND_MAX_BASELINE = 1_000_000
LOW_VALUE_BLEND_CANDIDATE_WEIGHT = 0.50
RUNTIME_HIGH_VALUE_THRESHOLD = 5_120_000


def _finite(value, default=0.0):
    try:
        number = float(value)
        return number if math.isfinite(number) else default
    except (TypeError, ValueError, OverflowError):
        return default


def _log1p_positive(value):
    return math.log1p(max(0.0, _finite(value)))


def _ratio(numerator, denominator):
    if _finite(denominator) <= 0:
        return 0.0
    return max(
        0.0,
        min(16.0, _finite(numerator) / _finite(denominator)),
    )


def _sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def apply_low_value_blend(metadata):
    """Blend candidate and legacy values for ordinary low-value auctions."""
    if not isinstance(metadata, dict) or not metadata.get("applied"):
        return metadata
    try:
        baseline = int(metadata.get("baseline") or 0)
        candidate = int(metadata.get("candidate") or 0)
    except (TypeError, ValueError, OverflowError):
        return metadata
    if (
        baseline <= 0
        or candidate <= 0
        or baseline >= LOW_VALUE_BLEND_MAX_BASELINE
    ):
        return metadata
    weight = LOW_VALUE_BLEND_CANDIDATE_WEIGHT
    blended = int(round(
        baseline * (1.0 - weight) + candidate * weight
    ))
    result = dict(metadata)
    result.update({
        "pre_low_value_blend_candidate": candidate,
        "candidate": blended,
        "reason": "applied_low_value_blend",
        "low_value_blend_applied": blended != candidate,
        "low_value_blend_selected": True,
        "low_value_blend_candidate_weight": weight,
        "low_value_blend_max_baseline": LOW_VALUE_BLEND_MAX_BASELINE,
        "relative_change_after_guard": round(
            blended / baseline - 1.0, 8
        ),
    })
    return result


def feature_vector(row):
    inventory = row.get("inventory_features") or {}
    values = []
    for name in INVENTORY_FEATURE_NAMES:
        value = max(0.0, _finite(inventory.get(name)))
        if name in MONETARY_FEATURES:
            value = math.log1p(value)
        elif name in RATIO_FEATURES:
            value = math.sqrt(min(value, 16.0))
        elif name == "effective_item_count":
            value = math.log1p(value)
        values.append(value)

    baseline = max(1.0, _finite(row.get("legacy_calibrated_value")))
    game = max(1.0, _finite(row.get("game_estimate")))
    coverage = max(0.0, min(1.0, _finite(row.get("coverage"))))
    round_value = max(0.0, min(8.0, _finite(row.get("round"))))
    values += [
        math.log(baseline),
        math.log(game),
        _log1p_positive(row.get("p50_total")),
        _log1p_positive(row.get("p75_total")),
        _log1p_positive(row.get("p90_total")),
        _log1p_positive(row.get("min_total")),
        _log1p_positive(row.get("mean_total")),
        _ratio(row.get("p50_total"), baseline),
        _ratio(row.get("p75_total"), baseline),
        _ratio(row.get("p90_total"), baseline),
        _ratio(row.get("min_total"), baseline),
        _ratio(row.get("mean_total"), baseline),
        coverage,
        max(0.0, min(1.0, _finite(row.get("coverage_area")))),
        math.log1p(max(0.0, _finite(row.get("block_count")))),
        _ratio(row.get("named_count"), row.get("block_count")),
        1.0 if row.get("checksum_ok") else 0.0,
        max(
            -2.0,
            min(2.0, _finite(row.get("checksum_diff")) / game),
        ),
        round_value,
        round_value * coverage,
    ]
    return values


class ValueResidualModel:
    def __init__(self, path):
        self.path = os.path.abspath(path)
        self.mtime = None
        self.document = {}
        self.model = {}
        self.feature_names = []
        self.feature_mean = None
        self.feature_scale = None
        self.coefficients = None
        self.sha256 = ""
        self.load()

    @property
    def available(self):
        return bool(
            self.model
            and self.feature_mean is not None
            and self.feature_scale is not None
            and self.coefficients is not None
        )

    def load(self):
        try:
            self.mtime = os.path.getmtime(self.path)
            with open(self.path, encoding="utf-8") as stream:
                document = json.load(stream)
            model = document.get("model") or {}
            names = list(model.get("feature_names") or [])
            mean = np.asarray(model.get("feature_mean") or [], dtype=float)
            scale = np.asarray(model.get("feature_scale") or [], dtype=float)
            coefficients = np.asarray(
                model.get("coefficients") or [], dtype=float
            )
            if not names or len(mean) != len(names):
                raise ValueError("candidate feature_mean length mismatch")
            if len(scale) != len(names):
                raise ValueError("candidate feature_scale length mismatch")
            if len(coefficients) != len(names) + 1:
                raise ValueError("candidate coefficients length mismatch")
            if not np.isfinite(mean).all():
                raise ValueError("candidate feature_mean is not finite")
            if not np.isfinite(scale).all():
                raise ValueError("candidate feature_scale is not finite")
            if not np.isfinite(coefficients).all():
                raise ValueError("candidate coefficients are not finite")
            self.document = document
            self.model = model
            self.feature_names = names
            self.feature_mean = mean
            self.feature_scale = np.where(
                np.abs(scale) < 1e-9, 1.0, scale
            )
            self.coefficients = coefficients
            self.sha256 = _sha256(self.path)
            return True
        except Exception:
            self.document = {}
            self.model = {}
            self.feature_names = []
            self.feature_mean = None
            self.feature_scale = None
            self.coefficients = None
            self.sha256 = ""
            return False

    def reload_if_changed(self):
        try:
            changed = os.path.getmtime(self.path) != self.mtime
        except Exception:
            changed = bool(self.mtime)
        return self.load() if changed else self.available

    def predict(self, row):
        baseline = max(0, int(_finite(row.get("legacy_calibrated_value"))))
        metadata = {
            "available": self.available,
            "baseline": baseline,
            "candidate": baseline,
            "applied": False,
            "reason": "",
            "model_sha256": self.sha256,
            "model_version": int(self.document.get("version") or 0),
        }
        scope = self.document.get("scope") or {}
        document_threshold = int(
            scope.get("high_value_threshold") or 0
        )
        effective_threshold = RUNTIME_HIGH_VALUE_THRESHOLD
        if document_threshold > 0:
            effective_threshold = min(
                effective_threshold, document_threshold
            )
        metadata["effective_high_value_threshold"] = effective_threshold
        if not self.available:
            metadata["reason"] = "model_unavailable"
            return metadata
        if baseline <= 0:
            metadata["reason"] = "baseline_missing"
            return metadata

        game = max(0, int(_finite(row.get("game_estimate"))))
        if (effective_threshold > 0
                and max(baseline, game) >= effective_threshold):
            metadata["reason"] = "high_value_guard"
            return metadata

        application = self.document.get("application") or {}
        gate = float(application.get("gate_min_baseline") or 0.0)
        factor = float(application.get("factor") or 1.0)
        blend = float(application.get("blend") or 1.0)
        if baseline < gate:
            metadata["reason"] = "below_gate"
            return metadata

        raw_features = np.asarray(feature_vector(row), dtype=float)
        if len(raw_features) != len(self.feature_names):
            metadata["reason"] = "feature_length_mismatch"
            return metadata
        normalized = (
            raw_features - self.feature_mean
        ) / self.feature_scale
        design = np.concatenate(([1.0], normalized))
        correction = float(design @ self.coefficients)
        clip = list(
            self.document.get("correction_multiplier_clip") or [0.70, 1.30]
        )
        correction = min(
            math.log(max(1e-9, float(clip[1]))),
            max(math.log(max(1e-9, float(clip[0]))), correction),
        )
        raw_candidate = baseline * math.exp(correction) * factor
        target = max(1e-9, raw_candidate)
        corrected = baseline * math.exp(
            max(0.0, min(1.0, blend))
            * math.log(target / baseline)
        )
        candidate_value = max(0, int(round(corrected)))
        deployment_policy = self.document.get("deployment_policy") or {}
        max_p75_ratio = max(
            0.0,
            _finite(
                deployment_policy.get("candidate_over_p75_max_ratio"),
                0.0,
            ),
        )
        p75_value = max(0.0, _finite(row.get("p75_total")))
        p75_cap_applied = False
        p75_cap_value = None
        if max_p75_ratio > 0 and p75_value > 0:
            p75_cap_value = int(round(
                max(float(baseline), p75_value * max_p75_ratio)
            ))
            if candidate_value > p75_cap_value:
                candidate_value = p75_cap_value
                p75_cap_applied = True
        metadata.update({
            "candidate": candidate_value,
            "applied": True,
            "reason": "applied",
            "raw_correction": round(correction, 8),
            "raw_candidate": max(0, int(round(raw_candidate))),
            "relative_change": round(corrected / baseline - 1.0, 8),
            "relative_change_after_guard": round(
                candidate_value / baseline - 1.0, 8
            ),
            "p75_cap_applied": p75_cap_applied,
            "p75_cap_value": p75_cap_value,
            "p75_cap_ratio": max_p75_ratio,
        })
        return metadata
