# -*- coding: utf-8 -*-
"""即刻落槌 · 日结报表

用法：
    python 日报.py            # 今天
    python 日报.py 2026-11-03 # 指定日期

读 记录\\日志\\<日期>\\拍卖记录.txt，输出到屏幕，
另外存一份到 记录\\日报\\日报_<日期>.txt
"""
import os
import re
import sys
from datetime import datetime

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

BASE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(BASE)
LOG_DIR = os.path.join(ROOT, "记录", "日志")
OUT_DIR = os.path.join(ROOT, "记录", "日报")

NUM = r"[+-]?\d[\d,]*"


def _int(s):
    if not s:
        return None
    s = s.replace(",", "").replace("−", "-").replace("+", "").strip()
    try:
        return int(s)
    except ValueError:
        return None


def parse_records(path):
    text = open(path, encoding="utf-8").read()
    rows = []
    for block in re.split(r"={10,}", text):
        if "第1回合估价" not in block:
            continue
        b = block.strip()
        m_no = re.search(r"第\s*(\d+)\s*场", b)
        m_tm = re.search(r"时间:\s*([\d\-]+\s+[\d:]+)", b)
        m_res = re.search(r"结果:\s*(\S+)", b)
        m_cost = re.search(r"本局成本:\s*(\d[\d,]*)", b)
        m_fin = re.search(r"最终成交价:\s*(\d[\d,]*)", b)
        m_val = re.search(r"实际价值:\s*(\d[\d,]*)", b)
        m_net = re.search(r"净收益:\s*(" + NUM + r")\s*（我的收入\s*(" + NUM +
                          r")\s*[−-]\s*成本\s*(\d[\d,]*)）", b)
        ests = [_int(x) for x in re.findall(r"第\d回合估价:\s*(\d[\d,]*)", b)]
        rows.append({
            "no": int(m_no.group(1)) if m_no else 0,
            "time": m_tm.group(1) if m_tm else "",
            "result": m_res.group(1) if m_res else "?",
            "cost": _int(m_cost.group(1)) if m_cost else 0,
            "fin": _int(m_fin.group(1)) if m_fin else None,
            "val": _int(m_val.group(1)) if m_val else None,
            "net": _int(m_net.group(1)) if m_net else None,
            "income": _int(m_net.group(2)) if m_net else None,
            "rounds": len(ests),
            "est1": ests[0] if ests else 0,
        })
    return rows


def money(v):
    if v is None:
        return "-"
    return ("-" if v < 0 else "+") + "{:,}".format(abs(v))


def build(rows, day):
    out = []
    w = out.append
    total = len(rows)
    win = [r for r in rows if r["result"] == "我拍到"]
    lose = [r for r in rows if r["result"] != "我拍到"]
    net = sum(r["net"] for r in rows if r["net"] is not None)
    income = sum(r["income"] for r in rows if r["income"] is not None)
    cost = sum(r["cost"] for r in rows if r["cost"])
    w("即刻落槌 · {} 日结".format(day))
    w("=" * 62)
    w("总场次 {} ｜ 我拍到 {} ({:.1f}%) ｜ 他人拍走 {}".format(
        total, len(win), 100.0 * len(win) / total if total else 0, len(lose)))
    w("我的收入 {:,} ｜ 成本 {:,} ｜ 净收益 {:,}".format(income, cost, net))
    w("平均每场净 {:,} ｜ 平均每场成本 {:,}".format(
        net // total if total else 0, cost // total if total else 0))

    wn = [r for r in win if r["net"] is not None]
    if wn:
        gain = [r for r in wn if r["net"] > 0]
        loss = [r for r in wn if r["net"] < 0]
        w("")
        w("【拍到的 {} 场】".format(len(wn)))
        w("  赚 {} 场 合计 {} ｜ 亏 {} 场 合计 {}".format(
            len(gain), money(sum(r["net"] for r in gain)),
            len(loss), money(sum(r["net"] for r in loss))))
        w("  平均 {} ｜ 最好 {} ｜ 最差 {}".format(
            money(sum(r["net"] for r in wn) // len(wn)),
            money(max(r["net"] for r in wn)), money(min(r["net"] for r in wn))))

    w("")
    w("【按第 1 回合估价】")
    buckets = [(0, 300000, "<30 万"), (300000, 580000, "30~58 万"),
               (580000, 1314520, "58~131 万"), (1314520, 3000000, "131~300 万"),
               (3000000, 5121024, "300~512 万"), (5121024, 1 << 62, ">512 万")]
    for lo, hi, label in buckets:
        grp = [r for r in rows if lo <= r["est1"] < hi]
        if not grp:
            continue
        gw = [r for r in grp if r["result"] == "我拍到"]
        gnet = sum(r["net"] for r in grp if r["net"] is not None)
        w("  {:<10} 场次 {:>4}  拍到 {:>3} ({:>3.0f}%)  净 {:>15,}".format(
            label, len(grp), len(gw), 100.0 * len(gw) / len(grp), gnet))

    w("")
    w("【按打到第几回合】")
    for k in range(1, 7):
        grp = [r for r in rows if r["rounds"] == k]
        if not grp:
            continue
        gw = [r for r in grp if r["result"] == "我拍到"]
        gnet = sum(r["net"] for r in grp if r["net"] is not None)
        w("  第{}回合 {:>4} 场  拍到 {:>3}  净 {:>15,}".format(
            k, len(grp), len(gw), gnet))

    top = sorted(wn, key=lambda r: r["net"], reverse=True)
    if top:
        w("")
        w("【最赚 5 场】")
        for r in top[:5]:
            w("  第{:>3}场 {}  成交 {:>11,}  价值 {:>11,}  {}  ({} 回合)".format(
                r["no"], r["time"][11:16] if len(r["time"]) > 11 else r["time"],
                r["fin"] or 0, r["val"] or 0, money(r["net"]), r["rounds"]))
        w("【最亏 5 场】")
        for r in top[-5:][::-1]:
            w("  第{:>3}场 {}  成交 {:>11,}  价值 {:>11,}  {}  ({} 回合)".format(
                r["no"], r["time"][11:16] if len(r["time"]) > 11 else r["time"],
                r["fin"] or 0, r["val"] or 0, money(r["net"]), r["rounds"]))
    return "\n".join(out)


def write_report(day, verbose=True):
    """生成某一天的日结，返回 (是否成功, 输出路径)。"""
    path = os.path.join(LOG_DIR, day, "拍卖记录.txt")
    if not os.path.exists(path):
        if verbose:
            print("没找到 {}".format(path))
        return False, ""
    rows = parse_records(path)
    if not rows:
        if verbose:
            print("{} 里没有解析到场次".format(path))
        return False, ""
    report = build(rows, day)
    if verbose:
        print(report)
    os.makedirs(OUT_DIR, exist_ok=True)
    out_path = os.path.join(OUT_DIR, "日报_{}.txt".format(day))
    with open(out_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(report + "\n")
    if verbose:
        print("\n已存到 {}".format(out_path))
    return True, out_path


def main():
    day = sys.argv[1] if len(sys.argv) > 1 else datetime.now().strftime("%Y-%m-%d")
    ok, _ = write_report(day)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
