# -*- coding: utf-8 -*-
"""藏品仓库「整仓分页抓图」—— 逻辑搬自 EvilNte 的 dog 系列，接口换成本脚本自己的。

为什么要单独一套：拍卖界面右侧那个小仓和「藏品仓库」整页是两个不同布局，
滚动条位置/行数都不一样，所以这里用单独的 DOG_* 标定，不碰拍卖那套。

对外只有一个入口：
    分页抓整仓(window_fn, shot_fn, click_fn, log=print)
返回 (canvas, page_infos, pages) 或 None。
    window_fn() -> (left, top, w, h) 客户区在屏幕上的位置
    shot_fn(region) -> PIL.Image     region=(屏幕x, 屏幕y, w, h)
    click_fn(x, y) -> bool           屏幕坐标点击
"""
from __future__ import annotations

import time

# ---- 1920x1080 客户区里「藏品仓库」右侧仓库的标定（实测自 EvilNte，和本机一致）----
DOG_GRID_BOX = (1265, 272, 590, 564)   # x, y, w, h
DOG_GRID_WIDTH = 565                   # 去掉右侧滚动条后的有效宽度
DOG_TOTAL_ROWS = 60                    # 仓库总行数
DOG_ROW_H = 56.4                       # 每行像素高
DOG_SCROLL_TOP = 7                     # 滑块上沿最小 y（相对网格框）
DOG_SCROLL_BOTTOM = 563                # 滑块下沿最大 y
DOG_PAGE_MARGIN_Y = 16                 # 每页上下多截一点，防止首行被切
DOG_PAGE_TOP_IN_CAPTURE = 8
DOG_STITCH_SEARCH_PX = 40
DOG_STITCH_BLEND_PX = 14


def _scale(window):
    left, top, w, h = window
    return left, top, w / 1920.0, h / 1080.0


def 抓格图(window_fn, shot_fn):
    win = window_fn()
    if win is None:
        return None
    left, top, sx, sy = _scale(win)
    x, y, w, h = DOG_GRID_BOX
    return shot_fn((left + int(round(x * sx)), top + int(round(y * sy)),
                    int(round(w * sx)), int(round(h * sy))))


def 抓页图(window_fn, shot_fn):
    win = window_fn()
    if win is None:
        return None
    left, top, sx, sy = _scale(win)
    x, y, w, h = DOG_GRID_BOX
    return shot_fn((
        left + int(round(x * sx)),
        top + int(round((y - DOG_PAGE_MARGIN_Y) * sy)),
        int(round(w * sx)),
        int(round((h + DOG_PAGE_MARGIN_Y * 2) * sy)),
    ))


def 归一页(page):
    from PIL import Image
    page = page.convert("RGB")
    want = (DOG_GRID_BOX[2], DOG_GRID_BOX[3] + DOG_PAGE_MARGIN_Y * 2)
    if page.size != want:
        page = page.resize(want, Image.LANCZOS)
    crop = page.crop((0, DOG_PAGE_TOP_IN_CAPTURE, DOG_GRID_WIDTH,
                      DOG_PAGE_TOP_IN_CAPTURE + DOG_GRID_BOX[3]))
    if crop.size != (DOG_GRID_WIDTH, DOG_GRID_BOX[3]):
        padded = Image.new("RGB", (DOG_GRID_WIDTH, DOG_GRID_BOX[3]))
        padded.paste(crop, (0, 0))
        crop = padded
    return crop


def 滑块位置(img=None, window_fn=None, shot_fn=None):
    """返回 (滚动条在图内 x, 滑块顶, 滑块底)；只认最右 ~20px 里那条长亮线。"""
    try:
        import numpy as np
        shot = img if img is not None else 抓格图(window_fn, shot_fn)
        if shot is None:
            return None
        gray = np.asarray(shot.convert("L"), dtype=np.int16)
        best = None
        for cx in range(max(1, gray.shape[1] - 20), gray.shape[1]):
            ys = np.where(gray[:, cx] > 150)[0]
            if len(ys) < 10:
                continue
            start = prev = int(ys[0])
            for raw_y in ys[1:]:
                y = int(raw_y)
                if y - prev > 4:
                    if prev - start >= 20 and (best is None or prev - start > best[2] - best[1]):
                        best = (cx, start, prev)
                    start = y
                prev = y
            if prev - start >= 20 and (best is None or prev - start > best[2] - best[1]):
                best = (cx, start, prev)
        return best
    except Exception:
        return None


def 滑块范围(img=None, window_fn=None, shot_fn=None):
    hit = 滑块位置(img, window_fn, shot_fn)
    if hit is None:
        return None
    return hit[1], hit[2]


def 跳滑块(window_fn, shot_fn, click_fn, desired_top, drag_fn=None):
    """点滚动条轨道让它直接跳到位；成功返回 (顶, 底)。"""
    win = window_fn()
    if win is None:
        return None
    left, top, sx, sy = _scale(win)
    hit = 滑块位置(None, window_fn, shot_fn)
    if hit is None:
        return None
    local_x, thumb_top, thumb_bottom = hit
    thumb_len = thumb_bottom - thumb_top
    target_top = max(DOG_SCROLL_TOP * sy,
                     min(DOG_SCROLL_BOTTOM * sy - thumb_len, float(desired_top) * sy))
    if abs(thumb_top - target_top) <= max(6.0, 8.0 * sy):
        return int(round(thumb_top / sy)), int(round(thumb_bottom / sy))
    x = int(round(left + DOG_GRID_BOX[0] * sx + local_x))
    candidates = [target_top + thumb_len / 2.0]
    if target_top >= DOG_SCROLL_BOTTOM * sy - thumb_len - 2:
        candidates.append(DOG_SCROLL_BOTTOM * sy - 2 * sy)
    for click_target in candidates:
        click_target = max(DOG_SCROLL_TOP * sy + 10 * sy,
                           min(DOG_SCROLL_BOTTOM * sy - 10 * sy, click_target))
        y = int(round(top + DOG_GRID_BOX[1] * sy + click_target))
        try:
            click_fn(x, y)
        except Exception:
            pass
        time.sleep(0.2)
        current = 滑块位置(None, window_fn, shot_fn)
        if current is None:
            continue
        if abs(current[1] - target_top) <= max(6.0, 8.0 * sy):
            return int(round(current[1] / sy)), int(round(current[2] / sy))
        corrected = max(DOG_SCROLL_TOP * sy + 10 * sy,
                        min(DOG_SCROLL_BOTTOM * sy - 10 * sy,
                            click_target + target_top - current[1]))
        if len(candidates) < 2 and all(abs(corrected - c) > 2.0 for c in candidates):
            candidates.append(corrected)
    # 点轨道没反应 → 直接拖滑块过去（很多游戏只认拖拽）
    if drag_fn is not None:
        try:
            again = 滑块位置(None, window_fn, shot_fn)
            if again is not None:
                _lx, cur_top, cur_bottom = again
                _len = cur_bottom - cur_top
                _want = max(DOG_SCROLL_TOP * sy,
                            min(DOG_SCROLL_BOTTOM * sy - _len, float(desired_top) * sy))
                dx = int(round(left + DOG_GRID_BOX[0] * sx + _lx))
                y_from = int(round(top + DOG_GRID_BOX[1] * sy + (cur_top + cur_bottom) / 2.0))
                y_to = int(round(top + DOG_GRID_BOX[1] * sy + _want + _len / 2.0))
                drag_fn(dx, y_from, dx, y_to)
                time.sleep(0.3)
                done = 滑块位置(None, window_fn, shot_fn)
                if done is not None and abs(done[1] - _want) <= max(8.0, 12.0 * sy):
                    return int(round(done[1] / sy)), int(round(done[2] / sy))
        except Exception:
            pass
    return None


def _页位移(previous, current, expected):
    """两页重叠区域做像素对齐，返回像素位移；找不到返回 None。"""
    import numpy as np
    previous = np.asarray(previous.convert("L"), dtype=np.int16)
    current = np.asarray(current.convert("L"), dtype=np.int16)
    height = min(previous.shape[0], current.shape[0])
    width = min(DOG_GRID_WIDTH, previous.shape[1], current.shape[1])
    best = None
    for offset in range(int(round(expected - DOG_STITCH_SEARCH_PX)),
                        int(round(expected + DOG_STITCH_SEARCH_PX)) + 1):
        overlap = height - offset
        if overlap < 80:
            continue
        upper = previous[offset:offset + overlap, :width]
        lower = current[:overlap, :width]
        active = (np.abs(upper) > 45) | (np.abs(lower) > 45)
        mask = active if active.mean() >= 0.01 else np.ones_like(active, dtype=bool)
        difference = np.abs(upper - lower)
        active_error = float(difference[mask].mean())
        mask_mismatch = float(((upper > 45) != (lower > 45)).mean())
        edge_error = float(np.abs(np.abs(np.diff(upper, axis=0)) -
                                  np.abs(np.diff(lower, axis=0))).mean())
        score = active_error + 25.0 * mask_mismatch + 0.12 * edge_error + 0.12 * abs(offset - expected)
        if best is None or score < best[0]:
            best = (score, offset)
    return None if best is None else int(best[1])


def _页偏移(pages, view_h, canvas_h):
    content_travel = max(1, int(canvas_h) - int(view_h))
    thumbs = [int(page[2]) for page in pages]
    if len(thumbs) > 1 and thumbs[-1] > thumbs[0] + 10:
        travel = float(thumbs[-1] - thumbs[0])
        coarse = [(float(v - thumbs[0]) / travel) * content_travel for v in thumbs]
    else:
        coarse = [float(int(page[1]) * DOG_ROW_H) for page in pages]
    coarse[0] = 0.0
    coarse[-1] = float(content_travel)
    offsets = [0.0]
    for index in range(1, len(pages)):
        expected = coarse[index] - offsets[-1]
        shift = _页位移(pages[index - 1][0], pages[index][0], expected)
        candidate = coarse[index] if shift is None else offsets[-1] + float(shift)
        if abs(candidate - coarse[index]) > DOG_ROW_H * 1.25:
            candidate = coarse[index]
        candidate = max(offsets[-1] + 20.0, min(content_travel, candidate))
        offsets.append(float(candidate))
    offsets[-1] = float(content_travel)
    return offsets


def _贴页(canvas, page, y):
    import numpy as np
    from PIL import Image
    y = max(0, int(round(y)))
    page = page.convert("RGB")
    if y >= canvas.height:
        return
    visible_h = min(page.height, canvas.height - y)
    if visible_h <= 0:
        return
    page = page.crop((0, 0, page.width, visible_h))
    if y == 0:
        canvas.paste(page, (0, 0))
        return
    existing = np.asarray(canvas.crop((0, y, page.width, y + visible_h)), dtype=np.uint16)
    incoming = np.asarray(page, dtype=np.uint16)
    blend_h = min(DOG_STITCH_BLEND_PX, visible_h)
    if blend_h > 0:
        weights = np.linspace(0.0, 1.0, blend_h, endpoint=False, dtype=np.float32)[:, None, None]
        existing[:blend_h] = (existing[:blend_h] * (1.0 - weights) +
                              incoming[:blend_h] * weights).astype(np.uint16)
    existing[blend_h:] = incoming[blend_h:]
    canvas.paste(Image.fromarray(existing.astype(np.uint8)), (0, y))


def 分页抓整仓(window_fn, shot_fn, click_fn, log=print, drag_fn=None):
    """把藏品仓库右侧那块 10×60 的仓分页抓全并拼成一张长图。"""
    from PIL import Image
    first = 抓格图(window_fn, shot_fn)
    hit = 滑块位置(first)
    if hit is None:
        log("❌ 藏品仓库：认不到右侧滚动条（确认停留在藏品仓库页、并且是管理员运行）")
        return None
    top = 跳滑块(window_fn, shot_fn, click_fn, DOG_SCROLL_TOP, drag_fn)
    if top is None or abs(top[0] - DOG_SCROLL_TOP) > 8:
        log("❌ 藏品仓库：没能把仓库滚到顶部")
        return None
    thumb_len = top[1] - top[0]
    travel_bottom = DOG_SCROLL_BOTTOM - thumb_len
    view_h = DOG_GRID_BOX[3]
    thumb_travel = max(1, travel_bottom - DOG_SCROLL_TOP)
    page_view_rows = int(DOG_TOTAL_ROWS / 6)
    page_rows = [0, 2, 10, 18, 26, 34, 42, 50]
    pages = []
    for index, row_start in enumerate(page_rows):
        if row_start == 0:
            rng = top
        elif row_start + page_view_rows >= DOG_TOTAL_ROWS:
            rng = 跳滑块(window_fn, shot_fn, click_fn, travel_bottom, drag_fn)
        else:
            target = DOG_SCROLL_TOP + (float(row_start) / max(1, DOG_TOTAL_ROWS - 10) * thumb_travel)
            rng = 跳滑块(window_fn, shot_fn, click_fn, target, drag_fn)
        if rng is None:
            break
        time.sleep(0.55 if index == 0 else 0.2)
        shot = 抓页图(window_fn, shot_fn)
        if shot is not None:
            pages.append((shot, row_start, rng[0]))
    if len(pages) != len(page_rows):
        跳滑块(window_fn, shot_fn, click_fn, DOG_SCROLL_TOP)
        log("❌ 藏品仓库：只抓到 %d/%d 页，已中止" % (len(pages), len(page_rows)))
        return None
    canvas_h = int(round(DOG_TOTAL_ROWS * DOG_ROW_H))
    canvas = Image.new("RGB", (DOG_GRID_WIDTH, canvas_h + 1))
    normalized = [(归一页(shot), row_start, thumb) for shot, row_start, thumb in pages]
    ys = [int(round(v)) for v in _页偏移(normalized, view_h, canvas_h)]
    page_infos = []
    for (page, row_start, thumb_top), y in zip(normalized, ys):
        _贴页(canvas, page, y)
        page_infos.append({
            "row_start": int(row_start),
            "thumb_top": int(thumb_top),
            "canvas_y": int(y),
            "view_h": int(view_h),
            "scroll_start": round(float(y) / DOG_ROW_H, 6),
        })
    log("🧩 藏品仓库拼接：%d 页 → %dx%d（各页 y=%s）" % (len(pages), canvas.width, canvas.height, ys))
    return canvas, page_infos, [p[0] for p in normalized]


# ---------------------------------------------------------------------------
# 滚轮版：游戏里的"滚动条点轨道"经常不认（点了没反应），滚轮更稳。
# 流程：先把光标放网格中央 → 连续上滚到顶 → 一页页下滚截图（每页记滑块位置）
#      → 用重叠区像素对齐拼起来。
# ---------------------------------------------------------------------------
def _网格中心(window):
    left, top, sx, sy = _scale(window)
    cx = left + int(round((DOG_GRID_BOX[0] + DOG_GRID_BOX[2] / 2.0) * sx))
    cy = top + int(round((DOG_GRID_BOX[1] + DOG_GRID_BOX[3] / 2.0) * sy))
    return cx, cy


def 滚到顶(window_fn, shot_fn, wheel_fn, log=print):
    win = window_fn()
    if win is None:
        return None
    cx, cy = _网格中心(win)
    prev = None
    for _ in range(60):
        try:
            wheel_fn(cx, cy, 3)
        except Exception:
            return None
        time.sleep(0.08)
        cur = 滑块范围(None, window_fn, shot_fn)
        if cur is None:
            return None
        if prev is not None and abs(cur[0] - prev[0]) <= 1:
            return cur
        prev = cur
    return prev


def 分页抓整仓_滚轮(window_fn, shot_fn, wheel_fn, log=print, max_pages=12):
    """用滚轮翻页抓整仓（按滑块行程算每页该滚多少）。返回 (canvas, page_infos, pages)。"""
    from PIL import Image
    win = window_fn()
    if win is None:
        return None
    top_rng = 滚到顶(window_fn, shot_fn, wheel_fn, log)
    if top_rng is None:
        log("❌ 藏品仓库：滚轮滚不动（认不到滑块？）")
        return None
    thumb_len = max(20, int(top_rng[1] - top_rng[0]))
    travel = max(1, (DOG_SCROLL_BOTTOM - thumb_len) - DOG_SCROLL_TOP)
    # 每页往下 8 行 → 滑块应移动这么多像素
    step_delta = max(8.0, travel * 8.0 / float(max(1, DOG_TOTAL_ROWS - 10)))
    cx, cy = _网格中心(win)
    pages = []
    cur = 滑块范围(None, window_fn, shot_fn)
    for index in range(max_pages):
        if cur is None:
            break
        shot = 抓页图(window_fn, shot_fn)
        if shot is None:
            break
        pages.append((shot, index * 8, cur[0]))
        moved_total = 0.0
        notches = 0
        while moved_total < step_delta and notches < 40:
            before = cur[0]
            try:
                wheel_fn(cx, cy, -1)
            except Exception:
                break
            notches += 1
            time.sleep(0.12)
            cur2 = 滑块范围(None, window_fn, shot_fn)
            if cur2 is None:
                cur = None
                break
            _delta = abs(cur2[0] - before)
            moved_total += _delta
            cur = cur2
            if abs(cur[0] - (DOG_SCROLL_BOTTOM - thumb_len)) <= 2:
                break
            if _delta <= 1:
                # 滚了一档滑块纹丝不动 = 已经到底，别再空滚 40 档（实测拖到底后还空转很久）
                break
        if notches == 0 or moved_total < 2:
            break  # 滚不动 = 到底
        if abs(cur[0] - (DOG_SCROLL_BOTTOM - thumb_len)) <= 2:
            # 已经到底，再抓最后一页就收工
            shot = 抓页图(window_fn, shot_fn)
            if shot is not None:
                pages.append((shot, (len(pages)) * 8, cur[0]))
            break
    if len(pages) < 2:
        log("❌ 藏品仓库：滚轮只抓到 %d 页，已中止" % len(pages))
        return None
    canvas_h = int(round(DOG_TOTAL_ROWS * DOG_ROW_H))
    canvas = Image.new("RGB", (DOG_GRID_WIDTH, canvas_h + 1))
    normalized = [(归一页(shot), row_start, thumb) for shot, row_start, thumb in pages]
    view_h = DOG_GRID_BOX[3]
    try:
        tops = [int(pg[2]) for pg in normalized]
        t0, t1 = min(tops), max(tops)
        if t1 > t0 + 10:
            full = canvas_h - view_h
            ys = [int(round((t - t0) / float(t1 - t0) * full)) for t in tops]
        else:
            ys = [i * (canvas_h - view_h) // max(1, len(normalized) - 1) for i in range(len(normalized))]
    except Exception:
        ys = [i * 500 for i in range(len(normalized))]
    page_infos = []
    for (page, row_start, thumb_top), y in zip(normalized, ys):
        _贴页(canvas, page, y)
        page_infos.append({
            "row_start": int(row_start),
            "thumb_top": int(thumb_top),
            "canvas_y": int(y),
            "view_h": int(view_h),
            "scroll_start": round(float(y) / DOG_ROW_H, 6),
        })
    log("🧩 藏品仓库拼接（滚轮）：%d 页 → %dx%d（各页 y=%s）"
        % (len(normalized), canvas.width, canvas.height, ys))
    return canvas, page_infos, [p[0] for p in normalized]
