# -*- coding: utf-8 -*-
"""大肥鱼standby 自查脚本
改完代码先跑这个，别只看“能启动”。

检查项：
 1) 语法编译（paimai.py / 界面.py / warehouse_cleanup.py）
 2) 未定义名字扫描（AST，抓“删了变量还在用”这类改坏的代码）
 3) 关键模块导入 + 关键函数冒烟
 4) 素材模板是否齐全
 5) 版本号
用法：  python 自查.py
"""
import ast
import builtins
import importlib.util
import io
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)
FILES = ["paimai.py", "界面.py", "warehouse_cleanup.py"]
fails = []


def section(title):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


# ---------- 1) 编译 ----------
section("1) 语法编译")
for f in FILES:
    p = os.path.join(HERE, f)
    try:
        src = io.open(p, encoding="utf-8").read()
        compile(src, p, "exec")
        print(f"   ✅ {f}")
    except Exception as e:
        print(f"   ❌ {f}: {e}")
        fails.append(f"编译 {f}")

# ---------- 2) 未定义名字 ----------
section("2) 未定义名字扫描")
CLOSURE_NAMES = {"__file__", "self", "fn", "cls", "est", "on_done", "args", "kwargs"}


def scan_file(path):
    tree = ast.parse(io.open(path, encoding="utf-8").read())
    module_names = set(dir(builtins))
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            module_names.add(node.name)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            module_names.add(node.id)
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            for a in node.names:
                module_names.add((a.asname or a.name).split(".")[0])
    hits = []
    for fn in [n for n in ast.walk(tree)
               if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]:
        local = set()
        for a in (list(fn.args.args) + list(fn.args.kwonlyargs)
                  + list(getattr(fn.args, "posonlyargs", []))):
            local.add(a.arg)
        if fn.args.vararg:
            local.add(fn.args.vararg.arg)
        if fn.args.kwarg:
            local.add(fn.args.kwarg.arg)
        declared = set()
        for node in ast.walk(fn):
            if isinstance(node, (ast.Global, ast.Nonlocal)):
                declared.update(node.names)
            elif isinstance(node, ast.Name) and isinstance(node.ctx, (ast.Store, ast.Del)):
                local.add(node.id)
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) and node is not fn:
                local.add(node.name)
            elif isinstance(node, ast.ExceptHandler) and node.name:
                local.add(node.name)
            elif isinstance(node, ast.arg):
                local.add(node.arg)
            elif isinstance(node, ast.comprehension):
                for t in ast.walk(node.target):
                    if isinstance(t, ast.Name):
                        local.add(t.id)
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                for a in node.names:
                    local.add((a.asname or a.name).split(".")[0])
            elif isinstance(node, ast.Lambda):
                for a in list(node.args.args) + list(node.args.kwonlyargs):
                    local.add(a.arg)
            elif isinstance(node, (ast.With, ast.AsyncWith)):
                for item in node.items:
                    if item.optional_vars is not None:
                        for t in ast.walk(item.optional_vars):
                            if isinstance(t, ast.Name):
                                local.add(t.id)
        for node in ast.walk(fn):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                if (node.id not in local and node.id not in module_names
                        and node.id not in declared and node.id not in CLOSURE_NAMES):
                    hits.append((fn.name, node.id, node.lineno))
    return hits


for f in ("paimai.py", "界面.py"):
    try:
        hits = scan_file(os.path.join(HERE, f))
        if hits:
            print(f"   ❌ {f}: {len(hits)} 处可疑")
            for name, nid, ln in hits[:10]:
                print(f"        {name}() 第 {ln} 行: {nid}")
            fails.append(f"未定义名字 {f}")
        else:
            print(f"   ✅ {f} 没有未定义名字")
    except Exception as e:
        print(f"   ❌ {f} 扫描失败: {e}")
        fails.append(f"扫描 {f}")

# ---------- 3) 导入 + 冒烟 ----------
section("3) 导入与关键函数冒烟")
os.environ["PAIMAI_SELFTEST"] = "1"
sys.path.insert(0, HERE)
try:
    spec = importlib.util.spec_from_file_location("pm", os.path.join(HERE, "paimai.py"))
    pm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(pm)
    print("   ✅ paimai.py 导入成功")
except Exception as e:
    print(f"   ❌ paimai.py 导入失败: {e}")
    fails.append("导入 paimai")
    pm = None

if pm is not None:
    checks = [
        ("金额转键位图", lambda: len(pm.金额转键位图("1234567")[0]) == 7),
        ("取出价金额", lambda: pm.取出价金额("465512", 3) is not None),
        ("该做仓库视觉识别", lambda: isinstance(pm.该做仓库视觉识别(0), bool)),
        ("急吗()", lambda: isinstance(pm.急吗(), bool)),
        ("清仓模块", lambda: pm._取清仓模块() is not None),
        ("从都市闲趣进大厅", lambda: callable(pm.从都市闲趣进大厅)),
        ("结算/清仓入口", lambda: callable(pm.清仓_扫描并出计划)),
    ]
    for name, fn in checks:
        try:
            good = bool(fn())
            print(f"   {'✅' if good else '❌'} {name}")
            if not good:
                fails.append(name)
        except Exception as e:
            print(f"   ❌ {name}: {type(e).__name__}: {e}")
            fails.append(name)

# ---------- 4) 素材 ----------
section("4) 素材模板")
need = ["step1.png", "step2.png", "step3.png", "step5.png", "step7.png",
        "auction_hall.png", "urban_leisure.png", "instant_hammer.png",
        "btn_report.png", "btn_playlist_close.png", "count_1.png", "count_0.png"]
missing = [n for n in need if not os.path.isfile(os.path.join(BASE, "素材", n))]
if missing:
    print(f"   ❌ 缺少: {'、'.join(missing)}")
    fails.append("素材缺失")
else:
    print(f"   ✅ {len(need)} 个关键素材齐全")

# ---------- 5) 版本 ----------
section("5) 版本号")
try:
    import importlib
    ver = importlib.import_module("版本")
    print(f"   {ver.APP_VERSION}  （{ver.APP_DISPLAY}）")
except Exception as e:
    print(f"   ❌ 读版本失败: {e}")
    fails.append("版本")

# ---------- 总结 ----------
section("总结")
if fails:
    print(f"❌ 有 {len(fails)} 项没过：{'、'.join(fails)}")
    sys.exit(1)
print("✅ 全部检查通过")
