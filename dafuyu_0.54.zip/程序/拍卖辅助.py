# -*- coding: utf-8 -*-
"""拍卖辅助页（左侧导航第七页）。

它只干一件事：把「这一仓到底值多少」摊开给人看，不用翻日志翻图。

数据全部来自 记录\\试验记录.jsonl 里的 warehouse_vision 事件，**只读**：
不回写、不改参数、不碰鼠标键盘。跟挂机进程零耦合 —— 脚本没跑的时候
也能翻上一局的结果。

跟大佬那份视觉分析器的关系：思路参考，代码独立写的。这边不做训练、不做
逐格校验页，只保留挂机时真正会瞄一眼的那几样：
估值三档、认出多少、格子分布、逐件清单、以及跟游戏估价差在哪。
"""

from __future__ import annotations

import json
import os

from PyQt5.QtCore import QPointF, QRectF, Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QColor, QFont, QPainter, QPalette, QPen, QPixmap
from PyQt5.QtWidgets import (
    QFrame,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

EVENT_TYPE = "warehouse_vision"
# 整仓固定 10 列 × 25 行（跟脚本那边 warehouse_vision.COLS/ROWS 一致）。
# 写死是为了跨局可比 —— 不然一局货少，格子就被放大成一整片，看不出分布。
GRID_COLS = 10
GRID_ROWS = 25
# 只在文件尾巴上找，几十兆的记录不整个读
TAIL_BYTES = 768 * 1024
MAX_PARSE_LINES = 500

QUALITY_HEX = {
    "白色": "#d7dbe3",
    "绿色": "#22c55e",
    "蓝色": "#3b82f6",
    "紫色": "#a855f7",
    "金色": "#f6c344",
    "红色": "#ef4444",
    "特殊红色": "#ff2d6f",
}


def _fmt(value):
    """金额给人看的写法：18200 → 1.8万，省得数字长到挤不下。"""
    try:
        n = int(value or 0)
    except (TypeError, ValueError):
        return "—"
    if n <= 0:
        return "—"
    if n >= 10000:
        return "{:.1f}万".format(n / 10000.0)
    return "{:,}".format(n)


def _fmt_full(value):
    try:
        return "{:,}".format(int(value or 0))
    except (TypeError, ValueError):
        return "—"


def _quality_color(name):
    return QUALITY_HEX.get(str(name or ""), "#7c8698")


def _nice(value):
    """往下贴到 …9999，跟挂机出价那边一个手感（1,350,000 → 1,349,999）。"""
    try:
        v = int(value or 0)
    except (TypeError, ValueError):
        return 0
    if v <= 0:
        return 0
    out = v // 10000 * 10000 + 9999
    if out > v:
        out -= 10000
    return out if out > 0 else v


def _wrong_cost(item):
    """这件要是认错了，最坏能差多少钱。

    候选里最贵那个减掉这件的价 —— 就是「名字认小、其实是个更贵的货」
    那一部分。只有一个候选（或者根本没候选）就算不出风险，给 0。
    """
    cands = item.get("candidate_top") or []
    prices = []
    for c in cands:
        try:
            prices.append(float(c.get("price") or 0))
        except (TypeError, ValueError):
            continue
    if len(prices) < 2:
        return 0.0
    try:
        base = float(item.get("median") or item.get("mean") or 0)
    except (TypeError, ValueError):
        return 0.0
    if base <= 0:
        return 0.0
    return max(0.0, max(prices) - base)


def _wrong_cost_total(items):
    """整仓认错风险：把每件最坏虚高加起来，返回 (总额, 有几件会差)。"""
    total = 0.0
    hits = 0
    for it in items or []:
        cost = _wrong_cost(it)
        if cost > 0:
            total += cost
            hits += 1
    return total, hits


def _suggest(event):
    """按视觉估值给三档参考价。不看对手、不看回合、也不要游戏估价。

    稳一点 = 最低能值（每件都按最便宜算，出到这数基本不亏）
    常规   = 均值 8 折，留两成利润
    想抢   = 均值 9 折，抢货用，赚得薄
    """
    try:
        mean = int(event.get("mean_total") or 0)
        low = int(event.get("min_total") or 0)
    except (TypeError, ValueError):
        return None
    if mean <= 0:
        return None
    cap = mean * 0.70
    safe = min(low, cap) if low > 0 else mean * 0.65
    return {
        "safe": _nice(safe),
        "normal": _nice(mean * 0.80),
        "push": _nice(mean * 0.90),
    }


def _read_tail_records(path, max_bytes=TAIL_BYTES):
    """从 jsonl 尾巴读最后若干条记录。

    按字节从末尾切一块，块首那行可能是半截，直接丢掉。解析失败的行也跳过 ——
    挂机进程正在写的时候偶尔会撞上半行，这里不值得报错。
    """
    try:
        size = os.path.getsize(path)
    except OSError:
        return []
    if size <= 0:
        return []
    try:
        with open(path, "rb") as fp:
            start = max(0, size - int(max_bytes))
            fp.seek(start)
            blob = fp.read()
    except OSError:
        return []
    if start > 0:
        cut = blob.find(b"\n")
        blob = blob[cut + 1:] if cut >= 0 else b""
    records = []
    for raw in blob.split(b"\n")[-MAX_PARSE_LINES:]:
        raw = raw.strip()
        if not raw:
            continue
        # 一条视觉事件带着整仓 items，单行几十 KB。尾巴里绝大多数是别的
        # 事件，先按字符串粗筛，能省掉九成的 JSON 解析。
        if b'"warehouse_vision"' not in raw:
            continue
        try:
            obj = json.loads(raw.decode("utf-8"))
        except Exception:
            continue
        if isinstance(obj, dict):
            records.append(obj)
    return records


# 原图解码缓存：一张整仓图 1.5MB，切页/刷新时反复解码很浪费。
# 按 (路径, mtime) 认，文件被替换就重新读。
_PIX_CACHE = {}


class GridMap(QWidget):
    """10×25 的整仓格子图。

    认出来的格子填品质色，没认出来的画空心。
    点一下格子，外面就能看到这格到底是什么。
    """

    picked = pyqtSignal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._items = []
        self._selected = -1
        self._hover = -1
        self._rects = []
        self._ink = None
        self._pix = None
        self._img_rect = QRectF()
        # 整仓图的像素坐标→格子：13.5 + 列×56.6。跟 warehouse_vision.FULL_GRID 一致，
        # 事件里带了就用事件里的，带不到就用这套默认值。
        self._grid = (13.5, 15.0, 56.6)
        self.setMinimumHeight(160)
        self.setMinimumWidth(280)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("")

    def set_image(self, path):
        """铺一张整仓原图当底。图没了就退回纯色块，不影响别的。"""
        pix = None
        if path and os.path.isfile(path):
            try:
                stamp = os.path.getmtime(path)
            except OSError:
                stamp = 0
            hit = _PIX_CACHE.get(path)
            if hit is not None and hit[0] == stamp:
                pix = hit[1]
            else:
                pm = QPixmap(path)
                if not pm.isNull():
                    if len(_PIX_CACHE) >= 8:
                        _PIX_CACHE.clear()
                    _PIX_CACHE[path] = (stamp, pm)
                    pix = pm
        self._pix = pix
        self.update()

    def set_grid(self, origin_x=None, origin_y=None, cell=None):
        ox, oy, c = self._grid
        try:
            if origin_x is not None:
                ox = float(origin_x)
            if origin_y is not None:
                oy = float(origin_y)
            if cell is not None and float(cell) > 0:
                c = float(cell)
        except (TypeError, ValueError):
            pass
        self._grid = (ox, oy, c)

    def set_ink(self, color):
        """格阵里的线 / 文字颜色。页面主题变了就跟着刷。"""
        self._ink = QColor(color) if color else None
        self.update()

    def set_items(self, items):
        self._items = list(items or [])
        self._selected = -1
        self._hover = -1
        self._rects = []
        self.update()

    def clear(self):
        self.set_items([])
        self._pix = None
        self._img_rect = QRectF()
        self.update()

    def selected_item(self):
        if 0 <= self._selected < len(self._items):
            return self._items[self._selected]
        return None

    def _text_color(self):
        if self._ink is not None:
            return self._ink
        return self.palette().color(QPalette.WindowText)

    # ---------- 布局 ----------

    def _geometry_base(self):
        """没有原图时的底图几何：格子保持正方形，整块居中。

        以前横竖各自等分，格子会被控件拉成宽扁形，看着像表格不像仓库。
        """
        w = max(1, self.width())
        h = max(1, self.height())
        pad = 6.0
        cell = min(max(1.0, w - pad * 2) / float(GRID_COLS),
                   max(1.0, h - pad * 2) / float(GRID_ROWS))
        return ((w - cell * GRID_COLS) / 2.0,
                (h - cell * GRID_ROWS) / 2.0,
                cell)

    def _layout_rects(self):
        """把格子坐标换算成控件里的矩形。

        有原图就贴着原图的像素走（认错时能跟真图对上），没有就退回
        固定 10×25 的等分网格。整仓口径固定 10×25，横竖各自缩放。
        """
        if not self._items:
            return []
        if self._pix is not None and not self._img_rect.isNull():
            ox, oy, cell = self._grid
            rect = self._img_rect
            scale = rect.width() / float(max(1, self._pix.width()))
            out = []
            for it in self._items:
                try:
                    x = int(it.get("x", 0))
                    y = int(it.get("y", 0))
                    iw = max(1, int(it.get("w", 1)))
                    ih = max(1, int(it.get("h", 1)))
                except (TypeError, ValueError):
                    out.append(QRectF())
                    continue
                out.append(
                    QRectF(
                        rect.x() + (ox + x * cell) * scale,
                        rect.y() + (oy + y * cell) * scale,
                        max(1.5, iw * cell * scale),
                        max(1.5, ih * cell * scale),
                    )
                )
            return out
        ox, oy, cell = self._geometry_base()
        rects = []
        for it in self._items:
            try:
                x = int(it.get("x", 0))
                y = int(it.get("y", 0))
                iw = max(1, int(it.get("w", 1)))
                ih = max(1, int(it.get("h", 1)))
            except (TypeError, ValueError):
                rects.append(QRectF())
                continue
            rects.append(
                QRectF(
                    ox + x * cell + 0.5,
                    oy + y * cell + 0.5,
                    max(1.5, iw * cell - 1.0),
                    max(1.5, ih * cell - 1.0),
                )
            )
        return rects

    # ---------- 绘制 ----------

    def _paint_canvas(self, painter, text_color):
        """铺底：有原图就铺原图，没有就铺淡格线。顺手把 _img_rect 定下来。"""
        if self._pix is not None and not self._pix.isNull():
            pw = max(1, self._pix.width())
            ph = max(1, self._pix.height())
            avail_w = max(1.0, self.width() - 8.0)
            avail_h = max(1.0, self.height() - 8.0)
            scale = min(avail_w / float(pw), avail_h / float(ph))
            iw = pw * scale
            ih = ph * scale
            self._img_rect = QRectF(
                (self.width() - iw) / 2.0, (self.height() - ih) / 2.0, iw, ih)
            painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
            painter.drawPixmap(self._img_rect, self._pix, QRectF(self._pix.rect()))
            edge = QColor(text_color)
            edge.setAlpha(60)
            painter.setPen(QPen(edge, 1))
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(self._img_rect.adjusted(-0.5, -0.5, 0.5, 0.5), 3, 3)
            return
        self._img_rect = QRectF()
        ox, oy, cell = self._geometry_base()
        faint = QColor(text_color)
        faint.setAlpha(38)
        painter.setPen(QPen(faint, 1))
        painter.setBrush(Qt.NoBrush)
        for c in range(GRID_COLS + 1):
            x = ox + c * cell
            painter.drawLine(QPointF(x, oy), QPointF(x, oy + GRID_ROWS * cell))
        for r in range(GRID_ROWS + 1):
            y = oy + r * cell
            painter.drawLine(QPointF(ox, y), QPointF(ox + GRID_COLS * cell, y))

    def paintEvent(self, event):  # noqa: N802 (Qt 命名)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        text_color = self._text_color()
        idle = QColor(text_color)
        idle.setAlpha(70)

        if not self._items:
            painter.setPen(QPen(idle, 1, Qt.DashLine))
            painter.drawRoundedRect(QRectF(2, 2, self.width() - 4, self.height() - 4), 8, 8)
            painter.setPen(QPen(idle, 1))
            font = QFont(self.font())
            font.setPointSize(max(8, font.pointSize() - 1))
            painter.setFont(font)
            painter.drawText(
                self.rect(), Qt.AlignCenter,
                "还没有整仓识别结果\n"
                "点右上角【扫一次仓】就能试一次（不用挂机）\n"
                "或者去「策略」页打开仓库视觉，之后每回合都有",
            )
            painter.end()
            return

        self._paint_canvas(painter, text_color)
        self._rects = self._layout_rects()
        on_image = not self._img_rect.isNull()

        for idx, (it, rect) in enumerate(zip(self._items, self._rects)):
            if rect.isNull():
                continue
            color = QColor(_quality_color(it.get("color")))
            named = bool(it.get("item"))
            no_data = str(it.get("source") or "") == "no-data"
            if no_data:
                painter.setBrush(Qt.NoBrush)
                painter.setPen(QPen(idle, 1, Qt.DashLine))
            elif on_image:
                # 叠在真图上：只描一圈色 + 很淡的填充，别把底下的东西盖住
                fill = QColor(color)
                fill.setAlpha(58)
                painter.setBrush(fill)
                painter.setPen(QPen(color, 2))
            else:
                fill = QColor(color)
                fill.setAlpha(215 if named else 80)
                painter.setBrush(fill)
                painter.setPen(QPen(color.darker(190), 1))
            painter.drawRoundedRect(rect, 3, 3)
            if idx == self._selected:
                painter.setBrush(Qt.NoBrush)
                painter.setPen(QPen(text_color, 2))
                painter.drawRoundedRect(rect.adjusted(-1, -1, 1, 1), 4, 4)
            elif idx == self._hover:
                hover_pen = QColor(text_color)
                hover_pen.setAlpha(160)
                painter.setBrush(Qt.NoBrush)
                painter.setPen(QPen(hover_pen, 1.5))
                painter.drawRoundedRect(rect.adjusted(-1, -1, 1, 1), 4, 4)
        painter.end()

    # ---------- 鼠标 ----------

    def _hit(self, pos):
        for idx, rect in enumerate(self._rects):
            if rect.isNull():
                continue
            if rect.adjusted(-1, -1, 1, 1).contains(pos):
                return idx
        return -1

    def mouseMoveEvent(self, event):  # noqa: N802
        idx = self._hit(event.pos())
        if idx != self._hover:
            self._hover = idx
            it = self._items[idx] if 0 <= idx < len(self._items) else None
            if it:
                top = (it.get("candidate_top") or [{}])[0]
                name = it.get("item") or top.get("name") or "没认出"
                self.setToolTip("%s\n第%d列 第%d行 · %s" % (
                    name, int(it.get("x", 0)) + 1, int(it.get("y", 0)) + 1,
                    _fmt(it.get("mean"))))
            else:
                self.setToolTip("")
            self.update()
        super().mouseMoveEvent(event)

    def leaveEvent(self, event):  # noqa: N802
        self._hover = -1
        self.setToolTip("")
        self.update()
        super().leaveEvent(event)

    def mousePressEvent(self, event):  # noqa: N802
        if event.button() == Qt.LeftButton:
            idx = self._hit(event.pos())
            if idx >= 0:
                self._selected = idx if idx != self._selected else -1
                self.update()
                self.picked.emit(self._selected)
        super().mousePressEvent(event)


class ItemBar(QWidget):
    """一件一行，背后一条按占比的底色条。

    条长 = 这件的中位价 / 清单里最贵那件。一眼就能看出「这一仓的钱是
    哪几件撑起来的」——比一排纯数字直观，也不用额外占地方。
    """

    def __init__(self, name, where, price, share, color, parent=None,
                 conf=None, source="", ncand=0):
        super().__init__(parent)
        self._name = str(name)
        self._where = str(where)
        self._price = str(price)
        self._share = max(0.0, min(1.0, float(share)))
        self._color = QColor(color)
        self._ink = None
        self._warn = None
        self._conf = conf
        self._source = str(source or "")
        self._ncand = int(ncand or 0)
        self.setMinimumHeight(23)
        self.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)

    def _source_mark(self):
        """认名字的来路：对上了模板就不标，靠形状蒙的给个记号。"""
        s = self._source
        if s == "exact":
            return ""
        if s.startswith("no-shape"):
            return "?"
        if s == "shape":
            return "≈"
        if s == "no-data":
            return "?"
        return "≈" if s else ""

    def set_ink(self, color):
        self._ink = QColor(color) if color else None
        self.update()

    def _ink_color(self):
        if self._ink is not None:
            return self._ink
        return self.palette().color(QPalette.WindowText)

    def paintEvent(self, _event):
        painter = QPainter(self)
        try:
            painter.setRenderHint(QPainter.Antialiasing, True)
            w = float(self.width())
            h = float(self.height())
            if w <= 4 or h <= 2:
                return

            # 底条：占比越高越长，颜色就是品质色，淡一点别抢戏
            bar = QRectF(0.0, 1.0, max(3.0, (w - 2.0) * self._share), h - 2.0)
            fill = QColor(self._color)
            fill.setAlpha(58)
            painter.setPen(Qt.NoPen)
            painter.setBrush(fill)
            painter.drawRoundedRect(bar, 3, 3)

            ink = self._ink_color()
            font = self.font()
            font.setPixelSize(12)
            painter.setFont(font)
            fm = painter.fontMetrics()

            # 色点
            painter.setBrush(self._color)
            painter.drawRect(QRectF(1.0, (h - 7.0) / 2.0, 7.0, 7.0))

            # 从右往左摆：价格 · 位置 · 置信 · 候选数，剩下的都留给名字
            price_w = 54.0
            pos_w = 48.0
            conf_w = 34.0
            cand_w = 22.0 if self._ncand > 1 else 0.0
            gap = 6.0
            name_x = 12.0
            right = w - 2.0
            price_left = right - price_w
            pos_left = price_left - gap - pos_w
            conf_left = pos_left - gap - conf_w
            cand_left = conf_left - gap - cand_w if cand_w else conf_left
            name_w = (cand_left if cand_w else conf_left) - gap - name_x

            painter.setPen(ink)
            if name_w > 18.0:
                shown = self._source_mark() + self._name
                painter.drawText(
                    QRectF(name_x, 0.0, name_w, h),
                    int(Qt.AlignLeft | Qt.AlignVCenter),
                    fm.elidedText(shown, Qt.ElideRight, int(name_w)))

            faint = QColor(ink)
            faint.setAlpha(150)

            if self._ncand > 1 and cand_w:
                painter.setPen(faint)
                painter.drawText(
                    QRectF(cand_left, 0.0, cand_w, h),
                    int(Qt.AlignLeft | Qt.AlignVCenter), "×%d" % self._ncand)

            if self._conf is not None:
                # 拿得准的就是常态色，拿不准的才跳出来
                if self._conf < 0.60:
                    warn = self._colors_warn()
                    painter.setPen(QColor(warn) if warn else faint)
                else:
                    painter.setPen(faint)
                painter.drawText(
                    QRectF(conf_left, 0.0, conf_w, h),
                    int(Qt.AlignLeft | Qt.AlignVCenter),
                    "%d%%" % int(round(self._conf * 100)))

            painter.setPen(faint)
            painter.drawText(
                QRectF(pos_left, 0.0, pos_w, h),
                int(Qt.AlignLeft | Qt.AlignVCenter), self._where)

            painter.setPen(ink)
            painter.drawText(
                QRectF(price_left, 0.0, price_w, h),
                int(Qt.AlignRight | Qt.AlignVCenter), self._price)
        finally:
            painter.end()

    def _colors_warn(self):
        return getattr(self, "_warn", None)

    def set_warn(self, color):
        self._warn = QColor(color) if color else None
        self.update()


class 拍卖辅助页(QWidget):
    """整页形态的拍卖辅助：上面一行指标，左边整仓格子，右边逐件清单。"""

    def __init__(self, jsonl_path, colors=None, on_scan=None, parent=None):
        super().__init__(parent)
        self._jsonl = jsonl_path
        # 记录\试验记录.jsonl → 上一层就是 anon 根目录，事件里的 image_path 是相对它写的
        self._base = os.path.dirname(os.path.dirname(os.path.abspath(jsonl_path)))
        self._colors = dict(colors or {})
        self._on_scan = on_scan
        self._stamp = None
        self._event = None
        self._build()
        self._timer = QTimer(self)
        self._timer.timeout.connect(self.refresh)
        self._timer.start(3000)

    def flash(self, text):
        """页面上临时显示一句（扫仓进度 / 报错），下次刷新会被正常内容盖掉。"""
        try:
            self.note_lab.setText(str(text))
        except Exception:
            pass

    def set_scanning(self, busy):
        """扫仓进行中：按钮锁住，免得连点两次抢鼠标。"""
        try:
            self.scan_btn.setEnabled(not busy)
            self.scan_btn.setText("⏳  正在翻仓…" if busy else "📸  扫一次仓")
        except Exception:
            pass

    def _fire_scan(self):
        if self._on_scan is None:
            return
        self.set_scanning(True)
        try:
            self._on_scan()
        except Exception:
            self.set_scanning(False)

    # ---------- 搭界面 ----------

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(10)

        # --- 顶部：这组数据是什么时候的 + 手动刷新 ---
        head = QHBoxLayout()
        head.setSpacing(10)
        self.when_lab = QLabel("还没读到整仓识别结果")
        self.when_lab.setObjectName("big")
        self.note_lab = QLabel("")
        self.note_lab.setObjectName("cap")
        self.refresh_btn = QPushButton("↻  刷新")
        self.refresh_btn.setObjectName("blue")
        self.refresh_btn.setMinimumHeight(34)
        self.refresh_btn.setFixedWidth(104)
        self.refresh_btn.clicked.connect(self.refresh)
        self.scan_btn = QPushButton("📸  扫一次仓")
        self.scan_btn.setObjectName("primary")
        self.scan_btn.setMinimumHeight(34)
        self.scan_btn.setFixedWidth(148)
        self.scan_btn.setToolTip(
            "不用挂机：把游戏停在藏品仓库页，点一下就能翻一遍整仓并记下来\n"
            "翻的时候别动仓库、别切窗口，大概要 10 秒"
        )
        self.scan_btn.clicked.connect(self._fire_scan)
        head.addWidget(self.when_lab)
        head.addSpacing(12)
        head.addWidget(self.note_lab)
        head.addStretch(1)
        head.addWidget(self.scan_btn)
        head.addWidget(self.refresh_btn)
        root.addLayout(head)

        # --- 八张指标卡（照视觉计算那套排的：一行四张，两行）---
        # 出价参考的是「推荐值」= P75；校准值只作影子参考。
        cards = QGridLayout()
        cards.setSpacing(8)
        self.metric_vals = {}
        specs = (
            ("estimate", "游戏估价", "挂机时从画面读到的估价；手动扫仓没有这一项"),
            ("min", "视觉最低", "每个格子都按最便宜的可能算，加起来的下限"),
            ("mean", "高风险参考线", "视觉均值。高风险值低于这条线时，不建议冒险追价"),
            ("cal", "数据校准值", "历史结算样本训出来的校准模型给的，只作影子参考"),
            ("p50", "稳妥值", "P50，稳妥分析参考"),
            ("p75", "推荐值", "P75，现在的出价就按它参考"),
            ("p90", "高风险值", "P90，高风险分析参考"),
            ("gap", "视觉 vs 估价", "视觉均值比游戏估价高多少"),
        )
        for idx, (key, label, tip) in enumerate(specs):
            v = QLabel("—")
            v.setObjectName("big")
            c = QLabel(label)
            c.setObjectName("cap")
            box = QVBoxLayout()
            box.setContentsMargins(12, 8, 12, 8)
            box.setSpacing(2)
            box.addWidget(v)
            box.addWidget(c)
            holder = QWidget()
            holder.setObjectName("statCard")
            holder.setLayout(box)
            holder.setToolTip(tip)
            cards.addWidget(holder, idx // 4, idx % 4)
            self.metric_vals[key] = v
        root.addLayout(cards)

        # 校验与状态：这一批识别结果靠不靠谱，先看在它上面
        self.check_lab = QLabel("")
        self.check_lab.setObjectName("cap")
        self.check_lab.setWordWrap(True)
        self.check_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(self.check_lab)

        # 推荐出价那一行：纯按视觉估值算，不依赖游戏估价
        self.suggest_lab = QLabel("")
        self.suggest_lab.setWordWrap(True)
        self.suggest_lab.setMinimumHeight(20)
        self.suggest_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(self.suggest_lab)

        # 认错风险：写清楚这仓的估值最多能虚高多少，别按虚高的价去抢
        self.risk_lab = QLabel("")
        self.risk_lab.setWordWrap(True)
        self.risk_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        root.addWidget(self.risk_lab)

        # --- 主体：左格阵 / 右清单 ---
        mid = QHBoxLayout()
        mid.setSpacing(12)

        self.grid_group = QGroupBox("整仓格子（10 × 25，点一格看它是什么）")
        left = self.grid_group
        lv = QVBoxLayout(left)
        lv.setSpacing(8)
        self.gridmap = GridMap()
        self.gridmap.picked.connect(self._on_pick)
        self.gridmap.setMinimumHeight(380)
        lv.addWidget(self.gridmap, 1)
        self.pick_lab = QLabel("点一格看它是什么")
        self.pick_lab.setObjectName("hint")
        self.pick_lab.setWordWrap(True)
        self.pick_lab.setMinimumHeight(54)
        lv.addWidget(self.pick_lab)
        mid.addWidget(left, 3)

        right = QGroupBox("认出来的件")
        rv = QVBoxLayout(right)
        rv.setSpacing(8)
        # 价格贡献：这仓的钱都压在哪些品质上
        self.contrib_lab = QLabel("")
        self.contrib_lab.setObjectName("hint")
        self.contrib_lab.setWordWrap(True)
        self.contrib_lab.setTextInteractionFlags(Qt.TextSelectableByMouse)
        rv.addWidget(self.contrib_lab)
        self.items_head = QLabel("")
        self.items_head.setObjectName("hint")
        rv.addWidget(self.items_head)
        self.item_box = QWidget()
        self.item_lay = QVBoxLayout(self.item_box)
        self.item_lay.setContentsMargins(0, 0, 0, 0)
        self.item_lay.setSpacing(4)
        self.item_lay.addStretch(1)
        wrap = QScrollArea()
        wrap.setWidgetResizable(True)
        wrap.setFrameShape(QFrame.NoFrame)
        wrap.setWidget(self.item_box)
        rv.addWidget(wrap, 1)
        mid.addWidget(right, 2)
        root.addLayout(mid, 1)

    def apply_colors(self, colors):
        """主题换了，把格阵里的线 / 字色跟上。"""
        self._colors = dict(colors or {})
        self.gridmap.set_ink(self._colors.get("card_fg"))

    # ---------- 数据 ----------

    def load_event(self, event):
        """外部直接喂一条事件（预览 / 测试用，正常走 refresh 自己读文件）。"""
        if isinstance(event, dict) and event.get("items"):
            self._apply(event)

    def refresh(self):
        # 没切到这一页就别扫文件了，省点力气
        if not self.isVisible():
            return
        try:
            stat = os.stat(self._jsonl)
        except OSError:
            self._show_empty("还没开始跑 —— 记录里一条数据都没有")
            return
        stamp = (stat.st_size, int(stat.st_mtime))
        if stamp == self._stamp:
            return
        self._stamp = stamp
        try:
            records = _read_tail_records(self._jsonl)
        except Exception:
            return
        event = None
        for rec in reversed(records):
            if rec.get("type") == EVENT_TYPE and rec.get("items"):
                event = rec
                break
        if not event:
            # 尾巴上没有视觉事件，但之前读到过 —— 保留上次的，别一有普通日志就闪成空白
            if self._event is None:
                self._show_empty("还没有整仓数据")
            return
        self._apply(event)

    def _show_empty(self, message):
        self.when_lab.setText(message)
        self.note_lab.setText("点右上角【扫一次仓】就能试一次，不用挂机")
        for key in self.metric_vals:
            self.metric_vals[key].setText("—")
        self.gridmap.clear()
        self.grid_group.setTitle("整仓格子（10 × 25，点一格看它是什么）")
        self.pick_lab.setText("点一格看它是什么")
        self.items_head.setText("还没有认出来的东西")
        self.suggest_lab.setText("")
        if hasattr(self, "check_lab"):
            self.check_lab.setText("")
        if hasattr(self, "contrib_lab"):
            self.contrib_lab.setText("")
        self._clear_items()

    def _clear_items(self):
        while self.item_lay.count() > 1:
            item = self.item_lay.takeAt(0)
            w = item.widget()
            if w is not None:
                # 光 deleteLater 不够：它要等事件循环，这期间旧行还挂在
                # item_box 上、停在老位置，看着就像文字叠在一起。
                w.setParent(None)
                w.deleteLater()

    def _apply(self, event):
        self._event = event
        rnd = int(event.get("round") or 0)
        estimate = int(event.get("game_estimate") or 0)
        low = int(event.get("min_total") or 0)
        mean = int(event.get("mean_total") or 0)
        p50 = int(event.get("p50_total") or 0)
        p75 = int(event.get("p75_total") or 0)
        p90 = int(event.get("p90_total") or 0)
        cal = int(event.get("calibrated_value") or 0)
        named = int(event.get("named_count") or 0)
        blocks = int(event.get("block_count") or 0)
        ok = bool(event.get("checksum_ok"))
        ts = str(event.get("ts") or "")
        manual = str(event.get("scan_mode") or "") == "manual"

        if manual:
            self.when_lab.setText("手动扫仓 · %s" % (ts or "时间未知"))
        else:
            self.when_lab.setText(
                "%s · %s" % ("第%d回合" % rnd if rnd else "上一局", ts or "时间未知"))
        bits = ["%d 件" % blocks, "认出 %d" % named, "校验%s" % ("通过" if ok else "没过")]
        elapsed = int(event.get("elapsed_ms") or 0)
        if elapsed:
            bits.append("识别 %.1f 秒" % (elapsed / 1000.0))
        self.note_lab.setText(" · ".join(bits))

        self.metric_vals["min"].setText(_fmt(low))
        self.metric_vals["mean"].setText(_fmt(mean))
        self.metric_vals["cal"].setText(_fmt(cal) if cal > 0 else "—")
        self.metric_vals["p50"].setText(_fmt(p50))
        self.metric_vals["p75"].setText(_fmt(p75))
        self.metric_vals["p90"].setText(_fmt(p90))
        est_lab = self.metric_vals["estimate"]
        if estimate > 0:
            est_lab.setText(_fmt(estimate))
            est_lab.setToolTip("")
        else:
            est_lab.setText("—")
            est_lab.setToolTip(
                "手动扫仓时停在仓库页，画面里没有游戏估价可读；\n"
                "只有挂机拍卖时才能读到。推荐出价不依赖它。"
            )

        # 差多少 —— 挂机时最该瞄的就是这一格
        gap_lab = self.metric_vals["gap"]
        gap_lab.setStyleSheet("")
        verdict = ""
        if estimate > 0 and mean > 0:
            pct = (mean - estimate) * 100.0 / estimate
            if pct >= 8:
                gap_lab.setText("+%.0f%%" % pct)
                gap_lab.setStyleSheet("color:%s;" % _colors_up(self._colors))
                verdict = "视觉比估价高，这仓值得抢"
            elif pct <= -8:
                gap_lab.setText("%.0f%%" % pct)
                gap_lab.setStyleSheet("color:%s;" % _colors_down(self._colors))
                verdict = "视觉比估价低，别追太狠"
            else:
                gap_lab.setText("%+.0f%%" % pct)
                verdict = "跟估价差不多"
        else:
            gap_lab.setText("—")

        self.note_lab.setText(" · ".join(bits + ([verdict] if verdict else [])))
        self.pick_lab.setText("点一格看它是什么")

        # 推荐出价：纯视觉算，有没有游戏估价都能给
        tiers = _suggest(event)
        if tiers:
            tail = (
                "（按视觉估值算的，没算对手和回合）" if estimate > 0
                else "（手动扫时没有游戏估价，这几档是纯按视觉算的）"
            )
            self.suggest_lab.setText(
                '<span style="font-size:13px;">推荐出价　'
                '<b>稳 %s</b>　常规 %s　想抢 %s　'
                '<span style="color:%s;font-size:12px;">%s</span></span>'
                % (_fmt(tiers["safe"]), _fmt(tiers["normal"]),
                   _fmt(tiers["push"]),
                   _colors_hint(self._colors), tail)
            )
        else:
            self.suggest_lab.setText("")

        items = event.get("items") or []

        # 校验与状态：这批识别结果靠不靠谱
        try:
            cov_blocks = float(event.get("coverage_blocks") or 0)
        except (TypeError, ValueError):
            cov_blocks = 0.0
        try:
            cov_area = float(event.get("coverage_area") or 0)
        except (TypeError, ValueError):
            cov_area = 0.0
        try:
            cdiff = int(event.get("checksum_diff") or 0)
            ctol = int(event.get("checksum_tolerance") or 0)
        except (TypeError, ValueError):
            cdiff, ctol = 0, 0
        confs = []
        for it in items:
            if not it.get("item"):
                continue
            try:
                c = it.get("top_candidate_confidence")
                if c is not None:
                    confs.append(float(c))
            except (TypeError, ValueError):
                pass
        avg_conf = (sum(confs) / len(confs)) if confs else 0.0
        named_pct = (named * 100.0 / blocks) if blocks else 0.0
        ok_col = _colors_up(self._colors) if ok else _colors_down(self._colors)
        bits_chk = [
            "块覆盖率 %d%%" % int(round(cov_blocks * 100)),
            "面积覆盖率 %d%%" % int(round(cov_area * 100)),
            "配名率 %d%%（%d/%d）" % (int(round(named_pct)), named, blocks),
            '<span style="color:%s;">金额校验 %s</span>'
            % (ok_col, "通过" if ok else "没过"),
        ]
        if ctol > 0:
            bits_chk.append("差 %s / 容差 %s" % (_fmt_full(cdiff), _fmt_full(ctol)))
        if confs:
            bits_chk.append("平均置信 %d%%" % int(round(avg_conf * 100)))
        if elapsed:
            bits_chk.append("识别 %.1f 秒" % (elapsed / 1000.0))
        self.check_lab.setText(" · ".join(bits_chk))

        # 价格贡献：这仓的钱压在哪些品质上
        byq = {}
        for it in items:
            q = str(it.get("color") or "?")
            try:
                v = float(it.get("mean") or 0)
            except (TypeError, ValueError):
                v = 0.0
            cell = byq.setdefault(q, [0, 0.0])
            cell[0] += 1
            cell[1] += v
        grand = sum(v for _n, v in byq.values())
        rows_q = sorted(byq.items(), key=lambda kv: -kv[1][1])[:5]
        if grand > 0 and rows_q:
            parts = []
            for q, (n, v) in rows_q:
                parts.append(
                    '<span style="color:%s;">■</span>%s %d件 %s（%d%%）'
                    % (_quality_color(q), q, n, _fmt(v), int(round(v / grand * 100))))
            self.contrib_lab.setText("价格贡献　" + "　".join(parts))
        else:
            self.contrib_lab.setText("")

        # 认错风险：候选里最贵的那些，跟现在的估值差多少
        risk_total, risk_hits = _wrong_cost_total(items)
        try:
            mean_total = float(event.get("mean_total") or 0)
        except (TypeError, ValueError):
            mean_total = 0.0
        if risk_total > 0 and mean_total > 0:
            share = int(round(risk_total / mean_total * 100))
            self.risk_lab.setText(
                '<span style="font-size:12px;color:%s;">⚠ 有 %d 件认不准，'
                '最坏虚高 %s（占估值的 %d%%）</span>'
                % (_colors_down(self._colors), risk_hits,
                   _fmt(risk_total), share))
        else:
            self.risk_lab.setText("")

        # 原图：有就贴着真图叠框，认错的时候一眼能看出错在哪一格
        rel = str(event.get("image_path") or "").strip()
        img_path = os.path.join(self._base, rel) if rel else ""
        has_img = bool(img_path and os.path.isfile(img_path))
        self.gridmap.set_grid(
            event.get("grid_origin_x"), event.get("grid_origin_y"), event.get("grid_cell"))
        self.gridmap.set_image(img_path if has_img else None)
        if has_img:
            self.grid_group.setTitle("整仓原图 + 识别框（10 × 25，点一格看它是什么）")
            self.grid_group.setToolTip("")
        else:
            self.grid_group.setTitle("整仓格子（10 × 25，点一格看它是什么）")
            self.grid_group.setToolTip(
                "这一条没存原图。手动扫仓一定会存；挂机要存得去「策略」页把\n"
                "【保存仓库视觉图】打开，之后每回合都会留一张。")
        self.gridmap.set_items(items)
        self._fill_items(items)

    def _fill_items(self, items):
        self._clear_items()
        rows = []
        for it in items:
            if not it.get("item"):
                continue
            try:
                mean = float(it.get("mean") or 0)
            except (TypeError, ValueError):
                mean = 0.0
            rows.append((mean, it))
        rows.sort(key=lambda pair: -pair[0])
        self.items_head.setText(
            "认得出名字的 %d 件 · 条是占比 · ≈ 是猜的" % len(rows) if rows
            else "这一局没有一件认得出名字")
        maxv = rows[0][0] if rows else 0.0
        for mean, it in rows[:24]:
            share = (mean / maxv) if maxv > 0 else 0.0
            try:
                conf = it.get("top_candidate_confidence")
                conf = float(conf) if conf is not None else None
            except (TypeError, ValueError):
                conf = None
            try:
                ncand = int(it.get("n") or 0)
            except (TypeError, ValueError):
                ncand = 0
            bar = ItemBar(
                str(it.get("item")),
                "%d列%d行" % (int(it.get("x", 0)) + 1, int(it.get("y", 0)) + 1),
                _fmt(mean),
                share,
                _quality_color(it.get("color")),
                conf=conf,
                source=str(it.get("source") or ""),
                ncand=ncand,
            )
            bar.set_ink(self._colors.get("card_fg"))
            bar.set_warn(self._colors.get("down"))
            tip = ["%s × %d 格" % (it.get("item"),
                                   int(it.get("w", 1)) * int(it.get("h", 1))),
                   "中位估值 %s" % _fmt(mean),
                   "来源 %s（exact=对上了模板，shape=靠形状猜的）"
                   % (it.get("source") or "没记"),
                   "候选 %d 个" % ncand]
            if conf is not None:
                tip.append("置信 %d%%" % int(round(conf * 100)))
            bar.setToolTip("\n".join(tip))
            self.item_lay.insertWidget(self.item_lay.count() - 1, bar)

    def _on_pick(self, idx):
        item = self.gridmap.selected_item()
        if item is None:
            self.pick_lab.setText("点一格看它是什么")
            return
        name = item.get("item") or "没认出"
        color = item.get("color") or "?"
        try:
            mean = int(float(item.get("mean") or 0))
        except (TypeError, ValueError):
            mean = 0
        size = "%d×%d 格" % (int(item.get("w", 1)), int(item.get("h", 1)))
        where = "第%d列 第%d行" % (int(item.get("x", 0)) + 1, int(item.get("y", 0)) + 1)
        parts = ["%s（%s · %s · %s）" % (name, color, size, where)]
        if mean:
            parts.append("这格估 %s" % _fmt_full(mean))
        tops = item.get("candidate_top") or []
        if tops:
            guesses = "、".join(
                "%s %s" % (t.get("name"), _fmt(t.get("price")))
                for t in tops[:3] if t.get("name")
            )
            if guesses:
                parts.append("可能：" + guesses)
        self.pick_lab.setText("\n".join(parts))


def _colors_up(colors):
    return str((colors or {}).get("up") or "#22c55e")


def _colors_down(colors):
    return str((colors or {}).get("down") or "#ef4444")


def _colors_hint(colors):
    return str((colors or {}).get("hint_fg") or "#8b93a5")


def _colors_down(colors):
    """跌/警告色。主题里没配就退回一个偏红的。"""
    return str((colors or {}).get("down") or "#d9534f")