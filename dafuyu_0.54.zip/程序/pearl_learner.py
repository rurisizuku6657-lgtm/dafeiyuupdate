# -*- coding: utf-8 -*-
"""用真实成交记录重算珍珠档的「先验」—— 一仓大概会出现什么。

先验是给识别器兜底用的：某个格子认不清时，它会参考「同颜色、同尺寸的格子
里，历史上最常出现的是哪几件」。这份统计越贴近你自己的号，认错的概率越低。

数据从哪来
  试验记录.jsonl 里 auction_end 的 actual_value > 0，说明这局真拍出去了，
  拿它这一局的 warehouse_vision 的 items 当样本。

  同一局会扫好几个回合，**只取最后一个回合**。不这么做东西会被数六七遍。

为什么不随便覆盖
  样本不够的时候统计出来的比例是歪的，还不如用旧的。所以少于 MIN_GAMES 局
  就只报告、不写文件；真要写加 --force。

用法
  python pearl_learner.py              # 够样本就重算
  python pearl_learner.py --dry-run    # 只看看能收多少局
  python pearl_learner.py --force      # 样本不够也写（不建议）
"""

import argparse
import json
import os
import shutil
import sys
from collections import Counter
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
DEFAULT_RECORD = HERE.parent / "记录" / "试验记录.jsonl"
DEFAULT_OUTPUT = HERE / "vision_core" / "pearl_priors.json"

# 少于这么多局就别覆盖旧先验了
MIN_GAMES = 10


def _iter_jsonl(path):
    with open(path, "r", encoding="utf-8", errors="replace") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            try:
                yield json.loads(line)
            except (ValueError, TypeError):
                continue


def collect(path):
    """攒出「这局真成交了 + 最后一回合看见的东西」。"""
    actual = {}
    latest = {}
    for ev in _iter_jsonl(path):
        kind = ev.get("type")
        if kind not in ("auction_end", "warehouse_vision"):
            continue
        try:
            no = int(ev.get("auction_no") or 0)
        except (TypeError, ValueError):
            continue
        if kind == "auction_end":
            try:
                value = float(ev.get("actual_value") or 0)
            except (TypeError, ValueError):
                value = 0.0
            if value > 0:
                actual[no] = value
            continue
        items = ev.get("items") or []
        if not items:
            continue
        try:
            rnd = int(ev.get("round") or 0)
        except (TypeError, ValueError):
            rnd = 0
        if no not in latest or rnd >= latest[no][0]:
            latest[no] = (rnd, ev)

    records = []
    for no, value in sorted(actual.items()):
        got = latest.get(no)
        if not got:
            continue
        items = got[1].get("items") or []
        # 有一件没认出来，这局就不算：半份清单统计出来的比例是歪的
        if any(not str(it.get("item") or "").strip() for it in items):
            continue
        records.append({"auction_no": no, "actual_value": value,
                        "items": items})
    return records


def _size_key(item):
    return "%dx%d" % (int(item.get("w") or 1), int(item.get("h") or 1))


def build_priors(records):
    overall = Counter()
    color = Counter()
    overall_size = {}
    color_size = {}
    total_item_counts = Counter()
    color_count_totals = Counter()
    color_area_totals = Counter()

    for record in records:
        items = record.get("items") or []
        total_item_counts[len(items)] += 1
        local_colors = Counter()
        local_areas = Counter()
        for item in items:
            name = str(item.get("item") or "").strip()
            item_color = str(item.get("color") or "未知").strip()
            if not name:
                continue
            size = _size_key(item)
            area = int(item.get("w") or 1) * int(item.get("h") or 1)
            overall[name] += 1
            color[item_color] += 1
            overall_size.setdefault(size, Counter())[name] += 1
            color_size.setdefault(item_color, {}).setdefault(
                size, Counter())[name] += 1
            local_colors[item_color] += 1
            local_areas[item_color] += area
        color_count_totals.update(local_colors)
        color_area_totals.update(local_areas)

    return {
        "version": 2,
        "tier": "pearl",
        "incremental_update": False,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source": "pearl_learner.py",
        "games": len(records),
        "item_instances": sum(overall.values()),
        "unique_items": len(overall),
        "overall": dict(overall),
        "color": dict(color),
        "overall_size": {size: dict(c) for size, c in overall_size.items()},
        "color_size": {
            item_color: {size: dict(c) for size, c in groups.items()}
            for item_color, groups in color_size.items()
        },
        "total_item_counts": {str(k): int(v)
                              for k, v in sorted(total_item_counts.items())},
        "color_count_totals": dict(color_count_totals),
        "color_area_totals": dict(color_area_totals),
    }


def write_priors(data, output_path):
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.is_file():
        shutil.copy2(output, str(output) + ".bak")
    tmp = output.with_suffix(output.suffix + ".tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as fp:
        json.dump(data, fp, ensure_ascii=False, indent=2, sort_keys=True)
        fp.write("\n")
    os.replace(tmp, output)
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description="重算珍珠档先验")
    parser.add_argument("--records", default=str(DEFAULT_RECORD),
                        help="试验记录.jsonl 的路径")
    parser.add_argument("--output", default=str(DEFAULT_OUTPUT))
    parser.add_argument("--dry-run", action="store_true",
                        help="只报能收多少局，不写文件")
    parser.add_argument("--force", action="store_true",
                        help="样本不够也写（不建议）")
    args = parser.parse_args(argv)

    record_path = Path(args.records)
    if not record_path.is_file():
        print("找不到记录文件：%s" % record_path)
        return 2

    records = collect(record_path)
    games = len(records)
    instances = sum(len(r.get("items") or []) for r in records)
    uniq = len({str(it.get("item") or "").strip()
                for r in records for it in (r.get("items") or [])})
    print("能用作样本的对局：%d 局，共 %d 件，%d 种" % (games, instances, uniq))

    if games == 0:
        print("没有可用样本：需要有 auction_end(actual_value>0) 的局，")
        print("而且那一局的 warehouse_vision 里每件都认出来了。")
        print("现在什么都不写，旧的先验原样留着。")
        return 1

    if args.dry_run:
        print("（--dry-run，没写文件）")
        return 0

    if games < MIN_GAMES and not args.force:
        print("样本只有 %d 局，少于 %d 局的底线 —— 统计出来的比例不可信，"
              "旧的先验原样留着。" % (games, MIN_GAMES))
        print("真想覆盖就加 --force。")
        return 1

    data = build_priors(records)
    path = write_priors(data, args.output)
    print("PEARL_PRIORS_OK games=%d items=%d unique=%d -> %s"
          % (data["games"], data["item_instances"], data["unique_items"], path))
    print("旧文件已备份成 %s.bak" % path)
    return 0


if __name__ == "__main__":
    sys.exit(main())