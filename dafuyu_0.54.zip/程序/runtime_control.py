# -*- coding: utf-8 -*-
"""顶层控制策略。

本模块不含 OCR、点击或游戏相关 I/O，只把一帧观测到的画面
转成一个明确动作。保持这张决策表纯粹，才能在主循环执行之前
验证每个已知画面都有出口。
"""
from dataclasses import dataclass
from contextlib import contextmanager
import threading


class Screen:
    UNKNOWN = "unknown"
    REWARD_TIP = "reward_tip"
    MONTHLY_CARD = "monthly_card"
    LOGIN = "login"
    HALL = "hall"
    SETTLEMENT = "settlement"
    BID_PANEL = "bid_panel"
    AUCTION_ROOM = "auction_room"
    EXIT_CONFIRM = "exit_confirm"
    HIGH_BID_CONFIRM = "high_bid_confirm"
    ENTRY_CONFIRM = "entry_confirm"
    TITLE_ENTER = "title_enter"


KNOWN_SCREENS = frozenset({
    Screen.UNKNOWN,
    Screen.REWARD_TIP,
    Screen.MONTHLY_CARD,
    Screen.LOGIN,
    Screen.HALL,
    Screen.SETTLEMENT,
    Screen.BID_PANEL,
    Screen.AUCTION_ROOM,
    Screen.EXIT_CONFIRM,
    Screen.HIGH_BID_CONFIRM,
    Screen.ENTRY_CONFIRM,
    Screen.TITLE_ENTER,
})


class Action:
    WAIT = "wait"
    ESC = "esc"
    DISMISS_REWARD = "dismiss_reward"
    DISMISS_MONTHLY = "dismiss_monthly"
    RECOVER_LOGIN = "recover_login"
    RECOVER_TITLE_ENTER = "recover_title_enter"
    RUN_SETTLEMENT = "run_settlement"
    RETRY_SETTLEMENT_EXIT = "retry_settlement_exit"
    CLOSE_BID_AND_RESUME = "close_bid_and_resume"
    RESUME_AUCTION = "resume_auction"
    HALL_READY = "hall_ready"
    CONFIRM_EXIT = "confirm_exit"
    CONFIRM_HIGH_BID = "confirm_high_bid"
    CANCEL_ENTRY = "cancel_entry"


class Mode:
    NORMAL = "normal"
    DAILY = "daily"
    RECOVERY = "recovery"


@dataclass(frozen=True)
class Decision:
    action: str
    reason: str


_STATIC_ACTIONS = {
    Screen.REWARD_TIP: (Action.DISMISS_REWARD, "关闭奖励详情"),
    Screen.MONTHLY_CARD: (Action.DISMISS_MONTHLY, "清理月卡弹窗"),
    Screen.LOGIN: (Action.RECOVER_LOGIN, "恢复登录"),
    Screen.HALL: (Action.HALL_READY, "已在大厅"),
    Screen.BID_PANEL: (Action.CLOSE_BID_AND_RESUME, "关闭出价遮挡并从当前回合续接"),
    Screen.AUCTION_ROOM: (Action.RESUME_AUCTION, "从当前回合续接拍卖"),
    Screen.EXIT_CONFIRM: (Action.CONFIRM_EXIT, "确认退出对局"),
    Screen.HIGH_BID_CONFIRM: (Action.CONFIRM_HIGH_BID, "确认异常高价"),
    Screen.ENTRY_CONFIRM: (Action.CANCEL_ENTRY, "取消入场费确认并回大厅"),
    Screen.TITLE_ENTER: (Action.RECOVER_TITLE_ENTER, "从 Enter 恢复进入主世界"),
}


def plan_flow_action(state, *, unknown_seconds=0.0, allow_escape=True,
                     esc_ready=True, auction_finished=False):
    """Return the single next action for an observed screen.

    The unknown branch is deliberately bounded: it either waits for screen
    stability, sends ESC, or reports WAIT while the ESC cooldown is active.
    Every known non-unknown screen has exactly one mapped action.
    """
    state = str(state or Screen.UNKNOWN)
    if state == Screen.UNKNOWN:
        if not allow_escape:
            return Decision(Action.WAIT, "未允许 ESC，等待下一帧")
        if float(unknown_seconds) < 8.0:
            return Decision(Action.WAIT, "未知画面尚未稳定 8 秒")
        if not esc_ready:
            return Decision(Action.WAIT, "ESC 冷却中")
        return Decision(Action.ESC, "未知画面持续稳定，执行 ESC")
    if state == Screen.SETTLEMENT:
        if auction_finished:
            return Decision(Action.RETRY_SETTLEMENT_EXIT,
                            "本局已记账，只重试退出，不重复结算")
        return Decision(Action.RUN_SETTLEMENT, "执行结算并形成事务记录")
    mapped = _STATIC_ACTIONS.get(state)
    if mapped is None:
        return Decision(Action.WAIT, "未知状态值，等待恢复")
    return Decision(mapped[0], mapped[1])


def is_known_screen(state):
    return str(state or Screen.UNKNOWN) in KNOWN_SCREENS


class OperationAuthority:
    """Serialize high-level owners while allowing nested calls in one thread.

    Main automation normally owns the controller.  A daily-card operation or a
    restart operation gets exclusive authority; main-loop sleeps and the next
    loop iteration yield until that operation finishes.  Reentrant calls from
    the owning thread are allowed, which is required by existing recovery and
    popup helper functions that call each other.
    """

    def __init__(self):
        self._gate = threading.RLock()
        self._state_lock = threading.Lock()
        self._mode = Mode.NORMAL
        self._owner_tid = None
        self._owner_name = ""
        self._depth = 0

    @contextmanager
    def operation(self, mode, owner):
        self._gate.acquire()
        tid = threading.get_ident()
        try:
            with self._state_lock:
                nested = self._depth > 0 and self._owner_tid == tid
                previous = (self._mode, self._owner_tid, self._owner_name, self._depth)
                if not nested:
                    self._mode = str(mode)
                    self._owner_tid = tid
                    self._owner_name = str(owner)
                    self._depth = 1
                else:
                    self._depth += 1
            yield
        finally:
            with self._state_lock:
                if self._depth > 1 and self._owner_tid == tid:
                    self._depth -= 1
                else:
                    (self._mode, self._owner_tid,
                     self._owner_name, self._depth) = previous
            self._gate.release()

    def allows_current_thread(self):
        tid = threading.get_ident()
        with self._state_lock:
            return self._depth == 0 or self._owner_tid == tid

    def mode(self):
        with self._state_lock:
            return self._mode
