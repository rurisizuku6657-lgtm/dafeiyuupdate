# -*- coding: utf-8 -*-
import base64
import datetime
import glob
import json
import os
import re
import subprocess
import time
import sys
import zlib

_HERE_FOR_VERSION = os.path.dirname(os.path.abspath(__file__))
if _HERE_FOR_VERSION not in sys.path:
    sys.path.insert(0, _HERE_FOR_VERSION)
try:
    from 版本 import APP_VERSION, APP_DISPLAY, previous_upgrade_version, release_notes_between  # 版本号唯一来源：程序\版本.py
except Exception:  # 版本.py 丢了也不至于开不了，兜底一个写死的
    APP_VERSION = "0.2"
    APP_DISPLAY = "大肥鱼standby" + str(APP_VERSION)
    previous_upgrade_version = lambda *_: ""
    release_notes_between = lambda *_: []
APP_DISPLAY_BASE = "大肥鱼standby"

_BOT_ALIVE_CACHE = {"at": 0.0, "val": None}
# bot_pids 的缓存：它一次要起 wmic/PowerShell 子进程（本机 0.5 秒以上），
# 而面板每秒就要问一次「脚本在跑吗」——不缓存会把 GUI 线程卡死。
_BOT_PIDS_CACHE = {"at": 0.0, "val": []}

SELF_DIR = os.path.dirname(os.path.abspath(__file__))
BASE = SELF_DIR
# 冻结模式：可写根 = exe 所在目录；资源根 = _MEIPASS
FROZEN = bool(getattr(sys, "frozen", False))
RES_DIR = getattr(sys, "_MEIPASS", SELF_DIR) if FROZEN else SELF_DIR
if FROZEN:
    BASE = os.path.dirname(os.path.abspath(sys.executable))
for _d in (() if FROZEN else (SELF_DIR, os.path.dirname(SELF_DIR))):
    # 只认「python」目录：以前连「素材」也算，只要 程序\素材 一出现（哪怕空的），
    # BASE 就会错指到 程序\，接着找不到 PyQt5 插件、界面直接起不来。
    if os.path.isdir(os.path.join(_d, "python")):
        BASE = _d
        break
# ---- 大肥鱼standby：BASE 必须是「有 素材 的那一层」----
#   原版靠「python 目录」判断发布结构；我们打包后没有 python 目录，
#   所以再加一条：谁旁边有 素材 谁就是根。
if not os.path.isdir(os.path.join(BASE, "素材")):
    for _cand in (os.path.dirname(SELF_DIR), os.path.dirname(BASE), RES_DIR):
        if _cand and os.path.isdir(os.path.join(_cand, "素材")):
            BASE = _cand
            break
PY_DIR = os.path.join(BASE, "python")
# 嵌入式 Python 带了 python310._pth，跑脚本时脚本目录不进 sys.path，
# 同目录的模块（拍卖辅助.py）会 import 不到，界面就静默起不来。这里自己补上。
if SELF_DIR not in sys.path:
    sys.path.insert(0, SELF_DIR)
_qt_root = os.path.join(PY_DIR, "Lib", "site-packages", "PyQt5", "Qt5")
if os.path.isdir(_qt_root):
    _qt_bin = os.path.join(_qt_root, "bin")
    _qt_plugins = os.path.join(_qt_root, "plugins")
    os.environ.setdefault("QT_QPA_PLATFORM_PLUGIN_PATH", _qt_plugins)
    os.environ["PATH"] = _qt_bin + os.pathsep + os.environ.get("PATH", "")
    try:
        os.add_dll_directory(_qt_bin)
    except Exception:
        pass

from PyQt5.QtCore import Qt, QTimer, pyqtSignal, QObject, QSize, QRect
from PyQt5.QtGui import QPixmap, QIcon, QMovie, QRegion, QColor, QPainter
from PyQt5.QtWidgets import (
    QProxyStyle,
    QStyle,
    QApplication,
    QMainWindow,
    QWidget,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QMenu,
    QPlainTextEdit,
    QComboBox,
    QLineEdit,
    QCheckBox,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QDialog,
    QScrollArea,
    QGroupBox,
    QFileDialog,
    QStackedWidget,
    QSpinBox,
    QFrame,
    QSizePolicy,
    QSlider,
)

# 右边那条辅助栏已经改成左侧导航的第七页了
from 拍卖辅助 import 拍卖辅助页
from 视觉报告 import 视觉报告页

REC = (os.path.join(BASE, "异环大肥鱼standby", "记录")
       if getattr(sys, "frozen", False) else os.path.join(BASE, "记录"))
BANNER_IMG = "banner_bg.png"  # 顶部横幅底图（放在 素材/ 下）



class _ToggleProxyStyle(QProxyStyle):
    """大肥鱼standby：用 QPainter 自绘「胶囊开关」和「下拉箭头」——按已确认样张，56x26。"""

    TW, TH, KNOB, PAD = 56, 26, 9, 4

    def drawPrimitive(self, element, option, painter, widget=None):
        from PyQt5.QtGui import QColor, QPainter, QPainterPath, QPen
        from PyQt5.QtCore import QRectF, Qt

        painter.save()
        painter.setRenderHint(QPainter.Antialiasing, True)

        if element == QStyle.PE_IndicatorArrowDown:
            from PyQt5.QtCore import Qt
            from PyQt5.QtGui import QColor, QPen
            r = option.rect
            cx = r.center().x()
            cy = r.center().y()
            pen = QPen(QColor("#cfd8e6"), 1.6)
            pen.setCapStyle(Qt.RoundCap)
            painter.setPen(pen)
            painter.drawLine(cx - 5, cy - 2, cx, cy + 3)
            painter.drawLine(cx, cy + 3, cx + 5, cy - 2)
            painter.restore()
            return

        painter.restore()
        super().drawPrimitive(element, option, painter, widget)


# ============================================================================
# 自绘控件（胶囊开关 / 下拉箭头 / 下拉弹层）的主题配色
# Main 每次套用主题都会调 _apply_widget_theme()，把这些值刷成当前主题的
# ============================================================================
WIDGET_THEME = {
    "toggle_on": "#22d3ee", "toggle_off": "#2a3240",
    "knob_on": "#0a0e14", "knob_off": "#b2bbc8",
    "ring": "#546276", "text": "#d6dbe6", "text_off": "#7f8ba0",
    "arrow": "#9fb0c6",
    "popup_bg": "#1d2430", "popup_border": "#333c4c",
    "popup_fg": "#c8d3e2", "popup_hover": "#232b38",
    "popup_sel_bg": "#16323a", "popup_sel_fg": "#5ee0e6",
}

THEME_WIDGETS = {
    "oknte": {"toggle_on": "#22d3ee", "toggle_off": "#2a3240",
              "knob_on": "#0a0e14", "knob_off": "#b2bbc8",
              "ring": "#546276", "text": "#d6dbe6", "text_off": "#7f8ba0",
              "arrow": "#9fb0c6",
              "popup_bg": "#1d2430", "popup_border": "#333c4c",
              "popup_fg": "#c8d3e2", "popup_hover": "#232b38",
              "popup_sel_bg": "#16323a", "popup_sel_fg": "#5ee0e6"},
    "anon": {"toggle_on": "#d9658f", "toggle_off": "#e7bbcd",
             "knob_on": "#ffffff", "knob_off": "#ffffff",
             "ring": "#d79cb4", "text": "#5c4450", "text_off": "#c0a9b5",
             "arrow": "#b98ea5",
             "popup_bg": "#ffffff", "popup_border": "#f3d7e6",
             "popup_fg": "#5c4450", "popup_hover": "#fff2f8",
             "popup_sel_bg": "#fbe9f1", "popup_sel_fg": "#d9658f"},
    "requiem": {"toggle_on": "#e8392c", "toggle_off": "#402826",
                "knob_on": "#fff5f2", "knob_off": "#ffd9d3",
                "ring": "#5c2b24", "text": "#f0e3e1", "text_off": "#8a6d68",
                "arrow": "#c08a84",
                "popup_bg": "#1b1412", "popup_border": "#3a221e",
                "popup_fg": "#e9dbd7", "popup_hover": "#251614",
                "popup_sel_bg": "#2c1815", "popup_sel_fg": "#ff6a5c"},
    "malice": {"toggle_on": "#e0557f", "toggle_off": "#f3c8d8",
               "knob_on": "#ffffff", "knob_off": "#ffffff", "ring": "#e7a9c0",
               "text": "#4a2f3a", "text_off": "#c08d9e", "arrow": "#b06a83",
               "popup_bg": "#ffffff", "popup_border": "#f7d6e2",
               "popup_fg": "#4a2f3a", "popup_hover": "#ffedf4",
               "popup_sel_bg": "#ffedf4", "popup_sel_fg": "#e0557f"},
    "killer": {"toggle_on": "#0f9d8c", "toggle_off": "#c6e9e2",
               "knob_on": "#ffffff", "knob_off": "#ffffff", "ring": "#9fd7cd",
               "text": "#23413c", "text_off": "#7dafa7", "arrow": "#5f9c93",
               "popup_bg": "#ffffff", "popup_border": "#cfeee8",
               "popup_fg": "#23413c", "popup_hover": "#e6f8f4",
               "popup_sel_bg": "#e6f8f4", "popup_sel_fg": "#0f9d8c"},
    "shenyi": {"toggle_on": "#2f7fd6", "toggle_off": "#cfe0f5",
               "knob_on": "#ffffff", "knob_off": "#ffffff", "ring": "#a9c6e8",
               "text": "#23384f", "text_off": "#7d9dbc", "arrow": "#5e88b3",
               "popup_bg": "#ffffff", "popup_border": "#d3e3f7",
               "popup_fg": "#23384f", "popup_hover": "#e8f1ff",
               "popup_sel_bg": "#e8f1ff", "popup_sel_fg": "#2f7fd6"},
    "zhulei": {"toggle_on": "#7a63d6", "toggle_off": "#dcd4f6",
               "knob_on": "#ffffff", "knob_off": "#ffffff", "ring": "#bdb0e6",
               "text": "#322a4d", "text_off": "#9689c0", "arrow": "#8672c4",
               "popup_bg": "#ffffff", "popup_border": "#ddd6f7",
               "popup_fg": "#322a4d", "popup_hover": "#efeaff",
               "popup_sel_bg": "#efeaff", "popup_sel_fg": "#7a63d6"},
    "light": {"toggle_on": "#2563eb", "toggle_off": "#d6dde8",
              "knob_on": "#ffffff", "knob_off": "#ffffff",
              "ring": "#cbd5e3", "text": "#2a3242", "text_off": "#9aa7ba",
              "arrow": "#7c8aa0",
              "popup_bg": "#ffffff", "popup_border": "#e2e8f0",
              "popup_fg": "#2a3242", "popup_hover": "#f2f4f7",
              "popup_sel_bg": "#e8eefc", "popup_sel_fg": "#2563eb"},
    "dark": {"toggle_on": "#38bdf8", "toggle_off": "#2c3442",
             "knob_on": "#0b0f16", "knob_off": "#c3ccda",
             "ring": "#4a5464", "text": "#c3ccda", "text_off": "#7b8798",
             "arrow": "#8b98ab",
             "popup_bg": "#12161d", "popup_border": "#262d38",
             "popup_fg": "#c3ccda", "popup_hover": "#1b212b",
             "popup_sel_bg": "#0f2a33", "popup_sel_fg": "#38bdf8"},
    "lacquer": {"toggle_on": "#d9b26a", "toggle_off": "#3a3025",
                "knob_on": "#14100b", "knob_off": "#e6d6b2",
                "ring": "#5a4a34", "text": "#e6d6b2", "text_off": "#a3906f",
                "arrow": "#c9b48a",
                "popup_bg": "#221b13", "popup_border": "#3d3122",
                "popup_fg": "#e6d6b2", "popup_hover": "#2c2317",
                "popup_sel_bg": "#3a2f1f", "popup_sel_fg": "#d9b26a"},
}


def _apply_widget_theme(theme):
    """把当前主题的配色灌进自绘控件用的全局表。"""
    t = str(theme or "oknte")
    WIDGET_THEME.update(THEME_WIDGETS.get(t) or THEME_WIDGETS["oknte"])


class ToggleSwitch(QCheckBox):
    """大肥鱼standby：自绘胶囊开关（可带右侧文字 + 点击滑动动画）。

    QSS 的 indicator 无论怎么设都会被 Qt 二次缩放，只有自己 paintEvent 才能保证
    和设计稿一模一样；行为仍是 QCheckBox（isChecked / toggled / clicked 全兼容）。
    开关切换时圆点会从一端滑到另一端（130ms，OutCubic）。
    """

    W, H = 44, 22        # 与 14px 文字高度对齐
    KNOB = 7
    PAD = 3
    GAP = 9
    ANIM_MS = 130

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from PyQt5.QtCore import Qt, QEasingCurve, QVariantAnimation
        self.setCursor(Qt.PointingHandCursor)
        self.setMinimumHeight(self.H + 8)
        try:
            self.setMinimumWidth(self.W + self.GAP +
                                 self.fontMetrics().horizontalAdvance(self.text()) + 4)
        except Exception:
            self.setMinimumWidth(self.W + self.GAP + 60)
        self._pos = 1.0 if self.isChecked() else 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(self.ANIM_MS)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)
        self._anim.valueChanged.connect(self._on_anim_value)
        self.toggled.connect(self._start_slide)

    def _on_anim_value(self, value):
        try:
            self._pos = float(value)
        except Exception:
            self._pos = 1.0 if self.isChecked() else 0.0
        self.update()

    def _start_slide(self, checked):
        target = 1.0 if checked else 0.0
        if abs(self._pos - target) < 0.002 or not self.isVisible():
            self._anim.stop()
            self._pos = target
            self.update()
            return
        self._anim.stop()
        self._anim.setStartValue(float(self._pos))
        self._anim.setEndValue(target)
        self._anim.start()

    def setChecked(self, value):
        """不可见时（读配置/构建界面）直接落到终点；可见时照常走滑动动画。"""
        super().setChecked(value)
        if not self.isVisible():
            try:
                self._anim.stop()
            except Exception:
                pass
            self._pos = 1.0 if self.isChecked() else 0.0
            self.update()

    def hitButton(self, pos):
        return self.rect().contains(pos)

    def _mix(self, c1, c2, t):
        from PyQt5.QtGui import QColor
        a, b = QColor(c1), QColor(c2)
        return QColor(
            int(a.red() + (b.red() - a.red()) * t),
            int(a.green() + (b.green() - a.green()) * t),
            int(a.blue() + (b.blue() - a.blue()) * t),
            int(a.alpha() + (b.alpha() - a.alpha()) * t),
        )

    def paintEvent(self, _event):
        from PyQt5.QtCore import QRectF, Qt
        from PyQt5.QtGui import QColor, QPainter, QPainterPath, QPen

        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.TextAntialiasing, True)

        w, h = self.W, self.H
        y = (self.height() - h) / 2.0
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, y, w, h), h / 2.0, h / 2.0)

        t = max(0.0, min(1.0, float(getattr(self, "_pos", 1.0 if self.isChecked() else 0.0))))
        # 轨道：关=深灰，开=青色，中间插值
        painter.fillPath(path, self._mix(WIDGET_THEME["toggle_off"],
                                         WIDGET_THEME["toggle_on"], t))
        if t < 0.98:
            _ring = QColor(WIDGET_THEME["ring"])
            _ring.setAlpha(int(200 * (1.0 - t)))
            pen = QPen(_ring, 2)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            painter.drawRoundedRect(
                QRectF(1, y + 1, w - 2, h - 2), (h - 2) / 2.0, (h - 2) / 2.0
            )
        # 圆点：从左滑到右，颜色也跟着变
        left_x = self.PAD + self.KNOB
        right_x = w - self.PAD - self.KNOB
        kx = left_x + (right_x - left_x) * t
        ky = y + h / 2.0
        painter.setPen(Qt.NoPen)
        painter.setBrush(self._mix(WIDGET_THEME["knob_off"],
                                  WIDGET_THEME["knob_on"], t))
        painter.drawEllipse(QRectF(kx - self.KNOB, ky - self.KNOB,
                                   self.KNOB * 2, self.KNOB * 2))

        painter.setPen(QColor(WIDGET_THEME["text"] if self.isEnabled()
                              else WIDGET_THEME["text_off"]))
        tx = w + self.GAP
        painter.drawText(QRectF(tx, 0, max(10.0, self.width() - tx), self.height()),
                         int(Qt.AlignVCenter | Qt.AlignLeft), self.text())
        painter.end()


class NoWheelComboBox(QComboBox):
    """滚轮不改值 + 自定义弹出列表（圆角/内边距6/行高34/选中青条）。"""

    def _popup_qss(self):
        t = WIDGET_THEME
        return """
QListView { background:%s; border:1px solid %s; border-radius:8px;
            padding:4px; outline:0; color:%s; }
QListView::item { color:%s; padding:0 8px; border-radius:6px; }
QListView::item:hover { background:%s; }
QListView::item:selected { background:%s; color:%s; }
""" % (t["popup_bg"], t["popup_border"], t["popup_fg"],
       t["popup_fg"], t["popup_hover"], t["popup_sel_bg"], t["popup_sel_fg"])

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.setMaxVisibleItems(12)
        try:
            self.setFrame(False)   # 去掉平台自带的方框（浅色主题下右边会多一道灰线）
        except Exception:
            pass
        try:
            self._install_view()
        except Exception:
            pass

    def _install_view(self):
        from PyQt5.QtCore import QSize
        from PyQt5.QtWidgets import QFrame, QListView, QStyledItemDelegate

        class _RowDelegate(QStyledItemDelegate):
            def sizeHint(self, option, index):
                sz = super().sizeHint(option, index)
                return QSize(sz.width(), 34)

            def paint(self, painter, option, index):
                super().paint(painter, option, index)
                # 某一项被标成"当前正在用"时，在行右边补一个（当前）
                try:
                    from PyQt5.QtCore import Qt as _Qt
                    from PyQt5.QtGui import QColor as _QColor
                    if bool(index.data(_Qt.UserRole + 77)):
                        rect = option.rect.adjusted(0, 0, -14, 0)
                        painter.save()
                        painter.setPen(_QColor(WIDGET_THEME["popup_sel_fg"]))
                        painter.drawText(rect, _Qt.AlignRight | _Qt.AlignVCenter, "（当前）")
                        painter.restore()
                except Exception:
                    pass

        view = QListView(self)
        view.setObjectName("darkPopup")
        view.setFrameShape(QFrame.NoFrame)
        view.setSpacing(0)
        view.setUniformItemSizes(False)
        view.setStyleSheet(self._popup_qss())
        view.setItemDelegate(_RowDelegate(view))
        self.setView(view)

    def wheelEvent(self, event):  # noqa: N802
        event.ignore()

    def showPopup(self):  # noqa: N802
        try:
            from PyQt5.QtCore import Qt
            v = self.view()
            v.setStyleSheet(self._popup_qss())
            win = v.window()
            win.setStyleSheet("QFrame{background:transparent;border:none;}")
            win.setAttribute(Qt.WA_TranslucentBackground, True)
        except Exception:
            pass
        super().showPopup()

LOG_ROOT = os.path.join(REC, "日志")
SHOT_ROOT = os.path.join(REC, "高价值截图")
ANA_SHOT_ROOT = os.path.join(REC, "高价值分析图")
CFG_FILE = os.path.join(REC, "面板设置.json")
# 面板自身的界面设置（窗口分辨率、字号），和脚本参数分开放，
# 免得被 save_cfg() 覆写掉。
UI_CFG_FILE = os.path.join(REC, "界面设置.json")
MAIN_PY = os.path.join(SELF_DIR, "paimai.py")
DOG_GRID_PY = os.path.join(SELF_DIR, "狗叫图生成.py")
DOG_STATUS_FILE = os.path.join(REC, "狗叫图生成_最后状态.json")
# 不挂机扫一次仓：子进程跑，扫完往 试验记录.jsonl 追一条 warehouse_vision
SCAN_PY = os.path.join(SELF_DIR, "扫一次仓.py")
SCAN_STATUS_FILE = os.path.join(REC, "扫一次仓_最后状态.json")
PY = os.path.join(PY_DIR, "python.exe")
SELFTEST_PY = os.path.join(SELF_DIR, "selftest.py")
UPDATE_CHECK_PY = os.path.join(SELF_DIR, "更新检查.py")
UPDATE_APPLY_PY = os.path.join(SELF_DIR, "更新下载.py")
ANALYZE_PY = os.path.join(SELF_DIR, "analyze.py")
REPORT = os.path.join(REC, "分析报告.txt")
JSONL = os.path.join(REC, "试验记录.jsonl")
PANEL_SESSION_START = datetime.datetime.now()
FLAG_START = os.path.join(REC, "_面板_开始.flag")
FLAG_STOP = os.path.join(REC, "_面板_停止.flag")
# 自动撞果盘开关：1 = 走自动撞果盘流程，0/没有文件 = 正常挂机流程
GP_FLAG = os.path.join(REC, "_面板_撞果盘.flag")
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
LOG_ORDER = ["拍卖记录.txt", "运行日志.txt", "控制台输出.txt", "报错日志.txt", "报错日志.jsonl"]


def _pos_on_any_screen(x, y, w=0, h=0):
    """这个窗口位置还有没有落在任意屏幕上（副屏拔掉/分辨率变了时用）。"""
    try:
        from PyQt5.QtWidgets import QApplication

        for scr in QApplication.screens():
            g = scr.availableGeometry()
            # 标题栏那一条至少要露在屏幕里
            if (g.left() - 200 < x < g.right() - 40
                    and g.top() - 40 < y < g.bottom() - 40):
                return True
    except Exception:
        return True
    return False


def decode_process_output(raw):
    """Decode child-process output across UTF-8 and Chinese Windows codepages."""
    if isinstance(raw, str):
        return raw
    decoded = []
    for line in (raw or b"").splitlines(keepends=True):
        try:
            decoded.append(line.decode("utf-8"))
        except UnicodeDecodeError:
            try:
                decoded.append(line.decode("gb18030"))
            except UnicodeDecodeError:
                decoded.append(line.decode("utf-8", errors="replace"))
    return "".join(decoded)


def _valid_generated_image(path, expected_size=None):
    try:
        if not path or not os.path.isfile(path) or os.path.getsize(path) < 10 * 1024:
            return False
        from PIL import Image, ImageStat

        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            if expected_size is not None and im.size != tuple(expected_size):
                return False
            if float(ImageStat.Stat(im.convert("L")).stddev[0]) < 2.0:
                return False
            return True
    except Exception:
        return False


def resolve_dog_generation_result(return_code, output, status, started_at, search_dir):
    """Resolve success from the produced image, not only from the child exit code."""
    output = str(output or "")
    status = status if isinstance(status, dict) else {}
    path = str(status.get("path") or "").strip() if status.get("ok") else ""
    if not path:
        for line in output.splitlines():
            text = line.strip()
            if "EVILNTE_DOG_OK=" in text:
                path = text.split("EVILNTE_DOG_OK=", 1)[1].strip().strip('"')
            elif "炫耀家底生成完成：" in text:
                path = text.split("炫耀家底生成完成：", 1)[1].strip().strip('"')

    expected_size = (565, 3385)
    if not _valid_generated_image(path, expected_size):
        candidates = []
        try:
            candidates = []
            for _pat in ("炫耀家底_*.png", "狗叫图_*.png"):  # 旧名也认，以前的图还找得到
                candidates += [
                    p
                    for p in glob.glob(os.path.join(search_dir, _pat))
                    if os.path.getmtime(p) >= float(started_at) - 1.0
                ]
            candidates.sort(key=os.path.getmtime, reverse=True)
        except Exception:
            candidates = []
        path = next((p for p in candidates if _valid_generated_image(p, expected_size)), "")

    if path and _valid_generated_image(path, expected_size):
        note = ""
        if int(return_code) != 0:
            note = (
                "生成进程退出码为 %s，但本次图片已实际生成并通过尺寸校验，"
                "因此按成功处理。" % return_code
            )
        return True, path, note

    detail = str(status.get("error") or "").strip()
    tail = "\n".join(output.splitlines()[-20:]) or "没有返回错误信息"
    if detail and detail not in tail:
        tail = "错误：%s\n%s" % (detail, tail)
    if int(return_code) != 0 and "进程退出码" not in tail:
        tail += "\n进程退出码：%s" % return_code
    return False, "", tail


SETTINGS = [
    (
        "SLOW_PC_SKIP_HEAVY",
        "慢机器省时模式（跳过查举报 / 数品质）",
        "bool",
        "1",
        "1 = 打开后直接跳过「查举报面板」「数品质」这两个重动作（省 4~10 秒/回合，"
        "代价是少拿对手信息、少记颜色）；0 = 照做。",
    ),
    (
        "SLOW_PC_K_THRESHOLD",
        "慢机器判定门槛（抓帧系数）",
        "float",
        "2.0",
        "抓一帧耗时 ÷ 120ms 得到的系数；≥ 这个值就算「慢机器」。"
        "1.8 = 更早进入省时模式（更省时间、少拿情报）；3.0 = 只有特别慢才省。",
    ),
    (
        "NO_EXIT_NO_DOWNGRADE",
        "不退出模式不降价",
        "bool",
        "1",
        "1（默认）= 不退出模式下每回合至少按 CHASE_STEP_RATIO 往上递增，绝不回落；"
        "0 = 允许按智能估价回落，只有算不出价时才拿保底链兜底。",
    ),
    (
        "INSTRUMENT_GROUP",
        "仪器组（巨物 / 至尊）",
        "str",
        "SUPER_APPRAISAL",
        "SUPER_APPRAISAL = 巨物（1号 5万 / 5号 2万）；"
        "SUPREME = 至尊（1号至尊鉴定 10万 / 5号九格均价 7万）。"
        "2/3/4 号两组完全一样。主界面「快捷设置」里能一键切，会连 TOOL_PRICES 一起改。",
    ),
    (
        "SAFE_CAP_RATIO",
        "求稳 · 第 3~4 回合上限（估价×）",
        "float",
        "1.2",
        "求稳模式下这两回合最多出到估价的几倍。",
    ),
    (
        "SAFE_CAP_RATIO_LATE",
        "求稳 · 第 5 回合起上限（估价×）",
        "float",
        "1.3",
        "后面几回合放宽到几倍。",
    ),
    (
        "SAFE_MODE",
        "模式选择：拿仓 / 求稳",
        "bool",
        "0",
        "0 = 拿仓（能顶到估价 1.5 倍，抢得更凶）；"
        "1 = 求稳（第 3~4 回合最多 1.2 倍估价，第 5 回合起 1.3 倍）。前两回合的保底价不受影响。",
    ),
    (
        "HARD_CAP_MULT",
        "最多出估价的几倍（总闸）",
        "float",
        "1.5",
        "不管哪条路算出来的价，最后都被这个数压一次；追到底、超价额度都归它管。"
        "0 = 关掉（那就完全按各条路径自己算）。",
    ),
    (
        "NO_EXIT_GUARD_ENABLED",
        "防亏刹车（不退出模式下）",
        "bool",
        "0",
        "打开后：追到底的过程中，如果保底链要出的价已经高过估价的九成、"
        "而且对手根本没在跟（对手参考价低或没读到），就别自己抬自己，本局收手。"
        "默认关——不退出模式要真拍到底，提前退出会丢掉结算真值的样本。",
    ),
    (
        "NO_EXIT_GUARD_START_ROUND",
        "防亏刹车 · 第几回合起",
        "int",
        "3",
        "前两回合不受影响，默认第 3 回合起才管。",
    ),
    (
        "NO_EXIT_GUARD_MIN_VALUE_RATIO",
        "防亏刹车 · 出价超过估价的几成算亏",
        "float",
        "0.90",
        "保底链要出的价 > 估价 × 这个数，才算「已经出多了」。",
    ),
    (
        "NO_EXIT_GUARD_MAX_OPP_SUPPORT",
        "防亏刹车 · 对手至少跟到我的几成",
        "float",
        "1.50",
        "我叫的价 > 对手参考价 × 这个数，就算「没人跟我抢」。"
        "对手价没读到也算没人跟。",
    ),
    (
        "RIVAL_PREMIUM_CAP",
        "别比对手多出（倍）",
        "float",
        "1.3",
        "第 3 回合起，出价最多是「对手上一轮最高」的这么多倍。实盘中位数是 1.43 倍，压到 1.3 能省不少。0 = 关。",
    ),
    ("BID_AUTO_PRICE", "智能出价", "bool", "1", "关掉就退回老式档位表，一般不用动。"),
    (
        "OPENING_PRICE_RANGE",
        "开局保底价区间（推荐）",
        "str",
        "",
        "填 500000-600000（低-高，横杠或逗号都行）就每局在这个范围里随机一个开局价，"
        "尾数自动贴成 …9999。比固定价更像人手打的，对面不容易看出是脚本。"
        "留空 = 用下面那个固定价。",
    ),
    (
        "OPENING_PRICE_1",
        "固定开局价（区间留空时才用）",
        "int",
        "599999",
        "上面那条区间留空时，每局就直接用这个价。"
        "原来还有 ②③④ 三个候选随机挑，已经并成这一个了。",
    ),
    (
        "MIN_BID_AMOUNT",
        "最低出价（别出得太寒酸）",
        "int",
        "200000",
        "算出来低于这个数就抬到这里；0 = 关掉。",
    ),
    (
        "EXIT_BELOW_PRICE",
        "估价太低就收手",
        "int",
        "500000",
        "第 3 回合起，估价低于这个数就退出本局，不浪费时间。"
        "但「估价明显压着对手」时不看这条，照常跟。",
    ),
    (
        "CHASE_TO_END",
        "不退出模式（估价再低也不退）",
        "bool",
        "1",
        "1 = 估价再低也不退，每回合按下面的倍率往上加；0 = 按退出线走，估价太低就收手。默认开。",
    ),
    (
        "CHASE_STEP_RATIO",
        "不退出模式 · 每回合加价倍率",
        "float",
        "1.05",
        "只在上一条打开时生效。1.05 = 每回合比上一注高 5%。",
    ),
    ("STOP_BELOW_FUNDS", "资产低于这个数就自动停", "int", "5000000", "防止越亏越多。"),
    (
        "READ_TOLERANCE",
        "读金额允许多大误差",
        "float",
        "0.5",
        "0.5 = ±50%。填 0 就是一位都不许错。",
    ),
    ("READ_RIVAL_BIDS", "读取对手出价", "bool", "1", "关掉就只会出保底价，跟不了价。"),
    (
        "BIG_LOT_SHOT",
        "高价值成交自动截图",
        "bool",
        "1",
        "存到 记录\\高价值截图\\，面板「高价值截图」页能看。",
    ),
    (
        "NIGHT_USE_TIER",
        "天黑场地按档位价出",
        "bool",
        "1",
        "看不到对手金额时（天黑），按估价套档位价。",
    ),
    (
        "NIGHT_CAP_BY_PRICE",
        "天黑时也别超估价",
        "bool",
        "1",
        "1 = 档位价还要被自己的估价夹一下，不容易买贵。",
    ),
    (
        "SHOT_KEEP_MAX",
        "截图留多少张（0=全留）",
        "int",
        "300",
        "0 = 全留，挺占地方：一天约 0.5~1 GB。填 300 就只留最近 300 张。",
    ),
    (
        "R2_RIVAL_MULT",
        "第 2 回合出对手的几倍",
        "float",
        "1.2",
        "对手第 1 回合最高价 × 这个数。调低更保守。",
    ),
    (
        "INFO_ADVANTAGE_RATIO",
        "估价要压过对手几成才继续跟",
        "float",
        "0.8",
        "第 3 回合起，估价 ÷ 对手上一轮价 ≥ 这个数就继续跟。"
        "1.0 = 压得住就跟；1.2 = 要压两成；调高只对差价大的局出手。",
    ),
    (
        "BAIL_IF_OUTBID",
        "对手也看上了就撤",
        "bool",
        "0",
        "开：估价压不住对手就退出，不陪着互相抬价。关：继续跟，容易买贵。",
    ),
    # "第 3 回合门槛（ROUND3_GAP_RATIO）"从面板撤掉：
    #   它和信息差门槛是同一件事的旧版本、只管第 3 回合；信息差改成优先之后它已经走不到了
    #   （估价低于门槛 → 信息差那一步就退了；不低于 → 信息差命中，这道门被跳过）。
    #   常量留在 paimai.py 里当兜底（把信息差门槛填 0 / 关掉闸门时才会用到）。
    ("R3_RIVAL_MULT", "第 3 回合出对手的几倍", "float", "1.2", "对手第 2 回合最高价 × 这个数。"),
    ("R4_RIVAL_MULT", "第 4 回合出对手的几倍", "float", "1.15", "对手第 3 回合最高价 × 这个数。"),
    ("R5_RIVAL_MULT", "第 5、6 回合出对手的几倍", "float", "1.1", "对手上一轮最高价 × 这个数。"),
    (
        "OVER_PRICE_ROOM",
        "出价允许超估价多少（0=不许超）",
        "int",
        "500000",
        "填 500000 = 可以比估价多出 50 万。0 = 死守估价。",
    ),
    ("OVER_PRICE_FROM_R", "上面那条从第几回合起", "int", "3", "默认第 3 回合。"),
    (
        "BIG_LOT_GATE",
        "算『大仓』的门槛",
        "int",
        "2333333",
        "估价超过它就按七档阶梯价出（233 / 321 / 512 / 898 / 1123 / 1680 / 2017）。",
    ),
    (
        "RED_PIECE_BONUS",
        "看到一块红加多少钱",
        "int",
        "50000",
        "红档藏品估价压得最狠，看到就加。0 = 不加。",
    ),
    (
        "GOLD_PIECE_BONUS",
        "看到一块金加多少钱",
        "int",
        "10000",
        "金档平均只值两三万，给多了要亏。0 = 不加。",
    ),
    (
        "TOOL_R1",
        "第 1 回合用几号仪器",
        "int",
        "4",
        "仪器从上到下编号 1~5：1=特殊鉴定仪器(占格最大的一件)｜2=超级品鉴仪器(10件品质)｜3=超级尺寸仪器(12件轮廓)｜4=超级鉴定仪器(6件藏品)｜5=金品计数仪器(金色总数)。0 = 该回合不用仪器。默认 4123 = 前 4 回合依次用 4/1/2/3 号。",
    ),
    (
        "TOOL_R2",
        "第 2 回合用几号仪器",
        "int",
        "2",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R3",
        "第 3 回合用几号仪器",
        "int",
        "0",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R4",
        "第 4 回合用几号仪器",
        "int",
        "0",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R5",
        "第 5 回合用几号仪器",
        "int",
        "0",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_PRICES",
        "各仪器单价（1-5 号，元）",
        "str",
        "50000,10000,10000,10000,20000",
        "按 1~5 号顺序填，逗号隔开。默认 1号5万、2号1万、3号1万、4号1万、5号2万。用了几台仪器就按这个表扣几台的钱，成本统计、净收益都跟着它算。",
    ),
    (
        "INSTRUMENT_EFFECT_REQUIRED",
        "哪些仪器要确认生效",
        "str",
        "2,3,4",
        "填几号仪器（逗号隔开）。用完这台仪器后要等「估价变了」才算成功；"
        "没列进来的（比如 1 号、5 号本来就不改估价）就不陪它等，省几秒。留空 = 都要等。",
    ),
    (
        "INSTRUMENT_FAILURE_PAUSE",
        "仪器没生效就暂停",
        "bool",
        "0",
        "打开后：上面这些仪器用完，等到超时估价都没变 → 直接暂停脚本，"
        "别拿旧估价乱出价。默认关（记一笔、继续读完整估价）。",
    ),
    (
        "WAREHOUSE_VISION_ENABLED",
        "仓库视觉（认整仓里的具体藏品）",
        "bool",
        "0",
        "打开后每回合抓一次整仓图，按 230 个藏品模板认出每个格子里大概是什么、"
        "再算一个价值区间。第一次打开要多等一两秒加载模型，之后每回合多花约 1 秒。默认关。",
    ),
    (
        "WAREHOUSE_VISION_SHADOW_MODE",
        "仓库视觉 · 只看不改（影子模式）",
        "bool",
        "1",
        "开着时只打印、只记日志，不动出价 —— 先跑几局看它认得准不准。"
        "想让它参与出价再关掉这个。",
    ),
    (
        "WAREHOUSE_VISION_RISK_ENABLED",
        "仓库视觉 · 参与出价",
        "bool",
        "0",
        "总开关打开、影子模式关掉、这个也打开，才会拿它的均值/P75 去修正估价。"
        "三层默认都关着 —— 没看到几局靠谱数据之前别开。",
    ),
    (
        "WAREHOUSE_VISION_SAVE_IMAGE",
        "仓库视觉 · 存整仓图",
        "bool",
        "0",
        "每次识别顺手存一张整仓图到 记录\\仓库视觉\\日期\\。"
        "想事后对账「它认得准不准」就打开；一张约一百多 KB，只留最近 300 张。",
    ),
    (
        "SCAN_AT_ROUND",
        "整仓识别·第几回合",
        "int",
        "0",
        "在第几回合拉一次整仓识别（把整个仓从下翻一遍）要认的藏品；认到了这一回合就不用仪器（省下巨物）。0 = 不识别。",
    ),
    (
        "SCAN_TIMING",
        "整仓识别·时机（0=仪器之前）",
        "int",
        "0",
        "0 = 用仪器之前识别（认到了就不点这台仪器）；1 = 用仪器之后识别（仪器照点，只在日志里记认到了什么）。",
    ),
    (
        "SCAN_ITEM_NAMES",
        "整仓识别·要认哪些藏品",
        "str",
        "储钱小哼,万有星仪,绝对是亲手钓的鱼",
        "逗号隔开。模板放 记录\\藏品模板\\<名字>.png（或 素材\\item_<名字>.png）。默认认的就是群友、高玩、臭鱼。",
    ),
    (
        "SCAN_SKIP_TOOL",
        "整仓识别·认到就不用仪器",
        "int",
        "0",
        "1 = 认到上面任意一件 → 这一回合不点仪器（省下巨物）；0 = 照常点仪器，只记日志。",
    ),
    (
        "GATE_1100",
        "守望者档·触发估价",
        "int",
        "1100000",
        "估价大于 1,100,000 且不超过 1,314,520 时进入本档（比永恒之心还低一档）。",
    ),
    ("TIER_1100_OPEN", "守望者档·预设价（第 1 回合）", "int", "1000000", "守望者档第 1 回合固定出价。"),
    ("TIER_1100_R2_MULT", "守望者档·第 2 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_1100_R3_MULT", "守望者档·第 3 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_1100_R4_MULT", "守望者档·第 4 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_1100_R5_MULT", "守望者档·第 5、6 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_1100_KEEP", "守望者档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    (
        "GATE_179",
        "永恒之心档·触发估价",
        "int",
        "1314520",
        "估价严格大于 1,314,520 且小于 2,333,333 时进入本档；" "正好等于两端边界时不进入本档。",
    ),
    (
        "LOW_TIER_OPEN",
        "永恒之心档·首轮价（第 1 回合）",
        "int",
        "1145140",
        "本档第 1 回合统一卡价 1,145,140。",
    ),
    ("LOW_TIER_R2_MULT", "永恒之心档·第 2 回合倍率（估价×倍率）", "float", "0.9", ""),
    ("LOW_TIER_R3_MULT", "永恒之心档·第 3 回合倍率（估价×倍率）", "float", "1.2", ""),
    ("LOW_TIER_R4_MULT", "永恒之心档·第 4 回合倍率（估价×倍率）", "float", "1.5", ""),
    ("LOW_TIER_R5_MULT", "永恒之心档·第 5、6 回合倍率（估价×倍率）", "float", "1.8", ""),
    ("GATE_233", "乐园巧克力档·触发估价", "int", "2333333", "估价超过它就进入本档。"),
    ("TIER_233_OPEN", "乐园巧克力档·预设价（第 1 回合）", "int", "1888999", "乐园巧克力档第 1 回合固定出价。"),
    (
        "TIER_233_R2_MULT",
        "乐园巧克力档·第 2 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "0.7",
        "留空 = 第 2 回合保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    ("LOW_TIER_KEEP", "永恒之心档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    (
        "TIER_233_R3_MULT",
        "乐园巧克力档·第 3 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "0.9",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_233_R4_MULT",
        "乐园巧克力档·第 4 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "1.1",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_233_R5_MULT",
        "乐园巧克力档·第 5、6 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "1.2",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    ("TIER_233_KEEP", "乐园巧克力档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_321", "家用电影机档·触发估价", "int", "3210000", "估价超过它就进入本档。"),
    ("TIER_321_OPEN", "家用电影机档·预设价（第 1 回合）", "int", "2199999", "家用电影机档第 1 回合固定出价。"),
    (
        "TIER_321_R2_MULT",
        "家用电影机档·第 2 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "0.7",
        "留空 = 第 2 回合保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R3_MULT",
        "家用电影机档·第 3 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "0.9",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R4_MULT",
        "家用电影机档·第 4 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "1.1",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R5_MULT",
        "家用电影机档·第 5、6 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "1.2",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    ("TIER_321_KEEP", "家用电影机档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_280", "超级存储盘档·触发估价", "int", "5121024", "估价超过它 → 超级存储盘档，出下面的预设价。"),
    ("TIER_280_OPEN", "超级存储盘档·预设价（第 1 回合）", "int", "2721000", "超级存储盘档第 1 回合出价。"),
    (
        "TIER_280_R2_MULT",
        "超级存储盘档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R3_MULT",
        "超级存储盘档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R4_MULT",
        "超级存储盘档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R5_MULT",
        "超级存储盘档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("TIER_280_KEEP", "超级存储盘档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_898", "翠刃档·触发估价", "int", "8980000", "估价超过它 → 翠刃档。"),
    ("TIER_420_OPEN", "翠刃档·预设价（第 1 回合）", "int", "3777777", "翠刃档第 1 回合出价。"),
    (
        "TIER_420_R2_MULT",
        "翠刃档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.6",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R3_MULT",
        "翠刃档·第 3 回合倍率（估价×倍率）",
        "float",
        "0.8",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R4_MULT",
        "翠刃档·第 4 回合倍率（估价×倍率）",
        "float",
        "0.9",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R5_MULT",
        "翠刃档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("TIER_420_KEEP", "翠刃档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_588", "碧波天垂档·触发估价", "int", "11235813", "估价超过它 → 碧波天垂档。"),
    ("TIER_588_OPEN", "碧波天垂档·预设价（第 1 回合）", "int", "4100000", "碧波天垂档第 1 回合出价。"),
    (
        "TIER_588_R2_MULT",
        "碧波天垂档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R3_MULT",
        "碧波天垂档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R4_MULT",
        "碧波天垂档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R5_MULT",
        "碧波天垂档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("TIER_588_KEEP", "碧波天垂档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_1680", "夜光杯档·触发估价", "int", "16800000", "估价超过它 → 夜光杯档。"),
    (
        "TIER_620_OPEN",
        "夜光杯档·预设价（第 1 回合）",
        "int",
        "4100000",
        "夜光杯档第 1 回合出价。",
    ),
    (
        "TIER_620_R2_MULT",
        "夜光杯档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.6",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R3_MULT",
        "夜光杯档·第 3 回合倍率（估价×倍率）",
        "float",
        "0.8",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R4_MULT",
        "夜光杯档·第 4 回合倍率（估价×倍率）",
        "float",
        "0.9",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R5_MULT",
        "夜光杯档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("TIER_620_KEEP", "夜光杯档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    ("GATE_666", "Pendragon模型档·触发估价", "int", "20171210", "估价超过它 → Pendragon模型档。"),
    (
        "TIER_666_OPEN",
        "Pendragon模型档·预设价（第 1 回合）",
        "int",
        "4100000",
        "Pendragon模型档第 1 回合出价（最高档）。",
    ),
    (
        "TIER_666_R2_MULT",
        "Pendragon模型档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.6",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R3_MULT",
        "Pendragon模型档·第 3 回合倍率（估价×倍率）",
        "float",
        "0.8",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R4_MULT",
        "Pendragon模型档·第 4 回合倍率（估价×倍率）",
        "float",
        "0.9",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R5_MULT",
        "Pendragon模型档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("TIER_666_KEEP", "Pendragon模型档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    (
        "GATE_22668",
        "金锦鲤雕像档·触发估价",
        "int",
        "22668888",
        "估价大于 22,668,888 时进入本档（目前最贵的一档）。",
    ),
    ("TIER_22668_OPEN", "金锦鲤雕像档·预设价（第 1 回合）", "int", "8800000", "金锦鲤雕像档第 1 回合固定出价。"),
    ("TIER_22668_R2_MULT", "金锦鲤雕像档·第 2 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_22668_R3_MULT", "金锦鲤雕像档·第 3 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_22668_R4_MULT", "金锦鲤雕像档·第 4 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_22668_R5_MULT", "金锦鲤雕像档·第 5、6 回合倍率（估价×倍率）", "float_optional", "1.1", ""),
    ("TIER_22668_KEEP", "金锦鲤雕像档·保留（这件不卖）", "switch", "0",
     "打开 = 清仓时跳过这件藏品；关闭 = 当普通藏品处理。"),
    (
        "RESTART_ON_STUCK",
        "卡死自动重启",
        "bool",
        "1",
        "1（默认）= 开：挂机中长时间没有任何进展，就自动关掉游戏、走下面的快捷方式重开；0 = 关（卡住了也不重启，只是原地重试）。",
    ),
    (
        "LAUNCH_LINK",
        "游戏启动快捷方式",
        "str",
        "",
        "桌面那个游戏快捷方式的路径（每台电脑不一样，自己填）。例：C:/Users/xxx/Desktop/异环.lnk；也可以填启动器 exe 的全路径。反斜杠会自动换成正斜杠，留空 = 不自动重启。",
    ),
    (
        "STUCK_MINUTES",
        "多久没进展算卡死（分钟）",
        "int",
        "5",
        "默认 5 分钟。连续这么久没有任何进展（没进大厅 / 没识别到回合 / 没出价 / 没结算）才算卡死，正常等对手出价（最长 45 秒）不会被当成卡死。别调太小：一局平均 2 分多钟，建议 ≥3。",
    ),
    (
        "RESTART_HOURLY_CAP",
        "每小时最多自动重启（次）",
        "int",
        "5",
        "防止无限重启：一小时内超过这个次数就停下载机、写日志，等人工看一眼。",
    ),
    (
        "TITLE_WAIT_MINUTES",
        "等标题画面的上限（分钟）",
        "int",
        "10",
        "点了【开始游戏】后游戏还要做资源校验。这里等标题画面（Enter 图标 / 登录页 / 大厅，任一个出现就算到）；超过这个时间还没出现，就把游戏关掉、重来一轮。默认 10 分钟；更新完第一次启动或机器慢可以调大。",
    ),
    (
        "LAUNCHER_WAIT_SEC",
        "匹配开始游戏·每次等待（秒）",
        "int",
        "30",
        "抓到启动器窗口后，先等这么久让界面渲染完再匹配【开始游戏】按钮；没匹配到也是等这么久再重新匹配。默认 30 秒。",
    ),
    (
        "LAUNCHER_TRIES",
        "匹配开始游戏·最多几次",
        "int",
        "0",
        "0（默认）= 不限：一直等到【开始游戏】按钮出现再点（更新/下载/修复可能很久）。填 3 就表示三次都没找到就当卡住、关掉重来一轮。",
    ),
    (
        "WAIT_ON_RECONNECT",
        "掉线自动等待",
        "bool",
        "1",
        "1（默认）= 开：游戏弹出「网络不稳定，尝试重新连接中」时，脚本原地等它自己恢复（不点任何东西、也不算卡死）；0 = 关（维持老行为，会一直硬点，最后报「出价面板消失 / 找不到 ESC」）。",
    ),
    (
        "RECONNECT_WAIT_MIN",
        "掉线最多等多久（分钟）",
        "int",
        "3",
        "默认 3 分钟。等待期间不会关游戏；超过这个时间还没恢复就交回主流程，由上面的『卡死自救』按设定处理（关游戏重开）。建议别填得比『多久没进展算卡死』更大。",
    ),
    (
        "CURSOR_RESTORE",
        "后台模式·点完把鼠标还原",
        "bool",
        "1",
        "1（默认）= 每次后台点击后，把你原来的鼠标位置还回去（推荐，不还原的话指针会留在游戏里）。",
    ),
    (
        "CURSOR_STEAL_GUARD",
        "后台模式·防游戏吸鼠标",
        "bool",
        "1",
        "1（默认）= 开着。异环在后台状态下会把你鼠标指针吸到屏幕中心，脚本会立刻把它挪回你原来的位置；"
        "0 = 不干预（你会看到指针隔一会儿跳到屏幕中间）。",
    ),
]
SETTING_MAP = {s[0]: s for s in SETTINGS}
# 「普通倍率」这张卡的 13 个输入框不在 SETTINGS 列表里（它们是自己画的卡片），
# 这里补上类型，保存时才会按整数写进 参数配置.json（否则会写成 130.0）。
for _nm_key, _nm_label in (
    ("NORMAL_MULT_1_HI", "普通倍率·第1段上限"),
    ("NORMAL_MULT_1_RATE", "普通倍率·第1段倍率"),
    ("NORMAL_MULT_2_LO", "普通倍率·第2段下限"),
    ("NORMAL_MULT_2_HI", "普通倍率·第2段上限"),
    ("NORMAL_MULT_2_RATE", "普通倍率·第2段倍率"),
    ("NORMAL_MULT_3_LO", "普通倍率·第3段下限"),
    ("NORMAL_MULT_3_HI", "普通倍率·第3段上限"),
    ("NORMAL_MULT_3_RATE", "普通倍率·第3段倍率"),
    ("NORMAL_MULT_4_LO", "普通倍率·第4段下限"),
    ("NORMAL_MULT_4_HI", "普通倍率·第4段上限"),
    ("NORMAL_MULT_4_RATE", "普通倍率·第4段倍率"),
    ("NORMAL_MULT_5_LO", "普通倍率·第5段下限"),
    ("NORMAL_MULT_5_HI", "普通倍率·第5段上限"),
    ("NORMAL_MULT_5_RATE", "普通倍率·第5段倍率"),
    ("NORMAL_MULT_6_LO", "普通倍率·第6段下限"),
    ("NORMAL_MULT_6_HI", "普通倍率·第6段上限"),
    ("NORMAL_MULT_6_RATE", "普通倍率·第6段倍率"),
    ("NORMAL_MULT_7_LO", "普通倍率·第7段下限"),
    ("NORMAL_MULT_7_RATE", "普通倍率·第7段倍率"),
):
    SETTING_MAP.setdefault(_nm_key, (_nm_key, _nm_label, "int", "0", ""))
# 这几个键只出现在「档位表下方的清仓卡」里，不在参数列表里，补一下类型给保存用
SETTING_MAP.setdefault(
    "CLEAN_SELL_ALL_BELOW",
    ("CLEAN_SELL_ALL_BELOW", "结算价值低于该价格全部出售（包括红色）", "int", "0", ""),
)
SETTING_MAP.setdefault(
    "CLEAN_SKIP_SELL",
    ("CLEAN_SKIP_SELL", "不进入仓库出售藏品", "switch", "0", ""),
)
SETTING_MAP.setdefault(
    "TIER_YANYUN_KEEP",
    ("TIER_YANYUN_KEEP", "烟云盏·保留（这件不卖）", "switch", "0", ""),
)
SETTING_MAP.setdefault(
    "TIER_SHOUTI_KEEP",
    ("TIER_SHOUTI_KEEP", "古旧手提箱·保留（这件不卖）", "switch", "0", ""),
)
SETTING_MAP.setdefault(
    "AUTO_CLEAN_MAX_VALUE",
    ("AUTO_CLEAN_MAX_VALUE", "清仓时单件最高卖价", "int", "1000000", ""),
)


CONFIG_COPY = {
    "BACKGROUND_RUN": ("允许游戏窗口被遮挡", "游戏窗口保持打开，可被其他窗口盖住。点击仍借用系统鼠标。"),
    "CURSOR_RESTORE": ("点击后还原鼠标", "点击后光标仍停在脚本放置的位置时，将它还回点击前的位置。"),
    "CURSOR_STEAL_GUARD": ("防止游戏把光标拉到中央", "检测到游戏把光标拉到窗口中央时，尝试还回你的位置。"),
    "CURSOR_YIELD_USER": ("你在用鼠标时等待", "明显移动鼠标或点击其他窗口时，暂缓鼠标动作。松手后重新识别画面，再继续适用的操作。"),
    "READ_TOLERANCE": ("出价金额核对容差", "确认出价前的 OCR 核对。预期 100 万、容差 50% 时，读到 50–150 万都可能通过。填 0% 要求读数相符。"),
    "HARD_CAP_MULT": ("第 3 回合起的出价上限", "适用路径按当前估价乘这个倍数封顶。前两回合和目标藏品独立出价另有规则。0 表示关闭。"),
    "SAFE_MODE": ("智能策略的出价风格", "求稳会降低适用回合的出价上限，拿仓按普通上限计算。前两回合保底价另行计算。"),
    "BID_AUTO_PRICE": ("使用智能策略算价", "开启后使用智能策略。关闭时按普通倍率、档位和目标藏品规则算价。"),
    "READ_RIVAL_BIDS": ("读取对手出价", "关闭后不采集对手金额，按当前策略中的估价或档位规则继续算价。"),
    "MIN_BID_AMOUNT": ("最低出价", "适用的策略算出的金额过低时抬到这个值。填 0 关闭。"),
    "CHASE_TO_END": ("低于退出线时继续竞拍", "开启会跳过低估价退出判断，出价仍取决于策略、递增设置和适用的上限。"),
    "NO_EXIT_NO_DOWNGRADE": ("继续竞拍时按倍率抬价", "开启后，适用的智能策略会按上一注和加价倍率计算最低价，随后仍检查适用的上限。"),
    "OPENING_PRICE_RANGE": ("开局保底价区间", "例如填 500000-600000，每局在范围内抽一个保底价，尾数会贴整。留空使用固定开局价。"),
}
SETTING_MAP["CURSOR_YIELD_USER"] = ("CURSOR_YIELD_USER", CONFIG_COPY["CURSOR_YIELD_USER"][0], "bool", "1", CONFIG_COPY["CURSOR_YIELD_USER"][1])
VISION_KEYS = ("WAREHOUSE_VISION_ENABLED", "WAREHOUSE_VISION_SHADOW_MODE", "WAREHOUSE_VISION_RISK_ENABLED")
VISION_FLAGS = ((0, 1, 0), (1, 1, 0), (1, 0, 1))
VISION_OPTIONS = ("关闭识别", "只记录识别结果", "用识别结果修正出价估价")
LIVE_CONFIG_KEYS = {"CLEAN_SELL_ALL_BELOW", "CLEAN_SKIP_SELL", "AUTO_CLEAN_MAX_VALUE",
                    "AUTO_CLEAN_SELL_ENABLED", "AUTO_CLEAN_TARGET_ENABLED"}


def typed_setting(kind, value):
    import math
    text = str(value).strip()
    if kind in ("choice", "str"):
        return text
    if kind in ("bool", "switch"):
        if text.lower() in ("1", "true", "开", "是"):
            return 1
        if text.lower() in ("0", "false", "关", "否"):
            return 0
        raise ValueError("需要选择开或关")
    if kind == "float_optional" and not text:
        return None
    if kind == "int":
        from decimal import Decimal, InvalidOperation
        try:
            number = Decimal(text)
        except InvalidOperation:
            raise ValueError("请填写整数") from None
        if not number.is_finite() or number != number.to_integral_value():
            raise ValueError("请填写整数")
        return int(number)
    try:
        number = float(text)
    except ValueError:
        raise ValueError("请填写数字") from None
    if not math.isfinite(number):
        raise ValueError("请填写有限数字")
    if kind == "percent":
        if not 0 <= number <= 100:
            raise ValueError("请输入 0–100 的百分比")
        return number / 100
    return number


def validate_multiplier_ranges(values):
    previous_high = None
    previous_row = None
    gaps = []
    for row in range(1, 8):
        lo_key = f"NORMAL_MULT_{row}_LO"
        hi_key = f"NORMAL_MULT_{row}_HI"
        low = values.get(lo_key, 0)
        high = values.get(hi_key)
        rate = values.get(f"NORMAL_MULT_{row}_RATE", 0)
        if min(low, rate, high if high is not None else low) < 0:
            return (lo_key if low < 0 else (hi_key if high is not None and high < 0 else f"NORMAL_MULT_{row}_RATE"),
                    "请输入非负数"), gaps
        if rate <= 0 or high == 0 or (row > 1 and low == 0):
            continue
        if high is not None and low >= high:
            return (hi_key, f"第 {row} 段上限必须大于下限"), gaps
        if previous_high is not None:
            if low <= previous_high:
                return (lo_key, f"第 {previous_row}、{row} 段重叠"), gaps
            if low > previous_high + 1:
                gaps.append(f"{previous_high + 1:,}–{low - 1:,}")
        elif low > 1:
            gaps.append(f"1–{low - 1:,}")
        previous_high, previous_row = high, row
    if previous_high is not None:
        gaps.append(f"{previous_high + 1:,} 以上")
    return None, gaps


PARAM_JSON = os.path.join(SELF_DIR, "参数配置.json")

# 两套仪器组的成本表（1~5 号仪器单价）。
# 2/3/4 号两组价格完全一样，只有 1 号和 5 号不同：
#   巨物      1号 5万  5号 2万
#   至尊      1号 10万 5号 7万
INSTRUMENT_GROUP_PRICES = {
    "SUPER_APPRAISAL": "50000,10000,10000,10000,20000",
    "SUPREME": "100000,10000,10000,10000,70000",
}
INSTRUMENT_GROUP_NAMES = {
    "SUPER_APPRAISAL": "巨物",
    "SUPREME": "至尊",
}
_PARAM_CACHE = {}


def param_file_load(force=False):
    """读参数配置文件，带一层缓存（面板每次渲染要问一百多次）。"""
    global _PARAM_CACHE
    if _PARAM_CACHE and not force:
        return _PARAM_CACHE
    data = {}
    try:
        if os.path.isfile(PARAM_JSON):
            with open(PARAM_JSON, encoding="utf-8") as fh:
                loaded = json.load(fh)
            if isinstance(loaded, dict):
                data = loaded
    except Exception:
        data = {}
    _PARAM_CACHE = data
    return _PARAM_CACHE


def param_file_save(data):
    """Atomically publish a fully validated snapshot in the config directory."""
    import tempfile
    global _PARAM_CACHE

    temp_path = None
    try:
        fd, temp_path = tempfile.mkstemp(prefix=".参数配置-", suffix=".tmp",
                                         dir=os.path.dirname(os.path.abspath(PARAM_JSON)))
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as fp:
            json.dump(data, fp, ensure_ascii=False, indent=2, sort_keys=True, allow_nan=False)
            fp.write("\n")
        os.replace(temp_path, PARAM_JSON)
        _PARAM_CACHE = dict(data)
        return True
    except (OSError, ValueError, TypeError):
        return False
    finally:
        if temp_path is not None:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


_DEFAULT_SOURCE_CACHE = (None, "")


def setting_defaults_source():
    global _DEFAULT_SOURCE_CACHE
    st = os.stat(MAIN_PY)
    identity = (MAIN_PY, st.st_mtime_ns, st.st_size)
    if _DEFAULT_SOURCE_CACHE[0] != identity:
        with open(MAIN_PY, encoding="utf-8") as fp:
            _DEFAULT_SOURCE_CACHE = (identity, fp.read())
    return _DEFAULT_SOURCE_CACHE[1]


def read_setting(key):
    """面板显示用：参数文件里有就用文件里的，没有就用源码里的默认值。"""
    try:
        data = param_file_load()
        if key in data:
            v = data[key]
            if isinstance(v, bool):
                return "1" if v else "0"
            return str(v)
    except Exception:
        pass
    try:
        src = setting_defaults_source()
        m = re.search(r"^%s[ \t]*=[ \t]*(['\"])(.*?)\1" % re.escape(key), src, re.M)
        if m:
            return m.group(2)
        m = re.search(r"^%s\s*=\s*([^\s#]+)" % re.escape(key), src, re.M)
        return m.group(1).strip().strip("\"'") if m else ""
    except Exception:
        return ""


def write_setting(key, value):
    """保存一个参数到 参数配置.json。返回 False 表示这个键压根不存在。"""
    try:
        src = setting_defaults_source()
        if not re.search(r"^%s[ \t]*=" % re.escape(key), src, re.M):
            return False
        info = SETTING_MAP.get(key)
        kind = info[2] if info else "float"
        new = str(value).strip()
        if kind in ("choice", "str"):
            # 路径这类字符串：留着原样，只把反斜杠统一成正斜杠，存文件里好读
            newval = new.replace("\\", "/")
        elif kind in ("bool", "switch"):
            # 胶囊开关也用 0/1 存，别写成 1.0（挂机端是按整数读的）
            newval = 1 if new in ("1", "True", "true", "开", "是") else 0
        elif kind == "int":
            newval = int(float(new))
        else:
            newval = float(new)
        data = dict(param_file_load())
        data[key] = newval
        return param_file_save(data)
    except Exception:
        return False


# ---------- 参数分享：一串文本，发给别人贴进去就能套用 ----------
SHARE_PREFIX = "ANK1."
# 跟这台机器绑的参数不往外带（路径、后台、点击速度）
SHARE_SKIP = {"LAUNCH_LINK", "BACKGROUND_RUN", "CLICK_SPEED"}


def pack_param_code():
    """把「和默认值不一样的项」压成一串码。"""
    data = {}
    for key, label, kind, rec, hint in SETTING_MAP.values():
        if key in SHARE_SKIP or key in ("BIG_LOT_GATE", "FAST_SETTLE", "FAST_SETTLE_VALUE"):
            continue
        try:
            cur = str(read_setting(key)).strip()
        except Exception:
            continue
        if cur != str(rec).strip():
            data[key] = cur
    raw = json.dumps(data, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    blob = base64.urlsafe_b64encode(zlib.compress(raw, 9)).decode("ascii").rstrip("=")
    return SHARE_PREFIX + blob


def unpack_param_code(code):
    """解开参数码，返回 {key: 文本值}。解不开就抛异常。"""
    text = (code or "").strip().replace("\n", "").replace("\r", "")
    if not text.startswith(SHARE_PREFIX):
        raise ValueError("不是参数码（应该以 %s 开头）" % SHARE_PREFIX)
    blob = text[len(SHARE_PREFIX):]
    if not blob:
        raise ValueError("码是空的")
    blob += "=" * (-len(blob) % 4)
    try:
        raw = zlib.decompress(base64.urlsafe_b64decode(blob.encode("ascii")))
    except Exception:
        raise ValueError("这串码解不开（可能复制少了几位）")
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception:
        raise ValueError("码里面的内容坏了")
    if not isinstance(data, dict):
        raise ValueError("码里的内容不认识")
    return {str(k): str(v) for k, v in data.items()}


def compare_param_code(data):
    """分成三类：要改的 / 一样的 / 这边没有的。"""
    labels = {key: CONFIG_COPY.get(key, (row[1], ""))[0] for key, row in SETTING_MAP.items()
              if key not in ("BIG_LOT_GATE", "FAST_SETTLE", "FAST_SETTLE_VALUE")}
    diff, same, unknown = [], [], []
    for key, value in data.items():
        if key not in labels:
            unknown.append(key)
            continue
        try:
            old = str(read_setting(key)).strip()
        except Exception:
            old = ""
        if old == str(value).strip():
            same.append(key)
        else:
            diff.append((key, labels[key], old, str(value).strip()))
    return diff, same, unknown


def repair_main_py():
    fixed_names = []
    try:
        src = open(MAIN_PY, encoding="utf-8").read()
    except Exception:
        return fixed_names
    out = src
    for key in ("BID_MODE",):
        pat = re.compile(r"^(%s\s*=\s*)([A-Za-z_]\w*)([ \t]*(?:#.*)?)$" % re.escape(key), re.M)
        m = pat.search(out)
        if m:
            fixed_names.append('%s = %s -> "%s"' % (key, m.group(2), m.group(2)))
            out = pat.sub(
                lambda mm: mm.group(1) + '"' + mm.group(2) + '"' + mm.group(3), out, count=1
            )
    if out != src:
        try:
            tmp = MAIN_PY + ".tmp_fix"
            with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(out)
            os.replace(tmp, MAIN_PY)
        except Exception:
            fixed_names = []
        if fixed_names:
            try:
                d = os.path.join(LOG_ROOT, datetime.date.today().strftime("%Y-%m-%d"))
                os.makedirs(d, exist_ok=True)
                with open(os.path.join(d, "运行日志.txt"), "a", encoding="utf-8") as fp:
                    fp.write(
                        "[%s] 面板启动时修复了被写坏的配置：%s（已补引号，否则脚本会启动失败）\n"
                        % (
                            datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                            "; ".join(fixed_names),
                        )
                    )
            except Exception:
                pass
    return fixed_names


def date_list():
    days = set()
    for root in (LOG_ROOT, SHOT_ROOT):
        try:
            for name in os.listdir(root):
                if re.match(r"^\d{4}-\d{2}-\d{2}$", name):
                    days.add(name)
        except Exception:
            pass
    days.add(datetime.date.today().strftime("%Y-%m-%d"))
    return sorted(days, reverse=True)


def load_cfg():
    global LOG_ROOT, SHOT_ROOT
    try:
        if os.path.exists(CFG_FILE):
            d = json.loads(open(CFG_FILE, encoding="utf-8").read())
            if d.get("log_root") and os.path.isdir(d["log_root"]):
                LOG_ROOT = d["log_root"]
            if d.get("shot_root") and os.path.isdir(d["shot_root"]):
                SHOT_ROOT = d["shot_root"]
    except Exception:
        pass


def save_cfg():
    try:
        os.makedirs(os.path.dirname(CFG_FILE), exist_ok=True)
        with open(CFG_FILE, "w", encoding="utf-8") as fp:
            json.dump(
                {"log_root": LOG_ROOT, "shot_root": SHOT_ROOT}, fp, ensure_ascii=False, indent=2
            )
    except Exception:
        pass


def guess_roots(want="日志"):
    hits = []
    cands = [
        os.path.join(BASE, "记录"),
        os.path.join(BASE, "1.1", "记录"),
        os.path.join(os.path.dirname(BASE), "记录"),
        os.path.join(os.path.dirname(BASE), "正式版", "记录"),
        os.path.join(os.path.expanduser("~"), "Desktop", "记录"),
    ]
    for c in cands:
        p = os.path.join(c, want)
        if os.path.isdir(p) and p not in hits:
            hits.append(p)
    return hits


def bot_pids(fresh=False):
    """在跑的挂机进程 pid 列表。

    大肥鱼standby 提速：**结果缓存 3 秒 + 优先用 psutil 扫命令行**。
    原因：本机没有 wmic（Win11 已移除），原来的实现每次都掉到 PowerShell 兜底、
    一次 0.5 秒以上；而「实时输出」每秒都要问一次，等于每秒把界面冻半秒。
    需要最新结果的场合（比如「彻底停止脚本」要拿 pid 去杀）传 fresh=True。
    """
    _now = datetime.datetime.now().timestamp()
    if not fresh and _now - _BOT_PIDS_CACHE["at"] < 3.0:
        return list(_BOT_PIDS_CACHE["val"])

    def _remember(seq):
        _BOT_PIDS_CACHE["at"] = _now
        _BOT_PIDS_CACHE["val"] = list(seq)
        return list(seq)

    # 冻结模式：挂机进程是「同一个 exe --bot」，不是 python.exe + paimai.py
    if getattr(sys, "frozen", False):
        pids = []
        try:
            exe = os.path.basename(sys.executable)
            out = (subprocess.run(
                ["wmic", "process", "where",
                 "name='%s'" % exe.replace("'", "''"),
                 "get", "ProcessId,CommandLine"],
                capture_output=True, text=True, timeout=10,
                creationflags=NO_WINDOW,
            ).stdout or "")
            for line in out.splitlines():
                if "--bot" in line:
                    mm = re.search(r"(\d+)\s*$", line.strip())
                    if mm:
                        _p = int(mm.group(1))
                        if _p != os.getpid():
                            pids.append(_p)
        except Exception:
            pass
        if not pids:
            try:
                out = (subprocess.run(
                    ["powershell", "-NoProfile", "-Command",
                     "Get-CimInstance Win32_Process | "
                     "Where-Object { $_.CommandLine -like '*--bot*' } | "
                     "Select-Object -ExpandProperty ProcessId"],
                    capture_output=True, text=True, timeout=10,
                    creationflags=NO_WINDOW,
                ).stdout or "")
                for line in out.splitlines():
                    line = line.strip()
                    if line.isdigit() and int(line) != os.getpid():
                        pids.append(int(line))
            except Exception:
                pass
        return _remember(pids)

    # ── 非冻结（python.exe 跑 paimai.py）──
    # 1) 首选 psutil 扫命令行：一次 30~50ms，且不依赖外部程序
    pids = []
    _psutil = None
    try:
        import psutil as _psutil
    except Exception:
        _psutil = None
    if _psutil is not None:
        _scan_ok = False
        try:
            _me = os.getpid()
            for proc in _psutil.process_iter(["pid", "cmdline"]):
                try:
                    if proc.info.get("pid") == _me:
                        continue
                    _cmd = " ".join(proc.info.get("cmdline") or []).lower()
                    if "paimai.py" in _cmd:
                        pids.append(int(proc.info["pid"]))
                except Exception:
                    continue
            _scan_ok = True
        except Exception:
            pids = []
        if _scan_ok:
            # psutil 扫成功就以它为准：不再往 wmic/PowerShell 里掉（那要 0.5 秒以上）
            return _remember(pids)
    # 2) psutil 不可用才退回 wmic（Win11 可能已移除）→ PowerShell（慢，0.5 秒以上）
    if not pids:
        try:
            import shutil as _shutil
            _has_wmic = bool(_shutil.which("wmic"))
        except Exception:
            _has_wmic = False
        if _has_wmic:
            try:
                out = (
                    subprocess.run(
                        ["wmic", "process", "where", "name='python.exe'",
                         "get", "ProcessId,CommandLine"],
                        capture_output=True,
                        text=True,
                        timeout=10,
                        creationflags=NO_WINDOW,
                    ).stdout
                    or ""
                )
                for line in out.splitlines():
                    if "paimai.py" in line:
                        m = re.search(r"(\d+)\s*$", line.strip())
                        if m:
                            pids.append(int(m.group(1)))
            except Exception:
                pass
    if not pids:
        try:
            ps = (
                "Get-CimInstance Win32_Process -Filter \"name='python.exe'\" | "
                "Where-Object { $_.CommandLine -like '*paimai.py*' } | "
                "Select-Object -ExpandProperty ProcessId"
            )
            out = (
                subprocess.run(
                    ["powershell", "-NoProfile", "-Command", ps],
                    capture_output=True,
                    text=True,
                    timeout=20,
                    creationflags=NO_WINDOW,
                ).stdout
                or ""
            )
            pids = [int(x) for x in re.findall(r"\d+", out)]
        except Exception:
            pass
    return _remember(pids)


def bot_alive(fresh=False):
    """脚本进程（python.exe paimai.py）还在不在。

    用 psutil 扫一遍命令行，比 wmic/powershell 快一个数量级；
    psutil 不可用就退回 bot_pids()。返回 True/False，查不清返回 None。
    结果缓存 10 秒：扫一遍进程表要 30~150ms，每 3 秒来一次会让界面周期性顿一下。
    真正要紧的场合（关脚本 / 更新前）都会传 fresh=True，立即重扫。
    """
    now = datetime.datetime.now().timestamp()
    if not fresh and now - _BOT_ALIVE_CACHE["at"] < 10.0:
        return _BOT_ALIVE_CACHE["val"]
    val = None
    try:
        import psutil
    except Exception:
        psutil = None
    if psutil is not None:
        try:
            val = False
            for proc in psutil.process_iter(["cmdline"]):
                try:
                    cmdline = proc.info.get("cmdline") or []
                except Exception:
                    continue
                # 只认"脚本就是 paimai.py"的进程（cmdline[1] 是脚本路径），
                # 免得把命令行里恰好提到 paimai.py 的其它 python 也算成挂机。
                if len(cmdline) >= 2 and str(cmdline[1]).lower().endswith("paimai.py"):
                    val = True
                    break
        except Exception:
            val = None
    if val is None:
        try:
            val = bool(bot_pids())
        except Exception:
            val = None
    _BOT_ALIVE_CACHE["at"] = now
    _BOT_ALIVE_CACHE["val"] = val
    return val


def is_elevated():
    try:
        import ctypes

        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


_BOT_PROC = None      # 大肥鱼standby：我们自己起的挂机子进程


def _hide_bot_console():
    """要不要隐藏挂机黑窗口。

    · v3 测试版（脚本目录直接跑）：**显示** CMD 窗口 —— 测试时要看日志；
    · exe 版（启动器注入了 DFY_EXE_PATH）：隐藏窗口，日志只写文件。
    """
    try:
        if os.environ.get("DFY_EXE_PATH"):
            return True
        return bool(getattr(sys, "frozen", False))
    except Exception:
        return False


def start_bot_process():
    # ---------------- 大肥鱼standby：冻结模式自调用 ----------------
    # 打包后没有 python\pythonw.exe，也没有可执行的 paimai.py 脚本文件，
    # 于是改成「同一个 exe 用 --bot 再起一个自己」。
    if getattr(sys, "frozen", False):
        cmd = [sys.executable, "--bot", "--auto"]
        try:
            # 大肥鱼standby：不要黑窗口；输出直接写 记录\<日期>\日志\控制台输出.txt
            import datetime as _dt
            _day = _dt.date.today().strftime("%Y-%m-%d")
            _cdir = os.path.join(REC, _day, "日志")
            os.makedirs(_cdir, exist_ok=True)
            _cpath = os.path.join(_cdir, "控制台输出.txt")
            _fh = open(_cpath, "a", encoding="utf-8", buffering=1)
            _env = dict(os.environ, STANDBY_CONSOLE_REDIRECT="1")
            _proc = subprocess.Popen(
                cmd, cwd=BASE, stdout=_fh, stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0), env=_env,
            )
            global _BOT_PROC
            _BOT_PROC = _proc
            # ---- 大肥鱼standby：子进程 2.5 秒内就退出 → 一定是启动失败，直接把原因说出来 ----
            time.sleep(2.5)
            _rc = _proc.poll()
            _tail = ""
            try:
                if os.path.isfile(_cpath):
                    with open(_cpath, encoding="utf-8", errors="replace") as _rf:
                        _tail = "\n".join(_rf.read().splitlines()[-12:])
            except Exception:
                pass
            try:
                import datetime as _dt2
                with open(os.path.join(REC, "面板启动日志.txt"), "a", encoding="utf-8") as _lf:
                    _lf.write("%s  启动 --bot pid=%s rc=%s 日志=%s\n%s\n"
                              % (_dt2.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                 _proc.pid, _rc, _cpath, _tail))
            except Exception:
                pass
            if _rc is not None:
                return False, ("挂机进程启动后立刻退出（退出码 %s）。以下是它的输出：\n%s"
                               % (_rc, _tail or "（日志为空）"))
            return True, "已启动挂机脚本（不弹黑窗口），日志直接显示在「实时输出」里。"
        except Exception as exc:
            try:
                import datetime as _dt3
                with open(os.path.join(REC, "面板启动日志.txt"), "a", encoding="utf-8") as _lf:
                    _lf.write("%s  启动失败: %r\n"
                              % (_dt3.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), exc))
            except Exception:
                pass
            return False, "启动挂机进程失败：%s" % exc
    # 大肥鱼standby：没有内嵌 python 时，用当前解释器跑 paimai.py
    _py = PY if os.path.isfile(PY) else sys.executable
    if is_elevated():
        _hide = _hide_bot_console()
        if not _hide:
            # v3 测试版：照旧开一个可见的 CMD 窗口，方便盯日志
            subprocess.Popen(
                [_py, MAIN_PY, "--auto"],
                cwd=BASE,
                creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0),
            )
            return True, "已启动挂机脚本（黑窗口已打开，就是它；按 F10 开始 / F11 暂停继续 / F12 彻底停止）。"
        _log_fh = None
        try:
            import datetime as _dt0
            _cdir0 = os.path.join(REC, _dt0.date.today().strftime("%Y-%m-%d"), "日志")
            os.makedirs(_cdir0, exist_ok=True)
            # 注意：不能重定向到 控制台输出.txt —— 挂机脚本自己会 tee 一份进去，
            # 重定向到同一个文件会导致每行日志重复两遍。这里只是给子进程一个合法的 stdout，
            # 真正的日志由脚本自己写。
            _log_fh = open(os.devnull, "w", encoding="utf-8")
        except Exception:
            _log_fh = None
        try:
            if _log_fh is not None:
                subprocess.Popen([_py, MAIN_PY, "--auto"], cwd=BASE,
                                 stdout=_log_fh, stderr=subprocess.STDOUT,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            else:
                subprocess.Popen([_py, MAIN_PY, "--auto"], cwd=BASE,
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        except Exception as exc:
            return False, "启动挂机进程失败：%s" % exc
        return True, "已启动挂机脚本（不弹黑窗口），日志看「实时输出」或 记录\\<日期>\\日志\\控制台输出.txt；F10 开始 / F11 暂停继续 / F12 彻底停止。"
    try:
        import ctypes

        rc = ctypes.windll.shell32.ShellExecuteW(
            None, "runas", _py, '"%s" --auto' % MAIN_PY, BASE,
            0 if _hide_bot_console() else 1
        )
        if rc > 32:
            return (
                True,
                "面板不是管理员运行 → 已用【管理员身份】启动脚本（会弹一次 UAC 确认，启动后没有黑窗口）。",
            )
    except Exception:
        pass
    subprocess.Popen(
        [_py, MAIN_PY, "--auto"],
        cwd=BASE,
        creationflags=(getattr(subprocess, "CREATE_NO_WINDOW", 0)
                       if _hide_bot_console()
                       else getattr(subprocess, "CREATE_NEW_CONSOLE", 0)),
    )
    return True, (
        "⚠️ 没能提权启动（可能你点了『否』）：脚本会以普通权限跑，"
        "如果游戏是管理员启动的，点击会被系统拦掉——请关掉面板、右键以管理员身份运行 点我启动.bat"
    )


_LAST_STATS_CACHE = {"path": "", "offset": 0, "hb": None, "stats": {}}


def _last_stats_result(c):
    """把缓存摊成 last_stats 的老返回值。"""
    running, hb = False, c.get("hb")
    if hb:
        try:
            t = datetime.datetime.strptime(hb, "%Y-%m-%d %H:%M:%S")
            running = (datetime.datetime.now() - t).total_seconds() < 720
        except Exception:
            running = False
    return running, hb, c.get("stats") or {}


def last_stats():
    _read_auction_ends()
    return _last_stats_result(_LAST_STATS_CACHE)


_ENDS_CACHE = {"offset": 0, "path": "", "rows": []}


def _read_auction_ends():
    """只读新增的那一段 —— 记录文件几十兆，每次都从头扫会让切统计卡住一两秒。"""
    global _ENDS_CACHE, _LAST_STATS_CACHE
    try:
        size = os.path.getsize(JSONL)
    except OSError:
        return []
    if _ENDS_CACHE["path"] != JSONL or size < _ENDS_CACHE["offset"]:
        # 换了文件、或者被清空/轮转过：从头再来
        _ENDS_CACHE = {"offset": 0, "path": JSONL, "rows": []}
        _LAST_STATS_CACHE = {"path": JSONL, "offset": 0, "hb": None, "stats": {}}
    if size == _ENDS_CACHE["offset"]:
        return _ENDS_CACHE["rows"]
    out = _ENDS_CACHE["rows"]
    try:
        with open(JSONL, "rb") as fp:
            fp.seek(_ENDS_CACHE["offset"])
            chunk = fp.read()
    except OSError:
        return out
    # 末尾可能正写到一半，只处理到最后一个换行
    cut = chunk.rfind(b"\n")
    if cut < 0:
        return out
    complete = chunk[:cut + 1]
    _ENDS_CACHE["offset"] += len(complete)
    for line in complete.splitlines():
        if not any(tag in line for tag in (b'"auction_end"', b'"heartbeat"', b'"session_start"')):
            continue
        try:
            d = json.loads(line)
        except Exception:
            continue
        kind = d.get("type")
        if kind == "auction_end":
            out.append(d)
        if kind in ("heartbeat", "session_start", "auction_end"):
            _LAST_STATS_CACHE["hb"] = d.get("ts")
            if d.get("stats"):
                _LAST_STATS_CACHE["stats"] = d["stats"]
    return out


def _sum_ends(ends):
    st = {"auctions": 0, "won": 0, "lost": 0, "quit": 0, "cost": 0, "net_profit": 0, "profit": 0}
    for d in ends:
        st["auctions"] += 1
        r = d.get("result")
        if r in ("won", "lost", "quit"):
            st[r] += 1
        for k, src in (("cost", "cost"), ("net_profit", "net_profit"), ("profit", "my_profit")):
            try:
                st[k] += int(d.get(src) or 0)
            except Exception:
                pass
    return st


def stats_range(mode, session_start=None):
    ends = _read_auction_ends()
    today = datetime.date.today()
    if mode == "session":
        ss = session_start or PANEL_SESSION_START
        key = ss.strftime("%Y-%m-%d %H:%M:%S")
        sel = [d for d in ends if str(d.get("ts") or "") >= key]
        label = "本次运行（%s 开面板起）" % ss.strftime("%m-%d %H:%M")
    elif mode == "recent3":
        days = set((today - datetime.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(3))
        sel = [d for d in ends if str(d.get("ts") or "")[:10] in days]
        label = "近三日（%s ~ %s）" % (
            (today - datetime.timedelta(days=2)).strftime("%m-%d"),
            today.strftime("%m-%d"),
        )
    elif mode == "all":
        sel = list(ends)
        label = "全部统计"
    else:
        key = today.strftime("%Y-%m-%d")
        sel = [d for d in ends if str(d.get("ts") or "").startswith(key)]
        label = "今日（%s）" % key
    return _sum_ends(sel), label


def _money(txt):
    if txt is None:
        return None
    m = re.search(r"[+-]?[\d,]+", str(txt))
    if not m:
        return None
    try:
        return int(m.group(0).replace(",", ""))
    except Exception:
        return None


def parse_auction_record(day):
    path = os.path.join(LOG_ROOT, day, "拍卖记录.txt")
    if not os.path.exists(path):
        return []
    try:
        txt = open(path, encoding="utf-8", errors="ignore").read()
    except Exception:
        return []
    recs = []
    for blk in txt.split("=" * 50):
        if "结果:" not in blk:
            continue
        rec = {
            "no": None,
            "time": "",
            "result": "",
            "winner": None,
            "rounds": {},
            "cost": 0,
            "final_price": None,
            "actual_value": None,
            "profit": None,
            "net": None,
            "my_income": None,
            "note": "",
            "text": blk.strip(),
            "max_opp": None,
            "max_est": None,
            "day": day,
        }
        for ln in blk.split("\n"):
            ln = ln.strip()
            m = re.match(r"第 (\d+) 场\s+时间:\s*(.+)", ln)
            if m:
                rec["no"] = int(m.group(1))
                rec["time"] = m.group(2).strip()
                continue
            if ln.startswith("结果:"):
                rec["result"] = ln.split(":", 1)[1].strip()
                continue
            if ln.startswith("玩家名称:"):
                rec["winner"] = ln.split(":", 1)[1].strip()
                continue
            m = re.match(r"第(\d+)回合估价:\s*([\d,]+)", ln)
            if m:
                r = int(m.group(1))
                d = rec["rounds"].setdefault(r, {})
                d["estimate"] = int(m.group(2).replace(",", ""))
                mb = re.search(r"出价:\s*([\d,]+)", ln)
                if mb:
                    d["bid"] = int(mb.group(1).replace(",", ""))
                continue
            m = re.match(r"第(\d+)回合各家出价：(.*)", ln)
            if m:
                rec["rounds"].setdefault(int(m.group(1)), {})["bids_raw"] = m.group(2).strip()
                continue
            if ln.startswith("本局成本:"):
                rec["cost"] = _money(ln) or 0
                continue
            if ln.startswith("最终成交价:"):
                rec["final_price"] = _money(ln)
                continue
            if ln.startswith("实际价值:"):
                rec["actual_value"] = _money(ln)
                continue
            if ln.startswith("收益:"):
                rec["profit"] = _money(ln)
                continue
            if ln.startswith("净收益:"):
                rec["net"] = _money(ln)
                m2 = re.search(r"我的收入\s*([+-][\d,]+)", ln)
                if m2:
                    rec["my_income"] = _money(m2.group(1))
                continue
            if ln.startswith("备注:"):
                rec["note"] = ln.split(":", 1)[1].strip()
                continue
        ests = [v.get("estimate") for v in rec["rounds"].values() if v.get("estimate")]
        rec["max_est"] = max(ests) if ests else None
        opp = None
        for v in rec["rounds"].values():
            raw = v.get("bids_raw") or ""
            if "天黑" in raw:
                continue
            for part in raw.split("｜"):
                if "（我）" in part:
                    continue
                mm = re.search(r"([\d,]{3,})", part)
                if mm:
                    val = int(mm.group(1).replace(",", ""))
                    if opp is None or val > opp:
                        opp = val
        rec["max_opp"] = opp
        recs.append(rec)
    return recs


def parse_all_auction_records():
    out = []
    try:
        days = sorted(d for d in os.listdir(LOG_ROOT) if re.match(r"^\d{4}-\d{2}-\d{2}$", d))
    except Exception:
        days = []
    for d in days:
        out.extend(parse_auction_record(d))
    out.sort(key=lambda r: (r.get("day") or "", r.get("time") or "", r.get("no") or 0))
    return out


ANALYSIS_SECTIONS = [
    ("summary", "① 自己的收益总览"),
    ("gap", "② 信息差大仓（实际价值 ≥ 估价 × 3）"),
    ("estimate", "③ 估价 > 阈值 的对局"),
    ("win", "④ 我拍到的【盈利】对局"),
    ("lose", "⑤ 我拍到的【亏损】对局"),
    ("value_high", "⑥ 结算价值（实际价值）> 阈值 的高价值对局"),
]

ALL_DAYS = "全部（所有对局）"


def build_analysis(recs, threshold):
    data = {}
    out = []
    total = len(recs)
    won = [r for r in recs if r["result"] == "我拍到"]
    lost = [r for r in recs if r["result"] == "他人拍走"]
    quit_ = [r for r in recs if r["result"] == "中途退出"]
    fee = sum(r["cost"] for r in recs)
    my_profit = sum(r["profit"] or 0 for r in won)
    dividend = sum(r["my_income"] or 0 for r in lost if (r["my_income"] or 0) > 0)
    net = sum(r["net"] or 0 for r in recs)

    out.append("=" * 60)
    out.append("📊 自己的收益情况")
    out.append("=" * 60)
    out.append("总场次: %d" % total)
    out.append("我拍到: %d ｜ 他人拍走: %d ｜ 中途退出: %d" % (len(won), len(lost), len(quit_)))
    out.append("总成本（入场费+仪器）: -%s" % format(fee, ","))
    out.append("我拍到的成交收益: %s" % format(my_profit, "+,"))
    out.append("果盘分红（别人亏钱的 10%%）: %s" % format(dividend, "+,"))
    out.append("最终净收益: %s" % format(net, "+,"))
    out.append("")
    out.append("-" * 60)
    out.append("📋 我拍到的场次明细")
    out.append("-" * 60)
    if won:
        for r in won:
            out.append(
                "第%s场  时间 %s  收益 %s  备注 %s"
                % (r["no"], r["time"], format(r["profit"] or 0, "+,"), r["note"] or "无")
            )
    else:
        out.append("（无）")
    out.append("")
    out.append("-" * 60)
    out.append("🍉 果盘分红来源场次")
    out.append("-" * 60)
    div_rows = [r for r in lost if (r["my_income"] or 0) > 0]
    if div_rows:
        for r in div_rows:
            out.append(
                "第%s场  时间 %s  玩家 %s  赢家收益 %s → 分红 %s"
                % (
                    r["no"],
                    r["time"],
                    r["winner"] or "?",
                    format(r["profit"] or 0, "+,"),
                    format(r["my_income"] or 0, "+,"),
                )
            )
    else:
        out.append("（无）")
    out.append("")
    out.append(
        "✅ 结论：总盈利 %s" % format(net, "+,")
        if net > 0
        else ("❌ 结论：总亏损 %s" % format(net, "+,") if net < 0 else "➖ 结论：收支平衡")
    )
    data["summary"] = {"text": "\n".join(out), "hits": []}

    def _section(key, title, sel, tag):
        o = ["=" * 60, title, "=" * 60, "命中场次: %d" % len(sel), ""]
        if not sel:
            o.append("（无）")
        for r in sel:
            o.append(
                "第%s场  时间 %s  结果 %s  玩家 %s  最高估价 %s  成交价 %s  实际价值 %s  收益 %s  净收益 %s  备注 %s"
                % (
                    r["no"],
                    r["time"],
                    r["result"],
                    r["winner"] or "（无）",
                    format(r["max_est"] or 0, ","),
                    format(r["final_price"] or 0, ","),
                    format(r["actual_value"] or 0, ","),
                    format(r["profit"] or 0, "+,"),
                    format(r["net"] or 0, "+,"),
                    r["note"] or "无",
                )
            )
            if r["max_opp"]:
                o.append("         对手最高出价 %s" % format(r["max_opp"], ","))
            try:
                if (r["actual_value"] or 0) > 0 and (r["max_est"] or 0) > 0:
                    o.append(
                        "         实际价值 ÷ 估价 = %.2f 倍（估价 %s ／ 实际 %s）"
                        % (
                            r["actual_value"] / float(r["max_est"]),
                            format(r["max_est"], ","),
                            format(r["actual_value"], ","),
                        )
                    )
            except Exception:
                pass
        data[key] = {"text": "\n".join(o), "hits": [(tag, r) for r in sel]}

    GAP_RATIO = 3.0
    _section(
        "gap",
        "📊 信息差大仓（实际价值 ≥ 估价 × %.1f 倍）" % GAP_RATIO,
        [
            r
            for r in recs
            if (r["actual_value"] or 0) > 0
            and (r["max_est"] or 0) > 0
            and r["actual_value"] >= r["max_est"] * GAP_RATIO
        ],
        "信息差",
    )
    _section(
        "estimate",
        "📊 估价 > %s 的对局" % format(threshold, ","),
        [r for r in recs if (r["max_est"] or 0) > threshold],
        "估价",
    )
    _section("win", "📊 我拍到的【盈利】对局", [r for r in won if (r["profit"] or 0) > 0], "我拍到")
    _section(
        "lose", "📊 我拍到的【亏损】对局", [r for r in won if (r["profit"] or 0) < 0], "我拍到"
    )
    _section(
        "value_high",
        "📊 结算价值（实际价值）> %s 的高价值对局" % format(threshold, ","),
        [r for r in recs if (r["actual_value"] or 0) > threshold],
        "高价值",
    )
    return data


def find_settlement_shot(day, no, when="", used=None):
    day8 = day.replace("-", "")
    used = used if used is not None else set()
    try:
        ref = datetime.datetime.strptime(when, "%Y-%m-%d %H:%M:%S")
    except Exception:
        ref = None
    TIME_OK = 600

    def _ts_of(path):
        m = re.search(r"(\d{8})_(\d{6})", os.path.basename(path))
        if not m:
            return None
        try:
            return datetime.datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        except Exception:
            return None

    def _pick(cands):
        cands = [p for p in cands if p not in used]
        if not cands:
            return None
        if ref is None:
            return None
        best, bestd = None, None
        for p in cands:
            t = _ts_of(p)
            if t is None:
                continue
            d = abs((ref - t).total_seconds())
            if d > TIME_OK:
                continue
            if bestd is None or d < bestd:
                best, bestd = p, d
        return best

    try:
        cands = []
        for p in glob.glob(os.path.join(ANA_SHOT_ROOT, "**", "*"), recursive=True):
            base = os.path.basename(p)
            m = re.match(r"a(\d+)_", base)
            if m and int(m.group(1)) == int(no) and day8 in base:
                cands.append(p)
        hit = _pick(cands)
        if hit:
            return hit
    except Exception:
        pass
    cands2 = []
    for root in (os.path.join(REC, "截图"), SHOT_ROOT):
        try:
            for p in glob.glob(os.path.join(root, "**", "*"), recursive=True):
                base = os.path.basename(p)
                m = re.search(r"_a(\d+)_settlement", base)
                if m and int(m.group(1)) == int(no) and day8 in base:
                    cands2.append(p)
        except Exception:
            pass
    hit2 = _pick(cands2)
    if hit2:
        return hit2
    if ref is None:
        return None
    best, bestd = None, 10**6
    for root in (SHOT_ROOT, os.path.join(REC, "截图")):
        try:
            for p in glob.glob(os.path.join(root, "**", "*"), recursive=True):
                if p in used:
                    continue
                base = os.path.basename(p)
                if "settlement" not in base.lower():
                    continue
                if re.search(r"a\d+_", base):
                    continue
                if day8 not in base:
                    continue
                t = _ts_of(p)
                if t is None:
                    continue
                d = (ref - t).total_seconds()
                if -150 <= d <= 30 and abs(d) < bestd:
                    best, bestd = p, abs(d)
        except Exception:
            pass
    return best


GAME_TITLE_KEYWORD = "异环"
OWN_TITLE_KEYWORDS = (
    "EvilNte",
    "控制面板",
    "NTE Control Panel",
    "NTE Selftest",
    "NTE Report",
    "NTE Instant Auction",
    "NTE Console",
    "面板错误",
    "即可落槌",
)


def is_own_title(title):
    t = title or ""
    return any(k in t for k in OWN_TITLE_KEYWORDS)


def game_hwnd():
    import win32gui

    best, best_area = None, -1
    try:
        import pygetwindow as gw

        candidates = gw.getWindowsWithTitle(GAME_TITLE_KEYWORD)
    except Exception:
        candidates = []
    for w in candidates:
        if is_own_title(getattr(w, "title", "")):
            continue
        try:
            h = w._hWnd
            r = win32gui.GetClientRect(h)
            area = int(r[2]) * int(r[3])
        except Exception:
            area = int(getattr(w, "width", 0)) * int(getattr(w, "height", 0))
        if area > best_area:
            best, best_area = h, area
    return best


def 游戏提窗口(timeout=6.0):
    import time as _t
    import win32api
    import win32con
    import win32gui
    import win32process

    deadline = _t.time() + timeout
    hwnd = game_hwnd()
    while hwnd is None and _t.time() < deadline:
        _t.sleep(0.4)
        hwnd = game_hwnd()
    if hwnd is None:
        return False, "没找到游戏窗口（标题里要含「%s」）" % GAME_TITLE_KEYWORD
    try:
        if win32gui.GetForegroundWindow() == hwnd:
            return True, "游戏窗口已经在最前面"
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            _t.sleep(0.3)
        win32api.keybd_event(win32con.VK_MENU, 0, 0, 0)
        win32api.keybd_event(win32con.VK_MENU, 0, win32con.KEYEVENTF_KEYUP, 0)
        win32gui.SetForegroundWindow(hwnd)
        if win32gui.GetForegroundWindow() == hwnd:
            return True, "已把游戏窗口抓到最前面"
        fg = win32gui.GetForegroundWindow()
        try:
            tid_fg = win32process.GetWindowThreadProcessId(fg)[0]
            tid_me = win32api.GetCurrentThreadId()
            win32process.AttachThreadInput(tid_fg, tid_me, True)
            win32gui.BringWindowToTop(hwnd)
            win32gui.SetForegroundWindow(hwnd)
            win32process.AttachThreadInput(tid_fg, tid_me, False)
        except Exception:
            pass
    except Exception as e:
        return False, "抓前台失败：%s" % e
    for _ in range(12):
        if win32gui.GetForegroundWindow() == hwnd:
            return True, "已把游戏窗口抓到最前面"
        _t.sleep(0.05)
    return False, "系统不让程序抢前台，请手动点一下游戏画面"


# ---------- 配色主题：爱音（粉白）/ 白 / 黑 ----------
# 三套主题共用下面同一份 QSS 模板，只换 $ 开头的颜色变量，
# 这样加一套主题不用复制整份样式表，也不会漏改某一条规则。
ANON = {
    "bg": "#fdf6f9",
    "fg": "#3d2b36",
    "side_bg": "#ffffff",
    "side_border": "#f3d7e6",
    "logo_fg": "#d9658f",
    "logo_sub_fg": "#c9a2b5",
    "nav_foot_fg": "#c4b1bb",
    "sep_bg": "#f7e3ec",
    "nav_fg": "#a08b98",
    "nav_hover_fg": "#d9658f",
    "nav_hover_bg": "#fff2f8",
    "nav_sel_fg": "#d9658f",
    "nav_sel_bg": "#fbe9f1",
    "nav_sel_bar": "#d9658f",
    "card_bg": "#ffffff",
    "card_border": "#f3d7e6",
    "card_title": "#b98ea5",
    "card_fg": "#5c4450",
    "stat_bg": "#fdf3f8",
    "stat_border": "#f9e2ee",
    "btn_bg": "#ffffff",
    "btn_border": "#f0d3e2",
    "btn_fg": "#4a3641",
    "btn_hover_bg": "#fff2f8",
    "btn_hover_border": "#e9bcd2",
    "btn_press_bg": "#fde8f2",
    "btn_checked_bg": "#d9658f",
    "btn_checked_hover": "#c85a82",
    "btn_dis_fg": "#c4b1bb",
    "btn_dis_bg": "#fdf4f8",
    "btn_dis_border": "#f6e6ef",
    "primary": "#d9658f",
    "primary_hover": "#c85a82",
    "primary_press": "#a94a6f",
    "danger": "#e8697a",
    "danger_hover": "#d4576a",
    "accent": "#7f9cbf",
    "accent_hover": "#6d89ad",
    "cfgall_bg": "#fdf2f8",
    "cfgall_border": "#f3d7e6",
    "cfgall_fg": "#b4548a",
    "cfgall_hover_bg": "#fce7f3",
    "cfgall_hover_border": "#f0bcd6",
    "gear_bg": "#fff6fa",
    "gear_border": "#f0d3e2",
    "gear_fg": "#c9a2b5",
    "gear_hover_fg": "#d9658f",
    "gear_hover_bg": "#fde8f2",
    "gear_press_bg": "#fbd5e8",
    "hint_fg": "#a68e9b",
    "big_fg": "#3d2b36",
    "cap_fg": "#ad96a2",
    "pick_bg": "#ffffff",
    "pick_border": "#f3d7e6",
    "pick_bar": "#e895b4",
    "pick_title": "#c85a82",
    "pick_sub": "#a68e9b",
    "cfghead_bg": "#fdf2f8",
    "cfghead_fg": "#c85a82",
    "cfghead_bar": "#e895b4",
    "ladder_bg": "#f0fdfa",
    "ladder_fg": "#0f766e",
    "ladder_bar": "#14b8a6",
    "anahead_bg": "#fdf2f8",
    "anahead_fg": "#c85a82",
    "anahead_bar": "#e895b4",
    "warn_fg": "#e11d48",
    "fix_fg": "#059669",
    "fix_bg": "#ecfdf5",
    "fix_bar": "#16a34a",
    "input_bg": "#ffffff",
    "input_fg": "#3d2b36",
    "input_border": "#f0d3e2",
    "input_hover_border": "#e9bcd2",
    "input_focus_border": "#e895b4",
    "input_focus_bg": "#fffafd",
    "spin_bg": "#fde8f2",
    "spin_hover_bg": "#fbdcec",
    "combo_sel_bg": "#fbe9f1",
    "combo_sel_fg": "#a94a6f",
    "check_fg": "#5c4450",
    "log_bg": "#ffffff",
    "log_fg": "#5c4450",
    "log_border": "#f3d7e6",
    "list_bg": "#ffffff",
    "list_border": "#f3d7e6",
    "list_hover_bg": "#fff2f8",
    "list_sel_bg": "#fbe9f1",
    "list_sel_fg": "#a94a6f",
    "scroll": "#f0d4e2",
    "scroll_hover": "#e3bcd0",
    "tip_bg": "#3d2b36",
    "tip_fg": "#ffffff",
    "status_fg": "#a68e9b",
    "menu_bg": "#ffffff",
    "menu_fg": "#3d2b36",
    "menu_border": "#f0d3e2",
    "menu_sel_bg": "#fbe9f1",
    "menu_sel_fg": "#a94a6f",
    "warn_strong": "#b45309",
    "muted": "#b3a0aa",
    "up": "#059669",
    "down": "#dc2626",
    # 勾选按钮的字色、原来 #blue 按钮的底色（抽成变量后每套主题各自决定实心还是描边）
    "btn_checked_fg": "#ffffff",
    "btn_alt_bg": "#7f9cbf",
    "btn_alt_fg": "#ffffff",
    "btn_alt_border": "#7f9cbf",
    "btn_alt_hover_bg": "#6d89ad",
    "btn_alt_hover_border": "#6d89ad",
}

LIGHT = {
    "bg": "#f6f7f9",
    "fg": "#1f2937",
    "side_bg": "#ffffff",
    "side_border": "#e6e9ef",
    "logo_fg": "#111827",
    "logo_sub_fg": "#9aa3b2",
    "nav_foot_fg": "#b4bcc8",
    "sep_bg": "#eef1f5",
    "nav_fg": "#6b7280",
    "nav_hover_fg": "#111827",
    "nav_hover_bg": "#f2f4f7",
    "nav_sel_fg": "#2563eb",
    "nav_sel_bg": "#eef4ff",
    "nav_sel_bar": "#2563eb",
    "card_bg": "#ffffff",
    "card_border": "#e6e9ef",
    "card_title": "#8a94a6",
    "card_fg": "#374151",
    "stat_bg": "#f9fafb",
    "stat_border": "#eceff4",
    "btn_bg": "#ffffff",
    "btn_border": "#dfe3ea",
    "btn_fg": "#374151",
    "btn_hover_bg": "#f7f9fc",
    "btn_hover_border": "#cbd3de",
    "btn_press_bg": "#eef1f6",
    "btn_checked_bg": "#2563eb",
    "btn_checked_hover": "#1d4ed8",
    "btn_dis_fg": "#b9c0cb",
    "btn_dis_bg": "#fafbfc",
    "btn_dis_border": "#eceff4",
    "primary": "#2563eb",
    "primary_hover": "#1d4ed8",
    "primary_press": "#1e40af",
    "danger": "#ef4444",
    "danger_hover": "#dc2626",
    "accent": "#6366f1",
    "accent_hover": "#4f46e5",
    "cfgall_bg": "#f2f4f7",
    "cfgall_border": "#e6e9ef",
    "cfgall_fg": "#5b6472",
    "cfgall_hover_bg": "#e9edf3",
    "cfgall_hover_border": "#d3dae4",
    "gear_bg": "#f9fafb",
    "gear_border": "#dfe3ea",
    "gear_fg": "#9aa3b2",
    "gear_hover_fg": "#2563eb",
    "gear_hover_bg": "#eef4ff",
    "gear_press_bg": "#e2ebff",
    "hint_fg": "#6b7280",
    "big_fg": "#111827",
    "cap_fg": "#8a94a6",
    "pick_bg": "#ffffff",
    "pick_border": "#e6e9ef",
    "pick_bar": "#2563eb",
    "pick_title": "#2563eb",
    "pick_sub": "#8a94a6",
    "cfghead_bg": "#f1f5fb",
    "cfghead_fg": "#1d4ed8",
    "cfghead_bar": "#3b82f6",
    "ladder_bg": "#f0fdfa",
    "ladder_fg": "#0f766e",
    "ladder_bar": "#14b8a6",
    "anahead_bg": "#f1f5fb",
    "anahead_fg": "#1d4ed8",
    "anahead_bar": "#3b82f6",
    "warn_fg": "#dc2626",
    "fix_fg": "#059669",
    "fix_bg": "#ecfdf5",
    "fix_bar": "#16a34a",
    "input_bg": "#ffffff",
    "input_fg": "#111827",
    "input_border": "#dfe3ea",
    "input_hover_border": "#cbd3de",
    "input_focus_border": "#2563eb",
    "input_focus_bg": "#ffffff",
    "spin_bg": "#f2f4f7",
    "spin_hover_bg": "#e6e9ef",
    "combo_sel_bg": "#eef4ff",
    "combo_sel_fg": "#1d4ed8",
    "check_fg": "#374151",
    "log_bg": "#ffffff",
    "log_fg": "#374151",
    "log_border": "#e6e9ef",
    "list_bg": "#ffffff",
    "list_border": "#e6e9ef",
    "list_hover_bg": "#f7f9fc",
    "list_sel_bg": "#eef4ff",
    "list_sel_fg": "#1d4ed8",
    "scroll": "#cdd4df",
    "scroll_hover": "#b3bccb",
    "tip_bg": "#111827",
    "tip_fg": "#ffffff",
    "status_fg": "#8a94a6",
    "menu_bg": "#ffffff",
    "menu_fg": "#111827",
    "menu_border": "#e6e9ef",
    "menu_sel_bg": "#eef4ff",
    "menu_sel_fg": "#1d4ed8",
    "warn_strong": "#b45309",
    "muted": "#9aa3b2",
    "up": "#059669",
    "down": "#dc2626",
    "btn_checked_fg": "#ffffff",
    "btn_alt_bg": "#6366f1",
    "btn_alt_fg": "#ffffff",
    "btn_alt_border": "#6366f1",
    "btn_alt_hover_bg": "#4f46e5",
    "btn_alt_hover_border": "#4f46e5",
}

DARK = {
    "bg": "#0d1016",
    "fg": "#e6e9ef",
    "side_bg": "#11141b",
    "side_border": "#1e2330",
    "logo_fg": "#22d3ee",
    "logo_sub_fg": "#525b6b",
    "nav_foot_fg": "#454d5c",
    "sep_bg": "#1e2431",
    "nav_fg": "#7c8698",
    "nav_hover_fg": "#c3ccda",
    "nav_hover_bg": "#151a23",
    "nav_sel_fg": "#22d3ee",
    "nav_sel_bg": "#161b25",
    "nav_sel_bar": "#22d3ee",
    "card_bg": "#151a23",
    "card_border": "#232b39",
    "card_title": "#8f9aac",
    "card_fg": "#c3ccda",
    "stat_bg": "#1b2029",
    "stat_border": "#262d3a",
    "btn_bg": "#1c222d",
    "btn_border": "#2b3340",
    "btn_fg": "#dfe5ee",
    "btn_hover_bg": "#232a37",
    "btn_hover_border": "#39424f",
    "btn_press_bg": "#171c25",
    "btn_checked_bg": "#0891b2",
    "btn_checked_hover": "#0e7490",
    "btn_dis_fg": "#5c6474",
    "btn_dis_bg": "#181c24",
    "btn_dis_border": "#242833",
    "primary": "#16a34a",
    "primary_hover": "#15803d",
    "primary_press": "#166534",
    "danger": "#dc2626",
    "danger_hover": "#b91c1c",
    "accent": "#0891b2",
    "accent_hover": "#0e7490",
    "cfgall_bg": "#1c222d",
    "cfgall_border": "#2b3340",
    "cfgall_fg": "#9fb0c4",
    "cfgall_hover_bg": "#232a37",
    "cfgall_hover_border": "#39424f",
    "gear_bg": "#161b24",
    "gear_border": "#2b3340",
    "gear_fg": "#7c8698",
    "gear_hover_fg": "#22d3ee",
    "gear_hover_bg": "#1b2230",
    "gear_press_bg": "#141923",
    "hint_fg": "#8b93a3",
    "big_fg": "#eef2f8",
    "cap_fg": "#8b93a3",
    "pick_bg": "#101d2b",
    "pick_border": "#1e3a52",
    "pick_bar": "#0891b2",
    "pick_title": "#22d3ee",
    "pick_sub": "#94a3b8",
    "cfghead_bg": "#161d28",
    "cfghead_fg": "#22d3ee",
    "cfghead_bar": "#0891b2",
    "ladder_bg": "#10241f",
    "ladder_fg": "#5eead4",
    "ladder_bar": "#0d9488",
    "anahead_bg": "#161d28",
    "anahead_fg": "#22d3ee",
    "anahead_bar": "#0891b2",
    "warn_fg": "#f87171",
    "fix_fg": "#86efac",
    "fix_bg": "#14261b",
    "fix_bar": "#16a34a",
    "input_bg": "#12151b",
    "input_fg": "#e6e9ef",
    "input_border": "#2b3340",
    "input_hover_border": "#39424f",
    "input_focus_border": "#0891b2",
    "input_focus_bg": "#141821",
    "spin_bg": "#1c222d",
    "spin_hover_bg": "#232a37",
    "combo_sel_bg": "#0891b2",
    "combo_sel_fg": "#ffffff",
    "check_fg": "#c3ccda",
    "log_bg": "#0a0d12",
    "log_fg": "#c3ccda",
    "log_border": "#232936",
    "list_bg": "#161a22",
    "list_border": "#232936",
    "list_hover_bg": "#232a37",
    "list_sel_bg": "#0e7490",
    "list_sel_fg": "#ffffff",
    "scroll": "#333a48",
    "scroll_hover": "#454e60",
    "tip_bg": "#e6e9ef",
    "tip_fg": "#111827",
    "status_fg": "#8b93a3",
    "menu_bg": "#161a22",
    "menu_fg": "#e6e9ef",
    "menu_border": "#2b3340",
    "menu_sel_bg": "#0891b2",
    "menu_sel_fg": "#ffffff",
    "warn_strong": "#f59e0b",
    "muted": "#5c6474",
    "up": "#34d399",
    "down": "#f87171",
    "btn_checked_fg": "#ffffff",
    "btn_alt_bg": "#0891b2",
    "btn_alt_fg": "#ffffff",
    "btn_alt_border": "#0891b2",
    "btn_alt_hover_bg": "#0e7490",
    "btn_alt_hover_border": "#0e7490",
}

# 「墨金」：暖黑底 + 落槌金。整套只用一个强调色，模拟拍卖行的账册气质。
# 和爱音版的区别不只是色相：卡片之间靠一档底色和一根发丝边分层，按钮只留一个实心。
LACQUER = {
    "bg": "#14110d",
    "fg": "#ece2cf",
    "side_bg": "#191510",
    "side_border": "#2b241b",
    "logo_fg": "#e3bd6b",
    "logo_sub_fg": "#7d6f58",
    "nav_foot_fg": "#6d6252",
    "sep_bg": "#2b241b",
    "nav_fg": "#8b7f6b",
    "nav_hover_fg": "#e6d6b2",
    "nav_hover_bg": "#221b13",
    "nav_sel_fg": "#e8c887",
    "nav_sel_bg": "#261f15",
    "nav_sel_bar": "#c9a24b",
    "card_bg": "#1d1814",
    "card_border": "#332b20",
    "card_title": "#a2937c",
    "card_fg": "#d9cdb6",
    "stat_bg": "#241e18",
    "stat_border": "#3a3125",
    "btn_bg": "#221c16",
    "btn_border": "#3a3126",
    "btn_fg": "#e5dac4",
    "btn_hover_bg": "#2b241b",
    "btn_hover_border": "#55452c",
    "btn_press_bg": "#1a1510",
    "btn_checked_bg": "#c9a24b",
    "btn_checked_hover": "#d9b45e",
    "btn_dis_fg": "#6d6252",
    "btn_dis_bg": "#191510",
    "btn_dis_border": "#2b241b",
    "primary": "#c9a24b",
    "primary_hover": "#d9b45e",
    "primary_press": "#ab8636",
    "danger": "#a8503f",
    "danger_hover": "#bf5f4b",
    "accent": "#6f8f79",
    "accent_hover": "#7fa189",
    "cfgall_bg": "#221c16",
    "cfgall_border": "#3a3126",
    "cfgall_fg": "#c0a77f",
    "cfgall_hover_bg": "#2b241b",
    "cfgall_hover_border": "#55452c",
    "gear_bg": "#221c16",
    "gear_border": "#3a3126",
    "gear_fg": "#8b7f6b",
    "gear_hover_fg": "#e3bd6b",
    "gear_hover_bg": "#261f15",
    "gear_press_bg": "#1a1510",
    "hint_fg": "#9a8d76",
    "big_fg": "#f6ecd8",
    "cap_fg": "#8a7d68",
    "pick_bg": "#1f1a15",
    "pick_border": "#3a3022",
    "pick_bar": "#c9a24b",
    "pick_title": "#e3bd6b",
    "pick_sub": "#9a8d76",
    "cfghead_bg": "#261f15",
    "cfghead_fg": "#e3bd6b",
    "cfghead_bar": "#c9a24b",
    "ladder_bg": "#17231e",
    "ladder_fg": "#9fcfb2",
    "ladder_bar": "#5c8f75",
    "anahead_bg": "#261f15",
    "anahead_fg": "#e3bd6b",
    "anahead_bar": "#c9a24b",
    "warn_fg": "#d99a5e",
    "fix_fg": "#8fbf8a",
    "fix_bg": "#17231c",
    "fix_bar": "#6f9c62",
    "input_bg": "#16120e",
    "input_fg": "#efe5d0",
    "input_border": "#3a3126",
    "input_hover_border": "#55452c",
    "input_focus_border": "#c9a24b",
    "input_focus_bg": "#1a1510",
    "spin_bg": "#2b241b",
    "spin_hover_bg": "#3a3126",
    "combo_sel_bg": "#3a2c18",
    "combo_sel_fg": "#f0dcb4",
    "check_fg": "#d9cdb6",
    "log_bg": "#100e0b",
    "log_fg": "#d9cdb6",
    "log_border": "#332b20",
    "list_bg": "#1b1612",
    "list_border": "#332b20",
    "list_hover_bg": "#2b241b",
    "list_sel_bg": "#3a2c18",
    "list_sel_fg": "#f0dcb4",
    "scroll": "#4a4033",
    "scroll_hover": "#6a5c48",
    "tip_bg": "#efe3c8",
    "tip_fg": "#1a1611",
    "status_fg": "#8a7d68",
    "menu_bg": "#1d1814",
    "menu_fg": "#ece2cf",
    "menu_border": "#3a3126",
    "menu_sel_bg": "#3a2c18",
    "menu_sel_fg": "#f0dcb4",
    "warn_strong": "#e0a86a",
    "muted": "#6d6252",
    "up": "#7fa86a",
    "down": "#c4675a",
    "btn_checked_fg": "#241c10",
    "btn_alt_bg": "transparent",
    "btn_alt_fg": "#c9a24b",
    "btn_alt_border": "#4a3d29",
    "btn_alt_hover_bg": "#261f15",
    "btn_alt_hover_border": "#c9a24b",
}

# ---- 大肥鱼standby：按用户提供的深色参考图重做一套主题 ----
OKNTE = dict(ANON, **{
    "bg": "#1b1f2a",            # 主背景（深蓝灰）
    "fg": "#d6dbe6",            # 主文字
    "side_bg": "#171b24",       # 侧栏
    "side_border": "#252b38",
    "logo_fg": "#e8eef8",
    "logo_sub_fg": "#7f8ba0",
    "nav_foot_fg": "#6b7688",
    "sep_bg": "#252b38",
    "nav_fg": "#96a1b4",
    "nav_hover_fg": "#e8eef8",
    "nav_hover_bg": "#20252f",
    "nav_sel_fg": "#22d3ee",     # 青色高亮
    "nav_sel_bg": "#1d2530",
    "nav_sel_bar": "#22d3ee",
    "card_bg": "#212734",        # 卡片
    "card_border": "#2b3340",
    "card_title": "#9fb0c6",
    "card_fg": "#cfd7e4",
    "stat_bg": "#1d2430",        # 统计小卡
    "stat_border": "#2b3340",
    "btn_bg": "#242b38",
    "btn_border": "#333c4c",
    "btn_fg": "#cfd7e4",
    "btn_hover_bg": "#2b3444",
    "btn_hover_border": "#3d4a5e",
    "btn_press_bg": "#202836",
    "btn_checked_bg": "#22d3ee",
    "btn_checked_fg": "#0d1117",
    "btn_checked_hover": "#16bcd4",
    "primary": "#22d3ee",
    "primary_hover": "#16bcd4",
    "primary_press": "#0e9fb5",
    "danger": "#e8697a",
    "danger_hover": "#d4576a",
    "btn_alt_bg": "#1f2836",
    "btn_alt_fg": "#8fd8e6",
    "btn_alt_border": "#2f4050",
    "btn_alt_hover_bg": "#243244",
    "btn_alt_hover_border": "#22d3ee",
    "hint_fg": "#7f8ba0",
    "big_fg": "#e8eef8",
    "cap_fg": "#7f8ba0",
    "pick_bg": "#212734",
    "pick_border": "#2b3340",
    "pick_bar": "#22d3ee",
    "pick_title": "#9fd9e6",
    "pick_sub": "#7f8ba0",
    "cfghead_bg": "#1d2430",
    "cfghead_fg": "#22d3ee",
    "cfghead_bar": "#22d3ee",
    "input_bg": "#191f29",
    "input_fg": "#d6dbe6",
    "input_border": "#2b3340",
    "input_hover_border": "#3a4656",
    "input_focus_border": "#22d3ee",
    "input_focus_bg": "#1d2430",
    "log_bg": "#171c25",
    "log_fg": "#c3cbd9",
    "log_border": "#2b3340",
    "list_bg": "#1b212c",
    "list_border": "#2b3340",
    "list_hover_bg": "#232b38",
    "list_sel_bg": "#1d2a36",
    "list_sel_fg": "#22d3ee",
    "check_fg": "#cfd7e4",
    "warn_fg": "#f0a0a8",
    "status_fg": "#7f8ba0",
    "tip_bg": "#2b3340",
    "tip_fg": "#e8eef8",
    "menu_bg": "#212734",
    "menu_fg": "#d6dbe6",
    "menu_border": "#2b3340",
    "menu_sel_bg": "#1d2a36",
    "menu_sel_fg": "#22d3ee",
    # 大肥鱼：下面这些键原来没覆盖，会从 ANON（粉白）继承过来 —— 在深色主题里
    # 表现为「白底粉字」的按钮/粉色滚动条，这次统一补成深色。
    "btn_dis_bg": "#1a2029",
    "btn_dis_border": "#2b3340",
    "cfgall_bg": "#1c222d",
    "cfgall_border": "#2b3340",
    "cfgall_hover_bg": "#232a37",
    "cfgall_hover_border": "#39424f",
    "combo_sel_bg": "#252e3c",
    "gear_border": "#2b3340",
    "gear_hover_bg": "#20252f",
    "gear_press_bg": "#161b24",
    "scroll": "#2b3340",
    "scroll_hover": "#3a4553",
    "spin_bg": "#1c222d",
    "spin_hover_bg": "#232a37",
    "anahead_bg": "#1b2230",
    "cfgall_fg": "#9fb0c4",
    "gear_fg": "#8b96aa",
    "anahead_fg": "#9fb0c4",
    "btn_dis_fg": "#6b7688",
    "combo_sel_fg": "#22d3ee",
})

THEME_LABELS = [("oknte", "大肥鱼"), ("anon", "小吱"), ("requiem", "安魂曲"),
                ("malice", "码丽丝"), ("killer", "杀手旋律"),
                ("shenyi", "神艺"), ("zhulei", "珠泪"),
                ("light", "白"), ("dark", "黑"), ("lacquer", "墨金")]
# ---- 安魂曲（黑红）：以 OKNTE 的结构为底，把主色换成血红 + 近黑底 ----
REQUIEM = dict(OKNTE)
REQUIEM.update({
    "bg": "#120d0d",
    "fg": "#f0e3e1",
    "side_bg": "#1a1211",
    "side_border": "#33201d",
    "logo_fg": "#ff5f52",
    "logo_sub_fg": "#8d6a66",
    "nav_foot_fg": "#7a5f5c",
    "sep_bg": "#2a1a18",
    "nav_fg": "#a98a86",
    "nav_hover_fg": "#ff8a7e",
    "nav_hover_bg": "#251614",
    "nav_sel_fg": "#ff6a5c",
    "nav_sel_bg": "#2c1815",
    "nav_sel_bar": "#e8392c",
    "card_bg": "#1b1412",
    "card_border": "#3a221e",
    "card_title": "#c08a84",
    "card_fg": "#ecdfdb",
    "stat_bg": "#221714",
    "stat_border": "#3a221e",
    "big_fg": "#f7ece9",
    "cap_fg": "#9b7a75",
    "hint_fg": "#9b7a75",
    "muted": "#8a6d68",
    "btn_bg": "#251816",
    "btn_border": "#402420",
    "btn_fg": "#f2e6e2",
    "btn_hover_bg": "#2f1d1a",
    "btn_hover_border": "#5c2b24",
    "btn_press_bg": "#1a100f",
    "btn_alt_bg": "#201513",
    "btn_alt_border": "#3a221e",
    "btn_alt_fg": "#e9dbd7",
    "btn_alt_hover_bg": "#2a1a17",
    "btn_alt_hover_border": "#5c2b24",
    "btn_checked_bg": "#e8392c",
    "btn_checked_fg": "#fff5f2",
    "btn_checked_hover": "#ff4f40",
    "btn_dis_bg": "#221816",
    "btn_dis_border": "#33201d",
    "btn_dis_fg": "#6f5652",
    "input_bg": "#1e1513",
    "input_border": "#3a221e",
    "input_fg": "#f0e3e1",
    "input_hover_border": "#6b2f28",
    "input_focus_border": "#e8392c",
    "input_focus_bg": "#241816",
    "spin_bg": "#201513",
    "spin_hover_bg": "#2a1a17",
    "check_fg": "#e9dbd7",
    "log_bg": "#140f0e",
    "log_fg": "#e6d3cf",
    "log_border": "#33201d",
    "list_bg": "#1a1211",
    "list_border": "#3a221e",
    "list_hover_bg": "#251614",
    "list_sel_bg": "#2c1815",
    "list_sel_fg": "#ff6a5c",
    "menu_bg": "#1b1412",
    "menu_border": "#3a221e",
    "menu_fg": "#e9dbd7",
    "menu_sel_bg": "#2c1815",
    "menu_sel_fg": "#ff6a5c",
    "combo_sel_bg": "#2c1815",
    "combo_sel_fg": "#ff6a5c",
    "primary": "#e8392c",
    "primary_hover": "#ff4f40",
    "primary_press": "#c22b20",
    "accent": "#ff5f52",
    "accent_hover": "#ff7a6e",
    "danger": "#ff5f52",
    "danger_hover": "#ff8579",
    "warn_fg": "#ffb4a8",
    "warn_strong": "#ff7a6e",
    "status_fg": "#e9dbd7",
    "scroll": "#3a221e",
    "scroll_hover": "#5c2b24",
    "gear_bg": "#1a1211",
    "gear_border": "#3a221e",
    "gear_fg": "#c08a84",
    "gear_hover_bg": "#251614",
    "gear_hover_fg": "#ff6a5c",
    "gear_press_bg": "#140f0e",
    "cfghead_bg": "#221714",
    "cfghead_bar": "#e8392c",
    "cfghead_fg": "#f0e3e1",
    "cfgall_bg": "#1e1513",
    "cfgall_border": "#3a221e",
    "cfgall_fg": "#e9dbd7",
    "cfgall_hover_bg": "#2a1a17",
    "cfgall_hover_border": "#5c2b24",
    "anahead_bg": "#221714",
    "anahead_bar": "#e8392c",
    "anahead_fg": "#f0e3e1",
    "ladder_bg": "#1e1513",
    "ladder_bar": "#e8392c",
    "ladder_fg": "#e9dbd7",
    "pick_bg": "#1e1513",
    "pick_border": "#3a221e",
    "pick_bar": "#e8392c",
    "pick_title": "#c08a84",
    "pick_sub": "#9b7a75",
    "fix_bg": "#1e1513",
    "fix_bar": "#e8392c",
    "fix_fg": "#efe3df",
    "tip_bg": "#241816",
    "tip_fg": "#f0e3e1",
})

# ---- 四个"图片主题"：都是浅色系，用统一生成器换主色，保证对比度一致 ----
def _light_variant(accent, bg, card, border, text, soft, title, sub):
    t = dict(ANON)
    t.update({
        "bg": bg, "fg": text,
        "side_bg": card, "side_border": border,
        "logo_fg": accent, "logo_sub_fg": sub, "nav_foot_fg": sub,
        "sep_bg": soft,
        "nav_fg": title, "nav_hover_fg": accent, "nav_hover_bg": soft,
        "nav_sel_fg": accent, "nav_sel_bg": soft, "nav_sel_bar": accent,
        "card_bg": card, "card_border": border, "card_title": title, "card_fg": text,
        "stat_bg": soft, "stat_border": border,
        "big_fg": text, "cap_fg": sub, "hint_fg": sub, "muted": sub,
        "btn_bg": card, "btn_border": border, "btn_fg": text, "btn_hover_bg": soft,
        "btn_hover_border": accent, "btn_alt_bg": soft, "btn_alt_border": border,
        "btn_alt_fg": text, "btn_alt_hover_bg": bg, "btn_alt_hover_border": accent,
        "btn_checked_bg": accent, "btn_checked_fg": "#ffffff", "btn_checked_hover": accent,
        "input_bg": card, "input_border": border, "input_fg": text,
        "input_hover_border": accent, "input_focus_border": accent, "input_focus_bg": bg,
        "spin_bg": soft, "spin_hover_bg": bg, "check_fg": text,
        "log_bg": bg, "log_fg": text, "log_border": border,
        "list_bg": card, "list_border": border, "list_hover_bg": soft,
        "list_sel_bg": soft, "list_sel_fg": accent,
        "menu_bg": card, "menu_border": border, "menu_fg": text,
        "menu_sel_bg": soft, "menu_sel_fg": accent,
        "combo_sel_bg": soft, "combo_sel_fg": accent,
        "primary": accent, "primary_hover": accent, "primary_press": accent,
        "accent": accent, "accent_hover": accent,
        "danger": "#d9484d", "danger_hover": "#e46166",
        "warn_fg": "#c07a2a", "warn_strong": "#a85f18", "status_fg": text,
        "scroll": border, "scroll_hover": accent,
        "gear_bg": card, "gear_border": border, "gear_fg": sub,
        "gear_hover_bg": soft, "gear_hover_fg": accent, "gear_press_bg": bg,
        "cfghead_bg": soft, "cfghead_bar": accent, "cfghead_fg": text,
        "cfgall_bg": card, "cfgall_border": border, "cfgall_fg": text,
        "cfgall_hover_bg": soft, "cfgall_hover_border": accent,
        "anahead_bg": soft, "anahead_bar": accent, "anahead_fg": text,
        "ladder_bg": card, "ladder_bar": accent, "ladder_fg": text,
        "pick_bg": card, "pick_border": border, "pick_bar": accent,
        "pick_title": title, "pick_sub": sub,
        "fix_bg": card, "fix_bar": accent, "fix_fg": text,
        "tip_bg": soft, "tip_fg": text,
    })
    return t


MALICE = _light_variant("#e0557f", "#fff5f8", "#ffffff", "#f7d6e2", "#4a2f3a",
                        "#ffedf4", "#b06a83", "#c08d9e")
KILLER = _light_variant("#0f9d8c", "#f1fbf9", "#ffffff", "#cfeee8", "#23413c",
                        "#e6f8f4", "#5f9c93", "#7dafa7")
SHENYI = _light_variant("#2f7fd6", "#f3f8ff", "#ffffff", "#d3e3f7", "#23384f",
                        "#e8f1ff", "#5e88b3", "#7d9dbc")
ZHULEI = _light_variant("#7a63d6", "#f6f4ff", "#ffffff", "#ddd6f7", "#322a4d",
                        "#efeaff", "#8672c4", "#9689c0")

THEME_COLORS = {"anon": ANON, "light": LIGHT, "dark": DARK, "lacquer": LACQUER,
                "oknte": OKNTE, "requiem": REQUIEM,
                "malice": MALICE, "killer": KILLER,
                "shenyi": SHENYI, "zhulei": ZHULEI}

QSS_TEMPLATE = """QWidget { font-family:"Microsoft YaHei UI","Microsoft YaHei",sans-serif; font-size:13px; color:$fg; }
QMainWindow, QDialog, QWidget#root, QWidget#body, QStackedWidget { background:$bg; }

/* ---------- 左侧导航 ---------- */
QWidget#side { background:$side_bg; border-right:1px solid $side_border; }
QLabel#logo { color:$logo_fg; font-size:19px; font-weight:700; letter-spacing:3px;
              background:transparent; }
QLabel#logoSub { color:$logo_sub_fg; font-size:10px; letter-spacing:1px;
                 background:transparent; }
QLabel#sideAvatar { background:transparent; border:2px solid $nav_sel_bar; border-radius:28px; }
QLabel#navFoot { color:$nav_foot_fg; font-size:11px; background:transparent; }
QFrame#sideSep { background:$sep_bg; border:none; }
QListWidget#nav { background:transparent; border:none; outline:0; padding:0; }
QListWidget#nav::item { color:$nav_fg; padding-left:14px; border-left:3px solid transparent;
                        border-radius:0 8px 8px 0; }
QListWidget#nav::item:hover { color:$nav_hover_fg; background:$nav_hover_bg; }
QListWidget#nav::item:selected { color:$nav_sel_fg; background:$nav_sel_bg;
                                 border-left:3px solid $nav_sel_bar; font-weight:600; }

/* ---------- 卡片 ---------- */
QGroupBox { background:$card_bg; border:1px solid $card_border; border-radius:12px;
            margin-top:0; padding:34px 18px 14px; font-weight:600; color:$card_fg; }
QGroupBox::title { subcontrol-origin: padding; subcontrol-position: top left;
                   left:18px; top:12px; padding:0; color:$card_title; font-weight:600;
                   letter-spacing:1px; }

QWidget#statCard { background:$stat_bg; border:1px solid $stat_border; border-radius:12px; }

/* ---------- 主页顶部大卡 ---------- */
QFrame#hero { background:$stat_bg; border:1px solid $card_border; border-radius:14px; }
QLabel#heroTag { color:$cap_fg; font-size:11px; letter-spacing:1px; }
QLabel#heroDot { color:$nav_sel_bar; font-size:10px; }
QLabel#heroState { color:$big_fg; font-size:30px; font-weight:700; letter-spacing:3px; }
QLabel#heroHint { color:$hint_fg; font-size:11px; }

/* ---------- 侧栏「工具与维护」 ---------- */
QPushButton#toolBtn { background:transparent; border:1px solid $btn_border; border-radius:9px;
                      padding:6px 8px; font-size:11px; color:$btn_fg; text-align:left; }
QPushButton#toolBtn:hover { border-color:$nav_sel_bar; color:$nav_sel_fg; }
QPushButton#toolBtn::menu-indicator { image:none; width:0; }

/* ---------- 主页「有问题反馈」 ---------- */
QPushButton#fbText { background:transparent; border:none; padding:0; font-size:11px;
                     color:$nav_sel_bar; }
QPushButton#fbText:hover { color:$primary; }
QDialog#qqDlg { background:$card_bg; }

/* ---------- 实时输出 ---------- */
QFrame#liveBox { background:$card_bg; border:1px solid $card_border; border-radius:12px; }
QPushButton#statBtn, QPushButton#miniBtn { padding:5px 12px; font-size:12px; border-radius:8px; }

/* ---------- 参数页的档位表 ---------- */
QFrame#tierCard { background:$card_bg; border:1px solid $card_border; border-radius:12px; }
QLabel#tierHead { color:$cap_fg; font-size:11px; letter-spacing:1px; }
QLabel#tierName { color:$card_fg; font-size:12px; font-weight:600; }
QLabel#liveTitle { color:$card_title; font-size:13px; font-weight:600; letter-spacing:1px; }
QPushButton#liveMore { background:transparent; border:none; padding:0; font-size:11px;
                       color:$nav_sel_bar; }
QPushButton#liveMore:hover { color:$primary; }
QPlainTextEdit#liveLog { background:transparent; border:none; padding:0;
                         font-family:"Consolas","Microsoft YaHei UI",monospace;
                         font-size:12px; color:$log_fg; }
QLabel#liveEmpty { color:$cap_fg; font-size:12px; }
QFrame#liveBar { background:$stat_bg; border:1px solid $card_border; border-radius:9px; }
QLabel#liveLast { color:$cap_fg; font-size:11px; }
QLabel#liveTag { color:$nav_sel_bar; font-size:10px; letter-spacing:1px; }

/* ---------- 按钮 ---------- */
QPushButton { background:$btn_bg; border:1px solid $btn_border; border-radius:9px;
              padding:9px 16px; font-size:14px; color:$btn_fg; }
QPushButton:hover { background:$btn_hover_bg; border-color:$btn_hover_border; }
QPushButton:pressed { background:$btn_press_bg; }
QPushButton:checked { background:$btn_checked_bg; color:$btn_checked_fg; border:1px solid $btn_checked_bg; font-weight:600; }
QPushButton:checked:hover { background:$btn_checked_hover; border-color:$btn_checked_hover; }
QPushButton:disabled { color:$btn_dis_fg; background:$btn_dis_bg; border-color:$btn_dis_border; }
QPushButton#primary { background:$primary; color:white; border:none; font-weight:600; }
QPushButton#primary:hover { background:$primary_hover; }
QPushButton#primary:pressed { background:$primary_press; }
QPushButton#danger { background:$danger; color:white; border:none; font-weight:600; }
QPushButton#danger:hover { background:$danger_hover; }
QPushButton#blue { background:$btn_alt_bg; color:$btn_alt_fg; border:1px solid $btn_alt_border; font-weight:600; }
QPushButton#blue:hover { background:$btn_alt_hover_bg; border-color:$btn_alt_hover_border; }
/* 左下角动图右边的齿轮设置按钮 */
QPushButton#cfgAll { background:$cfgall_bg; border:1px solid $cfgall_border; color:$cfgall_fg; }
QPushButton#cfgAll:hover { background:$cfgall_hover_bg; border-color:$cfgall_hover_border; }
QPushButton#gear { background:$gear_bg; border:1px solid $gear_border; border-radius:13px;
                   color:$gear_fg; font-size:15px; padding:0; font-weight:400; }
QPushButton#gear:hover { color:$gear_hover_fg; border-color:$gear_hover_fg; background:$gear_hover_bg; }
QPushButton#gear:pressed { background:$gear_press_bg; }

QLabel#hint { color:$hint_fg; font-size:12px; }
QLabel#big { font-size:19px; font-weight:700; color:$big_fg; }
QLabel#cap { color:$cap_fg; font-size:12px; }
QLabel#pageCrumb { color:$cap_fg; font-size:10px; letter-spacing:1px; }
QLabel#pageTitle { color:$big_fg; font-size:19px; font-weight:700; letter-spacing:2px; }
QFrame#pageRule { background:$nav_sel_bar; border:none; border-radius:1px; }
QLabel#pageDate { color:$cap_fg; font-size:10px; letter-spacing:1px; }
QLabel#pageClock { color:$fg; font-size:15px; font-weight:700;
                   font-family:"Consolas","Microsoft YaHei UI",monospace;
                   letter-spacing:1px; }

/* ---------- 参数页的说明块 / 分组 / 阶梯提示 ---------- */
QWidget#pickCard { background:$pick_bg; border:1px solid $pick_border;
                   border-left:4px solid $pick_bar; border-radius:10px; }
QLabel#pickTitle { color:$pick_title; border:none; background:transparent; }
QLabel#pickSub { color:$pick_sub; border:none; background:transparent; }
QPushButton#cfgHead { color:$cfghead_fg; background:$cfghead_bg; border:none;
                      border-left:4px solid $cfghead_bar; border-radius:6px;
                      padding:7px 10px; margin-top:12px; text-align:left; }
QLabel#cfgLadder { color:$ladder_fg; background:$ladder_bg;
                   border-left:4px solid $ladder_bar; border-radius:6px; padding:7px 10px; }
QFrame#cfgCard { background:$pick_bg; border:1px solid $pick_border; border-radius:10px; }
QFrame#cfgCard:hover { border:1px solid $cfghead_bar; }
QLabel#cfgName { color:$big_fg; border:none; background:transparent;
                 font-size:13px; font-weight:600; }
QLabel#cfgHint { color:$hint_fg; border:none; background:transparent; font-size:11px; }
QLabel#anaHead { color:$anahead_fg; background:$anahead_bg;
                 border-left:4px solid $anahead_bar; border-radius:6px; padding:7px 10px; }
QLabel#warnText { color:$warn_fg; font-size:12px; }
QLabel#fixText { color:$fix_fg; background:$fix_bg; border-left:5px solid $fix_bar;
                 padding:6px 8px; border-radius:6px; font-size:12px; }

/* ---------- 输入 ---------- */
QLineEdit, QComboBox, QSpinBox { border:1px solid $input_border; border-radius:8px; padding:6px 9px;
                       background:$input_bg; color:$input_fg; }
QLineEdit:hover, QComboBox:hover, QSpinBox:hover { border-color:$input_hover_border; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus { border:1px solid $input_focus_border; background:$input_focus_bg; }
QSpinBox::up-button, QSpinBox::down-button { width:18px; border:none; background:$spin_bg; }
QSpinBox::up-button { border-top-right-radius:8px; }
QSpinBox::down-button { border-bottom-right-radius:8px; }
QSpinBox::up-button:hover, QSpinBox::down-button:hover { background:$spin_hover_bg; }
QComboBox QAbstractItemView { border:1px solid $input_border; background:$input_bg; color:$input_fg;
                              selection-background-color:$combo_sel_bg; selection-color:$combo_sel_fg; outline:0; }
QCheckBox { color:$check_fg; spacing:8px; }

QPlainTextEdit { background:$log_bg; color:$log_fg; border:1px solid $log_border; border-radius:12px;
                 padding:11px; font-family:Consolas,"Microsoft YaHei UI",monospace; font-size:12px; }

QListWidget { background:$list_bg; border:1px solid $list_border; border-radius:12px; outline:0; }
QListWidget::item { padding:6px 8px; border-radius:6px; }
QListWidget::item:hover { background:$list_hover_bg; }
QListWidget::item:selected { background:$list_sel_bg; color:$list_sel_fg; }

QScrollArea { border:none; background:transparent; }
QScrollArea > QWidget > QWidget { background:transparent; }

QScrollBar:vertical { background:transparent; width:10px; margin:2px; }
QScrollBar::handle:vertical { background:$scroll; border-radius:5px; min-height:32px; }
QScrollBar::handle:vertical:hover { background:$scroll_hover; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background:transparent; }
QScrollBar:horizontal { background:transparent; height:10px; margin:2px; }
QScrollBar::handle:horizontal { background:$scroll; border-radius:5px; min-width:32px; }
QScrollBar::handle:horizontal:hover { background:$scroll_hover; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width:0; }
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal { background:transparent; }

QToolTip { background:$tip_bg; color:$tip_fg; border:none; padding:6px 8px; }
QStatusBar { background:$bg; color:$status_fg; }
QMenu { background:$menu_bg; color:$menu_fg; border:1px solid $menu_border; }
QMenu::item:selected { background:$menu_sel_bg; color:$menu_sel_fg; }

/* ---- 下拉框（放在最后，覆盖前面所有版本；箭头按主题选图） ---- */
QComboBox { border-radius:8px; padding-right:28px; }
QComboBox::drop-down { border:0px; width:22px; background:transparent; }
QComboBox::down-arrow { image:url("$chevron"); width:14px; height:9px; }
QComboBox QAbstractItemView, QComboBox QListView {
    background-color:$card_bg; border:1px solid $card_border; border-radius:8px;
    padding:6px; outline:0; color:$card_fg;
}
QComboBox QAbstractItemView::item, QComboBox QListView::item {
    min-height:32px; padding:6px 10px 6px 12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:hover { background:$nav_hover_bg; color:$nav_sel_fg; }
QComboBox QAbstractItemView::item:selected {
    background:$nav_sel_bg; border-left:3px solid $nav_sel_bar; color:$nav_sel_fg;
}

QPushButton#setNav {
    background:transparent; border:none; border-radius:0 8px 8px 0;
    color:$nav_fg; padding-left:14px; text-align:left; font-size:14px;
}
QPushButton#setNav:hover { color:$nav_sel_fg; background:$nav_hover_bg; }

/* ---------- 下拉框（收起态）---------- */
QComboBox {
    background:$input_bg; border:1px solid $input_border; border-radius:8px;
    padding:8px 10px 8px 12px; color:$input_fg; min-height:22px;
}
QComboBox:hover { border-color:$input_hover_border; }
QComboBox:focus { border-color:$input_focus_border; }
QComboBox::drop-down { subcontrol-origin:padding; subcontrol-position:center right;
                       width:26px; border:none; background:transparent; }
QComboBox::down-arrow { image:url("$chevron"); width:14px; height:9px; }

/* ---------- 下拉框（展开列表）---------- */
QComboBox QAbstractItemView {
    background:$card_bg; border:1px solid $card_border; border-radius:10px;
    color:$card_fg; outline:0; padding:6px;
    selection-background-color:$nav_sel_bg; selection-color:$nav_sel_fg;
}
QComboBox QAbstractItemView::item {
    min-height:34px; padding-left:12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:hover { background:$nav_hover_bg; color:$nav_sel_fg; }
QComboBox QAbstractItemView::item:selected {
    background:$nav_sel_bg; border-left:3px solid $nav_sel_bar; color:$nav_sel_fg;
}

/* ---------- 胶囊开关（用图片画，跟 ok-nte 一样有圆点）---------- */


/* ---- 下拉列表（强制覆盖，兼容不同 Qt 版本的选择器）---- */
QComboBox QAbstractItemView, QComboBox QListView {
    background-color:$card_bg; border:1px solid $card_border; border-radius:8px;
    padding:6px; outline:0;
}
QComboBox QAbstractItemView::item, QComboBox QListView::item {
    min-height:32px; padding:6px 10px 6px 12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:selected, QComboBox QListView::item:selected {
    background-color:#252e3c; border-left:3px solid #22d3ee; color:#22d3ee;
}
"""

THEME_EXTRA = {
    "anon": """
QWidget#body { background:qlineargradient(x1:0,y1:0,x2:0,y2:1,
                                           stop:0 #fdf6f9, stop:1 #f8e8f0); }
QLabel#cap { font-size:11px; }
QLabel#pageTitle { color:#b2497a; }
QWidget#statCard { background:#fdf3f8; border:1px solid #f8e5ee; border-radius:10px; }
QPushButton#primary { letter-spacing:1px; }
""",
    "lacquer": """
QLabel#big { font-size:22px; font-weight:700;
             font-family:"Georgia","Times New Roman","Microsoft YaHei UI",serif; }
QLabel#cap { font-size:11px; }
QGroupBox { border-radius:10px; }
QGroupBox::title { color:#b9a684; font-size:12px; letter-spacing:1px; }
QWidget#statCard { background:#28211a; border:1px solid #3d331f; border-radius:10px; }
QPushButton#primary { letter-spacing:1px; }
""",
}



# ---- 大肥鱼standby 追加样式（对齐 ok-nte：下拉框 / 胶囊开关 / 底部设置项）----
QSS_EXTRA_OKNTE = """
/* ---------- 大肥鱼：界面透明度滑条（仿 ok-nte 那条）---------- */
QSlider#uiTrans { min-height: 22px; }
QSlider#uiTrans::groove:horizontal {
    height: 3px; background: $card_border; border-radius: 2px;
}
QSlider#uiTrans::sub-page:horizontal {
    height: 3px; background: $primary; border-radius: 2px;
}
QSlider#uiTrans::add-page:horizontal {
    height: 3px; background: $card_border; border-radius: 2px;
}
QSlider#uiTrans::handle:horizontal {
    width: 13px; height: 13px; margin: -5px 0;
    border-radius: 7px; background: #22d3ee; border: 2px solid #0d1117;
}
QSlider#uiTrans::handle:horizontal:hover { background: $nav_sel_bar; }

/* ---------- 大肥鱼：窗口背景图（固定比例 · 居中裁剪）---------- */
/* 把主窗口/内容层的底色让出来，才能看到 paintEvent 里画的背景图 */
QMainWindow, QWidget#root, QWidget#body, QStackedWidget { background: transparent; }
QWidget#side { background: rgba(23, 27, 36, 214); }
QDialog { background: $bg; }
/* 底部「设置」：与左侧导航同一套观感 */
QPushButton#setNav {
    background:transparent; border:none; border-radius:0 8px 8px 0;
    color:$nav_fg; padding-left:14px; text-align:left; font-size:14px;
}
QPushButton#setNav:hover { color:$nav_sel_fg; background:$nav_hover_bg; }

/* ---------- 下拉框（收起态）---------- */
QComboBox {
    background:#232a36; border:1px solid #333c4c; border-radius:8px;
    padding:8px 10px 8px 12px; color:#d6dbe6; min-height:22px;
}
QComboBox:hover { border-color:$input_hover_border; }
QComboBox:focus { border-color:$input_focus_border; }
QComboBox::drop-down { subcontrol-origin:padding; subcontrol-position:center right;
                       width:26px; border:none; background:transparent; }
QComboBox::down-arrow { image:url("ui/chevron.png"); width:14px; height:9px; }

/* ---------- 下拉框（展开列表）---------- */
QComboBox QAbstractItemView {
    background:$card_bg; border:1px solid $card_border; border-radius:10px;
    color:#d6dbe6; outline:0; padding:6px;
    selection-background-color:$nav_sel_bg; selection-color:$nav_sel_fg;
}
QComboBox QAbstractItemView::item {
    min-height:34px; padding-left:12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:hover { background:$nav_hover_bg; color:$nav_sel_fg; }
QComboBox QAbstractItemView::item:selected {
    background:$nav_sel_bg; border-left:3px solid $nav_sel_bar; color:$nav_sel_fg;
}

/* ---------- 胶囊开关（用图片画，跟 ok-nte 一样有圆点）---------- */


/* ---- 下拉列表（强制覆盖，兼容不同 Qt 版本的选择器）---- */
QComboBox QAbstractItemView, QComboBox QListView {
    background-color:$card_bg; border:1px solid $card_border; border-radius:8px;
    padding:6px; outline:0;
}
QComboBox QAbstractItemView::item, QComboBox QListView::item {
    min-height:32px; padding:6px 10px 6px 12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:selected, QComboBox QListView::item:selected {
    background-color:#252e3c; border-left:3px solid #22d3ee; color:#22d3ee;
}
"""

QSS_BG_OKNTE = """
QMainWindow, QWidget#root, QWidget#body, QStackedWidget { background: transparent; }
/* 注意：QDialog 不能跟着透明 —— 它是独立顶层窗口，透明后会显示成黑色/透出桌面。
   对话框永远保持不透明底色（用主题的 $bg）。 */
"""


def build_qss(theme="anon", font_size=13, trans=0.0):
    """按主题 + 字号 + 界面透明度生成样式表；未知主题一律按爱音处理。

    trans：0 = 完全不透明（默认，和以前一模一样），1 = 完全透明（只剩文字和边线）。
    「圈起来的面板」——侧栏 / 主页大卡 / 数据概览 / 实时输出 / 快捷设置 / 统计小卡
    会按这个值变成半透明，底下的窗口背景图就透出来。
    """
    colors = THEME_COLORS.get(str(theme or "oknte")) or OKNTE
    css = QSS_TEMPLATE
    # 注意：$变量 的替换统一放在函数最后（后面追加的 THEME_EXTRA / QSS_EXTRA_OKNTE
    # 里也有 $bg / $nav_sel_fg / $chevron 这些占位符，早替换会漏掉它们 →
    # 表现就是"设置窗口黑底、下拉没箭头、按钮样式错乱"。
    # 主题专属的追加段：不改上面那份模板，旧主题就一点都不受影响
    css += THEME_EXTRA.get(str(theme or "anon"), "")
    css += globals().get("QSS_EXTRA_OKNTE", "")   # 大肥鱼standby 追加样式
    if str(theme or "anon") in ("oknte", "anon", "requiem", "malice",
                                "killer", "shenyi", "zhulei"):
        # 有背景图的主题（大肥鱼 / 小吱）才把内容层让出来；别的主题保持纯色底
        css += globals().get("QSS_BG_OKNTE", "")
    if str(theme or "anon") == "requiem":
        # 安魂曲是黑红主题：卡片压一点透明，背景图才透得出来
        css += """
QWidget#side { background: rgba(26,18,17,180); }
QFrame#hero, QFrame#liveBox, QFrame#liveBar { background: rgba(27,20,18,188); }
QWidget#statCard { background: rgba(27,20,18,180); }
QGroupBox { background: rgba(27,20,18,180); }
QFrame#tierCard { background: rgba(27,20,18,180); }
"""
    if str(theme or "anon") in ("anon", "malice", "killer", "shenyi", "zhulei"):
        # 浅色图片主题：卡片给一点底座透明，背景图才透得出来。
        # 这四张新底图比小吱那张亮得多，所以单独给更高的不透明度，保证字看得清。
        _bright = str(theme or "anon") in ("malice", "killer", "shenyi", "zhulei")
        _a1, _a2 = (196, 204) if _bright else (170, 178)
        css += """
QWidget#side { background: rgba(255,255,255,%d); }
QFrame#hero, QFrame#liveBox, QFrame#liveBar { background: rgba(255,255,255,%d); }
QWidget#statCard { background: rgba(255,255,255,%d); }
QGroupBox { background: rgba(255,255,255,%d); }
QFrame#tierCard { background: rgba(255,255,255,%d); }
""" % (_a1, _a2, _a1, _a1, _a1)
    try:
        base = float(font_size)
    except Exception:
        base = 13.0
    try:
        _t = max(0.0, min(1.0, float(trans)))
    except Exception:
        _t = 0.0
    _translucent_theme = str(theme or "anon") in ("anon", "requiem", "malice",
                                                  "killer", "shenyi", "zhulei")   # 小吱是浅色，卡片本身半透明
    if _t <= 0.002 and not _translucent_theme:
        # 不透明模式：把滚动内容压成实心底，Qt 才能整块 blit 平移（滚动 33ms/帧 → 6ms/帧）。
        # 有背景图的主题不能这么干，否则背景图会被这层实心底盖死（小吱尤其明显）。
        css += """
QScrollArea > QWidget > QWidget { background: $bg; }
"""
    if _t > 0.002:
        _a = int(round((1.0 - _t) * 255))

        def _rgba(key, alpha=_a, key_bg=None):
            h = str(colors.get(key_bg or key) or "#000000").lstrip("#")
            try:
                r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
            except Exception:
                r, g, b = 0, 0, 0
            return "rgba(%d,%d,%d,%d)" % (r, g, b, alpha)

        css += """
/* ---------- 界面透明度（设置里的滑条）---------- */
QWidget#side { background: %s; }
QFrame#hero { background: %s; }
QFrame#liveBox { background: %s; }
QFrame#liveBar { background: %s; }
QWidget#statCard { background: %s; }
QGroupBox { background: %s; }
QFrame#tierCard { background: %s; }
QWidget#pickCard, QFrame#cfgCard { background: %s; }
QPushButton#cfgHead { background: %s; }
QLabel#cfgLadder { background: %s; }
""" % (
            _rgba("side_bg"),
            _rgba("stat_bg"),
            _rgba("card_bg"),
            _rgba("stat_bg"),
            _rgba("stat_bg"),
            _rgba("card_bg"),
            _rgba("card_bg"),
            _rgba("pick_bg"),
            _rgba("cfghead_bg"),
            _rgba("ladder_bg"),
        )
    # 下拉框：放在最最后，覆盖前面所有硬编码深色版本（浅色主题才不会黑底）
    css += """
QComboBox { border-radius:8px; padding-right:28px; }
QComboBox::drop-down { border:0px; width:22px; background:transparent; }
QComboBox::down-arrow { image:url("$chevron"); width:14px; height:9px; }
QComboBox QAbstractItemView, QComboBox QListView {
    background-color:$card_bg; border:1px solid $card_border; border-radius:8px;
    padding:6px; outline:0; color:$card_fg;
}
QComboBox QAbstractItemView::item, QComboBox QListView::item {
    min-height:32px; padding:6px 10px 6px 12px; border-radius:6px;
    border-left:3px solid transparent; color:$card_fg;
}
QComboBox QAbstractItemView::item:hover { background:$nav_hover_bg; color:$nav_sel_fg; }
QComboBox QAbstractItemView::item:selected {
    background:$nav_sel_bg; border-left:3px solid $nav_sel_bar; color:$nav_sel_fg;
}
"""
    # 下拉框：放在最最后（模板 + 主题追加段都在它前面），保证不被旧的深色规则盖住
    css += """
QComboBox { background:$input_bg; border:1px solid $input_border; border-radius:8px;
            padding:8px 12px 8px 12px; color:$input_fg; min-height:22px; }
QComboBox:hover { border-color:$input_hover_border; }
QComboBox:focus { border-color:$input_focus_border; }
QComboBox::drop-down { border:0px; width:22px; background:transparent; }
QComboBox::down-arrow { image:url("$chevron"); width:14px; height:9px; }
"""
    # ---- 统一替换主题变量（此时模板 + 主题追加段 + 透明度段都已拼好）----
    for _key in sorted(colors, key=len, reverse=True):
        css = css.replace("$" + _key, colors[_key])
    # 下拉箭头：浅色主题用深一点的图，深色主题用亮一点的图
    css = css.replace(
        "$chevron",
        "ui/chevron_light.png" if str(theme or "anon") in ("anon", "light") else "ui/chevron_dark.png",
    )
    factor = max(10.0, min(20.0, base)) / 13.0
    if abs(factor - 1.0) < 0.005:
        return css

    def _rep(m):
        return "font-size:%dpx" % max(9, int(round(int(m.group(1)) * factor)))

    return re.sub(r"font-size:\s*(\d+)px", _rep, css)


# ---------- 界面设置：分辨率 / 字号 ----------

UI_DEFAULTS = {
    "window_pos": [],            # 上次拖到的窗口位置 [x, y]
    "geometry": "自动（适配屏幕）",
    "font_size": 13,
    "theme": "oknte",
    # 界面透明度：0 = 完全不透明，1 = 完全透明（设置里可拖动调整）
    "ui_trans": 0.0,
    # 上次关面板时的窗口大小（[宽, 高]，逻辑像素）；空 = 用 geometry 里的预设。
    "window_size": [],
    # 启动时静默检查更新（只改按钮文案，不弹窗/不写日志）
    "auto_check_update": True,
    # 数据概览右下那个勾选框：勾上显示「净收益」（扣掉成本和仪器费），
    # 不勾显示「总盈利」（只算成交赚了多少）。两种口径都有人看。
    "show_net_income": False,
    # 上次弹过「更新说明」的版本号（新版本第一次打开只弹一次）
    "notes_version": "",
}

# 面板窗口大小。None = 按屏幕自动缩到放得下
RES_PRESETS = [
    ("自动（适配屏幕）", None),
    ("1024 × 740", (1024, 740)),
    ("1280 × 800", (1280, 800)),
    ("1366 × 768", (1366, 768)),
    ("1440 × 900", (1440, 900)),
    ("1600 × 900", (1600, 900)),
    ("1920 × 1080", (1920, 1080)),
]


def load_ui_cfg():
    cfg = dict(UI_DEFAULTS)
    try:
        if os.path.exists(UI_CFG_FILE):
            raw = json.loads(open(UI_CFG_FILE, encoding="utf-8").read())
            if isinstance(raw, dict):
                for key in UI_DEFAULTS:
                    if key in raw:
                        cfg[key] = raw[key]
    except Exception:
        pass
    try:
        cfg["font_size"] = int(round(float(cfg.get("font_size") or 13)))
    except Exception:
        cfg["font_size"] = 13
    cfg["font_size"] = max(10, min(20, cfg["font_size"]))
    if not any(label == cfg.get("geometry") for label, _ in RES_PRESETS):
        cfg["geometry"] = UI_DEFAULTS["geometry"]
    if cfg.get("theme") not in THEME_COLORS:
        cfg["theme"] = UI_DEFAULTS["theme"]
    try:
        _ws = cfg.get("window_size") or []
        if isinstance(_ws, (list, tuple)) and len(_ws) == 2:
            cfg["window_size"] = [int(_ws[0]), int(_ws[1])]
        else:
            cfg["window_size"] = []
    except Exception:
        cfg["window_size"] = []
    try:
        _wp = cfg.get("window_pos") or []
        if isinstance(_wp, (list, tuple)) and len(_wp) == 2:
            cfg["window_pos"] = [int(_wp[0]), int(_wp[1])]
        else:
            cfg["window_pos"] = []
    except Exception:
        cfg["window_pos"] = []
    return cfg


def save_ui_cfg(cfg):
    try:
        _ws = []
        try:
            _raw = cfg.get("window_size") or []
            if isinstance(_raw, (list, tuple)) and len(_raw) == 2:
                _ws = [int(_raw[0]), int(_raw[1])]
        except Exception:
            _ws = []
        _wp = []
        try:
            _rawp = cfg.get("window_pos") or []
            if isinstance(_rawp, (list, tuple)) and len(_rawp) == 2:
                _wp = [int(_rawp[0]), int(_rawp[1])]
        except Exception:
            _wp = []
        os.makedirs(os.path.dirname(UI_CFG_FILE), exist_ok=True)
        with open(UI_CFG_FILE, "w", encoding="utf-8") as fp:
            json.dump(
                {
                    "geometry": cfg.get("geometry", UI_DEFAULTS["geometry"]),
                    "font_size": int(cfg.get("font_size", 13)),
                    "theme": cfg.get("theme", UI_DEFAULTS["theme"]),
                    "show_net_income": bool(
                        cfg.get("show_net_income", UI_DEFAULTS["show_net_income"])
                    ),
                    "window_size": _ws,
                    "window_pos": _wp,
                    "ui_trans": float(cfg.get("ui_trans", 0.0) or 0.0),
                    "notes_version": str(cfg.get("notes_version") or ""),
                },
                fp,
                ensure_ascii=False,
                indent=2,
            )
    except Exception:
        pass


def resolve_geometry(name):
    """把设置里的分辨率换成实际窗口大小。

    预设写的是**物理像素**（用户心里的「1920 × 1080」就是屏幕上 1920 个点），
    但 Qt 在 HighDpi 下用的是逻辑像素，所以要按缩放比例换算回来：
        150% 缩放时选 1920×1080 → 窗口 1280×720 逻辑 → 渲染 1920×1080 物理。
    不换算的话，min(1920, 逻辑屏宽) 会把预设直接吃掉，窗口变成满屏。
    """
    size = None
    for label, preset in RES_PRESETS:
        if label == name:
            size = preset
            break
    scr = None
    dpr = 1.0
    try:
        _screen = QApplication.primaryScreen()
        scr = _screen.availableGeometry()
        dpr = float(_screen.devicePixelRatio() or 1.0)
    except Exception:
        scr = None
        dpr = 1.0
    if dpr <= 0:
        dpr = 1.0

    if size is None:  # 自动：默认给「大肥鱼standby」惯用的小窗，屏幕装不下再收
        if scr is not None:
            # 大肥鱼standby：默认 1150×815（比原来的 1360×880 小一圈，留出桌面空间）；
            # 记住过窗口大小的话，__init__ 里会优先用记住的那个。
            w = min(1150, max(980, int(round(scr.width() * 0.9))))
            h = min(815, max(680, int(round(scr.height() * 0.85))))
        else:
            w, h = 1150, 815
        return w, h

    w, h = size
    # 物理像素 → 逻辑像素
    w = int(round(w / dpr))
    h = int(round(h / dpr))
    if scr is not None:
        w = min(w, scr.width())
        h = min(h, scr.height())
    return max(900, w), max(620, h)


class Worker(QObject):
    done = pyqtSignal(str, bool)

    def __init__(self, fn):
        super().__init__()
        self.fn = fn
    # ---- 大肥鱼standby：弹窗单独设样式（全局 QSS 对 popup 不稳定）----
    POPUP_QSS = """
    QListView { background:#1d2430; border:1px solid #333c4c; border-radius:10px;
                padding:6px; outline:0; color:#d6dbe6; }
    QListView::item { min-height:32px; padding:6px 10px 6px 12px; border-radius:6px;
                      border-left:3px solid transparent; color:$card_fg; }
    QListView::item:hover { background:#232b38; color:#e8eef8; }
    QListView::item:selected { background:$nav_sel_bg; border-left:3px solid $nav_sel_bar; color:$nav_sel_fg; }
    """

    POPUP_QSS = """
    QListView { background:#1d2430; border:1px solid #333c4c; border-radius:8px;
                padding:6px; outline:0; }
    QListView::item { min-height:34px; padding-left:12px; border-radius:6px;
                      border-left:3px solid transparent; color:$card_fg; }
    QListView::item:hover { background:#232b38; color:#e8eef8; }
    QListView::item:selected { background:#252e3c; border-left:3px solid #22d3ee;
                               color:#22d3ee; }
    """

    def showPopup(self):  # noqa: N802
        try:
            from PyQt5.QtWidgets import QFrame
            v = self.view()
            v.setStyleSheet(self._popup_qss())
            v.setFrameShape(QFrame.NoFrame)
            v.setSpacing(0)
            v.setUniformItemSizes(False)
            win = v.window()
            win.setStyleSheet("QFrame{background:#1d2430;border:1px solid #333c4c;"
                              "border-radius:8px;}")
        except Exception:
            pass
        super().showPopup()

    def run(self):
        try:
            text, ok = self.fn()
        except Exception as e:
            text, ok = "执行失败：%s" % e, False
        self.done.emit(text, ok)


class ClickableLabel(QLabel):
    """能点的图片标签（hero 卡那张动图用）。"""

    clicked = pyqtSignal()

    def mouseReleaseEvent(self, event):
        try:
            if event.button() == Qt.LeftButton:
                self.clicked.emit()
        except Exception:
            pass
        super().mouseReleaseEvent(event)


def appended_log_lines(path, cursor=None, limit=128 * 1024):
    """Read new complete UTF-8 lines; cap initial/large reads to a tail window."""
    with open(path, "rb") as fp:
        st = os.fstat(fp.fileno())
        identity = (path, st.st_dev, st.st_ino)
        reset = cursor is None or cursor[0] != identity or cursor[1] > st.st_size
        offset = 0 if reset else cursor[1]
        if st.st_size - offset > limit:
            offset = st.st_size - limit
            fp.seek(offset - 1)
            if fp.read(1) != b"\n":
                fp.readline()
            offset = fp.tell()
            reset = True
        fp.seek(offset)
        data = fp.read(max(0, st.st_size - offset))
    cut = data.rfind(b"\n") + 1
    return (identity, offset + cut), reset, data[:cut].decode("utf-8", errors="replace").splitlines()


class Main(QMainWindow):
    _hotkey = pyqtSignal(str)
    _status_ready = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self.ui_cfg = load_ui_cfg()  # 界面设置：分辨率 / 字号
        self.setWindowTitle("大肥鱼standby")
        self._hotkey.connect(self._on_hotkey)
        self._status_ready.connect(self._apply_status_snapshot)
        self._status_busy = False
        self._status_running = False
        self._status_heartbeat = None
        self._workers = set()
        self._start_hotkey_poll()

        # 大肥鱼standby：窗口图标（exe 旁 assets\\icon.ico；没有就用打包内嵌的）
        try:
            from PyQt5.QtGui import QIcon
            _ic = None
            for _p in (os.path.join(getattr(sys, "_MEIPASS", BASE), "assets", "icon.ico"),
                       os.path.join(getattr(sys, "_MEIPASS", BASE), "assets", "icon.ico"),
                       os.path.join(SELF_DIR, "素材", "icon.ico")):
                if os.path.isfile(_p):
                    _ic = _p
                    break
            if _ic:
                self.setWindowIcon(QIcon(_ic))
        except Exception:
            pass
        self.setStyleSheet(build_qss(self.ui_cfg.get("theme"), self.ui_cfg["font_size"], self.ui_cfg.get("ui_trans", 0.0)))
        self._sync_widget_theme()
        self._refresh_bg()
        # 上次关面板时的窗口大小优先；没记住过就用默认（1150×815）。
        # 但如果用户在设置里选了具体分辨率，就必须按分辨率还原 ——
        # 否则 window_size 会把预设顶掉，表现就是「改了分辨率，重开还是老大小」。
        _saved_ws = self.ui_cfg.get("window_size") or []
        if str(self.ui_cfg.get("geometry", "")) != "自动（适配屏幕）":
            _saved_ws = []
        try:
            if isinstance(_saved_ws, (list, tuple)) and len(_saved_ws) == 2:
                self.resize(max(900, int(_saved_ws[0])), max(620, int(_saved_ws[1])))
            else:
                self.resize(*resolve_geometry(self.ui_cfg["geometry"]))
        except Exception:
            self.resize(*resolve_geometry(self.ui_cfg["geometry"]))
        # 上次拖到的位置：留到第一次 show 之后再还原
        #（Qt 在 show 时会按窗口管理器给的默认位置摆一次，在 __init__ 里 move 会被覆盖）
        try:
            _sp = self.ui_cfg.get("window_pos") or []
            self._saved_pos = [int(_sp[0]), int(_sp[1])] if (
                isinstance(_sp, (list, tuple)) and len(_sp) == 2) else []
        except Exception:
            self._saved_pos = []
        self._pos_ready = False
        self._apply_window_lock()
        self._repaired = repair_main_py()
        # ---- 大肥鱼：主窗口背景图（素材\背景.jpg），等比缩放居中裁剪，不变形 ----
        # 注意：这里不要再把 _bg_pixmap 置空 —— 上面 setStyleSheet 之后已经
        # 调过 self._refresh_bg() 把图加载好了；以前这里又 QPixmap() 清了一次，
        # 表现就是"每次重开脚本背景图都没了、要进设置保存一下才回来"。
        # 注意：绝对不要开 Qt.WA_OpaquePaintEvent ——
        # 实测 1400x1000 参数页：开了它滚动要 42ms/帧（Qt 只能整窗重画），
        # 不开是 7.5ms/帧。背景靠「烘焙缓存 + 只贴脏区」就够了。
        root = QWidget()
        root.setObjectName("root")
        outer = QHBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        outer.addWidget(self._make_side())
        self._apply_nav_scale()

        body = QWidget()
        body.setObjectName("body")
        bl = QVBoxLayout(body)
        bl.setContentsMargins(14, 4, 14, 8)
        bl.setSpacing(0)
        bl.addWidget(self._make_page_head())
        self.stack = QStackedWidget()
        for _fn in (
            self.tab_control,
            self.tab_config,
            self.tab_log,
            self.tab_shot,
            self.tab_report,
            self.tab_guopan,
            self.tab_assist,
            self.tab_vision,
        ):
            self.stack.addWidget(_fn())
        bl.addWidget(self.stack, 1)
        outer.addWidget(body, 1)

        self.setCentralWidget(root)
        self.nav.currentRowChanged.connect(self._on_nav)
        self.nav.setCurrentRow(0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.refresh_status)
        self.timer.start(5000)
        # 启动 2.5 秒后静默查一次更新（只改侧栏按钮文案，不打扰用户）
        try:
            QTimer.singleShot(2500, self._auto_check_update)
        except Exception:
            pass
        # 新版本第一次打开：弹一次「更新说明」，看过就记进界面设置
        try:
            QTimer.singleShot(1200, self._maybe_show_whats_new)
        except Exception:
            pass
        # 之后每 2 小时再静默查一次（面板常驻也不用自己记着重开）
        try:
            self._update_timer = QTimer(self)
            self._update_timer.timeout.connect(self._auto_check_update)
            self._update_timer.start(2 * 60 * 60 * 1000)
        except Exception:
            pass
        # 大肥鱼standby：每秒把挂机日志刷到「实时输出」
        self._live_size = -1
        self._live_timer = QTimer(self)
        self._live_timer.timeout.connect(self._refresh_live_log)
        self._live_timer.start(2500)
        QTimer.singleShot(0, self.refresh_status)
        self._apply_card_shadow()
        self._clock_timer = QTimer(self)
        self._clock_timer.timeout.connect(self._update_clock)
        self._clock_timer.start(1000)

    def _apply_card_shadow(self):
        """卡片一层极淡投影：浅色主题下白卡才浮得起来。

        大肥鱼：深色主题（深色/黑/墨金）直接跳过 —— 投影在深色底上几乎看不见，
        但每次重绘都要算一遍模糊，滚动参数页时会明显掉帧。
        """
        try:
            if str(self.ui_cfg.get("theme", "oknte")) in ("oknte", "dark", "lacquer"):
                return
            from PyQt5.QtGui import QColor
            from PyQt5.QtWidgets import QGraphicsDropShadowEffect
            targets = list(self.findChildren(QGroupBox))
            targets += [f for f in self.findChildren(QFrame) if f.objectName() == "hero"]
            for _gb in targets:
                if _gb.graphicsEffect() is not None:
                    continue
                _eff = QGraphicsDropShadowEffect(_gb)
                _eff.setBlurRadius(26)
                _eff.setOffset(0, 3)
                _eff.setColor(QColor(110, 60, 85, 30))
                _gb.setGraphicsEffect(_eff)
        except Exception:
            pass

    NAV_NAMES = ("主页", "参数", "日志", "高价值截图", "对局分析", "自动撞果盘",
                 "拍卖辅助", "视觉报告")

    def _make_side(self):
        """左侧导航栏（大改 UI · 方案 A）。"""
        side = QWidget()
        side.setObjectName("side")
        side.setFixedWidth(196)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(16, 20, 14, 16)
        sl.setSpacing(0)

        # 品牌区：左边两行字，右边立绘头像（素材/avatar_anon.png）
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.setSpacing(10)
        names = QVBoxLayout()
        names.setContentsMargins(0, 0, 0, 0)
        names.setSpacing(2)
        logo = QLabel("即可落槌")
        logo.setObjectName("logo")
        sub = QLabel("AnonTokoy")
        sub.setObjectName("logoSub")
        names.addWidget(logo)
        # 「AnonTokoy」右边一颗小齿轮，点开是面板设置
        self.gear_btn = QPushButton("⚙")
        self.gear_btn.setObjectName("gear")
        self.gear_btn.setFixedSize(22, 22)
        self.gear_btn.setCursor(Qt.PointingHandCursor)
        self.gear_btn.setToolTip("设置：分辨率、字体大小")
        self.gear_btn.clicked.connect(self.open_settings)
        sub_row = QHBoxLayout()
        sub_row.setContentsMargins(0, 0, 0, 0)
        sub_row.setSpacing(5)
        sub_row.addWidget(sub)
        sub_row.addWidget(self.gear_btn, 0, Qt.AlignVCenter)
        sub_row.addStretch(1)
        names.addLayout(sub_row)
        names.addStretch(1)
        top.addLayout(names, 1)

        avatar = QLabel()
        avatar.setObjectName("sideAvatar")
        avatar.setFixedSize(56, 56)
        avatar.setAlignment(Qt.AlignCenter)
        _av_path = os.path.join(BASE, "素材", "avatar_anon.png")
        if os.path.exists(_av_path):
            _av_pm = QPixmap(_av_path)
            if not _av_pm.isNull():
                avatar.setPixmap(_av_pm.scaled(56, 56, Qt.KeepAspectRatioByExpanding,
                                               Qt.SmoothTransformation))
            else:
                avatar.hide()
        else:
            avatar.hide()
        top.addWidget(avatar, 0, Qt.AlignTop)
        # ---- 大肥鱼standby：左上品牌区（logo/AnonTokoy/齿轮/头像）整块不要 ----
        top.setParent(None) if False else None
        sl.addSpacing(16)
        _sep = QFrame()
        _sep.setObjectName("sideSep")
        _sep.setFixedHeight(1)
        sl.addWidget(_sep)
        sl.addSpacing(10)

        self.nav = QListWidget()
        self.nav.setObjectName("nav")
        self.nav.setFocusPolicy(Qt.NoFocus)
        self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        for _n in self.NAV_NAMES:
            it = QListWidgetItem(_n)   # 大肥鱼standby：去掉心形图标，只留文字
            it.setSizeHint(QSize(0, 44))
            self.nav.addItem(it)
        sl.addWidget(self.nav)
        self.nav.setFixedHeight(len(self.NAV_NAMES) * 44 + 4)  # 不按内容撑高，会被压成半截
        sl.addStretch(1)
        # ---- 大肥鱼standby：设置入口挪到左下 ----
        self.set_btn = QPushButton("设置")
        self.set_btn.setObjectName("setNav")   # 大肥鱼standby：与左侧导航同款样式
        self.set_btn.setMinimumHeight(34)
        self.set_btn.setCursor(Qt.PointingHandCursor)
        self.set_btn.clicked.connect(self.open_settings)
        sl.addWidget(self.set_btn)
        # ---- 大肥鱼standby：设置下面再加一个「检查更新」（同款样式）----
        # 默认就显示版本号且不可点；启动 2.5 秒后静默查一次，有新版本才变成可点的「⬆️ 更新到x.x」
        self.check_update_btn = QPushButton(APP_DISPLAY)
        self.check_update_btn.setObjectName("setNav")
        self.check_update_btn.setMinimumHeight(34)
        self.check_update_btn.setCursor(Qt.ArrowCursor)
        self.check_update_btn.setToolTip("当前已是最新版本（%s）" % APP_DISPLAY)
        self.check_update_btn.setEnabled(False)
        self.check_update_btn.setStyleSheet(
            "QPushButton#setNav{color:#7f8ba0;}"
            "QPushButton#setNav:hover{color:#7f8ba0; background:transparent;}"
        )
        self.check_update_btn.clicked.connect(self.do_check_update)
        sl.addWidget(self.check_update_btn)
        # 老代码里到处用 self.update_btn 改文案/样式，这里直接指到侧栏这个按钮上
        self.update_btn = self.check_update_btn
        self._update_state = "latest"


        mascot = QLabel()
        mascot.setFixedSize(52, 52)
        mascot.setMask(QRegion(0, 0, 52, 52, QRegion.Ellipse))
        gif = os.path.join(BASE, "素材", "mascot.gif")
        if os.path.exists(gif):
            mv = QMovie(gif)
            mv.setScaledSize(QSize(52, 52))
            mascot.setMovie(mv)
            # 大肥鱼standby：这块 UI-03 已经整块删掉，动图不再放进布局，
            # 就不要再 start() 让它后台一直解码（白烧 CPU）。
            self._mascot_movie = mv  # 保持引用，别让 Qt 回收掉
        self.mascot = mascot
        # 动图往左，右边一个「工具与维护」下拉：一键自检 / 炫耀家底
        foot = QHBoxLayout()
        foot.setContentsMargins(0, 0, 0, 0)
        foot.setSpacing(10)
        foot.addWidget(mascot, 0, Qt.AlignVCenter)
        self.tool_btn = QPushButton("工具与维护  ▾")
        self.tool_btn.setObjectName("toolBtn")
        self.tool_btn.setMinimumHeight(36)
        self.tool_btn.setCursor(Qt.PointingHandCursor)
        _menu = QMenu(self.tool_btn)
        _a_self = _menu.addAction("🧪  一键自检")
        _a_dog = _menu.addAction("🐕  炫耀家底")
        _menu.addSeparator()
        _a_upd = _menu.addAction("🔄  检查更新")
        _a_self.triggered.connect(self.do_selftest)
        _a_dog.triggered.connect(self.do_dog_grid)
        _a_upd.triggered.connect(self.do_check_update)
        self.tool_btn.setMenu(_menu)
        foot.addWidget(self.tool_btn, 1)
        # ---- 大肥鱼standby UI-03：左下「动图 + 工具与维护 + 版本号 + 检查更新」全部不要 ----
        sl.addSpacing(10)
        # 版本号放大一点：群友截图求助时这行必须一眼能看见
        ver = QLabel(f"v{APP_VERSION} · 爱音版")
        ver.setObjectName("navFoot")
        ver.setStyleSheet("font-size:13px;font-weight:700;")
        ver.setToolTip(f"程序版本 v{APP_VERSION}")
        # UI-03 已移除：版本号
        # 检查更新单独做一个文字按钮：藏在菜单里小白找不到
        self.update_btn = QPushButton("检查更新")
        self.update_btn.setObjectName("navFoot")
        self.update_btn.setCursor(Qt.PointingHandCursor)
        self.update_btn.setFlat(True)
        self.update_btn.setStyleSheet(
            "QPushButton{border:none;background:transparent;font-size:12px;"
            "text-decoration:underline;}"
        )
        self.update_btn.setToolTip("检查有没有新版本（只读，不会自动改你的文件）")
        self.update_btn.clicked.connect(self.do_check_update)
        # UI-03 已移除：检查更新按钮
        self.side = side
        return side

    def _make_page_head(self):
        """内容区顶部：中间「控制台 / 当前页」+ 大标题，右上角日期与时钟。"""
        head = QWidget()
        grid = QGridLayout(head)
        grid.setContentsMargins(0, 0, 0, 0)
        grid.setSpacing(0)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 0)
        grid.setColumnStretch(2, 1)

        self.page_crumb = QLabel("控制台  /  主页")
        self.page_crumb.setObjectName("pageCrumb")
        self.page_crumb.setAlignment(Qt.AlignHCenter)
        self.page_title = QLabel("主页")
        self.page_title.setObjectName("pageTitle")
        self.page_title.setAlignment(Qt.AlignHCenter)
        # ---- 大肥鱼standby UI-01：不要面包屑/大标题/细线（直接留白）----
        # 对象仍创建，其它地方还会改它们的文字；只是不放进布局。
        rule = QFrame()
        rule.setObjectName("pageRule")
        rule.setFixedSize(44, 2)
        for _w in (self.page_crumb, self.page_title, rule):
            try:
                _w.hide()
            except Exception:
                pass

        # 右上角：日期 + 走秒的时钟
        clock_w = QWidget()
        cl = QVBoxLayout(clock_w)
        cl.setContentsMargins(0, 0, 0, 0)
        cl.setSpacing(1)
        self.clock_date = QLabel(datetime.date.today().strftime("%Y.%m.%d"))
        self.clock_date.setObjectName("pageDate")
        self.clock_date.setAlignment(Qt.AlignRight)
        self.clock_time = QLabel("--:--:--")
        self.clock_time.setObjectName("pageClock")
        self.clock_time.setAlignment(Qt.AlignRight)
        cl.addWidget(self.clock_date)
        cl.addWidget(self.clock_time)
        self._clock_w = clock_w   # 大肥鱼standby：时钟改放 hero 卡右上
        self._update_clock()
        return head

    def _update_clock(self):
        """右上角的日期和时钟，每秒对一次系统时间。"""
        try:
            self.clock_time.setText(datetime.datetime.now().strftime("%H:%M:%S"))
            self.clock_date.setText(datetime.date.today().strftime("%Y.%m.%d"))
        except Exception:
            pass

    def set_instrument_group(self, key):
        """切换仪器组：成本表跟着换，重新开始挂机后生效。

        2/3/4 号两组的价格和仪器完全一样，所以现在这套配置（只用 2/3/4 号）
        换组只影响记账口径；真要哪天去点 1 号（至尊鉴定），成本才对得上。
        """
        prices = INSTRUMENT_GROUP_PRICES.get(key)
        if not prices:
            return
        try:
            data = dict(param_file_load(force=True))
            data.update(INSTRUMENT_GROUP=key, TOOL_PRICES=prices)
            if not param_file_save(data):
                raise OSError("无法写入参数配置.json")
        except Exception as exc:
            try:
                self.msg.appendPlainText("❌ 仪器组没保存成功：%s" % exc)
            except Exception:
                pass
            return
        try:
            self.msg.appendPlainText(
                "✅ 仪器组已切到「%s」，成本表 %s（重新开始挂机后生效）"
                % (INSTRUMENT_GROUP_NAMES.get(key, key), prices)
            )
        except Exception:
            pass

    def save_quick_settings(self):
        try:
            price = typed_setting("int", self.exit_price_edit.text().replace(",", "") or "500000")
            if price < 0:
                raise ValueError("请填写非负整数")
        except ValueError as exc:
            QMessageBox.warning(self, "退出线填写有误", str(exc))
            self.exit_price_edit.setFocus()
            return
        data = dict(param_file_load(force=True))
        data.update(BACKGROUND_RUN=int(self.bg_check.isChecked()),
                    CHASE_TO_END=int(self.chase_check.isChecked()),
                    NIGHT_CAP_BY_PRICE=int(self.cap_check.isChecked()),
                    NO_EXIT_NO_DOWNGRADE=int(self.ramp_check.isChecked()),
                    EXIT_BELOW_PRICE=price)
        if not param_file_save(data):
            QMessageBox.warning(self, "保存失败", "无法写入参数配置.json")
            return
        self.msg.appendPlainText("快捷设置已保存，重新启动挂机进程后生效。")
        self._sync_live()

    def _console_log_path(self):
        today = datetime.date.today().isoformat()
        options = (os.path.join(REC, "日志", today, "控制台输出.txt"),
                   os.path.join(REC, today, "日志", "控制台输出.txt"))
        existing = [p for p in options if os.path.isfile(p)]
        if existing:
            return max(existing, key=os.path.getmtime)
        for root, legacy in ((os.path.join(REC, "日志"), False), (REC, True)):
            try:
                days = sorted((d for d in os.listdir(root) if len(d) == 10 and d[4] == "-"), reverse=True)
            except OSError:
                continue
            for day in days:
                candidate = (os.path.join(root, day, "日志", "控制台输出.txt") if legacy
                             else os.path.join(root, day, "控制台输出.txt"))
                if os.path.isfile(candidate):
                    return candidate
        return options[0]

    def _refresh_live_log(self):
        if self.stack.currentIndex() != 0 or not self._status_running:
            return
        try:
            path = self._console_log_path()
            cursor, reset, lines = appended_log_lines(path, getattr(self, "_live_cursor", None))
            self._live_cursor = cursor
        except OSError:
            return
        markers = ("已提交出价", "等待第", "局结束", "开始匹配", "核对出价", "出价金额校验",
                   "回合 仪器→估价", "你正在使用鼠标", "结果不明", "确认回到大厅", "停止挂牌")
        events = [line for line in lines if any(marker in line for marker in markers)]
        if not lines and not reset:
            return
        self._append_log_widget(self.msg, lines[-200:], reset, 200)
        if not events:
            self._sync_live()
            return
        stage = events[-1]
        if "你正在使用鼠标" in stage:
            stage = "鼠标使用中 · 等待"
        elif "开始匹配" in stage:
            stage = "等待匹配"
        elif "出价金额校验" in stage:
            stage = "核对出价"
        else:
            match = re.search(r"等待第\s*(\d+)\s*回合", stage)
            if match:
                stage = f"等待第 {match.group(1)} 回合"
            elif "已提交出价" in stage:
                stage = "已提交出价"
            elif "确认回到大厅" in stage:
                stage = "已回到大厅"
            elif "结果不明" in stage:
                stage = "等待确认游戏状态"
            else:
                stage = "正在挂机"
        if not getattr(self, "_bot_action_pending", False):
            self.hero_state.setText(stage)
        self._sync_live()

    @staticmethod
    def _append_log_widget(widget, lines, reset, max_lines):
        if not lines and not reset:
            return
        document = widget.document()
        document.setMaximumBlockCount(max_lines)
        before = 0 if document.isEmpty() else document.blockCount()
        bar = widget.verticalScrollBar()
        at_end = bar.value() >= bar.maximum()
        old_value = bar.value()
        if reset:
            widget.setPlainText("\n".join(lines))
        elif lines:
            widget.appendPlainText("\n".join(lines))
        dropped = max(0, before + len(lines) - document.blockCount())
        bar.setValue(bar.maximum() if at_end or reset else max(0, old_value - dropped))

    def _sync_live(self):
        """实时输出：有内容就露日志，没内容就露空态提示。"""
        try:
            txt = self.msg.toPlainText().strip()
            if txt:
                self.live_stack.setCurrentWidget(self.msg)
                last = txt.splitlines()[-1].strip()
                self.live_last.setText(last[:64] + ("…" if len(last) > 64 else ""))
            else:
                self.live_stack.setCurrentWidget(self.live_empty)
                self.live_last.setText("等待脚本产生新事件。")
        except Exception:
            pass

    def show_qq(self):
        """弹出加好友的名片二维码。"""
        try:
            dlg = QDialog(self)
            dlg.setObjectName("qqDlg")
            dlg.setWindowTitle("加我好友")
            v = QVBoxLayout(dlg)
            v.setContentsMargins(20, 18, 20, 16)
            v.setSpacing(10)
            pic = QLabel()
            pic.setAlignment(Qt.AlignCenter)
            _p = os.path.join(BASE, "素材", "qq_card.png")
            if os.path.exists(_p):
                _pm = QPixmap(_p)
                if not _pm.isNull():
                    pic.setPixmap(_pm)
            v.addWidget(pic)
            tip = QLabel("扫一扫 加我好友 · QQ 162077215")
            tip.setObjectName("hint")
            tip.setAlignment(Qt.AlignCenter)
            v.addWidget(tip)
            ok = QPushButton("知道了")
            ok.setObjectName("primary")
            ok.setMinimumWidth(96)
            ok.clicked.connect(dlg.accept)
            v.addWidget(ok, 0, Qt.AlignHCenter)
            dlg.exec_()
        except Exception:
            pass

    # ---------- 界面设置 ----------

    def _font_factor(self):
        try:
            return max(0.8, min(1.6, float(self.ui_cfg.get("font_size", 13)) / 13.0))
        except Exception:
            return 1.0

    def _apply_nav_scale(self):
        """字号变了，左侧导航的宽度和行高跟着走，不然大字会挤成一团。"""
        factor = self._font_factor()
        try:
            self.side.setFixedWidth(int(round(196 * factor)))
            item_h = int(round(44 * factor))
            for i in range(self.nav.count()):
                self.nav.item(i).setSizeHint(QSize(0, item_h))
            self.nav.setFixedHeight(len(self.NAV_NAMES) * item_h + 4)
            size = int(round(52 * factor))
            self.mascot.setFixedSize(size, size)
            self.mascot.setMask(QRegion(0, 0, size, size, QRegion.Ellipse))
            if hasattr(self, "_mascot_movie"):
                self._mascot_movie.setScaledSize(QSize(size, size))
            gear = int(round(26 * factor))
            self.gear_btn.setFixedSize(gear, gear)
        except Exception:
            pass

    def _colors(self):
        """当前主题的配色表（给需要按主题改颜色的动态文字用）。"""
        return THEME_COLORS.get(str(self.ui_cfg.get("theme") or "anon"), ANON)

    # ---- 大肥鱼：窗口背景图 ----
    BG_IMAGE = "背景.jpg"
    BG_SCRIM = 150          # 压在背景上的暗色蒙版（0~255，越大越暗，保证文字可读）
    _BG_SCRIM_COLOR = None  # 当前主题的蒙版颜色（大肥鱼=压暗，小吱=压亮）

    def _apply_window_lock(self):
        """选了固定分辨率就锁死窗口大小（拉不动）；只有「自动」允许拖拽缩放。"""
        try:
            geo = str(self.ui_cfg.get("geometry", ""))
            if geo and geo != "自动（适配屏幕）":
                w, h = resolve_geometry(geo)
                self.setFixedSize(int(w), int(h))
            else:
                self.setMinimumSize(900, 620)
                self.setMaximumSize(16777215, 16777215)
        except Exception:
            pass

    def _refresh_scroll_opaque(self, *, transparency=None, theme=None):
        try:
            for _name in ("cfg_area", "ana_scroll"):
                _a = getattr(self, _name, None)
                if _a is not None and _a.widget() is not None:
                    self._make_scroll_opaque(_a, _a.widget(), transparency=transparency, theme=theme)
        except Exception:
            pass

    def _make_scroll_opaque(self, area, widget=None, *, transparency=None, theme=None):
        """把滚动区的内容底做成不透明色（**只在界面透明度=0 时**用）。

        Qt 只有在滚动内容不透明时才能"整块平移 blit"；一旦是透明的，
        每滚一格都要把可视区所有控件重画一遍 —— 实测 36ms/帧 → 10ms/帧。
        """
        try:
            if transparency is None:
                transparency = float(self.ui_cfg.get("ui_trans", 0.0) or 0.0)
            targets = [area.viewport()]
            content = widget if widget is not None else area.widget()
            if content is not None:
                targets.append(content)
            for target in targets:
                target.setAutoFillBackground(transparency <= 0.002)
            if transparency > 0.002:
                return
            colors = THEME_COLORS.get(theme or self.ui_cfg.get("theme") or "oknte") or OKNTE
            from PyQt5.QtGui import QColor, QPalette

            color = QColor(str(colors.get("bg") or "#1b1f2a"))
            for target in targets:
                palette = target.palette()
                palette.setColor(QPalette.Window, color)
                target.setPalette(palette)
        except Exception:
            pass

    # 每个主题各自的背景图（没有映射 = 纯色底）
    BG_IMAGE_BY_THEME = {
        "oknte": "背景.jpg", "anon": "背景_小吱.png", "requiem": "背景_安魂曲.png",
        "malice": "背景_码丽丝.jpg", "killer": "背景_杀手旋律.jpg",
        "shenyi": "背景_神艺.jpg", "zhulei": "背景_珠泪.jpg",
    }

    # 浅色系（卡片给半透明底座，背景图才透得出来）
    LIGHT_BG_THEMES = ("anon", "malice", "killer", "shenyi", "zhulei")

    def _sync_widget_theme(self, theme=None):
        """主题切换后，把胶囊开关 / 下拉箭头 / 下拉弹层的颜色也刷一遍。"""
        try:
            t = str(theme if theme is not None else self.ui_cfg.get("theme", "oknte"))
            _apply_widget_theme(t)
            try:
                self._apply_dark_titlebar()
            except Exception:
                pass
            try:
                # 版本号那行是"弱化"样式：颜色也得按主题来，不然浅色主题下发灰发暗
                _c = THEME_COLORS.get(t) or OKNTE
                _muted = _c.get("muted") or _c.get("nav_foot_fg") or _c.get("nav_fg")
                self.check_update_btn.setStyleSheet(
                    "QPushButton#setNav{color:%s;background:transparent;}"
                    "QPushButton#setNav:hover{color:%s;background:transparent;}" % (_muted, _muted)
                )
            except Exception:
                pass
            for w in self.findChildren(ToggleSwitch):
                w.update()
            for c in self.findChildren(NoWheelComboBox):
                try:
                    c.view().setStyleSheet(c._popup_qss())
                except Exception:
                    pass
                c.update()
        except Exception:
            pass

    def _refresh_bg(self, theme=None):
        """按主题加载背景图：大肥鱼 / 小吱 有图，其它主题纯色。"""
        try:
            t = str(theme if theme is not None else self.ui_cfg.get("theme", "oknte"))
            img = self.BG_IMAGE_BY_THEME.get(t)
            # 浅色主题（小吱）压一层白纱，深色（大肥鱼）压一层暗纱，保证文字可读
            if t == "anon":
                self._BG_SCRIM_COLOR = QColor(255, 255, 255, 70)
            else:
                self._BG_SCRIM_COLOR = QColor(0, 0, 0, int(self.BG_SCRIM or 0))
            if img:
                pm = self._load_bg_pixmap(img)
            else:
                pm = QPixmap()
            self._bg_pixmap = pm
            self._bg_cache = None
            self._bg_cache_size = None
            self.update()
        except Exception:
            pass

    def _load_bg_pixmap(self, name=None):
        """读 素材\\<name>；没有这张图就返回空 QPixmap，界面照常。"""
        try:
            p = os.path.join(BASE, "素材", name or self.BG_IMAGE)
            if os.path.isfile(p):
                pm = QPixmap(p)
                if not pm.isNull():
                    return pm
        except Exception:
            pass
        return QPixmap()

    def _bg_dpr_value(self):
        """当前屏幕缩放比例（150% 缩放 = 1.5）。高分屏必须按这个比例合成底图，否则会被系统放大变糊。"""
        try:
            return max(1.0, float(self.devicePixelRatioF() or 1.0))
        except Exception:
            return 1.0

    def _rebuild_bg_cache(self):
        """把背景图缩放 + 压暗一次性合成为一张不透明底图（按设备像素合成，高分屏才清晰）。"""
        pm = getattr(self, "_bg_pixmap", None)
        if pm is None or pm.isNull():
            self._bg_cache = None
            self._bg_cache_size = None
            return
        size = self.size()
        dpr = self._bg_dpr_value()
        dev_w = max(1, int(round(size.width() * dpr)))
        dev_h = max(1, int(round(size.height() * dpr)))
        scaled = pm.scaled(dev_w, dev_h, Qt.KeepAspectRatioByExpanding,
                           Qt.SmoothTransformation)
        canvas = QPixmap(dev_w, dev_h)
        canvas.fill(QColor(0, 0, 0))
        p = QPainter(canvas)
        p.setRenderHint(QPainter.SmoothPixmapTransform, True)
        p.drawPixmap((dev_w - scaled.width()) // 2,
                     (dev_h - scaled.height()) // 2, scaled)
        # 暗色蒙版直接烘进底图：每帧只剩「一次不透明贴图」，不再叠加半透明矩形
        p.fillRect(0, 0, dev_w, dev_h,
                   self._BG_SCRIM_COLOR or QColor(0, 0, 0, int(self.BG_SCRIM or 0)))
        p.end()
        self._bg_cache = canvas
        self._bg_cache_size = size
        self._bg_dpr = dpr

    def paintEvent(self, event):  # noqa: N802
        pm = getattr(self, "_bg_pixmap", None)
        if pm is None or pm.isNull():
            return super().paintEvent(event)
        try:
            _dpr_now = self._bg_dpr_value()
            if (getattr(self, "_bg_cache", None) is None
                    or self._bg_cache_size != self.size()
                    or abs(float(getattr(self, "_bg_dpr", 1.0) or 1.0) - _dpr_now) > 0.01):
                self._rebuild_bg_cache()
            if self._bg_cache is not None:
                painter = QPainter(self)
                # 只画"这次真正坏掉的那一块"（滚动时通常是一条窄带），
                # 不再每帧整窗贴一次 1400x1000 的大图。
                rect = event.rect()
                painter.setCompositionMode(QPainter.CompositionMode_Source)
                dpr = float(getattr(self, "_bg_dpr", 1.0) or 1.0)
                if abs(dpr - 1.0) < 0.01:
                    painter.drawPixmap(rect, self._bg_cache, rect)
                else:
                    # 缓存是按设备像素存的：源矩形要乘回缩放比例
                    src = QRect(int(round(rect.x() * dpr)), int(round(rect.y() * dpr)),
                                int(round(rect.width() * dpr)), int(round(rect.height() * dpr)))
                    painter.drawPixmap(rect, self._bg_cache, src)
                painter.end()
        except Exception:
            pass
        super().paintEvent(event)

    def moveEvent(self, event):  # noqa: N802
        """拖动窗口后记住位置（1.5 秒节流，避免拖的时候狂写文件）。"""
        try:
            super().moveEvent(event)
        except Exception:
            pass
        try:
            if not getattr(self, "_pos_ready", False):
                return          # 还没还原过，别把窗口管理器的默认位置写进配置
            import time as _t
            _now = _t.time()
            if _now - float(getattr(self, "_pos_saved_at", 0) or 0) < 1.5:
                return
            self._pos_saved_at = _now
            pos = self.pos()
            if pos.x() < -10000 or pos.y() < -10000:
                return            # 最小化时的假坐标
            self.ui_cfg["window_pos"] = [int(pos.x()), int(pos.y())]
            save_ui_cfg(self.ui_cfg)
        except Exception:
            pass

    def resizeEvent(self, event):  # noqa: N802
        try:
            self._bg_cache = None
        except Exception:
            pass
        super().resizeEvent(event)

    def showEvent(self, event):  # noqa: N802
        super().showEvent(event)
        try:
            self._apply_dark_titlebar()
        except Exception:
            pass
        # 第一次显示：把窗口挪回上次拖到的位置（show 之前 move 会被窗口管理器覆盖）
        if not getattr(self, "_pos_ready", False):
            try:
                _sp = getattr(self, "_saved_pos", []) or []
                if len(_sp) == 2 and _pos_on_any_screen(_sp[0], _sp[1], self.width(), self.height()):
                    self.move(int(_sp[0]), int(_sp[1]))
                    print(f"🪟 面板位置已还原到 ({_sp[0]}, {_sp[1]})")
                elif len(_sp) == 2:
                    print(f"🪟 上次的位置 ({_sp[0]}, {_sp[1]}) 不在任何屏幕上 → 用默认位置")
            except Exception:
                pass
            self._pos_ready = True

    def _apply_dark_titlebar(self):
        """系统标题栏跟着主题走：深/浅 + 标题栏底色（颜色只改这里，不动窗口结构）。

        - 深/浅：Win10 1809+ 的沉浸式暗色就能切（20/19 两个属性号兼容新旧版本）；
        - 底色/文字色：Win11（build 22000+）才支持 35/36/34 这三个属性；
          老系统会静默失败，标题栏保持系统默认，不影响使用。
        """
        try:
            import ctypes
            hwnd = int(self.winId())
            theme = str(self.ui_cfg.get("theme") or "oknte")
            dark = theme not in ("anon", "light")
            val = ctypes.c_int(1 if dark else 0)
            for attr in (20, 19):   # DWMWA_USE_IMMERSIVE_DARK_MODE：20=新版，19=旧版
                try:
                    ctypes.windll.dwmapi.DwmSetWindowAttribute(
                        ctypes.c_void_p(hwnd), attr,
                        ctypes.byref(val), ctypes.sizeof(val))
                except Exception:
                    pass
            colors = THEME_COLORS.get(theme) or OKNTE

            def _cref(hex_color):
                h = str(hex_color or "#000000").lstrip("#")
                r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
                # DWM 要的是 0xAABBGGRR
                return ctypes.c_uint((0xFF << 24) | (b << 16) | (g << 8) | r)

            for attr, key, alt in (
                (35, "side_bg", "bg"),        # DWMWA_CAPTION_COLOR
                (36, "fg", None),             # DWMWA_TEXT_COLOR
                (34, "side_border", "card_border"),  # DWMWA_BORDER_COLOR
            ):
                col = colors.get(key) or (colors.get(alt) if alt else None)
                if not col:
                    continue
                try:
                    v2 = _cref(col)
                    ctypes.windll.dwmapi.DwmSetWindowAttribute(
                        ctypes.c_void_p(hwnd), attr,
                        ctypes.byref(v2), ctypes.sizeof(v2))
                except Exception:
                    pass
        except Exception:
            pass

    def open_settings(self):
        """左下角齿轮点开的面板设置。"""
        dlg = QDialog(self)
        dlg.setWindowTitle("设置")
        dlg.setObjectName("settingsDialog")
        dlg.setMinimumWidth(420)
        v = QVBoxLayout(dlg)
        v.setContentsMargins(22, 20, 22, 18)
        v.setSpacing(12)

        title = QLabel("界面设置")
        title.setObjectName("big")
        v.addWidget(title)
        tip = QLabel("改完点保存立即生效，下次启动也记得住。")
        tip.setObjectName("hint")
        v.addWidget(tip)
        v.addSpacing(4)

        # ---- 分辨率 ----
        r1 = QHBoxLayout()
        r1.setSpacing(12)
        l1 = QLabel("分辨率")
        l1.setFixedWidth(78)
        combo = NoWheelComboBox()
        for label, _preset in RES_PRESETS:
            combo.addItem(label)
        idx = combo.findText(str(self.ui_cfg.get("geometry", "")))
        combo.setCurrentIndex(idx if idx >= 0 else 0)
        combo.setMinimumWidth(190)
        r1.addWidget(l1)
        r1.addWidget(combo, 1)
        v.addLayout(r1)
        d1 = QLabel("面板窗口的整体大小；屏幕装不下会自动缩到刚好放得下。")
        d1.setObjectName("cap")
        d1.setWordWrap(True)
        v.addWidget(d1)

        # ---- 字体大小 ----
        r2 = QHBoxLayout()
        r2.setSpacing(12)
        l2 = QLabel("字体大小")
        l2.setFixedWidth(78)
        spin = QSpinBox()
        spin.setRange(10, 20)
        spin.setSuffix(" px")
        spin.setValue(int(self.ui_cfg.get("font_size", 13)))
        spin.setMinimumWidth(110)
        r2.addWidget(l2)
        r2.addWidget(spin)
        r2.addStretch(1)
        v.addLayout(r2)
        d2 = QLabel("界面里所有文字的基准字号，默认 13 px；调大之后会更占地方。")
        d2.setObjectName("cap")
        d2.setWordWrap(True)
        v.addWidget(d2)

        # ---- 界面风格----
        r3 = QHBoxLayout()
        r3.setSpacing(12)
        l3 = QLabel("界面风格")
        l3.setFixedWidth(78)
        theme_box = NoWheelComboBox()
        for _key, _label in THEME_LABELS:
            theme_box.addItem(_label, _key)
        _cur = theme_box.findData(str(self.ui_cfg.get("theme", "anon")))
        theme_box.setCurrentIndex(_cur if _cur >= 0 else 0)
        try:
            # 只有"打开下拉列表"那一项才显示（当前）：收起时显示的是纯名字
            if _cur >= 0:
                theme_box.setItemData(_cur, True, Qt.UserRole + 77)
        except Exception:
            pass
        theme_box.setMinimumWidth(190)
        r3.addWidget(l3)
        r3.addWidget(theme_box, 1)
        v.addLayout(r3)
        d3 = QLabel("小吱是粉白配色，白是干净的白灰，黑是深蓝青，墨金是暖黑加落槌金（像拍卖行的账册）。")
        d3.setObjectName("cap")
        d3.setWordWrap(True)
        v.addWidget(d3)

        # ---- 界面透明度（0 = 不透明，1 = 全透明）----
        r4 = QHBoxLayout()
        r4.setSpacing(12)
        l4 = QLabel("界面透明度")
        l4.setFixedWidth(78)
        slider = QSlider(Qt.Horizontal)
        slider.setObjectName("uiTrans")
        slider.setRange(0, 100)
        slider.setSingleStep(1)
        slider.setPageStep(10)
        _cur_trans = float(self.ui_cfg.get("ui_trans", 0.0) or 0.0)
        slider.setValue(int(round(max(0.0, min(1.0, _cur_trans)) * 100)))
        slider.setMinimumHeight(22)
        slider.setMinimumWidth(260)
        val_lab = QLabel("%.2f" % (slider.value() / 100.0))
        val_lab.setObjectName("cap")
        val_lab.setFixedWidth(38)
        val_lab.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        r4.addWidget(l4)
        r4.addWidget(slider, 1)
        r4.addWidget(val_lab)
        v.addLayout(r4)
        d4 = QLabel("0 = 完全不透明（默认），1 = 完全透明；只有面板会变透，文字和按钮不受影响。")
        d4.setObjectName("cap")
        d4.setWordWrap(True)
        v.addWidget(d4)

        v.addSpacing(8)
        btns = QHBoxLayout()
        btns.setSpacing(8)
        btns.addStretch(1)
        reset = QPushButton("恢复默认")
        cancel = QPushButton("取消")
        ok = QPushButton("保存")
        ok.setObjectName("primary")
        ok.setMinimumWidth(92)

        def _reset():
            combo.setCurrentIndex(max(0, combo.findText(UI_DEFAULTS["geometry"])))
            spin.setValue(int(UI_DEFAULTS["font_size"]))
            _i = theme_box.findData(UI_DEFAULTS["theme"])
            if _i >= 0:
                theme_box.setCurrentIndex(_i)
            slider.setValue(int(round(float(UI_DEFAULTS.get("ui_trans", 0.0)) * 100)))

        reset.clicked.connect(_reset)
        cancel.clicked.connect(dlg.reject)
        ok.clicked.connect(
            lambda: self._save_ui_settings(
                dlg,
                combo.currentText(),
                spin.value(),
                theme_box.currentData(),
                slider.value() / 100.0,
            )
        )

        # 选中风格 / 拖滑条时即时预览，取消或关闭则退回原样
        _origin_theme = str(self.ui_cfg.get("theme", "anon"))
        _origin_trans = float(self.ui_cfg.get("ui_trans", 0.0) or 0.0)

        def _preview():
            _t = theme_box.currentData() or "anon"
            self.setStyleSheet(build_qss(_t, spin.value(), slider.value() / 100.0))
            self._sync_assist_theme(_t)
            self._sync_widget_theme(_t)
            self._refresh_bg(_t)
            self._refresh_scroll_opaque(transparency=slider.value() / 100.0, theme=_t)

        def _restore():
            self.setStyleSheet(build_qss(_origin_theme, spin.value(), _origin_trans))
            self._sync_assist_theme(_origin_theme)
            self._sync_widget_theme(_origin_theme)
            self._refresh_bg(_origin_theme)
            self._refresh_scroll_opaque(transparency=_origin_trans, theme=_origin_theme)

        def _on_trans(_mv):
            val_lab.setText("%.2f" % (slider.value() / 100.0))
            _preview()

        slider.valueChanged.connect(_on_trans)

        theme_box.currentIndexChanged.connect(_preview)
        dlg.rejected.connect(_restore)
        for b in (reset, cancel, ok):
            b.setMinimumHeight(36)
        btns.addWidget(reset)
        btns.addWidget(cancel)
        btns.addWidget(ok)
        v.addLayout(btns)
        dlg.exec_()

    def _save_ui_settings(self, dlg, geometry, font_size, theme="anon", ui_trans=None):
        try:
            self.ui_cfg["geometry"] = str(geometry or UI_DEFAULTS["geometry"])
            self.ui_cfg["font_size"] = max(10, min(20, int(font_size)))
            self.ui_cfg["theme"] = theme if theme in THEME_COLORS else "anon"
            if ui_trans is not None:
                self.ui_cfg["ui_trans"] = max(0.0, min(1.0, float(ui_trans)))
            # 用户明确选了分辨率 → 作废「记住的窗口大小」，下次严格按预设还原
            if str(self.ui_cfg.get("geometry", "")) != "自动（适配屏幕）":
                self.ui_cfg["window_size"] = []
            save_ui_cfg(self.ui_cfg)
            self.setStyleSheet(
                build_qss(
                    self.ui_cfg["theme"],
                    self.ui_cfg["font_size"],
                    self.ui_cfg.get("ui_trans", 0.0),
                )
            )
            self._sync_assist_theme(self.ui_cfg["theme"])
            self._sync_widget_theme(self.ui_cfg["theme"])
            self._apply_nav_scale()
            self.resize(*resolve_geometry(self.ui_cfg["geometry"]))
            self._apply_window_lock()
            self._refresh_bg(self.ui_cfg["theme"])
            for _a in (getattr(self, "cfg_area", None), getattr(self, "ana_scroll", None)):
                if _a is not None:
                    self._make_scroll_opaque(_a)
        except Exception:
            pass
        try:
            dlg.accept()
        except Exception:
            pass

    def _sync_assist_theme(self, theme):
        """换皮肤时，右侧拍卖辅助栏的字色跟着刷一遍。"""
        try:
            self.assist.apply_colors(THEME_COLORS.get(str(theme or "anon"), ANON))
        except Exception:
            pass
        try:
            self.vision_report.apply_colors(THEME_COLORS.get(str(theme or "anon"), ANON))
        except Exception:
            pass

    def _on_nav(self, idx):
        """切页：同步导航的实心/空心标记，再走原来的刷页逻辑。"""
        try:
            for i in range(self.nav.count()):
                it = self.nav.item(i)
                name = it.text()
                name = str(name).lstrip("◇◆♡♥▾▸ ").strip()   # 大肥鱼standby：去掉前缀符号
                it.setText(name)   # 大肥鱼standby：侧栏不要图标，只留文字
        except Exception:
            pass
        try:
            self.stack.setCurrentIndex(idx)
        except Exception:
            pass
        # 切到参数/分析页时重新确认"滚动内容不透明"（这是滚动顺滑的前提）
        try:
            from PyQt5.QtCore import QTimer as _QT
            _QT.singleShot(0, self._refresh_scroll_opaque)
        except Exception:
            pass
        try:
            _name = self.NAV_NAMES[idx]
            self.page_crumb.setText("控制台  /  " + _name)
            self.page_title.setText(_name)
        except Exception:
            pass
        self.on_tab_changed(idx)

    def tab_control(self):
        w = QWidget()
        _outer = QVBoxLayout(w)
        _outer.setContentsMargins(0, 0, 0, 0)
        _outer.setSpacing(0)
        # 套一层滚动区：窗口矮的时候能滚，不会把最下面的输出框压没
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QFrame.NoFrame)
        inner = QWidget()
        lay = QVBoxLayout(inner)
        lay.setSpacing(8)
        # 顶部大卡：状态 + 开始/停止 + 右侧立绘
        hero = QFrame()
        hero.setObjectName("hero")
        hl = QHBoxLayout(hero)
        hl.setContentsMargins(20, 10, 18, 12)
        hl.setSpacing(16)

        left = QVBoxLayout()
        left.setSpacing(4)
        _tag_row = QHBoxLayout()
        _tag_row.setSpacing(6)
        _tag_row.setContentsMargins(0, 0, 0, 0)
        _dot = QLabel("●")
        _dot.setObjectName("heroDot")
        _tag = QLabel("当前大肥鱼状态")
        _tag.setObjectName("heroTag")
        _tag_row.addWidget(_dot, 0, Qt.AlignVCenter)
        _tag_row.addWidget(_tag, 0, Qt.AlignVCenter)
        _tag_row.addStretch(1)
        left.addLayout(_tag_row)
        self.hero_state = QLabel("吃大米饭中")
        self.hero_state.setObjectName("heroState")
        left.addWidget(self.hero_state)
        left.addSpacing(8)

        row = QHBoxLayout()
        row.setSpacing(10)
        b1 = QPushButton("▶  开始挂机")
        b1.setObjectName("primary")
        b2 = QPushButton("■  停止挂机")
        b2.setObjectName("danger")
        b3 = QPushButton("⏹  彻底停止脚本")
        self.bot_action_buttons = (b1, b2, b3)
        for b in (b1, b2, b3):
            b.setMinimumHeight(44)
            row.addWidget(b)
        row.addStretch(1)
        b1.clicked.connect(self.do_start)
        b2.clicked.connect(self.do_stop)
        b3.clicked.connect(self.do_kill)
        left.addLayout(row)
        left.addSpacing(2)
        hint = QLabel("F10 开始挂机　·　F11 安全暂停 / 继续　·　F12 彻底停止　·　1080p 运行")
        hint.setObjectName("heroHint")
        left.addWidget(hint)
        left.addStretch(1)
        hl.addLayout(left, 1)

        # 反馈入口：只有一行字，点了弹加好友名片
        _fb = QVBoxLayout()
        _fb.setContentsMargins(0, 0, 4, 0)
        _fb.setSpacing(8)
        _fb_txt = QPushButton("有问题反馈 →")
        _fb_txt.setObjectName("fbText")
        _fb_txt.setCursor(Qt.PointingHandCursor)
        _fb_txt.clicked.connect(self.show_qq)
        _fb.addStretch(1)
        _fb.addWidget(_fb_txt, 0, Qt.AlignHCenter)
        _fb.addStretch(1)
        # ---- 大肥鱼standby UI-02：hero 右侧「有问题反馈 + 立绘」不要了（留白）----
        # hl.addLayout(_fb)

        _art = ClickableLabel()
        _art.setObjectName("heroArt")
        _art.setFixedSize(224, 126)
        _art.setCursor(Qt.PointingHandCursor)
        _art.setToolTip("点我 · 加好友 / 反馈问题")
        _art.clicked.connect(self.show_qq)
        _gif_path = os.path.join(BASE, "素材", "anon_hero.gif")
        _png_path = os.path.join(BASE, "素材", "anon_hero.png")
        _shown = False
        # 有 gif 就循环播（放素材\anon_hero.gif），没有就退回静态图
        if os.path.exists(_gif_path):
            try:
                _mv = QMovie(_gif_path)
                if _mv.isValid():
                    _mv.setScaledSize(QSize(224, 126))
                    _art.setMovie(_mv)
                    # 大肥鱼standby：hero 立绘（UI-02）已经不在布局里了，不 start()，
                    # 免得 1.8MB 的 GIF 在后台一直解码。
                    self._hero_movie = _mv  # 别让 Qt 回收
                    _shown = True
            except Exception:
                _shown = False
        if not _shown and os.path.exists(_png_path):
            _art_pm = QPixmap(_png_path)
            if not _art_pm.isNull():
                _art.setPixmap(_art_pm.scaled(224, 126, Qt.KeepAspectRatioByExpanding,
                                              Qt.SmoothTransformation))
                _shown = True
        if not _shown:
            _art.hide()
        # gif 是方的，裁个圆角跟卡片对齐
        try:
            from PyQt5.QtCore import QRectF
            from PyQt5.QtGui import QPainterPath
            _rp = QPainterPath()
            _rp.addRoundedRect(QRectF(0, 0, 224, 126), 10, 10)
            _art.setMask(QRegion(_rp.toFillPolygon().toPolygon()))
        except Exception:
            pass
        # hl.addWidget(_art, 0, Qt.AlignVCenter)   # UI-02：立绘 GIF 不要
        # 大肥鱼standby：时钟放到 hero 卡右上角
        _clock = getattr(self, "_clock_w", None)
        if _clock is not None:
            hl.addWidget(_clock, 0, Qt.AlignTop | Qt.AlignRight)
        lay.addWidget(hero)
        # 后台模式 + 点击速度（都放主界面）
        bgbox = QGroupBox("快捷设置")
        bgl = QVBoxLayout(bgbox)
        bgl.setSpacing(6)

        # 仪器组：两套组的 2/3/4 号完全一样，只有 1 号（至尊鉴定）和 5 号（九格均价）不同。
        # 切组只换成本表，仪器识别不受影响 —— 现在这套配置用的是 2/3/4 号。
        _grp_t = QLabel("仪器组")
        _grp_t.setObjectName("hint")
        _grp_t.setToolTip(
            "巨物：1号 5 万 / 5号 2 万\n"
            "至尊：1号 10 万（至尊鉴定）/ 5号 7 万（九格均价）\n"
            "2/3/4 号两组完全一样，切组只影响成本记账。"
        )
        bgl.addWidget(_grp_t)
        _grp_row = QHBoxLayout()
        _grp_row.setSpacing(8)
        self.group_btns = {}
        for _gk in ("SUPER_APPRAISAL", "SUPREME"):
            _gb = QPushButton(INSTRUMENT_GROUP_NAMES.get(_gk, _gk))
            _gb.setCheckable(True)
            _gb.setAutoExclusive(True)
            _gb.setObjectName("miniBtn")
            _gb.setMinimumHeight(28)
            _gb.setToolTip(_grp_t.toolTip())
            _gb.clicked.connect(lambda _=False, k=_gk: self.set_instrument_group(k))
            _grp_row.addWidget(_gb)
            self.group_btns[_gk] = _gb
        bgl.addLayout(_grp_row)
        try:
            _cur_grp = read_setting("INSTRUMENT_GROUP").strip() or "SUPER_APPRAISAL"
        except Exception:
            _cur_grp = "SUPER_APPRAISAL"
        self.group_btns.get(_cur_grp, self.group_btns["SUPER_APPRAISAL"]).setChecked(True)

        self.bg_check = ToggleSwitch("后台模式")
        self.bg_check.setToolTip(CONFIG_COPY["BACKGROUND_RUN"][1])
        try:
            self.bg_check.setChecked(read_setting("BACKGROUND_RUN").strip() == "1")
        except Exception:
            pass
        self.bg_check.stateChanged.connect(self.toggle_background_mode)

        self.chase_check = ToggleSwitch("一路追到底")
        self.chase_check.setToolTip(CONFIG_COPY["CHASE_TO_END"][1])
        try:
            self.chase_check.setChecked(read_setting("CHASE_TO_END").strip() == "1")
        except Exception:
            pass

        # 大肥鱼standby：每个开关占一行（并排会把文字挤掉）
        bgl.addWidget(self.bg_check)
        bgl.addWidget(self.chase_check)

        self.cap_check = ToggleSwitch("天黑别超估价")
        self.cap_check.setToolTip("看不到对手金额时（天黑），档位价还要被自己的估价夹一下")
        try:
            self.cap_check.setChecked(read_setting("NIGHT_CAP_BY_PRICE").strip() == "1")
        except Exception:
            pass
        bgl.addWidget(self.cap_check)

        # 「一路追到底」下面这条：不退出模式下要不要死守"只涨不跌"
        self.ramp_check = ToggleSwitch("不退出模式不降价")
        self.ramp_check.setToolTip(
            "开启（默认）：每回合至少按倍率往上递增，绝不回落\n"
            "关闭：允许按智能估价回落，只有算不出价时才拿保底链兜底"
        )
        try:
            _ramp = read_setting("NO_EXIT_NO_DOWNGRADE").strip()
            self.ramp_check.setChecked(_ramp != "0")
        except Exception:
            self.ramp_check.setChecked(True)
        bgl.addWidget(self.ramp_check)

        _spd_t = QLabel("点击速度")
        _spd_t.setObjectName("hint")
        bgl.addWidget(_spd_t)
        spd = QHBoxLayout()
        spd.setSpacing(8)
        self.speed_btns = {}
        for _k, _lab in ((1, "稳妥"), (2, "标准"), (3, "极速")):
            _b = QPushButton(_lab)
            _b.setCheckable(True)
            _b.setObjectName("miniBtn")
            _b.setMinimumHeight(28)
            _b.clicked.connect(lambda _=False, k=_k: self.set_click_speed(k))
            spd.addWidget(_b)
            self.speed_btns[_k] = _b
        bgl.addLayout(spd)
        try:
            _tier = int(read_setting("CLICK_SPEED").strip() or 2)
        except Exception:
            _tier = 2
        self.speed_btns.get(_tier, self.speed_btns[2]).setChecked(True)

        self.exit_price_edit = QLineEdit()
        try:
            self.exit_price_edit.setText(read_setting("EXIT_BELOW_PRICE").strip() or "500000")
        except Exception:
            self.exit_price_edit.setText("500000")
        self.exit_price_edit.setPlaceholderText("500000")
        self.exit_price_edit.setMinimumHeight(30)
        self.exit_price_edit.setToolTip(
            "第 3 回合起，估价低于这个数就退出本局，不浪费时间。\n"
            "但「估价明显压着对手」时不看这条，照常跟。")
        _ep_row = QHBoxLayout()
        _ep_row.setSpacing(8)
        _ep_t = QLabel("估价低于就收手")
        _ep_t.setObjectName("hint")
        _ep_t.setToolTip(self.exit_price_edit.toolTip())
        _ep_row.addWidget(_ep_t, 0, Qt.AlignVCenter)
        _ep_row.addWidget(self.exit_price_edit, 1)
        bgl.addLayout(_ep_row)

        # 卡片跟着窗口拉高时，把「保存」按钮和提示沉到卡片底部，
        # 参数留在上半部分 —— 不然按钮悬在中间、下面一整块空白更难看。
        bgl.addStretch(1)
        bgl.addSpacing(4)
        _quick_save = QPushButton("保存快捷设置")
        _quick_save.setObjectName("primary")
        _quick_save.setMinimumHeight(34)
        _quick_save.clicked.connect(self.save_quick_settings)
        bgl.addWidget(_quick_save)

        bg_hint = QLabel("保存后需重新启动挂机进程。")
        bg_hint.setObjectName("hint")
        bg_hint.setWordWrap(True)
        bgl.addWidget(bg_hint)
        # 后台模式卡不单独占一行了，等下放到「实时输出」右边
        if not is_elevated():
            warn = QLabel(
                "⚠️ 面板没以管理员身份运行，点游戏可能被拦。"
                "关掉面板，右键『点我启动.bat』→ 以管理员身份运行。"
            )
            warn.setObjectName("warnText")
            warn.setWordWrap(True)
            lay.addWidget(warn)
        if getattr(self, "_repaired", None):
            fix = QLabel(
                "✅ 已自动修复上次保存参数时写坏的一处配置（出价策略少了引号），"
                "现在可以正常开始挂机了：\n" + "\n".join(self._repaired)
            )
            fix.setObjectName("fixText")
            fix.setWordWrap(True)
            lay.addWidget(fix)

        # 【大改 UI】状态 + 六项统计合成一张「概览」卡片
        statbox = QGroupBox("数据概览")
        sv = QVBoxLayout(statbox)
        sv.setSpacing(9)

        # 状态大字已经挪到上面的 hero 卡了，这里只留心跳
        self.status_lab = QLabel("")
        self.status_lab.setObjectName("big")
        self.status_lab.hide()
        self.hb_lab = QLabel("")
        self.hb_lab.setObjectName("cap")

        self.stat_vals = {}
        self.stat_caps = {}
        self._stat_mode = "session"
        grid = QGridLayout()
        grid.setSpacing(8)
        for i, n in enumerate(["已完成局数", "我拍到", "他人拍走", "中途退出", "总成本", "净收益"]):
            v = QLabel("—")
            v.setObjectName("big")
            c = QLabel(n)
            c.setObjectName("cap")
            col = QVBoxLayout()
            col.setContentsMargins(10, 7, 10, 7)
            col.setSpacing(2)
            col.addWidget(v)
            col.addWidget(c)
            holder = QWidget()
            holder.setObjectName("statCard")
            holder.setLayout(col)
            grid.addWidget(holder, 0, i)
            self.stat_vals[n] = v
            self.stat_caps[n] = c
        sv.addLayout(grid)

        tier = QHBoxLayout()
        tier.setSpacing(8)
        tier.addWidget(self.hb_lab)
        tier.addStretch(1)
        tier.addWidget(QLabel("统计范围："))
        self.stat_btns = {}
        for key, label in (
            ("session", "本次运行"),
            ("today", "今日统计"),
            ("recent3", "近三日统计"),
            ("all", "全部统计"),
        ):
            b = QPushButton(label)
            b.setCheckable(True)
            b.setObjectName("statBtn")
            b.setMinimumHeight(28)
            b.clicked.connect(lambda _=False, k=key: self.set_stat_mode(k))
            tier.addWidget(b)
            self.stat_btns[key] = b
        # 最右边：净收益 / 总盈利 口径切换
        tier.addSpacing(12)
        self.stat_net_check = ToggleSwitch("显示净收益")
        self.stat_net_check.setObjectName("statBtn")
        self.stat_net_check.setCursor(Qt.PointingHandCursor)
        self.stat_net_check.setToolTip(
            "勾上：净收益 = 成交赚的 − 入场费 − 仪器费（到手的钱）\n"
            "不勾：总盈利 = 只看成交赚了多少（不扣成本）"
        )
        try:
            self.stat_net_check.setChecked(
                bool(self.ui_cfg.get("show_net_income", False))
            )
        except Exception:
            pass
        self.stat_net_check.toggled.connect(self._on_net_income_toggled)
        tier.addWidget(self.stat_net_check)
        sv.addLayout(tier)
        self.stat_btns["session"].setChecked(True)
        self.today_lab = QLabel("")
        self.today_lab.setObjectName("hint")
        self.today_lab.hide()  # 六格里已经有净收益了，这行省掉
        lay.insertWidget(1, statbox)  # 统计放上面，紧挨着大卡

        # 本局仓里的格子：面板上不显示了（对象留着，refresh_chest 还在往里填）
        chestbox = QGroupBox("本局仓里的格子", inner)
        cxl = QVBoxLayout(chestbox)
        cxl.setSpacing(8)
        self.chest_lab = QLabel(
            "还没数过仓 —— 开【图鉴模式】或者点【🐕 炫耀家底】之后才有"
        )
        self.chest_lab.setObjectName("hint")
        self.chest_lab.setWordWrap(True)
        cxl.addWidget(self.chest_lab)
        self.chest_grid = QGridLayout()
        self.chest_grid.setSpacing(8)
        cxl.addLayout(self.chest_grid)
        self.chest_cells = {}
        chestbox.hide()
        self.msg = QPlainTextEdit()
        self.msg.setObjectName("liveLog")
        self.msg.setReadOnly(True)
        self.msg.setMinimumHeight(96)


        # 实时输出：左边大卡，右边挂后台模式
        live = QFrame()
        live.setObjectName("liveBox")
        lv = QVBoxLayout(live)
        lv.setContentsMargins(16, 12, 16, 12)
        lv.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(8)
        _t = QLabel("实时输出")
        _t.setObjectName("liveTitle")
        head.addWidget(_t)
        head.addStretch(1)
        _all = QPushButton("查看全部 →")
        _all.setObjectName("liveMore")
        _all.setCursor(Qt.PointingHandCursor)
        _all.setToolTip("跳到「日志」页")
        _all.clicked.connect(lambda: self.nav.setCurrentRow(2))
        head.addWidget(_all)
        lv.addLayout(head)

        self.live_stack = QStackedWidget()
        self.live_empty = QLabel("等待脚本产生新事件。")
        self.live_empty.setObjectName("liveEmpty")
        self.live_empty.setAlignment(Qt.AlignCenter)
        self.live_stack.addWidget(self.live_empty)
        self.live_stack.addWidget(self.msg)
        lv.addWidget(self.live_stack, 1)

        bar = QFrame()
        bar.setObjectName("liveBar")
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(10, 5, 12, 5)
        bl.setSpacing(8)
        _dot = QLabel("●")
        _dot.setObjectName("heroDot")
        bl.addWidget(_dot, 0, Qt.AlignVCenter)
        self.live_last = QLabel("等待脚本产生新事件。")
        self.live_last.setObjectName("liveLast")
        bl.addWidget(self.live_last, 1)
        _tag = QLabel("实时")
        _tag.setObjectName("liveTag")
        bl.addWidget(_tag, 0, Qt.AlignVCenter)
        lv.addWidget(bar)

        bottom = QHBoxLayout()
        bottom.setSpacing(10)
        bottom.addWidget(live, 1)
        bgbox.setFixedWidth(360)
        # 去掉 AlignTop 还不够：QGroupBox 默认 Preferred，只"尽量"填满。
        # 显式 Expanding 才能和左边「实时输出」拉成一样高。
        bgbox.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Expanding)
        bottom.addWidget(bgbox, 0)
        # 大屏适配：窗口拉高时让这一行（实时输出 + 快捷设置）吃掉多余高度。
        # 以前这里是普通 addLayout + 末尾 addStretch，多余空间全堆到页面底部，
        # 2412×1528 的窗口上整页会空出小半屏。
        lay.addLayout(bottom, 1)
        area.setWidget(inner)
        try:
            self._make_scroll_opaque(area, inner)
        except Exception:
            pass
        _outer.addWidget(area)
        return w

    # ========================================================================
    # 拍卖辅助页：把这一仓认出来的东西摊开看，只读记录，不动出价
    # ========================================================================
    def tab_assist(self):
        self.assist = 拍卖辅助页(JSONL, colors=self._colors(),
                             on_scan=self.do_scan_once)
        return self.assist

    # 视觉报告页：把历史仓库视觉事件汇总，回答「敢不敢让视觉插嘴出价」
    def tab_vision(self):
        self.vision_report = 视觉报告页(JSONL, colors=self._colors())
        return self.vision_report

    def _flag(self, path):
        os.makedirs(REC, exist_ok=True)
        with open(path, "w", encoding="utf-8") as fp:
            fp.write(datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    # ========================================================================
    # 自动撞果盘页：配置 + 启动/停止 都在这一页
    # ========================================================================
    def tab_guopan(self):
        # 这一页内容比较多（参数 + 日志），套一层滚动区：
        # 以后再加东西也不会把按钮/输入框挤扁（窗口拉大就全部展开，不用滚）。
        w = QWidget()
        _outer = QVBoxLayout(w)
        _outer.setContentsMargins(0, 0, 0, 10)
        _inner = QWidget()
        lay = QVBoxLayout(_inner)
        t = QLabel("🍈 自动撞果盘（撞『福利多多』场地）")
        tf = t.font()
        tf.setBold(True)
        tf.setPointSize(tf.pointSize() + 2)
        t.setFont(tf)
        lay.addWidget(t)
        info = QLabel(
            "游戏1080p运行，在拍卖大厅启动脚本，会根据你设定好的时间和id自动撞福利多多和老板"
        )
        info.setObjectName("hint")
        info.setWordWrap(True)
        lay.addWidget(info)

        box = QGroupBox("自动撞果盘参数（改完点【💾 保存参数】）")
        g = QGridLayout(box)
        g.setColumnMinimumWidth(0, 250)
        self.gp_widgets = {}
        self.gp_labels = {}
        r = 0
        for key, label, kind in (
            ("NTP_TIME_SOURCE", "时间参考", "bool"),
            ("ENTER_AT_SECOND", "每分钟第几秒点【开始匹配】（留空/0=不按时间，连续撞）", "int"),
            ("WAIT_NAME_MIN", "名字至少命中几个才留下（每个允许约50%相似）", "int"),
            ("VENUE_WAIT_SEC", "房间出现后再等几秒判场地", "int"),
            ("PREP_SEC", "到点前提前几秒先「预备」", "int"),
            ("BONUS_KEEP_BID", "命中后固定出价（每回合都出，0=不出价）", "int"),
        ):
            self.gp_labels[key] = label
            lab = QLabel(label)
            lab.setMinimumWidth(250)
            g.addWidget(lab, r, 0)
            if kind == "bool":
                wd = NoWheelComboBox()
                wd.addItems(["1  (开·用联网北京时间)", "0  (关·用本机时间)"])
                try:
                    wd.setCurrentIndex(0 if read_setting(key).strip() == "1" else 1)
                except Exception:
                    pass
                wd.setFixedWidth(240)
            else:
                wd = QLineEdit(read_setting(key))
                wd.setMinimumWidth(240)
            wd.setMinimumHeight(30)
            g.addWidget(wd, r, 1, 1, 1, Qt.AlignLeft)
            self.gp_widgets[key] = (kind, wd)
            r += 1
        lay.addWidget(box)

        names_box = QGroupBox("蹲的玩家名字（最多 10 个，每框一个；全部留空=不检查）")
        names_grid = QGridLayout(names_box)
        names_grid.setHorizontalSpacing(6)
        names_grid.setVerticalSpacing(6)
        _saved_names = [
            p.strip()
            for p in re.split(r"[,，;；、\s\u3000]+", read_setting("WAIT_NAMES"))
            if p.strip()
        ][:10]
        self.gp_name_edits = []
        for i in range(10):
            wd = QLineEdit(_saved_names[i] if i < len(_saved_names) else "")
            wd.setPlaceholderText("玩家 ID %d" % (i + 1))
            wd.setMinimumHeight(30)
            wd.setMaximumWidth(170)
            names_grid.addWidget(wd, i // 5, i % 5)
            self.gp_name_edits.append(wd)
        self.gp_widgets["WAIT_NAMES"] = ("names", self.gp_name_edits)
        self.gp_labels["WAIT_NAMES"] = "要等的玩家名字"
        lay.addWidget(names_box)

        row = QHBoxLayout()
        b1 = QPushButton("💾  保存参数")
        b1.setObjectName("blue")
        b2 = QPushButton("▶  启动自动撞果盘")
        b2.setObjectName("primary")
        b3 = QPushButton("■  停止自动撞果盘")
        b3.setObjectName("danger")
        for b in (b1, b2, b3):
            b.setMinimumHeight(42)
            row.addWidget(b)
        row.addStretch(1)
        b1.clicked.connect(lambda: self.gp_save())
        b2.clicked.connect(self.gp_start)
        b3.clicked.connect(self.gp_stop)
        # 按钮行挪到滚动区外面固定住（跟参数页一致），
        # 以前它跟着内容滚，页面一长就得先滚到底才点得到保存。

        # 状态标签只保留内部状态刷新用途，不显示在三个按钮下方。
        self.gp_state = QLabel("当前状态：自动撞果盘【关】")
        gf = self.gp_state.font()
        gf.setBold(True)
        self.gp_state.setFont(gf)

        self.gp_msg = QPlainTextEdit()
        self.gp_msg.setReadOnly(True)
        self.gp_msg.setMinimumHeight(170)
        # 以前锁了 maxHeight 260，窗口再高这页也是上面一坨、下面空半屏。
        # 现在让它在滚动区里跟着长（最小 170，往上不封顶）。
        self.gp_msg.setPlainText("这里是自动撞果盘的操作结果 / 提示。")
        lay.addWidget(self.gp_msg, 1)
        self.gp_refresh_state()
        _scroll = QScrollArea()
        _scroll.setWidgetResizable(True)
        _scroll.setWidget(_inner)
        try:
            self._make_scroll_opaque(_scroll, _inner)
        except Exception:
            pass
        _outer.addWidget(_scroll)
        _outer.addLayout(row)
        return w

    def gp_write_flag(self, on):
        try:
            os.makedirs(REC, exist_ok=True)
            with open(GP_FLAG, "w", encoding="utf-8") as fp:
                fp.write("1" if on else "0")
            return True
        except Exception as e:
            try:
                self.gp_msg.setPlainText("写自动撞果盘开关文件失败：%s" % e)
            except Exception:
                pass
            return False

    def _gp_value(self, key):
        """读第⑥页自己的控件值。

        以前这里借用了第②页的 self.cfg_widgets / _cfg_value，
        可是自动撞果盘参数已经从第②页参数表里去掉了 → 保存时报 KeyError: 'NTP_TIME_SOURCE'。
        所以第⑥页必须自己读自己的控件。
        """
        kind, wd = self.gp_widgets[key]
        if kind == "bool":
            return "1" if wd.currentIndex() == 0 else "0"
        if kind == "names":
            names = [x.text().strip() for x in wd if x.text().strip()]
            return "，".join(names[:10])
        return wd.text().strip()

    def gp_save(self, quiet=False):
        pending = {}
        errors = []
        for key, (kind, _) in self.gp_widgets.items():
            text = self._gp_value(key)
            try:
                if key == "ENTER_AT_SECOND" and not text:
                    pending[key] = ""
                else:
                    base_kind = (SETTING_MAP.get(key) or ("", "", kind))[2]
                    value = typed_setting("str" if kind == "names" else base_kind, text)
                    if key == "ENTER_AT_SECOND" and not 0 <= int(value) <= 59:
                        raise ValueError("请输入 0–59 秒，或留空")
                    pending[key] = value
            except ValueError as exc:
                errors.append(f"{self.gp_labels.get(key, key)}：{exc}")
        if errors:
            QMessageBox.warning(self, "请检查参数", "\n".join(errors))
            return False
        data = dict(param_file_load(force=True))
        data.update(pending)
        if not param_file_save(data):
            QMessageBox.warning(self, "保存失败", "无法写入参数配置.json")
            return False
        if not quiet:
            self.gp_msg.setPlainText("自动撞果盘设置已保存，重新启动挂机进程后生效。")
        return True

    def gp_start(self):
        if getattr(self, "_bot_action_pending", False) or not self.gp_save(quiet=True):
            return
        sec = read_setting("ENTER_AT_SECOND")
        cadence = f"每分钟第 {sec} 秒匹配" if sec not in ("", "0") else "连续匹配"

        def start():
            why_fg = "后台模式"
            if read_setting("BACKGROUND_RUN") != "1":
                _, why_fg = 游戏提窗口(6)
            with open(GP_FLAG, "w", encoding="utf-8") as fp:
                fp.write("1")
            if bot_pids():
                self._flag(FLAG_START)
                return f"已发送开始指令。{cadence}。窗口：{why_fg}", True
            ok, msg = start_bot_process()
            if not ok:
                with open(GP_FLAG, "w", encoding="utf-8") as fp:
                    fp.write("0")
                return msg, False
            return f"{msg}\n{cadence}。窗口：{why_fg}", True

        self._background_bot_action("正在启动自动撞果盘…", start, target=self.gp_msg)

    def gp_stop(self):
        if getattr(self, "_bot_action_pending", False):
            self._stop_after_launch = True
        self.gp_write_flag(False)
        self._flag(FLAG_STOP)
        try:
            self.gp_msg.setPlainText(
                "已停止自动撞果盘，并让脚本停下（不会再点【开始匹配】）。\n"
                "想恢复原来那套正常挂机：点「控制」页的『▶ 开始挂机』。"
            )
        except Exception:
            pass
        self.gp_refresh_state()
        QTimer.singleShot(800, self.refresh_status)

    def gp_refresh_state(self):
        try:
            on = False
            try:
                with open(GP_FLAG, encoding="utf-8") as fp:
                    on = fp.read().strip() == "1"
            except Exception:
                on = False
            running, hb = self._status_running, self._status_heartbeat
            self.gp_state.setText(
                "当前状态：自动撞果盘【%s】　｜　挂机【%s】%s"
                % (
                    "开" if on else "关",
                    "运行中" if running else "没在跑",
                    ("　最近心跳 %s" % hb) if hb else "",
                )
            )
            _tc = self._colors()
            self.gp_state.setStyleSheet("color:%s;" % (_tc["warn_strong"] if on else _tc["muted"]))
        except Exception:
            pass

    def _on_hotkey(self, name):
        """面板全局热键回调（在主线程里执行）。"""
        if name == "f10":
            self.do_start()
        elif name == "f11":
            _alive = bot_alive()
            if _alive is True:
                self.do_stop()
            elif _alive is False:
                self.do_start()
        elif name == "f12":
            self.do_kill()

    def _start_hotkey_poll(self):
        """全局热键 F10/F11/F12：挂在面板进程上，用 GetAsyncKeyState 轮询。

        只要面板开着，无论哪个窗口在前台、无论脚本跑没跑，按键都生效
        （GetAsyncKeyState 读系统键状态，不受焦点/管理员窗口影响）。
        """
        import ctypes as _ct
        import threading as _th
        import time as _time
        _vk = {"f10": 0x79, "f11": 0x7A, "f12": 0x7B}
        _state = {k: False for k in _vk}

        def _loop():
            while True:
                try:
                    for _name, _code in _vk.items():
                        _down = bool(_ct.windll.user32.GetAsyncKeyState(_code) & 0x8000)
                        if _down and not _state[_name]:
                            _state[_name] = True
                            try:
                                self._hotkey.emit(_name)
                            except Exception as _exc:
                                print("⚠️ 面板热键 %s 处理出错: %s" % (_name.upper(), _exc))
                        elif not _down and _state[_name]:
                            _state[_name] = False
                except Exception:
                    pass
                _time.sleep(0.08)

        try:
            _th.Thread(target=_loop, daemon=True, name="panel-hotkey-poll").start()
            print("⌨️ 面板全局热键已启用（F10 开始 / F11 暂停继续 / F12 彻底停止）")
        except Exception as _exc:
            print("⚠️ 面板热键启动失败: %s" % _exc)

    def _background_bot_action(self, pending_label, action, target=None):
        if getattr(self, "_bot_action_pending", False):
            return
        self._bot_action_pending = True
        self.hero_state.setText(pending_label)
        for button in self.bot_action_buttons:
            button.setEnabled(False)

        def finish(text, ok):
            self._bot_action_pending = False
            for button in self.bot_action_buttons:
                button.setEnabled(True)
            self.hero_state.setText("等待状态更新" if ok else "操作未完成")
            if getattr(self, "_stop_after_launch", False):
                self._stop_after_launch = False
                self.do_kill()
            else:
                self.refresh_status()

        self._run_bg(action, self.msg if target is None else target, finish, raise_panel=False)

    def do_start(self):
        self._background_bot_action("正在启动…", self._do_start_inner)

    def _do_start_inner(self):
        why_fg = "后台模式"
        if read_setting("BACKGROUND_RUN") != "1":
            _, why_fg = 游戏提窗口(6)
        try:
            with open(GP_FLAG, encoding="utf-8") as fp:
                if fp.read().strip() == "1":
                    with open(GP_FLAG, "w", encoding="utf-8") as flag:
                        flag.write("0")
        except OSError:
            pass
        running = (_BOT_PROC is not None and _BOT_PROC.poll() is None) or bool(bot_pids())
        if running:
            self._flag(FLAG_START)
            return f"已发送开始指令。窗口：{why_fg}", True
        ok, msg = start_bot_process()
        return f"{msg}\n窗口：{why_fg}", ok

    def do_stop(self):
        self._flag(FLAG_STOP)
        self.hero_state.setText("已请求停止")
        self.msg.setPlainText("已发送停止请求，等待脚本在安全位置停下。")

    def do_kill(self):
        if getattr(self, "_bot_action_pending", False):
            self._stop_after_launch = True
            self.hero_state.setText("启动操作完成后停止…")
            return

        def stop():
            pids = bot_pids(fresh=True)
            failed = []
            for pid in pids:
                result = subprocess.run(["taskkill", "/PID", str(pid), "/F"],
                                        capture_output=True, timeout=10, creationflags=NO_WINDOW)
                if result.returncode:
                    failed.append(str(pid))
            if failed:
                return "未能停止进程：" + "、".join(failed), False
            return ("已停止挂机进程。" if pids else "脚本当前未运行。"), True
        self._background_bot_action("正在停止…", stop)

    def do_selftest(self):
        self.msg.setPlainText("正在跑自检，大约 1~3 分钟…")

        def job():
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            r = subprocess.run(
                [PY, SELFTEST_PY],
                cwd=BASE,
                capture_output=True,
                env=env,
                timeout=300,
                creationflags=NO_WINDOW,
            )

            def decode_lines(raw):
                decoded = []
                for line in (raw or b"").splitlines(keepends=True):
                    try:
                        decoded.append(line.decode("utf-8"))
                    except UnicodeDecodeError:
                        try:
                            decoded.append(line.decode("gb18030"))
                        except UnicodeDecodeError:
                            decoded.append(line.decode("utf-8", errors="replace"))
                return "".join(decoded)

            out = decode_lines(r.stdout) + decode_lines(r.stderr)
            lines = out.strip().splitlines()
            fail_lines = []
            for line in lines:
                text = line.strip()
                if text.startswith("FAIL ") or text.startswith("未通过:"):
                    if text not in fail_lines:
                        fail_lines.append(text)
            ok = r.returncode == 0
            if ok:
                head = "✅ 自检通过"
            else:
                head = "❌ 自检没通过"
                if fail_lines:
                    head += "\n\n失败项：\n" + "\n".join(fail_lines[:12])
                else:
                    head += (
                        "\n\n没有捕获到明确的 FAIL 行，自检进程异常结束"
                        "（退出码 %s）。" % r.returncode
                    )
            tail = "\n".join(lines[-24:]) or "没有返回输出"
            report_path = ""
            try:
                report_day = datetime.datetime.now().strftime("%Y%m%d")
                report_dir = os.path.join(REC, "日志", report_day)
                os.makedirs(report_dir, exist_ok=True)
                report_name = datetime.datetime.now().strftime("自检报告_%Y%m%d_%H%M%S.log")
                report_path = os.path.join(report_dir, report_name)
                with open(report_path, "w", encoding="utf-8") as fp:
                    fp.write(head + "\n\n完整输出：\n" + out)
            except Exception:
                report_path = ""
            result = head + "\n\n自检输出：\n" + tail
            if report_path:
                result += "\n\n完整报告：" + report_path
            return result, ok

        self._run_bg(job, self.msg)

    def closeEvent(self, event):  # noqa: N802 (Qt 命名)
        """关面板时记住窗口大小：下次打开还是这个大。"""
        try:
            self.ui_cfg["window_size"] = [int(self.width()), int(self.height())]
            _p = self.pos()
            if _p.x() > -10000 and _p.y() > -10000:
                self.ui_cfg["window_pos"] = [int(_p.x()), int(_p.y())]
            save_ui_cfg(self.ui_cfg)
        except Exception:
            pass
        try:
            super().closeEvent(event)
        except Exception:
            pass

    def do_check_update(self, silent=False):
        """检查有没有新版本。

        按钮三种状态：
          · 没查过 / 查失败 → 「检查更新」
          · 已是最新       → 「大肥鱼standby<版本号>」（点一下可重新检查）
          · 有新版本       → 「⬆️ 更新到0.3」（高亮，点一下自动下载安装并重启）

        silent=True 是启动时的静默检查：不写「实时输出」，也不报错弹字，只改按钮文案。
        """
        pending = getattr(self, "_pending_update", None)
        if pending:
            remote = str(pending.get("remote") or "")
            # ① 挂机还在跑 → 「更新失败」提示窗（只有确定）
            try:
                _running = bool(bot_pids(fresh=True))
            except Exception:
                _running = False
            if _running:
                self._update_dialog(
                    "更新失败",
                    "更新失败",
                    "当前脚本正在运行中，请彻底停止脚本后再进行更新。",
                    "确定",
                )
                return
            # ② 没在跑 → 「确认更新」窗（更新 / 取消）
            _pkg = str(pending.get("package_url") or "")
            if not _pkg:
                _urls = pending.get("package_urls") or []
                _pkg = str(_urls[0]) if _urls else ""
            if not _pkg and not (pending.get("has_exe_update") and os.environ.get("DFY_EXE_PATH")):
                self.msg.setPlainText("清单里没写下载地址，作者还没把安装包传上去。")
                return
            if not self._update_dialog(
                "确认更新",
                "确认更新",
                "确认是否更新到 %s 版本？\n更新会先备份旧版本；你的参数配置和对局记录都不会被改动。"
                % remote,
                "更新",
                "取消",
            ):
                return
            self._apply_update(pending)
            return
        if not os.path.isfile(UPDATE_CHECK_PY):
            if not silent:
                self.msg.setPlainText(
                    "❌ 缺少 程序\\更新检查.py，没法检查更新。\n\n"
                    "（这一版更新包应该带上它；如果是从很旧的版本覆盖上来的，"
                    "确认一下 程序 文件夹是整包覆盖的）"
                )
            return
        if not silent:
            self.msg.setPlainText("正在检查更新…")
            self._set_update_btn("checking", "检查更新…")
        self._update_has_new = False
        self._update_remote = ""
        self._update_failed = False
        self._update_error = ""

        def job():
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            try:
                r = subprocess.run(
                    [PY, UPDATE_CHECK_PY, "--json"],
                    cwd=BASE,
                    capture_output=True,
                    env=env,
                    timeout=45,
                    creationflags=NO_WINDOW,
                )
            except subprocess.TimeoutExpired:
                self._update_error = "检查超时（45 秒没响应），多半是网络问题"
                return (
                    "⏱️ 检查更新超时（45 秒没响应）。\n\n"
                    "多半是网络问题，或者 程序\\更新地址.json 里的地址连不上。",
                    False,
                )
            except Exception as e:
                self._update_error = "检查没能启动：%s" % e
                return f"❌ 检查更新没能启动：{e}", False

            out = decode_process_output(r.stdout).strip()
            payload = None
            for line in reversed(out.splitlines()):
                text = line.strip()
                if text.startswith("{"):
                    try:
                        payload = json.loads(text)
                        break
                    except Exception:
                        continue
            if not isinstance(payload, dict):
                err = decode_process_output(r.stderr).strip()
                return (
                    "❌ 检查更新返回了看不懂的内容。\n\n"
                    + (out or err or "（没有任何输出）"),
                    False,
                )

            local = str(payload.get("local") or "?")
            remote = str(payload.get("remote") or "")
            notes = payload.get("notes") or []
            if not payload.get("ok"):
                self._update_failed = True
                self._update_error = str(payload.get("error") or "未知错误")
                return (
                    f"❌ 检查失败（当前 {APP_DISPLAY}）\n\n"
                    + str(payload.get("error") or "未知错误"),
                    False,
                )
            self._update_has_new = bool(payload.get("has_new"))
            self._update_remote = remote
            if payload.get("has_new"):
                lines = [f"🆕 有新版本：{APP_DISPLAY} → {APP_DISPLAY_BASE}{remote}"]
                if payload.get("published_at"):
                    lines.append(f"发布时间：{payload['published_at']}")
                if notes:
                    lines.append("\n这一版更新内容：")
                    lines.extend(f"  · {n}" for n in notes)
                _urls = payload.get("package_urls") or []
                pkg = str(payload.get("package_url") or (_urls[0] if _urls else ""))
                if pkg or (payload.get("has_exe_update") and os.environ.get("DFY_EXE_PATH")):
                    # 记下来：按钮变成「⬆️ 更新到0.3」，再点一次就全自动装好
                    self._pending_update = payload
                    lines.append(
                        "\n要现在更新的话，点左下角那个「⬆️ 更新到%s」就行。" % remote
                    )
                    lines.append("（自动下载 → 校验 → 备份旧版 → 覆盖 → 自动重启面板；"
                                 "你的参数和对局记录不会被改）")
                else:
                    lines.append("\n（清单里没写下载地址，作者还没把包传上去）")
                return "\n".join(lines), True
            return f"✅ 已是最新版本（{APP_DISPLAY}）", True

        def after(text, _ok):
            if getattr(self, "_update_failed", False):
                # 检查失败也显示版本号（可点重试），别一直挂着「检查更新」让人以为没查
                self._set_update_btn("failed", APP_DISPLAY)
            elif getattr(self, "_update_has_new", False):
                r = str(getattr(self, "_update_remote", "") or "")
                self._set_update_btn("new", ("⬆️ 更新到%s" % r) if r else "⬆️ 有新版本")
            else:
                self._set_update_btn("latest", APP_DISPLAY)

        self._run_bg(job, None if silent else self.msg, after)

    def _update_dialog(self, win_title, heading, text, ok_text, cancel_text=None):
        """更新相关的小弹窗：风格跟「设置」窗口一致，但更矮。

        返回 True = 用户点了主按钮（确定/更新）；False = 取消/关闭。
        """
        dlg = QDialog(self)
        dlg.setWindowTitle(str(win_title or "提示"))
        dlg.setObjectName("settingsDialog")
        dlg.setMinimumWidth(430)
        v = QVBoxLayout(dlg)
        v.setContentsMargins(22, 16, 22, 14)
        v.setSpacing(8)
        t = QLabel(str(heading or win_title or "提示"))
        t.setObjectName("big")
        v.addWidget(t)
        tip = QLabel(str(text or ""))
        tip.setObjectName("cap")
        tip.setWordWrap(True)
        v.addWidget(tip)
        v.addSpacing(4)
        btns = QHBoxLayout()
        btns.setSpacing(10)
        btns.addStretch(1)
        ok = QPushButton(str(ok_text or "确定"))
        ok.setObjectName("primary")
        ok.setMinimumWidth(96)
        ok.setMinimumHeight(34)
        ok.setCursor(Qt.PointingHandCursor)
        ok.clicked.connect(dlg.accept)
        if cancel_text:
            cancel = QPushButton(str(cancel_text))
            cancel.setMinimumWidth(84)
            cancel.setMinimumHeight(34)
            cancel.setCursor(Qt.PointingHandCursor)
            cancel.clicked.connect(dlg.reject)
            btns.addWidget(cancel)
        btns.addWidget(ok)
        v.addLayout(btns)
        try:
            return dlg.exec_() == QDialog.Accepted
        except Exception:
            return False

    def _apply_update(self, payload):
        """真的下载并覆盖。这是唯一会改动文件的动作，所以先确认再动手。"""
        remote = str(payload.get("remote") or "")
        if not os.path.isfile(UPDATE_APPLY_PY):
            self.msg.setPlainText(
                "❌ 缺少 程序\\更新下载.py，没法自动更新。\n\n"
                "去群里下一个更新包，手动解压覆盖「程序」文件夹。"
            )
            self._reset_update_btn()
            return
        try:
            if bot_pids(fresh=True):
                self.msg.setPlainText(
                    "⏸️ 挂机脚本还在运行，不能更新。\n\n"
                    "请先点左边栏的【⏹ 彻底停止脚本】，等挂机窗口消失、"
                    "确认没有 paimai 进程之后再点更新。\n\n"
                    "（现在什么都没动，随时可以重试；更新脚本自己也会再检查一次）"
                )
                self._reset_update_btn()
                return
        except Exception:
            pass

        self._set_update_btn("checking", "正在更新…")
        self.msg.setPlainText(f"正在更新到 v{remote}…\n下载并校验完成后，会自动重启面板。")

        def job():
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"
            env["DFY_UPDATE_PANEL_PID"] = str(os.getpid())
            try:
                r = subprocess.run(
                    [PY, UPDATE_APPLY_PY, "--apply"],
                    cwd=BASE,
                    capture_output=True,
                    env=env,
                    timeout=600,
                    creationflags=NO_WINDOW,
                )
            except subprocess.TimeoutExpired:
                return "⏱️ 更新超时（10 分钟）。检查一下网络，然后重新点检查更新。", False
            except Exception as e:
                return f"❌ 更新没能启动：{e}", False
            out = (decode_process_output(r.stdout) + decode_process_output(r.stderr)).strip()
            tail = "\n".join(out.splitlines()[-18:]) or "（没有输出）"
            if r.returncode == 10:
                return "更新已准备就绪，正在关闭旧窗口并打开新版…", True
            if r.returncode == 0:
                return tail, False
            return "❌ 更新未完成。\n\n" + tail, False

        def after(_text, ok):
            self._pending_update = None
            if ok:
                QApplication.instance().quit()
            else:
                self._set_update_btn("check", "检查更新")

        self._run_bg(job, self.msg, after)

    def _restart_self(self):
        """更新完成后重启面板：先拉起一个新的自己，再退出当前进程。

        注意：必须用 pythonw.exe（无控制台）+ CREATE_NO_WINDOW + 输出丢弃，
        否则 python.exe 会弹出一个黑窗口，而面板就跑在那个黑窗里，关不掉也难看。
        """
        try:
            if FROZEN:
                cmd = [sys.executable]
            else:
                ui_py = os.path.join(SELF_DIR, "界面.py")
                if not os.path.isfile(ui_py):
                    return
                _pyw = os.path.join(PY_DIR, "pythonw.exe")
                if os.path.isfile(_pyw):
                    _exe = _pyw
                elif os.path.isfile(PY):
                    _exe = PY
                else:
                    _exe = sys.executable
                cmd = [_exe, ui_py]
            subprocess.Popen(
                cmd,
                cwd=BASE,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=(
                    getattr(subprocess, "CREATE_NO_WINDOW", 0)
                    | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
                ),
            )
        except Exception as e:
            try:
                self.msg.setPlainText("⚠️ 自动重启失败（%s），请手动关掉面板再打开。" % e)
            except Exception:
                pass
            return
        try:
            self._live_timer.stop()
        except Exception:
            pass
        try:
            QApplication.instance().quit()
        except Exception:
            os._exit(0)

    def _set_update_btn(self, kind, text):
        """侧栏「检查更新 / 大肥鱼standby<版本> / ⬆️ 更新到<新版本>」几种样子。

        · latest  已是最新 → 直接显示版本号，**不可点击**（灰）
        · new     有新版本 → 高亮可点
        · failed  检查失败 → 仍显示版本号，但可点（点一下重试），tooltip 写原因
        · checking 正在检查 → 灰、不可点
        """
        self._update_state = str(kind or "latest")
        try:
            btn = self.check_update_btn
        except Exception:
            btn = getattr(self, "update_btn", None)
        if btn is None:
            return
        try:
            btn.setText(str(text or APP_DISPLAY))
            if self._update_state == "new":
                btn.setEnabled(True)
                btn.setStyleSheet(
                    "QPushButton{background:#22d3ee; border:none; border-radius:8px;"
                    " color:#0d1117; font-weight:700; text-align:left; padding-left:12px;}"
                    "QPushButton:hover{background:#16bcd4;}"
                )
                btn.setCursor(Qt.PointingHandCursor)
                btn.setToolTip("点击立即下载并安装新版（装完自动重启面板）")
            elif self._update_state == "failed":
                btn.setEnabled(True)
                btn.setStyleSheet(
                    "QPushButton#setNav{color:#96a1b4;}"
                    "QPushButton#setNav:hover{color:#e8eef8;}"
                )
                btn.setCursor(Qt.PointingHandCursor)
                _why = str(getattr(self, "_update_error", "") or "连不上更新服务器").strip()
                btn.setToolTip("上次检查失败：%s\n点一下重试" % _why[:200])
            elif self._update_state == "checking":
                btn.setEnabled(False)
                btn.setStyleSheet(
                    "QPushButton#setNav{color:#5a6478;}"
                    "QPushButton#setNav:hover{color:#5a6478;}"
                )
                btn.setCursor(Qt.ArrowCursor)
                btn.setToolTip("正在检查新版本…")
            else:  # latest：已是最新，显示版本号，不可点
                btn.setEnabled(False)
                btn.setStyleSheet(
                    "QPushButton#setNav{color:#7f8ba0;}"
                    "QPushButton#setNav:hover{color:#7f8ba0; background:transparent;}"
                )
                btn.setCursor(Qt.ArrowCursor)
                btn.setToolTip("当前已是最新版本（%s）" % text)
        except Exception:
            pass

    def _maybe_show_whats_new(self):
        """Show unread releases in a fixed-size dialog."""
        seen = str(self.ui_cfg.get("notes_version") or "").strip()
        if seen == str(APP_VERSION):
            return
        transition = os.path.join(REC, "更新", "升级版本.json")
        previous = previous_upgrade_version(transition, APP_VERSION) or seen
        notes = release_notes_between(previous, APP_VERSION)
        if not notes:
            return

        dialog = QDialog(self)
        dialog.setWindowTitle(f"更新说明（{APP_DISPLAY}）")
        dialog.setFixedSize(560, 420)
        layout = QVBoxLayout(dialog)
        layout.addWidget(QLabel(f"{previous} → {APP_VERSION}" if previous else f"版本 {APP_VERSION}"))
        content = QPlainTextEdit(dialog)
        content.setReadOnly(True)
        content.setPlainText("\n\n".join(
            f"v{version}\n" + "\n".join(f"• {note}" for note in entries)
            for version, entries in notes
        ))
        content.moveCursor(content.textCursor().Start)
        layout.addWidget(content, 1)
        close = QPushButton("知道了", dialog)
        close.setDefault(True)
        close.clicked.connect(dialog.accept)
        layout.addWidget(close, 0, Qt.AlignRight)
        dialog.exec_()

        self.ui_cfg["notes_version"] = str(APP_VERSION)
        save_ui_cfg(self.ui_cfg)

    def _auto_check_update(self):
        """启动 2.5 秒后的静默检查：只改按钮文案，不打扰用户。"""
        try:
            if not bool(self.ui_cfg.get("auto_check_update", True)):
                return
            if getattr(self, "_pending_update", None):
                return
            self.do_check_update(silent=True)
        except Exception:
            pass

    def _reset_update_btn(self):
        self._set_update_btn("latest", APP_DISPLAY)

    def do_dog_grid(self):
        if bot_pids():
            self.msg.setPlainText(
                "❌ 挂机脚本正在运行。为避免抢仓库滚动条、影响对局，"
                "请先点【停止挂机】并等当前局结束，再生成炫耀家底。"
            )
            return
        ok, why = 游戏提窗口(3)
        if not ok:
            self.msg.setPlainText("❌ 炫耀家底生成失败：%s\n请先打开异环并进入藏品仓库页面。" % why)
            return
        if not os.path.isfile(DOG_GRID_PY):
            self.msg.setPlainText("❌ 缺少程序\\狗叫图生成.py，请确认安装完整。")
            return
        self.msg.setPlainText(
            "🐕 正在完整翻仓并拼接图片…\n"
            "请保持游戏停在藏品仓库页面，生成期间不要操作仓库。\n"
            "完成后图片会保存到点我启动.bat 所在文件夹。"
        )

        def job():
            import time as _time

            started = _time.time()
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"
            env["EVILNTE_DOG_STATUS"] = DOG_STATUS_FILE
            try:
                if os.path.exists(DOG_STATUS_FILE):
                    os.remove(DOG_STATUS_FILE)
            except Exception:
                pass
            try:
                r = subprocess.run(
                    [PY, DOG_GRID_PY],
                    cwd=BASE,
                    capture_output=True,
                    env=env,
                    timeout=180,
                    creationflags=NO_WINDOW,
                )
                out = (decode_process_output(r.stdout) + decode_process_output(r.stderr)).strip()
                return_code = r.returncode
            except subprocess.TimeoutExpired as e:
                out = (decode_process_output(e.stdout) + decode_process_output(e.stderr)).strip()
                return_code = -9
            status = {}
            try:
                with open(DOG_STATUS_FILE, encoding="utf-8") as fp:
                    status = json.load(fp)
            except Exception:
                status = {}

            ok_img, path, detail = resolve_dog_generation_result(
                return_code, out, status, started, BASE
            )
            if ok_img:
                note = ("\n\n注意：%s" % detail) if detail else ""
                return (
                    "✅ 炫耀家底生成完成\n\n%s\n\n"
                    "图片已保存到点我启动.bat 所在文件夹。%s" % (path, note),
                    True,
                )

            return "❌ 炫耀家底生成失败\n\n%s" % detail, False

        self._run_bg(job, self.msg)

    def do_scan_once(self):
        """不挂机扫一次仓：翻整仓 → 识别 → 往试验记录追一条。

        跟「炫耀家底」一样的子进程套路，区别是它会把结果写进
        试验记录.jsonl，所以扫完【拍卖辅助】页就有数了。
        """

        def bail(msg):
            try:
                self.assist.set_scanning(False)
                self.assist.flash(msg)
            except Exception:
                pass

        try:
            if bot_pids():
                bail("挂机正在跑，翻仓会跟它对抢鼠标 —— 先点【停止挂机】")
                return
            ok, why = 游戏提窗口(3)
            if not ok:
                bail("找不到异环窗口：%s\n先把游戏打开、停在藏品仓库页" % why)
                return
            if not os.path.isfile(SCAN_PY):
                bail("缺少程序\\扫一次仓.py，确认安装完整")
                return
        except Exception as e:
            bail("扫仓起不来：%s" % e)
            return

        try:
            self.assist.flash("正在翻整仓… 别动仓库、别切窗口")
        except Exception:
            pass

        def job():
            env = os.environ.copy()
            env["PYTHONIOENCODING"] = "utf-8"
            env["PYTHONUTF8"] = "1"
            env["PYTHONUNBUFFERED"] = "1"
            env["EVILNTE_SCAN_STATUS"] = SCAN_STATUS_FILE
            try:
                if os.path.exists(SCAN_STATUS_FILE):
                    os.remove(SCAN_STATUS_FILE)
            except Exception:
                pass
            try:
                r = subprocess.run(
                    [PY, SCAN_PY],
                    cwd=BASE,
                    capture_output=True,
                    env=env,
                    timeout=240,
                    creationflags=NO_WINDOW,
                )
                out = (decode_process_output(r.stdout)
                       + decode_process_output(r.stderr)).strip()
                return_code = r.returncode
            except subprocess.TimeoutExpired as e:
                out = (decode_process_output(e.stdout)
                       + decode_process_output(e.stderr)).strip()
                return_code = -9
            status = {}
            try:
                with open(SCAN_STATUS_FILE, encoding="utf-8") as fp:
                    status = json.load(fp)
            except Exception:
                status = {}
            if status.get("ok"):
                s = status.get("summary") or {}
                return (
                    "📸 扫完了：%d 件，认出 %d｜最低 %s / 均值 %s / P75 %s｜校验%s"
                    % (
                        int(s.get("block_count") or 0),
                        int(s.get("named_count") or 0),
                        "{:,}".format(int(s.get("min_total") or 0)),
                        "{:,}".format(int(s.get("mean_total") or 0)),
                        "{:,}".format(int(s.get("p75_total") or 0)),
                        "通过" if s.get("checksum_ok") else "没过",
                    ),
                    True,
                )
            detail = status.get("error") or out[-600:] or ("退出码 %s" % return_code)
            return "❌ 扫仓失败：%s" % detail, False

        import threading

        self._scan_worker = Worker(job)
        self._scan_worker.done.connect(self._on_scan_done)
        threading.Thread(target=self._scan_worker.run, daemon=True).start()

    def _on_scan_done(self, text, ok):
        try:
            self.assist.set_scanning(False)
        except Exception:
            pass
        try:
            self.assist.flash(text.splitlines()[0] if ok else text)
        except Exception:
            pass
        if ok:
            try:
                self.assist.refresh()
            except Exception:
                pass
        try:
            self.msg.setPlainText(text)
        except Exception:
            pass

    def _run_bg(self, fn, target, on_done=None, *, raise_panel=True):
        import threading

        worker = Worker(fn)
        self._workers.add(worker)

        def _finish(text, ok):
            self._workers.discard(worker)
            try:
                if target is not None:
                    target.setPlainText(text)
            except Exception:
                pass
            if on_done is not None:
                try:
                    on_done(text, ok)
                except Exception:
                    pass
            if raise_panel:
                self.back_to_front()

        worker.done.connect(_finish)
        threading.Thread(target=worker.run, daemon=True).start()

    def back_to_front(self):
        try:
            self.raise_()
            self.activateWindow()
            import win32api
            import win32con
            import win32gui

            hwnd = int(self.winId())
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            win32api.keybd_event(win32con.VK_MENU, 0, 0, 0)
            win32api.keybd_event(win32con.VK_MENU, 0, win32con.KEYEVENTF_KEYUP, 0)
            win32gui.SetForegroundWindow(hwnd)
        except Exception:
            pass

    def set_stat_mode(self, mode):
        self._stat_mode = mode
        for k, b in getattr(self, "stat_btns", {}).items():
            b.setChecked(k == mode)
        self.refresh_status()

    def _on_net_income_toggled(self, checked):
        """切换「净收益 / 总盈利」口径，顺手记进界面设置。

        净收益 = 成交赚的 − 入场费 − 仪器费（真正到手的）
        总盈利 = 只看成交赚了多少（不扣成本）
        """
        try:
            self.ui_cfg["show_net_income"] = bool(checked)
            save_ui_cfg(self.ui_cfg)
        except Exception:
            pass
        try:
            self.refresh_status()
        except Exception:
            pass

    def refresh_status(self):
        if self._status_busy:
            return
        import threading

        self._status_busy = True
        mode = getattr(self, "_stat_mode", "session")

        def read():
            try:
                running, hb, _ = last_stats()
                if running and bot_alive() is False:
                    running = False
                stats, label = stats_range(mode, PANEL_SESSION_START)
                self._status_ready.emit((mode, running, hb, stats, label))
            except Exception:
                self._status_ready.emit(None)

        threading.Thread(target=read, daemon=True).start()

    def _apply_status_snapshot(self, payload):
        self._status_busy = False
        if payload is None:
            return
        mode, running, hb, stats, label = payload
        if mode != getattr(self, "_stat_mode", "session"):
            self.refresh_status()
            return
        was_running = self._status_running
        self._status_running = running
        self._status_heartbeat = hb
        status = "正在挂机" if running else "未运行"
        if self.status_lab.text() != "状态：" + status:
            self.status_lab.setText("状态：" + status)
        if not getattr(self, "_bot_action_pending", False):
            if not running:
                self.hero_state.setText("吃大米饭中")
            elif not was_running or self.hero_state.text() == "等待状态更新":
                self.hero_state.setText("正在挂机")
        self.hb_lab.setText(("最近心跳 %s" % hb) if hb else "")
        self._sync_live()
        try:
            self.today_lab.setText("统计范围：%s" % label)
        except Exception:
            pass
        self.stat_vals["已完成局数"].setText(str(stats.get("auctions", 0)))
        self.stat_vals["我拍到"].setText(str(stats.get("won", 0)))
        self.stat_vals["他人拍走"].setText(str(stats.get("lost", 0)))
        self.stat_vals["中途退出"].setText(str(stats.get("quit", 0)))
        self.stat_vals["总成本"].setText("{:,}".format(stats.get("cost", 0)))
        # 最后一格：勾了显示净收益（扣成本），没勾显示总盈利（不扣成本）
        try:
            _show_net = bool(self.stat_net_check.isChecked())
        except Exception:
            _show_net = False
        _metric = "net_profit" if _show_net else "profit"
        _caption = "净收益" if _show_net else "总盈利"
        _val = stats.get(_metric, 0)
        # 内部键固定叫「净收益」，只换标题文字和数字，别让字典键跟着变
        self.stat_vals["净收益"].setText("{:+,}".format(_val))
        try:
            self.stat_caps["净收益"].setText(_caption)
        except Exception:
            pass
        _tc = self._colors()
        self.stat_vals["净收益"].setStyleSheet(
            "color:%s;" % (_tc["up"] if _val >= 0 else _tc["down"])
        )
        if self.stack.currentIndex() == 5:
            self.gp_refresh_state()
        elif self.stack.currentIndex() == 0:
            self.refresh_chest()

    def refresh_chest(self):
        """读 记录\仓计数.json，把各档几块铺成小格子。"""
        if not hasattr(self, "chest_lab"):
            return
        路径 = os.path.join(BASE, "记录", "仓计数.json")
        if not os.path.isfile(路径):
            return
        try:
            with open(路径, encoding="utf-8") as fh:
                数据 = json.load(fh)
        except Exception:
            return
        if not isinstance(数据, dict):
            return
        各档 = 数据.get("各档") or []
        if not isinstance(各档, list) or not 各档:
            return
        组合 = (数据.get("时间", ""), int(数据.get("局号") or 0), 各档)
        if getattr(self, "_chest_seen", None) == 组合:
            return
        for w in list(self.chest_cells.values()):
            self.chest_grid.removeWidget(w)
            w.deleteLater()
        self.chest_cells = {}
        图 = {"红": "#e06b8b", "金": "#d9a13b", "紫": "#8f7bd8", "蓝": "#5b9bd5"}
        for i, 行 in enumerate(各档):
            名字 = str(行.get("品质", "?"))
            格数 = int(行.get("格数") or 0)
            单价 = int(行.get("单价") or 0)
            小计 = int(行.get("小计") or 0)
            卡 = QWidget()
            卡.setObjectName("statCard")
            竖 = QVBoxLayout(卡)
            竖.setContentsMargins(12, 8, 12, 8)
            竖.setSpacing(2)
            大字 = QLabel("%s × %d 格" % (名字, 格数))
            大字.setObjectName("big")
            大字.setStyleSheet("color:%s;" % 图.get(名字, "#888"))
            小字 = QLabel(
                ("单价 {:,}".format(单价)) + ("　小计 {:,}".format(小计) if 单价 else "")
            )
            小字.setObjectName("cap")
            竖.addWidget(大字)
            竖.addWidget(小字)
            self.chest_grid.addWidget(卡, 0, i)
            self.chest_cells[名字] = 卡
        合计 = int(数据.get("总估值") or 0)
        几格 = int(数据.get("总格数") or 0)
        self.chest_lab.setText(
            "第 %d 局　%s　共 %d 格，按图鉴中位数估值 %s"
            % (int(数据.get("局号") or 0), 数据.get("时间", ""), 几格,
               "{:,}".format(合计))
        )
        self._chest_seen = 组合

    def tab_config(self):
        w = QWidget()
        outer = QVBoxLayout(w)
        outer.setSpacing(12)
        top = QLabel(
            "保存后，鼠标让行立即生效，清仓设置在相应步骤重新读取。其他参数需重启挂机进程。\n"
            "一共一百多项，默认只露常用的十几项；想看全就点掉「只看常用」，或者直接搜。"
        )
        top.setObjectName("hint")
        outer.addWidget(top)

        # 模式选择：原来跟价 / 档位两套，现在并成一套，这里就一个标题 + 说明
        pick = QWidget()
        pick.setObjectName("pickCard")
        pick_lay = QVBoxLayout(pick)
        pick_lay.setContentsMargins(14, 12, 14, 12)
        pick_lay.setSpacing(8)

        head = QHBoxLayout()
        head.setSpacing(10)
        _t = QLabel("出价策略")
        _t.setObjectName("pickTitle")
        _tf = _t.font()
        _tf.setBold(True)
        _tf.setPointSize(_tf.pointSize() + 3)
        _t.setFont(_tf)
        head.addWidget(_t)
        head.addStretch(1)
        self.cfg_assist_btn = QPushButton("📦  拍卖辅助 →")
        self.cfg_assist_btn.setObjectName("statBtn")
        self.cfg_assist_btn.setMinimumHeight(32)
        self.cfg_assist_btn.setMinimumWidth(126)
        self.cfg_assist_btn.setCursor(Qt.PointingHandCursor)
        self.cfg_assist_btn.setToolTip("看这一仓值多少：估值三档、认了多少、逐件清单。看不看随你，不影响挂机。")
        self.cfg_assist_btn.clicked.connect(lambda: self.nav.setCurrentRow(6))
        head.addWidget(self.cfg_assist_btn)
        pick_lay.addLayout(head)

        self.mode_hint = QLabel(MODE_HINT.get("opponent", ""))
        self.mode_hint.setObjectName("pickSub")
        self.mode_hint.setWordWrap(True)
        pick_lay.addWidget(self.mode_hint)
        outer.addWidget(pick)
        # 参数页 100 多项，找一项要滚半天：加搜索框 + 分组折叠
        self._cfg_collapsed = getattr(self, "_cfg_collapsed", set())
        self._cfg_rows = []
        srow = QHBoxLayout()
        srow.setSpacing(8)
        self.cfg_search = QLineEdit()
        self.cfg_search.setPlaceholderText("搜索参数，例如：保底价、后台、清仓")
        self.cfg_search.setClearButtonEnabled(True)
        self._cfg_search_timer = QTimer(self)
        self._cfg_search_timer.setSingleShot(True)
        self._cfg_search_timer.timeout.connect(self._apply_cfg_filter)
        self.cfg_search.textChanged.connect(lambda *_: self._cfg_search_timer.start(120))
        srow.addWidget(self.cfg_search, 1)
        self.cfg_all_btn = QPushButton("全部收起")
        self.cfg_all_btn.setObjectName("cfgAll")
        self.cfg_all_btn.setMinimumHeight(32)
        self.cfg_all_btn.clicked.connect(self._toggle_all_cfg_groups)
        srow.addWidget(self.cfg_all_btn)
        self.cfg_common = ToggleSwitch("只看常用")
        self.cfg_common.setChecked(True)
        self.cfg_common.setToolTip("一共一百多项，勾着只显示日常会调的那十几项；"
                                   "想全部看到就把它点掉，或者直接搜")
        self.cfg_common.toggled.connect(lambda *_: self._apply_cfg_filter())
        srow.addWidget(self.cfg_common)
        outer.addLayout(srow)
        area = QScrollArea()
        area.setWidgetResizable(True)
        try:
            from PyQt5.QtWidgets import QAbstractScrollArea
            # 大肥鱼：按像素滚动（滚轮一格挪一小段），比按行跳更顺、更不容易掉帧
            area.setVerticalScrollMode(QAbstractScrollArea.ScrollPerPixel)
            area.viewport().setAutoFillBackground(False)
        except Exception:
            pass
        self.cfg_area = area
        self.cfg_widgets = {}
        self._cfg_imported = {}
        outer.addWidget(area)
        self.rebuild_hint()
        self.rebuild_config()
        row = QHBoxLayout()
        save = QPushButton("💾  保存参数")
        save.setObjectName("blue")
        save.setMinimumHeight(40)
        save.clicked.connect(self.save_config)
        undo = QPushButton("↺  撤销未保存的修改")
        undo.clicked.connect(self.reload_config)
        share = QPushButton("📤  分享参数")
        share.setMinimumHeight(40)
        share.setToolTip("把「和默认值不一样的项」压成一串码，发给别人贴进去就能套用")
        share.clicked.connect(self.share_params)
        self.code_in = QLineEdit()
        self.code_in.setPlaceholderText("粘贴别人的参数码……")
        self.code_in.setMinimumHeight(40)
        self.code_in.returnPressed.connect(self.apply_params_code)
        use = QPushButton("套用")
        use.setMinimumHeight(40)
        use.setToolTip("把码里的参数套到这边（先给你看一眼要改哪些）")
        use.clicked.connect(self.apply_params_code)
        row.addWidget(save)
        row.addWidget(undo)
        row.addWidget(share)
        row.addSpacing(10)
        row.addWidget(self.code_in, 1)
        row.addWidget(use)
        row.addStretch(1)
        self.cfg_save_btn = save
        self.cfg_dirty_label = QLabel()
        self.cfg_dirty_label.setObjectName("cfgHint")
        outer.addWidget(self.cfg_dirty_label)
        outer.addLayout(row)
        self._update_cfg_draft()
        return w

    def share_params(self):
        """把改动过的参数打包成一段码，方便发给别人。"""
        try:
            code = pack_param_code()
        except Exception as exc:
            QMessageBox.warning(self, "分享参数", "生成参数码失败：%s" % exc)
            return
        dlg = QDialog(self)
        dlg.setObjectName("qqDlg")
        dlg.setWindowTitle("分享参数")
        dlg.resize(620, 300)
        lay = QVBoxLayout(dlg)
        lay.setContentsMargins(20, 18, 20, 18)
        lay.setSpacing(10)
        tip = QLabel("把下面这串发给对方，他粘到「粘贴参数码……」里点套用就行。\n"
                     "只包含你改过的项，路径/后台/点击速度这类跟机器绑的不会带出去。")
        tip.setWordWrap(True)
        lay.addWidget(tip)
        box = QPlainTextEdit(code)
        box.setReadOnly(True)
        box.setMinimumHeight(140)
        lay.addWidget(box, 1)
        brow = QHBoxLayout()
        copied = QLabel("")
        copy = QPushButton("复制")
        copy.setObjectName("blue")
        copy.setMinimumHeight(38)

        def _do_copy():
            try:
                QApplication.clipboard().setText(code)
                copied.setText("✅ 已复制到剪贴板")
            except Exception as exc:
                copied.setText("复制失败：%s" % exc)

        copy.clicked.connect(_do_copy)
        close = QPushButton("关闭")
        close.setMinimumHeight(38)
        close.clicked.connect(dlg.accept)
        brow.addWidget(copy)
        brow.addWidget(copied, 1)
        brow.addWidget(close)
        lay.addLayout(brow)
        dlg.exec_()

    def apply_params_code(self):
        """解析对方给的码，先预览要改哪些项，确认再写。"""
        code = (self.code_in.text() or "").strip()
        if not code:
            QMessageBox.information(self, "套用参数", "先把参数码粘进左边的框里。")
            return
        try:
            data = unpack_param_code(code)
        except Exception as exc:
            QMessageBox.warning(self, "套用参数", "这段码用不了：%s" % exc)
            return
        if not data:
            QMessageBox.information(self, "套用参数", "码里没有能用的参数（可能是别的版本的码）。")
            return
        diff, same, unknown = compare_param_code(data)
        lines = []
        if diff:
            lines.append("会改 %d 项：" % len(diff))
            for key, label, old, new in diff[:12]:
                lines.append("  · %s：%s → %s" % (label, old, new))
            if len(diff) > 12:
                lines.append("  ……还有 %d 项" % (len(diff) - 12))
        if unknown:
            lines.append("\n跳过 %d 项（这边没有这些参数）：%s"
                         % (len(unknown), "、".join(unknown[:6])))
        if not diff:
            QMessageBox.information(self, "套用参数", "这批参数和你现在的一模一样，不用改。")
            return
        lines.append("\n套用后记得点【保存参数】，不然只是显示成这样。")
        ok = QMessageBox.question(
            self, "套用参数", "\n".join(lines),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if ok != QMessageBox.Yes:
            return
        incoming = {key: data[key] for key, *_ in diff}
        flags = {key: incoming.pop(key) for key in VISION_KEYS if key in incoming}
        errors = []
        staged = {}
        for key, value in incoming.items():
            if key in ("FAST_SETTLE", "FAST_SETTLE_VALUE"):
                continue
            kind = (SETTING_MAP.get(key) or ("", "", "float"))[2]
            try:
                parsed = typed_setting(kind, value)
                if key == "READ_TOLERANCE":
                    if not 0 <= parsed <= 1:
                        raise ValueError("容差需在 0–1")
                    parsed = f"{parsed * 100:g}"
                staged[key] = parsed
            except ValueError as exc:
                errors.append(f"{key}：{exc}")
        if flags:
            try:
                staged["WAREHOUSE_VISION_MODE"] = self._vision_mode(flags)
            except ValueError as exc:
                errors.append(str(exc))
        if errors:
            QMessageBox.warning(self, "导入失败", "\n".join(errors))
            return
        for key, value in staged.items():
            if key not in self.cfg_widgets:
                self._cfg_imported[key] = value
                continue
            self._write_cfg_widget(key, "" if value is None else value)
        self._update_cfg_draft()
        self.msg.setPlainText(f"已载入 {len(staged)} 项草稿，点击「保存参数」后写入配置。")

    def toggle_background_mode(self, _state=None):
        """主界面的「后台模式」开关：直接把 BACKGROUND_RUN 写进 paimai.py"""
        want = "1" if self.bg_check.isChecked() else "0"
        if not write_setting("BACKGROUND_RUN", want):
            QMessageBox.warning(
                self,
                "保存失败",
                "没能在 paimai.py 里找到 BACKGROUND_RUN 这一项，"
                "请确认程序文件是完整的（可先用『一键自检』查一下）。",
            )
            return
        if want == "1":
            QMessageBox.information(
                self,
                "后台模式已打开",
                "已打开（重启脚本后生效）。\n"
                "需要管理员运行；游戏窗口不能最小化，盖住没问题。\n"
                "生效方式：先『停止挂机』，再『开始挂机』。",
            )
        else:
            QMessageBox.information(
                self,
                "后台模式已关闭",
                "已关闭（重启脚本后生效）。\n" "之后脚本会像以前一样把游戏窗口拉到最前台。",
            )

    def set_click_speed(self, tier):
        """主界面的「点击速度」三档：写进 paimai.py 的 CLICK_SPEED"""
        tier = int(tier)
        if not write_setting("CLICK_SPEED", str(tier)):
            QMessageBox.warning(
                self, "保存失败", "没能在 paimai.py 里找到 CLICK_SPEED，请确认程序文件完整。"
            )
            return
        for k, b in self.speed_btns.items():
            b.setChecked(k == tier)
        names = {1: "稳妥", 2: "标准", 3: "极速"}
        tips = {
            1: "和最早那版前台点击一样稳，一次约 0.23 秒",
            2: "现在后台在用的速度，一次约 0.10 秒",
            3: "最快，一次约 0.07 秒（仍然留了让游戏反应的安全余量）",
        }
        try:
            self.msg.setPlainText(
                "点击速度已设为「%s」：%s。\n"
                "「停止挂机」再「开始挂机」后生效。" % (names.get(tier, "标准"), tips.get(tier, ""))
            )
        except Exception:
            pass

    def _cfg_value(self, key):
        kind, wd = self.cfg_widgets[key]
        if kind == "vision":
            return str(wd.currentIndex())
        if kind == "switch":
            return "1" if wd.isChecked() else "0"
        if kind == "bool":
            return "1" if wd.currentIndex() == 0 else "0"
        if hasattr(wd, "currentText"):
            return wd.currentText().strip()
        return wd.text().strip()

    def current_mode(self):
        return "opponent"

    def active_settings(self):
        excluded = {"BIG_LOT_GATE", "FAST_SETTLE", "FAST_SETTLE_VALUE", *VISION_KEYS}
        for key, label, kind, default, hint in MODE_SETTINGS.get(self.current_mode(), MODE_SETTINGS["opponent"]):
            if key in excluded:
                if key == VISION_KEYS[0]:
                    yield "WAREHOUSE_VISION_MODE", "仓库视觉", "vision", "0", "仅记录可先检查识别结果。参与出价时，识别结果会修正策略估价。"
                continue
            label, hint = CONFIG_COPY.get(key, (label, hint))
            yield key, label, "percent" if key == "READ_TOLERANCE" else kind, default, hint
        yield SETTING_MAP["CURSOR_YIELD_USER"]

    def _vision_mode(self, values=None):
        values = values or {}
        flags = [typed_setting("bool", values.get(key, read_setting(key) or default))
                 for key, default in zip(VISION_KEYS, ("0", "1", "0"))]
        return 0 if not flags[0] else (2 if not flags[1] and flags[2] else 1)

    def _write_cfg_widget(self, key, text):
        kind, widget = self.cfg_widgets[key]
        if kind == "switch":
            widget.setChecked(str(text) == "1")
        elif kind == "bool":
            widget.setCurrentIndex(0 if str(text) == "1" else 1)
        elif kind == "vision":
            widget.setCurrentIndex(int(text))
        elif kind == "choice":
            widget.setCurrentText(str(text))
        else:
            widget.setText(str(text))

    def _update_cfg_draft(self, *_):
        if not hasattr(self, "cfg_dirty_label"):
            return
        count = sum(self._cfg_value(key) != old for key, old in self._cfg_baseline.items())
        count += len(self._cfg_imported)
        self.cfg_dirty_label.setText(f"{count} 项未保存" if count else "已保存")
        self.cfg_save_btn.setEnabled(bool(count))
        self.rebuild_hint()

    def rebuild_hint(self):
        enabled = (self._cfg_value("BID_AUTO_PRICE") if "BID_AUTO_PRICE" in self.cfg_widgets
                   else read_setting("BID_AUTO_PRICE"))
        self.mode_hint.setText(
            "已启用智能策略：按估价、回合和可用的对手信息算价。目标藏品规则优先。"
            if enabled == "1" else
            "当前按普通倍率、档位和目标藏品规则算价。可在参数中启用智能策略。"
        )

    def _build_normal_mult_card(self, vbox):
        """普通倍率卡片（放在「通用」组的第一项）。括号里就是输入框。"""
        nm = QFrame()
        nm.setObjectName("cfgCard")
        nm_lay = QVBoxLayout(nm)
        nm_lay.setContentsMargins(16, 11, 16, 11)
        nm_lay.setSpacing(6)
        _tip = QLabel("没有识别到目标藏品时按这里的倍率出价；倍率是百分比整数（130 = 估价×1.3，100 = 原价），括号里填估价边界（留空/0 = 这段不用）")
        _tip.setObjectName("cfgHint")
        _tip.setWordWrap(True)
        nm_lay.addWidget(_tip)

        def _num_box(key):
            wd = QLineEdit(read_setting(key))
            wd.setFixedWidth(110)
            wd.setMinimumHeight(28)
            wd.setPlaceholderText("估价")
            self.cfg_widgets[key] = ("int", wd)
            return wd

        def _rate_box(key):
            wd = QLineEdit(read_setting(key))
            wd.setFixedWidth(110)
            wd.setMinimumHeight(28)
            wd.setPlaceholderText("如 130")
            self.cfg_widgets[key] = ("int", wd)
            return wd

        def _row(items, rate_key):
            hl = QHBoxLayout()
            hl.setSpacing(6)
            for w in items:
                if isinstance(w, str):
                    lb = QLabel(w)
                    lb.setObjectName("cfgName")
                    hl.addWidget(lb)
                else:
                    hl.addWidget(w)
            hl.addStretch(1)
            lb2 = QLabel("倍率")
            lb2.setObjectName("cfgName")
            hl.addWidget(lb2)
            hl.addWidget(_rate_box(rate_key))
            nm_lay.addLayout(hl)

        _row(["（", _num_box("NORMAL_MULT_1_HI"), "）以内"], "NORMAL_MULT_1_RATE")
        _row(["（", _num_box("NORMAL_MULT_2_LO"), "）～（",
              _num_box("NORMAL_MULT_2_HI"), "）"], "NORMAL_MULT_2_RATE")
        _row(["（", _num_box("NORMAL_MULT_3_LO"), "）～（",
              _num_box("NORMAL_MULT_3_HI"), "）"], "NORMAL_MULT_3_RATE")
        _row(["（", _num_box("NORMAL_MULT_4_LO"), "）～（",
              _num_box("NORMAL_MULT_4_HI"), "）"], "NORMAL_MULT_4_RATE")
        _row(["（", _num_box("NORMAL_MULT_5_LO"), "）～（",
              _num_box("NORMAL_MULT_5_HI"), "）"], "NORMAL_MULT_5_RATE")
        _row(["（", _num_box("NORMAL_MULT_6_LO"), "）～（",
              _num_box("NORMAL_MULT_6_HI"), "）"], "NORMAL_MULT_6_RATE")
        _row(["（", _num_box("NORMAL_MULT_7_LO"), "）以上"], "NORMAL_MULT_7_RATE")

        vbox.addWidget(nm)
        self._cfg_rows.append({
            "kind": "row",
            "group": "通用",
            "key": "NORMAL_MULT_CARD",
            "text": "普通倍率 估价区间 倍率",
            "widgets": [nm],
        })

    def rebuild_config(self):
        try:
            self.rebuild_hint()
            inner = QWidget()
            vbox = QVBoxLayout(inner)
            vbox.setContentsMargins(2, 2, 2, 2)
            vbox.setSpacing(7)
            self.cfg_widgets = {}
            self._cfg_rows = []
            mode_now = self.current_mode()
            items = []
            for key, label, kind, rec, hint in self.active_settings():
                if key == "BID_MODE":
                    continue
                group = (GROUP_OF.get((mode_now, key))
                         or KEY_GROUP.get(key)
                         or GROUP_OF.get(key, "其它"))
                group = GROUP_ALIAS.get(group, group)
                if key == "CURSOR_YIELD_USER":
                    group = "运行方式 · 后台运行"
                if key.startswith("WAREHOUSE_VISION_"):
                    group = "仓库视觉"
                items.append((group, key, label, kind, hint))
            # 组内顺序：主开关 → 被依赖的开关 → 普通开关 → 数值。
            # 主开关就是这个组的主语（「不退出模式」那组里 CHASE_TO_END 必须排第一）。
            _masters = set(DEPENDS_ON.values())
            _group_first = {"不退出模式": ("CHASE_TO_END",)}
            _orig_idx = {id(_it): _i for _i, _it in enumerate(items)}
            _child_of = dict(DEPENDS_ON)
            _master_idx = {_it[1]: _orig_idx[id(_it)] for _it in items if _it[1] in _masters}

            def _row_key(_it):
                _g, _k, _l, _kd, _h = _it
                if _k in _group_first.get(_g, ()):
                    return (0, _orig_idx[id(_it)])
                if _k in _masters:
                    return (1, _orig_idx[id(_it)])
                _m = _child_of.get(_k)
                if _m in _master_idx:
                    # 子参数紧跟在它的主开关后面（别让「跳过点红点」和它的阈值被拆开）
                    return (1, _master_idx[_m] + 0.001)
                if _kd == "bool":
                    return (2, _orig_idx[id(_it)])
                return (3, _orig_idx[id(_it)])
            # 同名分组聚到一起：原来参数是按文件顺序排的，
            # 一页里「通用」「其它」会来回出现好几次，折叠也没法折。
            order, seen = [], set()
            for group, _k, _l, _kd, _h in items:
                if group not in seen:
                    seen.add(group)
                    order.append(group)

            # 档位表：八个档、每档六个值，一条条列出来太占地方，
            # 干脆拼成一张表 —— 一行一个档，一列一个回合
            _tier_groups, _tier_keys = [], {}
            for _g in order:
                _keys = [it[1] for it in items if it[0] == _g]
                if len(_keys) >= 5 and all(
                        k.startswith(("GATE_", "TIER_", "LOW_TIER_")) for k in _keys):
                    _tier_groups.append(_g)
                    _tier_keys[_g] = _keys
            _tier_done = False

            # 组按固定顺序摆，没列到的排最后（档位表固定插在大仓后面）
            def _group_rank(g):
                if g in _tier_keys:
                    return TIER_TABLE_RANK
                try:
                    return GROUP_ORDER.index(g)
                except ValueError:
                    return 90

            order.sort(key=_group_rank)

            for group in order:
                if group in _tier_keys:
                    if not _tier_done:
                        self._build_tier_table(vbox, items, _tier_groups, _tier_keys)
                        _tier_done = True
                    continue
                self._add_config_group_header(vbox, group)
                if group == "通用":
                    # 普通倍率放在「通用」第一项
                    self._build_normal_mult_card(vbox)
                _rows = [it for it in items if it[0] == group]
                _rows.sort(key=_row_key)
                for _g, key, label, kind, hint in _rows:
                    card = QFrame()
                    card.setObjectName("cfgCard")
                    cl = QHBoxLayout(card)
                    cl.setContentsMargins(16, 11, 16, 11)
                    cl.setSpacing(12)
                    left = QVBoxLayout()
                    left.setSpacing(2)
                    lab = QLabel(label)
                    lab.setObjectName("cfgName")
                    lab.setWordWrap(True)
                    left.addWidget(lab)
                    if hint:
                        hl = QLabel(hint)
                        hl.setObjectName("cfgHint")
                        hl.setWordWrap(True)
                        left.addWidget(hl)
                    cl.addLayout(left, 1)
                    _reg_kind = kind
                    if kind == "vision":
                        wd = NoWheelComboBox()
                        wd.addItems(VISION_OPTIONS)
                        wd.setCurrentIndex(self._vision_mode())
                    elif kind == "percent":
                        wd = QLineEdit(f"{float(read_setting(key) or 0) * 100:g}")
                        wd.setFixedWidth(128)
                    elif kind == "bool" and key in BOOL_LABELS:
                        # 这类不是单纯开关（例：拿仓 / 求稳），保留下拉框
                        wd = NoWheelComboBox()
                        wd.addItems(BOOL_LABELS.get(key) or ["1  (开)", "0  (关)"])
                        wd.setCurrentIndex(0 if read_setting(key) == "1" else 1)
                        wd.setFixedWidth(190)
                        wd.setMinimumHeight(30)
                    elif kind == "bool":
                        # 大肥鱼：纯开/关一律用胶囊开关（带滑动动画）
                        wd = ToggleSwitch("")
                        wd.setChecked(str(read_setting(key)).strip() == "1")
                        # 宽度 = 胶囊本身，右边缘才能和上面的下拉框/输入框对齐
                        wd.setFixedWidth(ToggleSwitch.W)
                        wd.setMinimumHeight(30)
                        _reg_kind = "switch"
                    else:
                        wd = QLineEdit(read_setting(key))
                        wd.setFixedWidth(190)
                        wd.setMinimumHeight(30)
                    wd.setToolTip(key)
                    cl.addWidget(wd, 0, Qt.AlignTop)
                    if kind == "percent" or key in ("HARD_CAP_MULT", "CHASE_STEP_RATIO"):
                        unit = QLabel("%" if kind == "percent" else "倍")
                        unit.setObjectName("cfgHint")
                        cl.addWidget(unit, 0, Qt.AlignTop)
                    vbox.addWidget(card)
                    self._cfg_rows.append(
                        {
                            "kind": "row",
                            "group": group,
                            "key": key,
                            "text": "%s %s %s" % (key, label, hint),
                            "widgets": [card],
                        }
                    )
                    self.cfg_widgets[key] = (_reg_kind, wd)
                ladder = tier_ladder_text(group)
                if ladder:
                    lb = QLabel(ladder)
                    lb.setObjectName("cfgLadder")
                    lb.setWordWrap(True)
                    vbox.addWidget(lb)
                    self._cfg_rows.append(
                        {"kind": "row", "group": group, "text": ladder, "widgets": [lb]}
                    )
            vbox.addStretch(1)
            # 把"普通倍率"那张卡的输入框并入保存列表
            try:
                self.cfg_widgets.update(getattr(self, "_nm_widgets", {}) or {})
            except Exception:
                pass
            self._cfg_baseline = {key: self._cfg_value(key) for key in self.cfg_widgets}
            for kind, widget in self.cfg_widgets.values():
                if kind == "switch":
                    widget.toggled.connect(self._update_cfg_draft)
                    widget.toggled.connect(self._apply_cfg_filter)
                elif hasattr(widget, "currentIndexChanged"):
                    widget.currentIndexChanged.connect(self._update_cfg_draft)
                    widget.currentIndexChanged.connect(self._apply_cfg_filter)
                else:
                    widget.textChanged.connect(self._update_cfg_draft)
            self.cfg_area.setWidget(inner)
            self._make_scroll_opaque(self.cfg_area, inner)
            try:
                from PyQt5.QtCore import QTimer as _QT
                _QT.singleShot(
                    0,
                    lambda a=self.cfg_area, w=inner: self._make_scroll_opaque(a, w),
                )
            except Exception:
                pass
            self._apply_cfg_filter()
        except Exception as e:
            self.msg.setPlainText("参数表刷新失败：%s" % e)

    def _add_config_group_header(self, vbox, group):
        head = QPushButton()
        head.setObjectName("cfgHead")
        head.setCursor(Qt.PointingHandCursor)
        font = head.font()
        font.setBold(True)
        font.setPointSize(font.pointSize() + 1)
        head.setFont(font)
        head.clicked.connect(lambda _=False: self._toggle_cfg_group(group))
        vbox.addWidget(head)
        self._cfg_rows.append({"kind": "head", "group": group, "text": group, "widgets": [head]})

    def _build_tier_table(self, vbox, items, groups, tier_keys):
        """十个档位拼成一张表：一行一个档，列是 保留藏品 / 门槛 / 首轮价 / R2~R5。"""
        tier_group = "高价值藏品以及特殊出价设置"
        self._add_config_group_header(vbox, tier_group)
        card = QFrame()
        card.setObjectName("tierCard")
        gl = QGridLayout(card)
        gl.setContentsMargins(14, 10, 14, 12)
        gl.setHorizontalSpacing(8)
        gl.setVerticalSpacing(6)

        def _ord(k):
            if k.startswith("GATE"):
                return 0
            if k.endswith("_OPEN"):
                return 1
            if k.endswith("_KEEP"):
                return 8
            m = re.search(r"_R(\d+)_", k)
            return int(m.group(1)) if m else 9

        heads = ("高价值藏品", "保留藏品", "门槛", "首轮价", "R2", "R3", "R4", "R5")
        # 给每列一个最小宽度：否则「保留藏品 / 门槛」这两个表头会挤在一起
        for _c, _w in enumerate((70, ToggleSwitch.W + 24, 96, 96, 60, 60, 60, 60)):
            gl.setColumnMinimumWidth(_c, _w)
        for c, h in enumerate(heads):
            lb = QLabel(h)
            lb.setObjectName("tierHead")
            lb.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)
            gl.addWidget(lb, 0, c)

        row = 1
        for g in groups:
            _nm0 = g.split("·")[0].strip() or g
            if _nm0 in ("守望者档", "永恒之心档", "乐园巧克力档"):
                continue  # 这三样改成下面单独的「保留藏品」行，不放进价表
            _nm0 = _nm0[:-1] if _nm0.endswith("档") else _nm0
            nm = QLabel(_nm0)
            nm.setObjectName("tierName")
            nm.setWordWrap(True)
            gl.addWidget(nm, row, 0)
            _kinds = dict((it[1], it[3]) for it in items)
            keys = sorted(tier_keys[g], key=_ord)
            keep_key = next((k for k in keys if k.endswith("_KEEP")), None)
            value_keys = [k for k in keys if not k.endswith("_KEEP")][:6]
            col = 1
            if keep_key:
                sw = ToggleSwitch("")
                sw.setChecked(str(read_setting(keep_key)).strip() == "1")
                sw.setFixedWidth(ToggleSwitch.W)
                sw.setToolTip("打开 = 清仓时跳过这件藏品（不卖）")
                holder = QWidget()
                holder.setFixedWidth(ToggleSwitch.W + 6)
                hl = QHBoxLayout(holder)
                hl.setContentsMargins(0, 0, 0, 0)
                hl.addWidget(sw, 0, Qt.AlignCenter)
                gl.addWidget(holder, row, col)
                self.cfg_widgets[keep_key] = ("switch", sw)
                col += 1
            for k in value_keys:
                wd = QLineEdit(read_setting(k))
                wd.setFixedWidth(96)
                wd.setMinimumHeight(26)
                gl.addWidget(wd, row, col)
                self.cfg_widgets[k] = (_kinds.get(k, "float"), wd)
                col += 1
            row += 1

        gl.setColumnStretch(0, 1)
        vbox.addWidget(card)

        # ---- 保留藏品（只保留、不参与出价）----
        # 横向排：标题一行，下面「名称 + 开关」从左往右依次排；以后新增藏品
        # 直接在 keep_only 里补一行 ("名称", "XXX_KEEP") 就会排到最后。
        keep_only = [("守望者", "TIER_1100_KEEP"),
                     ("永恒之心", "LOW_TIER_KEEP"),
                     ("乐园巧克力", "TIER_233_KEEP"),
                     ("烟云盏", "TIER_YANYUN_KEEP"),
                     ("古旧手提箱", "TIER_SHOUTI_KEEP")]
        kcard = QFrame()
        kcard.setObjectName("cfgCard")
        kvl = QVBoxLayout(kcard)
        kvl.setContentsMargins(16, 11, 16, 11)
        kvl.setSpacing(4)
        _kh = QLabel("保留藏品")
        _kh.setObjectName("tierHead")
        kvl.addWidget(_kh)
        _krow = QHBoxLayout()
        _krow.setSpacing(22)
        for _name, _key in keep_only:
            _kl = QLabel(_name)
            _kl.setObjectName("tierName")
            _krow.addWidget(_kl)
            _ksw = ToggleSwitch("")
            _ksw.setChecked(str(read_setting(_key)).strip() == "1")
            _ksw.setFixedWidth(ToggleSwitch.W)
            _ksw.setToolTip("打开 = 清仓时跳过这件藏品（不卖）")
            _krow.addWidget(_ksw)
            self.cfg_widgets[_key] = ("switch", _ksw)
        _krow.addStretch(1)
        kvl.addLayout(_krow)
        vbox.addWidget(kcard)

        # ---- 表下方：拍到目标藏品后自动清理仓库（独立底板，同「不退出模式」那张卡）----
        clean = QFrame()
        clean.setObjectName("cfgCard")
        hl2 = QHBoxLayout(clean)
        hl2.setContentsMargins(16, 11, 16, 11)
        hl2.setSpacing(12)
        lv = QVBoxLayout()
        lv.setSpacing(2)
        t1 = QLabel("拍到目标藏品后自动清理仓库")
        t1.setObjectName("cfgName")
        lv.addWidget(t1)
        t2 = QLabel(
            "自己拍到后，是否清仓由下方阈值和开关决定。"
            "它是一格一格看的：认不准的不卖；认准的、又不在上面「保留藏品」里的都卖。"
        )
        t2.setObjectName("cfgHint")
        t2.setWordWrap(True)
        lv.addWidget(t2)
        hl2.addLayout(lv, 1)
        # （原来的「拍到目标藏品后自动清理仓库」开关已删除：
        #   现在由下面的"结算价值阈值"决定要不要留红货 + 回大厅清仓）
        sell = QFrame()
        sell.setObjectName("cfgCard")
        hl3 = QHBoxLayout(sell)
        hl3.setContentsMargins(16, 11, 16, 11)
        hl3.setSpacing(12)
        lv3 = QVBoxLayout()
        lv3.setSpacing(2)
        t3 = QLabel("结算页全卖阈值（含红色藏品）")
        t3.setObjectName("cfgName")
        lv3.addWidget(t3)
        t4 = QLabel(
            "这个数你自己填，随便多少都行（示例：3000000 = 300 万）。"
            "规则：结算页【当前估价】低于你填的数 → 勾红圈全卖；"
            "高于等于 → 不勾红圈（红货留着），回大厅后进仓库识别保留藏品，勾选的保留、其余出售。"
            "填 0 = 关掉这套，永远勾红圈全卖。"
        )
        t4.setObjectName("cfgHint")
        t4.setWordWrap(True)
        lv3.addWidget(t4)
        hl3.addLayout(lv3, 1)
        _thr_edit = QLineEdit(read_setting("CLEAN_SELL_ALL_BELOW"))
        _thr_edit.setFixedWidth(190)
        _thr_edit.setMinimumHeight(30)
        _thr_edit.setPlaceholderText("如 3000000")
        hl3.addWidget(_thr_edit, 0, Qt.AlignVCenter)
        vbox.addWidget(sell)

        # ---- 单独一行：不进入仓库出售藏品（打开后无论如何都不清仓）----
        nosell = QFrame()
        nosell.setObjectName("cfgCard")
        hl4 = QHBoxLayout(nosell)
        hl4.setContentsMargins(16, 11, 16, 11)
        hl4.setSpacing(12)
        lv4 = QVBoxLayout()
        lv4.setSpacing(2)
        t5 = QLabel("跳过回大厅后的自动清仓")
        t5.setObjectName("cfgName")
        lv4.addWidget(t5)
        t6 = QLabel(
            "只控制回大厅后的仓库操作。低于全卖阈值时，结算页仍会一键出售红货。"
        )
        t6.setObjectName("cfgHint")
        t6.setWordWrap(True)
        lv4.addWidget(t6)
        hl4.addLayout(lv4, 1)
        _nosell_sw = ToggleSwitch("")
        _nosell_sw.setChecked(str(read_setting("CLEAN_SKIP_SELL")).strip() == "1")
        _nosell_sw.setFixedWidth(ToggleSwitch.W)
        _nosell_sw.setToolTip("开启后跳过大厅清仓。结算页依然按全卖阈值执行。")
        hl4.addWidget(_nosell_sw, 0, Qt.AlignVCenter)
        vbox.addWidget(nosell)

        self.cfg_widgets["CLEAN_SELL_ALL_BELOW"] = ("int", _thr_edit)
        self.cfg_widgets["CLEAN_SKIP_SELL"] = ("switch", _nosell_sw)

        _all = " ".join(k for g in groups for k in tier_keys[g]) + " 保留藏品 清理仓库"
        self._cfg_rows.append({
            "kind": "row",
            "group": tier_group,
            "key": "__tier__",
            "text": _all + " 档位表 门槛 首轮价",
            "widgets": [card, sell, nosell],
        })

    def _toggle_cfg_group(self, group):
        collapsed = getattr(self, "_cfg_collapsed", set())
        if group in collapsed:
            collapsed.discard(group)
        else:
            collapsed.add(group)
        self._cfg_collapsed = collapsed
        self._apply_cfg_filter()

    def _toggle_all_cfg_groups(self):
        rows = getattr(self, "_cfg_rows", [])
        groups = [r["group"] for r in rows if r["kind"] == "head"]
        collapsed = getattr(self, "_cfg_collapsed", set())
        if groups and all(g in collapsed for g in groups):
            self._cfg_collapsed = set()  # 全展开
        else:
            self._cfg_collapsed = set(groups)  # 全收起
        self._apply_cfg_filter()

    def _apply_cfg_filter(self):
        """按搜索词 + 折叠状态决定每一行显不显示。

        注意：只切显隐，不重建控件 —— 搜索时没保存的改动不会丢。
        """
        rows = getattr(self, "_cfg_rows", None)
        if not rows:
            return
        try:
            q = (self.cfg_search.text() if hasattr(self, "cfg_search") else "").strip().lower()
        except Exception:
            q = ""
        collapsed = getattr(self, "_cfg_collapsed", set())
        # 「只看常用」：没在搜索的时候，只露 COMMON_KEYS 那几项，其余收起来
        _common_only = False
        if not q:
            try:
                _common_only = bool(self.cfg_common.isChecked())
            except Exception:
                _common_only = False
        hit = {}
        # 常用模式下组头该按「这组里有没有常用项」决定 ——
        # 不能看折叠后的可见行，否则一点「全部收起」连组头都没了，整页空白。
        _common_groups = set()
        if _common_only:
            for _item in rows:
                if _item["kind"] == "row" and _item.get("key") in COMMON_KEYS:
                    _common_groups.add(_item["group"])
        # 从属参数：主开关关着就先不显示（搜索时例外）
        _dep_ok = {}
        if not q:
            for _child, _master in DEPENDS_ON.items():
                try:
                    if _master == VISION_KEYS[0] and "WAREHOUSE_VISION_MODE" in self.cfg_widgets:
                        master = str(int(self._cfg_value("WAREHOUSE_VISION_MODE") != "0"))
                    else:
                        master = self._cfg_value(_master) if _master in self.cfg_widgets else read_setting(_master)
                    _dep_ok[_child] = str(master).strip() == "1"
                except Exception:
                    _dep_ok[_child] = True
        for item in rows:
            if item["kind"] != "row":
                continue
            show = q in item["text"].lower() if q else item["group"] not in collapsed
            if _common_only and item.get("key", "") not in COMMON_KEYS:
                show = False
            if show and _dep_ok and not _dep_ok.get(item.get("key"), True):
                show = False
            for w in item["widgets"]:
                w.setVisible(show)
            if show:
                hit[item["group"]] = True
        for item in rows:
            if item["kind"] != "head":
                continue
            g = item["group"]
            head = item["widgets"][0]
            head.setText(("▸ " if g in collapsed else "▾ ") + g)
            if _common_only:
                # 有常用项的组，组头一直挂着（折叠了也在，点开就能看到）
                head.setVisible(g in _common_groups)
            else:
                head.setVisible((g in collapsed) or bool(hit.get(g)) or not q)
        if hasattr(self, "cfg_all_btn"):
            groups = [r["group"] for r in rows if r["kind"] == "head"]
            all_closed = bool(groups) and all(g in collapsed for g in groups)
            self.cfg_all_btn.setText("全部展开" if all_closed else "全部收起")

    def save_config(self):
        pending = dict(self._cfg_imported)
        for key, (kind, widget) in self.cfg_widgets.items():
            text = self._cfg_value(key)
            if text == self._cfg_baseline.get(key):
                continue
            if kind == "vision":
                pending.update(zip(VISION_KEYS, VISION_FLAGS[int(text)]))
                continue
            try:
                pending[key] = typed_setting(kind, text)
            except ValueError as exc:
                self._show_cb_error(key, str(exc))
                return
        if not pending:
            return
        data = dict(param_file_load(force=True))
        for key, value in pending.items():
            if value is None:
                data.pop(key, None)
            else:
                data[key] = value
        gaps = []
        if any(key.startswith("NORMAL_MULT_") for key in pending):
            ranges = {}
            for key in self.cfg_widgets:
                if key.startswith("NORMAL_MULT_"):
                    try:
                        ranges[key] = typed_setting("int", self._cfg_value(key))
                    except ValueError as exc:
                        self._show_cb_error(key, str(exc))
                        return
            invalid, gaps = validate_multiplier_ranges(ranges)
            if invalid:
                self._show_cb_error(*invalid)
                return
        if not param_file_save(data):
            QMessageBox.warning(self, "保存失败", "无法写入参数配置.json，草稿已保留。")
            return
        self._cfg_imported.clear()
        self._cfg_baseline = {key: self._cfg_value(key) for key in self.cfg_widgets}
        self._update_cfg_draft()
        notices = []
        if LIVE_CONFIG_KEYS.intersection(pending):
            notices.append("清仓设置在相应步骤重新读取")
        if "CURSOR_YIELD_USER" in pending:
            notices.append("鼠标让行已生效")
        if pending.keys() - LIVE_CONFIG_KEYS - {"CURSOR_YIELD_USER"}:
            notices.append("其余参数在挂机进程重新启动后生效")
        self.cfg_dirty_label.setText("已保存 · " + "，".join(notices))
        note = f"已保存 {len(pending)} 项到参数配置.json。"
        if gaps:
            note += "\n这些估价未配置普通倍率，将使用后续规则：" + "、".join(gaps)
            self.cfg_dirty_label.setText("已保存 · 倍率有空档")
            self.cfg_dirty_label.setToolTip(note)
        else:
            self.cfg_dirty_label.setToolTip("")
        self.msg.setPlainText(note)

    def _show_cb_error(self, key, message):
        label = CONFIG_COPY.get(key, ((SETTING_MAP.get(key) or ("", key))[1], ""))[0]
        QMessageBox.warning(self, "请检查参数", f"{label}：{message}")
        self.cfg_search.setText(key if not key.startswith("NORMAL_MULT_") else "普通倍率")
        self._apply_cfg_filter()
        if key in self.cfg_widgets:
            widget = self.cfg_widgets[key][1]
            self.cfg_area.ensureWidgetVisible(widget)
            widget.setFocus()

    def reload_config(self):
        self._cfg_imported.clear()
        param_file_load(force=True)
        self.rebuild_config()
        self._update_cfg_draft()

    def tab_log(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        row = QHBoxLayout()
        row.addWidget(QLabel("日期："))
        self.log_date = QComboBox()
        self.log_date.setMinimumWidth(120)
        self.log_date.currentIndexChanged.connect(self.load_file_list)
        row.addWidget(self.log_date)
        row.addWidget(QLabel("文件："))
        self.log_file = QComboBox()
        self.log_file.setMinimumWidth(260)
        self.log_file.currentIndexChanged.connect(self.load_log)
        row.addWidget(self.log_file)
        b = QPushButton("⟳ 刷新")
        b.clicked.connect(self.load_log)
        row.addWidget(b)
        b2 = QPushButton("📂 打开文件夹")
        b2.clicked.connect(lambda: self.open_folder("日志"))
        row.addWidget(b2)
        row.addStretch(1)
        lay.addLayout(row)
        # 第二行：自动刷新 + 换目录。原来六件东西挤一行，
        # 把整页的最小宽度撑到 1000 以上，小窗口根本放不下。
        row2 = QHBoxLayout()
        self.log_auto = ToggleSwitch("自动刷新（5 秒）")
        self.log_auto.stateChanged.connect(self._toggle_log_auto)
        row2.addWidget(self.log_auto)
        b3 = QPushButton("📁 换日志目录…")
        b3.clicked.connect(self.pick_log_root)
        row2.addWidget(b3)
        row2.addStretch(1)
        lay.addLayout(row2)
        self.log_dir_lab = QLabel("")
        self.log_dir_lab.setObjectName("hint")
        lay.addWidget(self.log_dir_lab)
        hint = QLabel(
            "运行日志 = 异常/超时；控制台输出 = 脚本窗口里的每一行；"
            "报错日志 = 什么时候报了什么错（带截图名）；拍卖记录 = 每局逐回合（含四家出价、成本、净收益）。"
        )
        hint.setObjectName("hint")
        hint.setWordWrap(True)
        lay.addWidget(hint)
        self.log_box = QPlainTextEdit()
        self.log_box.setReadOnly(True)
        self.log_box.setLineWrapMode(QPlainTextEdit.NoWrap)
        lay.addWidget(self.log_box)
        self.log_timer = QTimer(self)
        self.log_timer.timeout.connect(self.load_log)
        self.log_auto.setChecked(True)
        self.log_timer.stop()
        return w

    def _toggle_log_auto(self, state):
        if state and self.stack.currentIndex() == 2:
            self.log_timer.start(5000)
        else:
            self.log_timer.stop()

    def load_file_list(self):
        d = os.path.join(LOG_ROOT, self.log_date.currentText())
        files = []
        if os.path.isdir(d):
            files = sorted(f for f in os.listdir(d) if os.path.isfile(os.path.join(d, f)))
        try:
            self.log_dir_lab.setText(
                "日志目录："
                + LOG_ROOT
                + (
                    "　（这个目录不存在，用右边『换日志目录…』指到实际位置）"
                    if not os.path.isdir(LOG_ROOT)
                    else ""
                )
            )
        except Exception:
            pass
        files.sort(key=lambda f: (LOG_ORDER.index(f) if f in LOG_ORDER else len(LOG_ORDER), f))
        default = "拍卖记录.txt" if "拍卖记录.txt" in files else (files[0] if files else "")
        self.log_file.blockSignals(True)
        self.log_file.clear()
        self.log_file.addItems(files)
        if default:
            self.log_file.setCurrentText(default)
        self.log_file.blockSignals(False)
        if files:
            self.load_log()
        else:
            other = [x for x in date_list() if x != self.log_date.currentText()]
            extra = ""
            if other:
                extra = "\n\n其它有数据的日期：" + "、".join(other[:5]) + "（在上面的日期里换一下）"
            elif guess_roots("日志"):
                extra = (
                    "\n\n在别的位置发现了日志文件夹：\n   "
                    + "\n   ".join(guess_roots("日志"))
                    + "\n（点右边『📁 换日志目录…』选它的**上一级**，也就是那个 记录 文件夹）"
                )
            self.log_box.setPlainText(
                "这一天（%s）没有日志。\n面板正在读：%s%s\n\n"
                "如果脚本是在别的文件夹里跑的，用右边『📁 换日志目录…』指过去即可。"
                % (self.log_date.currentText(), LOG_ROOT, extra)
            )

    def pick_log_root(self):
        global LOG_ROOT
        start = LOG_ROOT if os.path.isdir(LOG_ROOT) else BASE
        p = QFileDialog.getExistingDirectory(
            self, "选择日志所在的文件夹（记录 或 记录\\日志 都行）", start
        )
        if not p:
            return
        if os.path.basename(p) == "日志" or any(
            os.path.isdir(os.path.join(p, x))
            for x in os.listdir(p)[:50]
            if len(x) == 10 and x[4] == "-"
        ):
            LOG_ROOT = p if os.path.basename(p) == "日志" else os.path.join(p, "日志")
        else:
            LOG_ROOT = p
        save_cfg()
        self.refresh_dates()

    def load_log(self):
        if self.stack.currentIndex() != 2:
            return
        day, name = self.log_date.currentText(), self.log_file.currentText()
        if not day or not name:
            return
        try:
            path = os.path.join(LOG_ROOT, day, name)
            cursor, reset, lines = appended_log_lines(path, getattr(self, "_detail_log_cursor", None))
            self._detail_log_cursor = cursor
            self._append_log_widget(self.log_box, lines[-500:], reset, 500)
        except OSError as exc:
            self._detail_log_cursor = None
            self.log_box.setPlainText(f"读不到这个文件：{exc}")

    def tab_shot(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        row = QHBoxLayout()
        row.addWidget(QLabel("日期："))
        self.shot_date = QComboBox()
        self.shot_date.setMinimumWidth(120)
        self.shot_date.currentIndexChanged.connect(self.load_shots)
        row.addWidget(self.shot_date)
        b = QPushButton("⟳ 刷新")
        b.clicked.connect(self.load_shots)
        row.addWidget(b)
        b2 = QPushButton("📂 打开文件夹")
        b2.clicked.connect(lambda: self.open_folder("高价值截图"))
        row.addWidget(b2)
        b3 = QPushButton("📁 换截图目录…")
        b3.clicked.connect(self.pick_shot_root)
        row.addWidget(b3)
        row.addStretch(1)
        lay.addLayout(row)
        self.shot_dir_lab = QLabel("")
        self.shot_dir_lab.setObjectName("hint")
        lay.addWidget(self.shot_dir_lab)
        hint = QLabel(
            "这里只放【我拍到的】高价值局（实际价值超过档位线时自动截图），"
            "按天存在 记录\\高价值截图\\日期\\ 里，双击看大图。\n"
            "别人拍走的高价值局不在这里显示，去「对局分析」页看"
            "（那边是全部对局，只显示数据、不配截图）。"
        )
        hint.setObjectName("hint")
        lay.addWidget(hint)
        self.shot_list = QListWidget()
        self.shot_list.setViewMode(QListWidget.IconMode)
        self.shot_list.setIconSize(QPixmap(260, 150).size())
        self.shot_list.setGridSize(QPixmap(282, 205).size())
        self.shot_list.setResizeMode(QListWidget.Adjust)
        self.shot_list.setSpacing(10)
        self.shot_list.itemDoubleClicked.connect(self.show_shot)
        lay.addWidget(self.shot_list)
        return w

    def load_shots(self):
        d = os.path.join(SHOT_ROOT, self.shot_date.currentText())
        self.shot_list.clear()
        try:
            self.shot_dir_lab.setText("截图目录：" + SHOT_ROOT)
        except Exception:
            pass
        files = []
        if os.path.isdir(d):
            files = sorted(
                (f for f in os.listdir(d) if f.lower().endswith((".png", ".jpg", ".jpeg"))),
                reverse=True,
            )
        _raw = len(files)
        _wins = self._my_win_times(self.shot_date.currentText())
        if _wins:
            files = [f for f in files if self._shot_is_mine(os.path.join(d, f), _wins)]
        if not files:
            if _raw:
                self.shot_list.addItem(
                    QListWidgetItem(
                        "这一天（%s）共有 %d 张高价值截图，但都不是【我拍到的】。\n\n"
                        "别人拍走的高价值局请看「对局分析」页：\n"
                        "　选『⑥ 结算价值（实际价值）> 阈值 的高价值对局』，\n"
                        "　那边是全部对局，每条都带结算截图和逐回合明细。"
                        % (self.shot_date.currentText(), _raw)
                    )
                )
                return
            tip = "这一天（%s）没有高价值截图。\n面板正在读：%s" % (
                self.shot_date.currentText(),
                SHOT_ROOT,
            )
            other = [x for x in date_list() if x != self.shot_date.currentText()]
            if other:
                tip += "\n其它有数据的日期：" + "、".join(other[:5]) + "（在上面换个日期）"
            found = guess_roots("高价值截图")
            if found:
                tip += (
                    "\n\n在别的位置发现了截图文件夹：\n   "
                    + "\n   ".join(found)
                    + "\n（点右边『📁 换截图目录…』指过去：选 记录 或 记录\\高价值截图 都行）"
                )
            else:
                tip += "\n\n如果脚本是在别的文件夹里跑的，点右边『📁 换截图目录…』指过去即可。"
            self.shot_list.addItem(QListWidgetItem(tip))
            return
        for f in files:
            fp = os.path.join(d, f)
            pm = QPixmap(fp)
            if pm.isNull():
                continue
            item = QListWidgetItem(
                QIcon(pm.scaled(260, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation)), f
            )
            item.setData(Qt.UserRole, fp)
            item.setTextAlignment(Qt.AlignHCenter)
            self.shot_list.addItem(item)

    @staticmethod
    def _my_win_times(day):
        try:
            recs = parse_auction_record(day)
        except Exception:
            return None
        if not recs:
            return None
        out = []
        for r in recs:
            if r.get("result") == "我拍到" and r.get("time"):
                try:
                    out.append(datetime.datetime.strptime(r["time"], "%Y-%m-%d %H:%M:%S"))
                except Exception:
                    pass
        return out or None

    @staticmethod
    def _shot_is_mine(path, wins, tol=240):
        m = re.search(r"(\d{8})_(\d{6})", os.path.basename(path))
        if not m:
            return True
        try:
            t = datetime.datetime.strptime(m.group(1) + m.group(2), "%Y%m%d%H%M%S")
        except Exception:
            return True
        return any(abs((t - w).total_seconds()) <= tol for w in wins)

    def pick_shot_root(self):
        global SHOT_ROOT
        p = QFileDialog.getExistingDirectory(
            self, "选择高价值截图所在的文件夹", SHOT_ROOT if os.path.isdir(SHOT_ROOT) else BASE
        )
        if not p:
            return
        SHOT_ROOT = p if os.path.basename(p) != "记录" else os.path.join(p, "高价值截图")
        save_cfg()
        self.refresh_dates()

    def show_shot(self, item):
        p = item.data(Qt.UserRole)
        if not p or not os.path.exists(p):
            return
        dlg = QDialog(self)
        dlg.setWindowTitle(os.path.basename(p))
        lay = QVBoxLayout(dlg)
        pm = QPixmap(p)
        scr = QApplication.primaryScreen().availableGeometry()
        lab = QLabel()
        lab.setPixmap(
            pm.scaled(
                int(scr.width() * 0.78),
                int(scr.height() * 0.78),
                Qt.KeepAspectRatio,
                Qt.SmoothTransformation,
            )
        )
        lay.addWidget(lab)
        row = QHBoxLayout()
        b1 = QPushButton("用系统看图打开")
        b1.clicked.connect(lambda: os.startfile(p))
        b2 = QPushButton("关闭")
        b2.clicked.connect(dlg.accept)
        row.addWidget(b1)
        row.addWidget(b2)
        row.addStretch(1)
        lay.addLayout(row)
        dlg.exec_()

    def tab_report(self):
        w = QWidget()
        lay = QVBoxLayout(w)
        row = QHBoxLayout()
        row.addWidget(QLabel("日期："))
        self.ana_date = QComboBox()
        self.ana_date.setMinimumWidth(120)
        self.ana_date.currentIndexChanged.connect(lambda *_: self.load_analysis())
        row.addWidget(self.ana_date)
        row.addWidget(QLabel("高价值阈值（万）："))
        self.ana_thr = QLineEdit("512")
        self.ana_thr.setFixedWidth(70)
        self.ana_thr.returnPressed.connect(self.load_analysis)
        row.addWidget(self.ana_thr)
        b1 = QPushButton("🔄 刷新")
        b1.setObjectName("blue")
        b1.setToolTip("重新读取拍卖记录（脚本在跑的时候，新打完的局也能刷出来）")
        b1.clicked.connect(lambda *_: self.refresh_analysis())
        row.addWidget(b1)
        b2 = QPushButton("📂 打开记录文件夹")
        b2.clicked.connect(lambda: self.open_folder(""))
        row.addWidget(b2)
        row.addStretch(1)
        lay.addLayout(row)
        row2 = QHBoxLayout()
        lab = QLabel("查看：")
        lf = lab.font()
        lf.setBold(True)
        lab.setFont(lf)
        row2.addWidget(lab)
        self.ana_sel = QComboBox()
        self.ana_sel.setMinimumWidth(300)
        for key, label in ANALYSIS_SECTIONS:
            self.ana_sel.addItem(label, key)
        self.ana_sel.currentIndexChanged.connect(lambda *_: self._render_analysis())
        row2.addWidget(self.ana_sel)
        row2.addStretch(1)
        lay.addLayout(row2)
        self.ana_hint = QLabel("")
        self.ana_hint.setObjectName("hint")
        self.ana_hint.setWordWrap(True)
        lay.addWidget(self.ana_hint)
        self.ana_scroll = QScrollArea()
        self.ana_scroll.setWidgetResizable(True)
        self.ana_cards = QWidget()
        self.ana_cards_lay = QVBoxLayout(self.ana_cards)
        self.ana_scroll.setWidget(self.ana_cards)
        self._make_scroll_opaque(self.ana_scroll, self.ana_cards)
        lay.addWidget(self.ana_scroll)
        return w

    def load_report(self):
        self.load_analysis()

    def refresh_analysis(self):
        try:
            self.refresh_dates()
        except Exception:
            pass
        self.load_analysis()
        try:
            self.ana_hint.setText(
                self.ana_hint.text()
                + "　✅ 已于 %s 刷新" % datetime.datetime.now().strftime("%H:%M:%S")
            )
        except Exception:
            pass

    def load_analysis(self):
        try:
            day = self.ana_date.currentText() or datetime.date.today().strftime("%Y-%m-%d")
            try:
                thr = int(float(self.ana_thr.text() or "512")) * 10000
            except Exception:
                thr = 5120000
            if day == ALL_DAYS:
                recs = parse_all_auction_records()
            else:
                recs = parse_auction_record(day)
            if not recs:
                other = [d for d in date_list() if d != day]
                self._show_analysis_text(
                    "还没有拍卖记录（当前选择：%s）。\n\n其它有数据的日期：%s\n"
                    "（在上面换个日期，或选『%s』看全部）"
                    % (day, "、".join(other[:6]) or "（无）", ALL_DAYS)
                )
                self.ana_hint.setText("记录目录：%s" % LOG_ROOT)
                self._ana_data = None
                return
            self._ana_data = build_analysis(recs, thr)
            self._ana_day = day
            self._ana_thr = thr
            self._ana_count = len(recs)
            self._ana_all = day == ALL_DAYS
            self._render_analysis()
        except Exception as e:
            import traceback

            self._show_analysis_text("分析出错：%s\n\n%s" % (e, traceback.format_exc()[-800:]))

    def _show_analysis_text(self, text, mono=True):
        self._clear_analysis_cards()
        tb = QPlainTextEdit()
        tb.setReadOnly(True)
        tb.setPlainText(text)
        tb.setMinimumHeight(240)
        if mono:
            tb.setStyleSheet("font-family:Consolas,monospace; font-size:12px;")
        # 让文本框吃掉整页剩余高度（大屏上别再只占 240px、下面空一大片）
        self.ana_cards_lay.addWidget(tb, 1)

    def _render_analysis(self):
        try:
            data = getattr(self, "_ana_data", None)
            if not data:
                return
            key = self.ana_sel.currentData() if hasattr(self, "ana_sel") else "summary"
            sec = data.get(key) or data.get("summary")
            hits = sec["hits"]
            self.ana_hint.setText(
                "日期 %s ｜ 共 %d 局 ｜ 高价值阈值 %s ｜ 当前查看【%s】｜ 命中 %d 局"
                "　（下面每条显示这一局的完整数据：逐回合估价/出价、四家出价、成交价、实际价值、收益；"
                "点『🔄 刷新』重新读取。结算截图看「高价值截图」页）"
                "　读取于 %s"
                % (
                    self._ana_day,
                    self._ana_count,
                    format(self._ana_thr, ","),
                    self.ana_sel.currentText(),
                    len(hits),
                    datetime.datetime.now().strftime("%H:%M:%S"),
                )
            )
            if hits:
                self._build_analysis_cards(self._ana_day, hits)
            else:
                self._show_analysis_text(sec["text"])
        except Exception as e:
            import traceback

            self._show_analysis_text("渲染出错：%s\n\n%s" % (e, traceback.format_exc()[-800:]))

    def _clear_analysis_cards(self):
        try:
            while self.ana_cards_lay.count():
                it = self.ana_cards_lay.takeAt(0)
                wd = it.widget()
                if wd is not None:
                    wd.deleteLater()
        except Exception:
            pass

    def _build_analysis_cards(self, day, hits):
        self._clear_analysis_cards()
        head = QLabel(
            "【%s】命中 %d 场"
            % (self.ana_sel.currentText() if hasattr(self, "ana_sel") else "", len(hits))
        )
        hf = head.font()
        hf.setBold(True)
        hf.setPointSize(hf.pointSize() + 1)
        head.setFont(hf)
        head.setObjectName("anaHead")
        self.ana_cards_lay.addWidget(head)
        if not hits:
            self.ana_cards_lay.addWidget(QLabel("（本日没有命中「高价值」的对局）"))
            self.ana_cards_lay.addStretch(1)
            return
        seen = set()
        for tag, rec in hits:
            key = (rec["no"], rec.get("time") or "")
            if key in seen:
                continue
            seen.add(key)
            box = QGroupBox(
                "第%s场 ｜ %s ｜ %s ｜ %s" % (rec["no"], rec["time"], rec["result"], tag + "命中")
            )
            v = QVBoxLayout(box)
            info = QLabel(rec["text"])
            info.setWordWrap(True)
            info.setStyleSheet("font-family:Consolas,monospace; font-size:12px;")
            v.addWidget(info)
            self.ana_cards_lay.addWidget(box)
        self.ana_cards_lay.addStretch(1)


    def refresh_dates(self):
        days = date_list()
        today = datetime.date.today().strftime("%Y-%m-%d")
        cbs = [(self.log_date, LOG_ROOT, False), (self.shot_date, SHOT_ROOT, False)]
        if hasattr(self, "ana_date"):
            cbs.append((self.ana_date, LOG_ROOT, True))
        for cb, root, with_all in cbs:
            cur = cb.currentText()
            cb.blockSignals(True)
            cb.clear()
            if with_all:
                cb.addItem(ALL_DAYS)
            cb.addItems(days if days else [today])
            target = None
            if with_all and cur == ALL_DAYS:
                target = ALL_DAYS
            elif cur in days:
                target = cur
            if target is None:
                target = today if today in days else None
            if target is None:
                for d in days:
                    if self._has_files(root, d):
                        target = d
                        break
            cb.setCurrentText(target or today)
            cb.blockSignals(False)
        if self.stack.currentIndex() == 2:
            self.load_file_list()
        elif self.stack.currentIndex() == 3:
            self.load_shots()

    def on_tab_changed(self, idx):
        self._toggle_log_auto(self.log_auto.isChecked())
        try:
            if idx == 2:
                self.refresh_dates()
                self.load_file_list()
                self.load_log()
            elif idx == 3:
                self.refresh_dates()
                self.load_shots()
            elif idx == 4:
                self.refresh_dates()
                self.load_analysis()
            elif idx == 5:
                self.gp_refresh_state()
            elif idx == 0:
                self.refresh_chest()
                self._refresh_live_log()
            elif idx == 6:
                # 切过去就刷一次，别让人对着旧数据干等两秒
                try:
                    self.assist.refresh()
                except Exception:
                    pass
            elif idx == 7:
                try:
                    self.vision_report.refresh()
                except Exception:
                    pass
        except Exception as e:
            try:
                self.msg.setPlainText("刷新出错：%s" % e)
            except Exception:
                pass

    @staticmethod
    def _has_files(root, day):
        p = os.path.join(root, day or "")
        try:
            return os.path.isdir(p) and any(
                os.path.isfile(os.path.join(p, f)) for f in os.listdir(p)
            )
        except Exception:
            return False

    def open_folder(self, which):
        today = datetime.date.today().strftime("%Y-%m-%d")
        target = {
            "": REC,
            "日志": os.path.join(LOG_ROOT, today),
            "高价值截图": os.path.join(SHOT_ROOT, today),
        }.get(which, REC)
        if not os.path.isdir(target):
            target = REC
        try:
            os.startfile(target)
        except Exception as e:
            QMessageBox.warning(self, "打不开", str(e))


MODE_HINT = {
    "preset": (
        "档位模式【默认】：完全不看对手出多少，只看【自己的估价】落在哪一档，按下面这张档位表出价。\n"
        "永恒之心档 = 估价 > 131.452 万且 < 233.3333 万，第 1 回合统一 1,145,140；"
        "高价值档从估价 > 233.3333 万起，共七档。\n"
        "每一档的第 1 回合出首轮价/预设价；第 2 回合起按【当回合估价 × 该档该回合的倍率】，\n"
        "新档倍率留空时保持首轮价或上轮已出价，不会当成 1.0 重新计算，也不会降价，\n"
        "算出来的数字还会向下贴成规整数字（1,888,888 / 6,666,888 / 17,888,888 这种）——\n"
        "每一档、每一回合的倍率和算出来的价钱，下面都写出来了，随时能改。\n"
        "好处是不会被『一个人开两个号抬价』骗；代价是遇到别人也看上的仓，容易按老价钱买贵或买不到。"
    ),
    "opponent": (
        "跟价模式：第 1 回合先保底撑住；低价卡价区间"
        "（131.452 万 < 估价 < 233.3333 万）直接出 1,145,140。"
        "从第 2 回合起盯着【对手上一轮的出价】加价抢仓。\n"
        "第 3 回合起带一道信息差闸门——只要「估价 > 对手上一轮最高价」就继续出价。"
        "打开『不退出模式』后，从第 1 回合保底价开始每回合至少 ×1.05 递增，"
        "即使估价或信息差不够也不降价、不退出。"
    ),
}
OPP_SETTINGS = SETTINGS

PRESET_SETTINGS = [
    (
        "OPENING_PRICE_1",
        "固定开局价（区间留空时才用）",
        "int",
        "522999",
        "档位模式下第 1 回合的保底价。区间那条填了就走区间，留空才用这个。"
        "原来四个候选已经并成这一个。",
    ),
    (
        "TIER_CAP_BY_PRICE",
        "后续回合按估价封顶",
        "bool",
        "0",
        "0（当前）= 不封顶，按『估价 × 倍率』照算，允许超过估价（倍率 1.2 = 出到估价的 1.2 倍）。"
        "估价只是每件藏品的最低价，红档最低 3 万、平均 280 万，超估价照样大赚；"
        "1 = 第 2 回合起出价不超过自己的估价（倍率大于 1 的档位会被夹住，上一轮已经更高就按住不降）。",
    ),
    (
        "EXIT_BELOW_PRICE",
        "第 3 回合退出线",
        "int",
        "999999",
        "第 3 回合起（小吱揭示后）估价低于这个数就退出、不浪费时间 —— "
        "但只限【信息差没命中】的时候：只要「估价 > 对手上一轮出价 × 信息差门槛」，就算有信息差、"
        "这条退出线完全不看（照常按倍数跟价）。",
    ),
    (
        "CHASE_TO_END",
        "不退出模式（拍到底）",
        "bool",
        "0",
        "0 = 按上面的退出线退出【默认】；1 = 第 3 回合起估价再低也不退出。"
        "第1回合出本局随机保底，之后每回合至少按上回合已出价的递增倍率上涨，绝不降价；"
        "即使估价、信息差或档位表本应退出，也继续出这条保底链。",
    ),
    (
        "CHASE_STEP_RATIO",
        "不退出模式每回合递增倍率",
        "float",
        "1.05",
        "默认 1.05。先按倍率算，再向上贴成 …999。例：555999 → 583999 → 613999。"
        "这是最低价链；对手跟价算出的更高价格仍可正常采用。只在不退出模式开启时生效。",
    ),
    (
        "FAST_SETTLE",
        "红点跳过总开关",
        "bool",
        "1",
        "1（默认）= 自己拍到的局，结算时命中下面任一阈值就【跳过点红点】：红色整仓留着不卖（点红点才是把红一起全卖），还省一次点击；0 = 不管值多少钱都照常点红点（全卖，结算慢一点）。",
    ),
    (
        "FAST_SETTLE_VALUE",
        "红点跳过阈值 · 实际价值",
        "int",
        "10000000",
        "结算显示的实际价值超过这个数 → 同样跳过红点（红色不卖）。上面两个阈值满足任意一个就跳过。",
    ),
    (
        "STOP_BELOW_FUNDS",
        "资金不足自动停（元）",
        "int",
        "5000000",
        "资产低于这个数就自动停脚本，避免越亏越多。",
    ),
    (
        "READ_TOLERANCE",
        "出价金额校验容差（±）",
        "float",
        "0.5",
        "OCR 读金额允许的误差，0.5 = ±50%；改 0 就是严格校验（读错一位就清空重输）。",
    ),
    (
        "READ_RIVAL_BIDS",
        "读取对手出价",
        "bool",
        "1",
        "1 = 读左侧玩家列表的对手出价（跟价的基础）；关掉就只能出保底/卡价。",
    ),
    (
        "BIG_LOT_SHOT",
        "高价值成交截图",
        "bool",
        "1",
        "1 = 实际价值超过档位线时自动截图，存到 记录\\高价值截图\\日期\\，本面板第 4 页能直接看。",
    ),
    (
        "NIGHT_USE_TIER",
        "天黑场地按档位价出",
        "bool",
        "1",
        "出现场地效果『天黑了』（只显示排名、看不到金额）时，按估价用下面的档位价出。",
    ),
    (
        "NIGHT_CAP_BY_PRICE",
        "天黑档位价也被估价夹住",
        "bool",
        "1",
        "1 = 天黑时档位价不超过自己的估价（更保守、不容易买贵）；0 = 照档位表出。",
    ),
    (
        "SHOT_KEEP_MAX",
        "截图留多少张（0=全留）",
        "int",
        "0",
        "0（当前）= 全部保留、一张都不删 —— 方便回头翻每一局的画面。注意占地方：一局大概存 5~8 张、每张约 200 KB，一天 500 局约 0.5~1 GB。填 300 就回到『只留最近 300 张』。",
    ),
    (
        "TOOL_R1",
        "第 1 回合用几号仪器",
        "int",
        "4",
        "仪器从上到下编号 1~5：1=特殊鉴定仪器(占格最大的一件)｜2=超级品鉴仪器(10件品质)｜3=超级尺寸仪器(12件轮廓)｜4=超级鉴定仪器(6件藏品)｜5=金品计数仪器(金色总数)。0 = 该回合不用仪器。默认 4123 = 前 4 回合依次用 4/1/2/3 号。",
    ),
    (
        "TOOL_R2",
        "第 2 回合用几号仪器",
        "int",
        "1",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R3",
        "第 3 回合用几号仪器",
        "int",
        "2",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R4",
        "第 4 回合用几号仪器",
        "int",
        "3",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_R5",
        "第 5 回合用几号仪器",
        "int",
        "0",
        "同上：这一回合用几号仪器（0 = 不用）。",
    ),
    (
        "TOOL_PRICES",
        "各仪器单价（1-5 号，元）",
        "str",
        "50000,10000,10000,10000,20000",
        "按 1~5 号顺序填，逗号隔开。默认 1号5万、2号1万、3号1万、4号1万、5号2万。用了几台仪器就按这个表扣几台的钱，成本统计、净收益都跟着它算。",
    ),
    (
        "INSTRUMENT_EFFECT_REQUIRED",
        "哪些仪器要确认生效",
        "str",
        "2,3,4",
        "填几号仪器（逗号隔开）。用完这台仪器后要等「估价变了」才算成功；"
        "没列进来的（比如 1 号、5 号本来就不改估价）就不陪它等，省几秒。留空 = 都要等。",
    ),
    (
        "INSTRUMENT_FAILURE_PAUSE",
        "仪器没生效就暂停",
        "bool",
        "0",
        "打开后：上面这些仪器用完，等到超时估价都没变 → 直接暂停脚本，"
        "别拿旧估价乱出价。默认关（记一笔、继续读完整估价）。",
    ),
    (
        "WAREHOUSE_VISION_ENABLED",
        "仓库视觉（认整仓里的具体藏品）",
        "bool",
        "0",
        "打开后每回合抓一次整仓图，按 230 个藏品模板认出每个格子里大概是什么、"
        "再算一个价值区间。第一次打开要多等一两秒加载模型，之后每回合多花约 1 秒。默认关。",
    ),
    (
        "WAREHOUSE_VISION_SHADOW_MODE",
        "仓库视觉 · 只看不改（影子模式）",
        "bool",
        "1",
        "开着时只打印、只记日志，不动出价 —— 先跑几局看它认得准不准。"
        "想让它参与出价再关掉这个。",
    ),
    (
        "WAREHOUSE_VISION_RISK_ENABLED",
        "仓库视觉 · 参与出价",
        "bool",
        "0",
        "总开关打开、影子模式关掉、这个也打开，才会拿它的均值/P75 去修正估价。"
        "三层默认都关着 —— 没看到几局靠谱数据之前别开。",
    ),
    (
        "WAREHOUSE_VISION_SAVE_IMAGE",
        "仓库视觉 · 存整仓图",
        "bool",
        "0",
        "每次识别顺手存一张整仓图到 记录\\仓库视觉\\日期\\。"
        "想事后对账「它认得准不准」就打开；一张约一百多 KB，只留最近 300 张。",
    ),
    (
        "SCAN_AT_ROUND",
        "整仓识别·第几回合",
        "int",
        "2",
        "在第几回合拉一次整仓识别（把整个仓从下翻一遍）要认的藏品；认到了这一回合就不用仪器（省下巨物）。0 = 不识别。",
    ),
    (
        "SCAN_TIMING",
        "整仓识别·时机（0=仪器之前）",
        "int",
        "0",
        "0 = 用仪器之前识别（认到了就不点这台仪器）；1 = 用仪器之后识别（仪器照点，只在日志里记认到了什么）。",
    ),
    (
        "SCAN_ITEM_NAMES",
        "整仓识别·要认哪些藏品",
        "str",
        "储钱小哼,万有星仪,绝对是亲手钓的鱼",
        "逗号隔开。模板放 记录\\藏品模板\\<名字>.png（或 素材\\item_<名字>.png）。默认认的就是群友、高玩、臭鱼。",
    ),
    (
        "SCAN_SKIP_TOOL",
        "整仓识别·认到就不用仪器",
        "int",
        "1",
        "1 = 认到上面任意一件 → 这一回合不点仪器（省下巨物）；0 = 照常点仪器，只记日志。",
    ),
    (
        "GATE_179",
        "永恒之心档·触发估价",
        "int",
        "1314520",
        "估价严格大于 1,314,520 且小于 2,333,333 时进入本档；" "正好等于两端边界时不进入本档。",
    ),
    (
        "LOW_TIER_OPEN",
        "永恒之心档·首轮价（第 1 回合）",
        "int",
        "1145140",
        "本档第 1 回合统一卡价 1,145,140。",
    ),
    ("LOW_TIER_R2_MULT", "永恒之心档·第 2 回合倍率（估价×倍率）", "float", "1.3", ""),
    ("LOW_TIER_R3_MULT", "永恒之心档·第 3 回合倍率（估价×倍率）", "float", "1.5", ""),
    ("LOW_TIER_R4_MULT", "永恒之心档·第 4 回合倍率（估价×倍率）", "float", "1.8", ""),
    ("LOW_TIER_R5_MULT", "永恒之心档·第 5、6 回合倍率（估价×倍率）", "float", "2.0", ""),
    ("GATE_233", "乐园巧克力档·触发估价", "int", "2333333", "估价超过它就进入本档。"),
    ("TIER_233_OPEN", "乐园巧克力档·预设价（第 1 回合）", "int", "1888999", "乐园巧克力档第 1 回合固定出价。"),
    (
        "TIER_233_R2_MULT",
        "乐园巧克力档·第 2 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 第 2 回合保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_233_R3_MULT",
        "乐园巧克力档·第 3 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_233_R4_MULT",
        "乐园巧克力档·第 4 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_233_R5_MULT",
        "乐园巧克力档·第 5、6 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    ("GATE_321", "家用电影机档·触发估价", "int", "3210000", "估价超过它就进入本档。"),
    ("TIER_321_OPEN", "家用电影机档·预设价（第 1 回合）", "int", "2199999", "家用电影机档第 1 回合固定出价。"),
    (
        "TIER_321_R2_MULT",
        "家用电影机档·第 2 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 第 2 回合保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R3_MULT",
        "家用电影机档·第 3 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R4_MULT",
        "家用电影机档·第 4 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    (
        "TIER_321_R5_MULT",
        "家用电影机档·第 5、6 回合倍率（估价×倍率，可留空）",
        "float_optional",
        "",
        "留空 = 保持首轮预设价或上轮已出价，不降价；填写后按估价×倍率正常计算。",
    ),
    ("GATE_280", "超级存储盘档·触发估价", "int", "5121024", "估价超过它 → 超级存储盘档，出下面的预设价。"),
    ("TIER_280_OPEN", "超级存储盘档·预设价（第 1 回合）", "int", "2888888", "超级存储盘档第 1 回合出价。"),
    (
        "TIER_280_R2_MULT",
        "超级存储盘档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R3_MULT",
        "超级存储盘档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R4_MULT",
        "超级存储盘档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_280_R5_MULT",
        "超级存储盘档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("GATE_898", "翠刃档·触发估价", "int", "8980000", "估价超过它 → 翠刃档。"),
    ("TIER_420_OPEN", "翠刃档·预设价（第 1 回合）", "int", "4222888", "翠刃档第 1 回合出价。"),
    (
        "TIER_420_R2_MULT",
        "翠刃档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R3_MULT",
        "翠刃档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R4_MULT",
        "翠刃档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_420_R5_MULT",
        "翠刃档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("GATE_588", "碧波天垂档·触发估价", "int", "11235813", "估价超过它 → 碧波天垂档。"),
    ("TIER_588_OPEN", "碧波天垂档·预设价（第 1 回合）", "int", "5888888", "碧波天垂档第 1 回合出价。"),
    (
        "TIER_588_R2_MULT",
        "碧波天垂档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R3_MULT",
        "碧波天垂档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R4_MULT",
        "碧波天垂档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_588_R5_MULT",
        "碧波天垂档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("GATE_1680", "夜光杯档·触发估价", "int", "16800000", "估价超过它 → 夜光杯档。"),
    (
        "TIER_620_OPEN",
        "夜光杯档·预设价（第 1 回合）",
        "int",
        "6222888",
        "夜光杯档第 1 回合出价。",
    ),
    (
        "TIER_620_R2_MULT",
        "夜光杯档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R3_MULT",
        "夜光杯档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R4_MULT",
        "夜光杯档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_620_R5_MULT",
        "夜光杯档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    ("GATE_666", "Pendragon模型档·触发估价", "int", "20171210", "估价超过它 → Pendragon模型档。"),
    (
        "TIER_666_OPEN",
        "Pendragon模型档·预设价（第 1 回合）",
        "int",
        "6666888",
        "Pendragon模型档第 1 回合出价（最高档）。",
    ),
    (
        "TIER_666_R2_MULT",
        "Pendragon模型档·第 2 回合倍率（估价×倍率）",
        "float",
        "0.7",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R3_MULT",
        "Pendragon模型档·第 3 回合倍率（估价×倍率）",
        "float",
        "1.0",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R4_MULT",
        "Pendragon模型档·第 4 回合倍率（估价×倍率）",
        "float",
        "1.1",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "TIER_666_R5_MULT",
        "Pendragon模型档·第 5、6 回合倍率（估价×倍率）",
        "float",
        "1.2",
        "按 估价 × 这个数 出；留空或填 0 = 不降价。",
    ),
    (
        "RESTART_ON_STUCK",
        "卡死自动重启",
        "bool",
        "1",
        "1（默认）= 开：挂机中长时间没有任何进展，就自动关掉游戏、走下面的快捷方式重开；0 = 关（卡住了也不重启，只是原地重试）。",
    ),
    (
        "LAUNCH_LINK",
        "游戏启动快捷方式",
        "str",
        "",
        "桌面那个游戏快捷方式的路径（每台电脑不一样，自己填）。例：C:/Users/xxx/Desktop/异环.lnk；也可以填启动器 exe 的全路径。反斜杠会自动换成正斜杠，留空 = 不自动重启。",
    ),
    (
        "STUCK_MINUTES",
        "多久没进展算卡死（分钟）",
        "int",
        "5",
        "默认 5 分钟。连续这么久没有任何进展（没进大厅 / 没识别到回合 / 没出价 / 没结算）才算卡死，正常等对手出价（最长 45 秒）不会被当成卡死。别调太小：一局平均 2 分多钟，建议 ≥3。",
    ),
    (
        "RESTART_HOURLY_CAP",
        "每小时最多自动重启（次）",
        "int",
        "5",
        "防止无限重启：一小时内超过这个次数就停下载机、写日志，等人工看一眼。",
    ),
    (
        "TITLE_WAIT_MINUTES",
        "等标题画面的上限（分钟）",
        "int",
        "10",
        "点了【开始游戏】后游戏还要做资源校验。这里等标题画面（Enter 图标 / 登录页 / 大厅，任一个出现就算到）；超过这个时间还没出现，就把游戏关掉、重来一轮。默认 10 分钟；更新完第一次启动或机器慢可以调大。",
    ),
    (
        "LAUNCHER_WAIT_SEC",
        "匹配开始游戏·每次等待（秒）",
        "int",
        "30",
        "抓到启动器窗口后，先等这么久让界面渲染完再匹配【开始游戏】按钮；没匹配到也是等这么久再重新匹配。默认 30 秒。",
    ),
    (
        "LAUNCHER_TRIES",
        "匹配开始游戏·最多几次",
        "int",
        "0",
        "0（默认）= 不限：一直等到【开始游戏】按钮出现再点（更新/下载/修复可能很久）。填 3 就表示三次都没找到就当卡住、关掉重来一轮。",
    ),
    (
        "WAIT_ON_RECONNECT",
        "掉线自动等待",
        "bool",
        "1",
        "1（默认）= 开：游戏弹出「网络不稳定，尝试重新连接中」时，脚本原地等它自己恢复（不点任何东西、也不算卡死）；0 = 关（维持老行为，会一直硬点，最后报「出价面板消失 / 找不到 ESC」）。",
    ),
    (
        "RECONNECT_WAIT_MIN",
        "掉线最多等多久（分钟）",
        "int",
        "3",
        "默认 3 分钟。等待期间不会关游戏；超过这个时间还没恢复就交回主流程，由上面的『卡死自救』按设定处理（关游戏重开）。建议别填得比『多久没进展算卡死』更大。",
    ),
    (
        "BACKGROUND_RUN",
        "后台模式（游戏可被盖住、不抢前台）",
        "bool",
        "0",
        "1 = 后台模式：游戏窗口被浏览器等完全盖住也照样跑，脚本不抢前台。"
        "需要管理员运行；游戏窗口不能最小化（用被别的窗口盖住代替）。改完重启脚本才生效。",
    ),
    (
        "CLICK_SPEED",
        "点击速度（1稳妥/2标准/3极速）",
        "int",
        "2",
        "1 = 稳妥（和最早那版前台点击一样，一次约 0.23 秒）；2 = 标准（默认，一次约 0.10 秒）；"
        "3 = 极速（一次约 0.07 秒，仍然留了让游戏反应的安全余量）。主界面上那三个按钮改的就是这一项。",
    ),
    (
        "CURSOR_RESTORE",
        "后台模式·点完把鼠标还原",
        "bool",
        "1",
        "1（默认）= 每次后台点击后，把你原来的鼠标位置还回去（推荐，不还原的话指针会留在游戏里）。",
    ),
    (
        "CURSOR_STEAL_GUARD",
        "后台模式·防游戏吸鼠标",
        "bool",
        "1",
        "1（默认）= 开着。异环在后台状态下会把你鼠标指针吸到屏幕中心，脚本会立刻把它挪回你原来的位置；"
        "0 = 不干预（你会看到指针隔一会儿跳到屏幕中间）。",
    ),
]

MODE_SETTINGS = {"opponent": OPP_SETTINGS, "preset": PRESET_SETTINGS}

# 「只看常用」放出来的这一小把 —— 日常真会动手调的，其余一百多项都收着
COMMON_KEYS = {
    "__tier__",
    "SLOW_PC_SKIP_HEAVY",
    "SLOW_PC_K_THRESHOLD",
    "NORMAL_MULT_CARD",
    "SAFE_MODE",
    "SAFE_CAP_RATIO",
    "HARD_CAP_MULT",
    "EXIT_BELOW_PRICE",
    "CHASE_TO_END",
    "CHASE_STEP_RATIO",
    "OPENING_PRICE_RANGE",
    "MIN_BID_AMOUNT",
    "STOP_BELOW_FUNDS",
    "NIGHT_USE_TIER",
    "CURSOR_YIELD_USER",
    "WAREHOUSE_VISION_MODE",
    "BIG_LOT_SHOT",
    "SHOT_KEEP_MAX",
    "READ_RIVAL_BIDS",
}

# 从属参数：主开关没开的时候，底下这几条先别占地方（搜索时照样能搜到）
DEPENDS_ON = {
    "SAFE_CAP_RATIO": "SAFE_MODE",
    "SAFE_CAP_RATIO_LATE": "SAFE_MODE",
    "NO_EXIT_GUARD_START_ROUND": "NO_EXIT_GUARD_ENABLED",
    "NO_EXIT_GUARD_MIN_VALUE_RATIO": "NO_EXIT_GUARD_ENABLED",
    "NO_EXIT_GUARD_MAX_OPP_SUPPORT": "NO_EXIT_GUARD_ENABLED",
    "FAST_SETTLE_VALUE": "FAST_SETTLE",
    "CHASE_STEP_RATIO": "CHASE_TO_END",
    "NIGHT_CAP_BY_PRICE": "NIGHT_USE_TIER",
    "WAREHOUSE_VISION_SHADOW_MODE": "WAREHOUSE_VISION_ENABLED",
    "WAREHOUSE_VISION_RISK_ENABLED": "WAREHOUSE_VISION_ENABLED",
    "WAREHOUSE_VISION_SAVE_IMAGE": "WAREHOUSE_VISION_ENABLED",
}

# 少数开关用「关/开」说不清，这里给它们自己的选项文字（下标 0 必须对应 1）
BOOL_LABELS = {
    "SAFE_MODE": ["1  求稳", "0  拿仓（抢得凶）"],
}

GROUP_OF = {
    "SLOW_PC_SKIP_HEAVY": "通用",
    "SLOW_PC_K_THRESHOLD": "通用",
    ("opponent", "SAFE_MODE"): "出价风格",
    ("opponent", "SAFE_CAP_RATIO"): "出价风格",
    ("opponent", "SAFE_CAP_RATIO_LATE"): "出价风格",
    ("opponent", "HARD_CAP_MULT"): "出价风格",
    ("opponent", "NO_EXIT_GUARD_ENABLED"): "不退出模式",
    ("opponent", "NO_EXIT_GUARD_START_ROUND"): "不退出模式",
    ("opponent", "NO_EXIT_GUARD_MIN_VALUE_RATIO"): "不退出模式",
    ("opponent", "NO_EXIT_GUARD_MAX_OPP_SUPPORT"): "不退出模式",
    ("opponent", "RIVAL_PREMIUM_CAP"): "出价风格",
    ("opponent", "BID_AUTO_PRICE"): "通用",
    ("opponent", "OPENING_PRICE_RANGE"): "通用",
    ("opponent", "OPENING_PRICE_1"): "通用",
    ("opponent", "EXIT_BELOW_PRICE"): "通用",
    ("opponent", "CHASE_TO_END"): "不退出模式",
    ("opponent", "FAST_SETTLE"): "通用",
    ("opponent", "FAST_SETTLE_VALUE"): "通用",
    ("opponent", "STOP_BELOW_FUNDS"): "通用",
    ("opponent", "READ_TOLERANCE"): "通用",
    ("opponent", "READ_RIVAL_BIDS"): "通用",
    ("opponent", "BIG_LOT_SHOT"): "通用",
    ("opponent", "NIGHT_USE_TIER"): "通用",
    ("opponent", "NIGHT_CAP_BY_PRICE"): "通用",
    ("opponent", "SHOT_KEEP_MAX"): "通用",
    ("opponent", "R2_RIVAL_MULT"): "前两回合 · 跟价",
    ("opponent", "INFO_ADVANTAGE_RATIO"): "第 3 回合起 · 信息差闸门",
    ("opponent", "BAIL_IF_OUTBID"): "第 3 回合起 · 信息差闸门",
    ("opponent", "R3_RIVAL_MULT"): "第 3~6 回合 · 跟价倍数",
    ("opponent", "R4_RIVAL_MULT"): "第 3~6 回合 · 跟价倍数",
    ("opponent", "R5_RIVAL_MULT"): "第 3~6 回合 · 跟价倍数",
    ("opponent", "OVER_PRICE_ROOM"): "跟价 · 超估价额度（抢仓）",
    ("opponent", "OVER_PRICE_FROM_R"): "跟价 · 超估价额度（抢仓）",
    ("opponent", "OVER_PRICE_FROM_R"): "跟价 · 超估价额度（抢仓）",
    ("opponent", "BIG_LOT_GATE"): "高价值仓（估价 > 233.3333 万，七档）",
    ("opponent", "TOOL_R1"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "TOOL_R2"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "TOOL_R3"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "TOOL_R4"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "TOOL_R5"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "TOOL_PRICES"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "WAREHOUSE_VISION_ENABLED"): "整仓识别（认到就不用仪器）",
    ("opponent", "WAREHOUSE_VISION_SHADOW_MODE"): "整仓识别（认到就不用仪器）",
    ("opponent", "WAREHOUSE_VISION_RISK_ENABLED"): "整仓识别（认到就不用仪器）",
    ("opponent", "WAREHOUSE_VISION_SAVE_IMAGE"): "整仓识别（认到就不用仪器）",
    ("opponent", "SCAN_AT_ROUND"): "整仓识别（认到就不用仪器）",
    ("opponent", "SCAN_TIMING"): "整仓识别（认到就不用仪器）",
    ("opponent", "SCAN_SKIP_TOOL"): "整仓识别（认到就不用仪器）",
    ("opponent", "SCAN_ITEM_NAMES"): "整仓识别（认到就不用仪器）",
    ("opponent", "GATE_179"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "LOW_TIER_OPEN"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "LOW_TIER_R2_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "LOW_TIER_R3_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "LOW_TIER_R4_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "LOW_TIER_R5_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("opponent", "GATE_233"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "TIER_233_OPEN"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "TIER_233_R2_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "TIER_233_R3_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "TIER_233_R4_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "TIER_233_R5_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("opponent", "GATE_321"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "TIER_321_OPEN"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "TIER_321_R2_MULT"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "TIER_321_R3_MULT"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "TIER_321_R4_MULT"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "TIER_321_R5_MULT"): "家用电影机档 · 估价 > 321 万",
    ("opponent", "GATE_280"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "TIER_280_OPEN"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "TIER_280_R2_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "TIER_280_R3_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "TIER_280_R4_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "TIER_280_R5_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("opponent", "GATE_898"): "翠刃档 · 估价 > 898 万",
    ("opponent", "TIER_420_OPEN"): "翠刃档 · 估价 > 898 万",
    ("opponent", "TIER_420_R2_MULT"): "翠刃档 · 估价 > 898 万",
    ("opponent", "TIER_420_R3_MULT"): "翠刃档 · 估价 > 898 万",
    ("opponent", "TIER_420_R4_MULT"): "翠刃档 · 估价 > 898 万",
    ("opponent", "TIER_420_R5_MULT"): "翠刃档 · 估价 > 898 万",
    ("opponent", "GATE_588"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "TIER_588_OPEN"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "TIER_588_R2_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "TIER_588_R3_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "TIER_588_R4_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "TIER_588_R5_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("opponent", "GATE_1680"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "TIER_620_OPEN"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "TIER_620_R2_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "TIER_620_R3_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "TIER_620_R4_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "TIER_620_R5_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("opponent", "GATE_666"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "TIER_666_OPEN"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "TIER_666_R2_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "TIER_666_R3_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "TIER_666_R4_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "TIER_666_R5_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("opponent", "RESTART_ON_STUCK"): "流程重启 · 卡死自救",
    ("opponent", "LAUNCH_LINK"): "流程重启 · 卡死自救",
    ("opponent", "STUCK_MINUTES"): "流程重启 · 卡死自救",
    ("opponent", "RESTART_HOURLY_CAP"): "流程重启 · 卡死自救",
    ("opponent", "TITLE_WAIT_MINUTES"): "流程重启 · 卡死自救",
    ("opponent", "LAUNCHER_WAIT_SEC"): "流程重启 · 卡死自救",
    ("opponent", "LAUNCHER_TRIES"): "流程重启 · 卡死自救",
    ("opponent", "WAIT_ON_RECONNECT"): "流程重启 · 卡死自救",
    ("opponent", "RECONNECT_WAIT_MIN"): "流程重启 · 卡死自救",
    ("opponent", "CURSOR_RESTORE"): "运行方式 · 后台运行",
    ("opponent", "CURSOR_STEAL_GUARD"): "运行方式 · 后台运行",
    ("preset", "OPENING_PRICE_RANGE"): "通用",
    ("preset", "OPENING_PRICE_1"): "通用",
    ("preset", "EXIT_BELOW_PRICE"): "通用",
    ("preset", "CHASE_TO_END"): "不退出模式",
    ("preset", "FAST_SETTLE"): "通用",
    ("preset", "FAST_SETTLE_VALUE"): "通用",
    ("preset", "STOP_BELOW_FUNDS"): "通用",
    ("preset", "READ_TOLERANCE"): "通用",
    ("preset", "READ_RIVAL_BIDS"): "通用",
    ("preset", "BIG_LOT_SHOT"): "通用",
    ("preset", "NIGHT_USE_TIER"): "通用",
    ("preset", "NIGHT_CAP_BY_PRICE"): "通用",
    ("preset", "SHOT_KEEP_MAX"): "通用",
    ("preset", "TOOL_R1"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "TOOL_R2"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "TOOL_R3"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "TOOL_R4"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "TOOL_R5"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "TOOL_PRICES"): "每回合仪器（1-5 号，0=不用）",
    ("preset", "WAREHOUSE_VISION_ENABLED"): "整仓识别（认到就不用仪器）",
    ("preset", "WAREHOUSE_VISION_SHADOW_MODE"): "整仓识别（认到就不用仪器）",
    ("preset", "WAREHOUSE_VISION_RISK_ENABLED"): "整仓识别（认到就不用仪器）",
    ("preset", "WAREHOUSE_VISION_SAVE_IMAGE"): "整仓识别（认到就不用仪器）",
    ("preset", "SCAN_AT_ROUND"): "整仓识别（认到就不用仪器）",
    ("preset", "SCAN_TIMING"): "整仓识别（认到就不用仪器）",
    ("preset", "SCAN_SKIP_TOOL"): "整仓识别（认到就不用仪器）",
    ("preset", "SCAN_ITEM_NAMES"): "整仓识别（认到就不用仪器）",
    ("preset", "GATE_179"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "LOW_TIER_OPEN"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "LOW_TIER_R2_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "LOW_TIER_R3_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "LOW_TIER_R4_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "LOW_TIER_R5_MULT"): "永恒之心档 · 131.452 万 ~ 233.3333 万",
    ("preset", "GATE_233"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "TIER_233_OPEN"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "TIER_233_R2_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "TIER_233_R3_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "TIER_233_R4_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "TIER_233_R5_MULT"): "乐园巧克力档 · 估价 > 233.3333 万",
    ("preset", "GATE_321"): "家用电影机档 · 估价 > 321 万",
    ("preset", "TIER_321_OPEN"): "家用电影机档 · 估价 > 321 万",
    ("preset", "TIER_321_R2_MULT"): "家用电影机档 · 估价 > 321 万",
    ("preset", "TIER_321_R3_MULT"): "家用电影机档 · 估价 > 321 万",
    ("preset", "TIER_321_R4_MULT"): "家用电影机档 · 估价 > 321 万",
    ("preset", "TIER_321_R5_MULT"): "家用电影机档 · 估价 > 321 万",
    ("preset", "GATE_280"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "TIER_280_OPEN"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "TIER_280_R2_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "TIER_280_R3_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "TIER_280_R4_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "TIER_280_R5_MULT"): "超级存储盘档 · 估价 > 512 万",
    ("preset", "GATE_898"): "翠刃档 · 估价 > 898 万",
    ("preset", "TIER_420_OPEN"): "翠刃档 · 估价 > 898 万",
    ("preset", "TIER_420_R2_MULT"): "翠刃档 · 估价 > 898 万",
    ("preset", "TIER_420_R3_MULT"): "翠刃档 · 估价 > 898 万",
    ("preset", "TIER_420_R4_MULT"): "翠刃档 · 估价 > 898 万",
    ("preset", "TIER_420_R5_MULT"): "翠刃档 · 估价 > 898 万",
    ("preset", "GATE_588"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "TIER_588_OPEN"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "TIER_588_R2_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "TIER_588_R3_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "TIER_588_R4_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "TIER_588_R5_MULT"): "碧波天垂档 · 估价 > 1123 万",
    ("preset", "GATE_1680"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "TIER_620_OPEN"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "TIER_620_R2_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "TIER_620_R3_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "TIER_620_R4_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "TIER_620_R5_MULT"): "夜光杯档 · 估价 > 1680 万",
    ("preset", "GATE_666"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "TIER_666_OPEN"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "TIER_666_R2_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "TIER_666_R3_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "TIER_666_R4_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "TIER_666_R5_MULT"): "Pendragon模型档 · 估价 > 2017 万",
    ("preset", "RESTART_ON_STUCK"): "流程重启 · 卡死自救",
    ("preset", "LAUNCH_LINK"): "流程重启 · 卡死自救",
    ("preset", "STUCK_MINUTES"): "流程重启 · 卡死自救",
    ("preset", "RESTART_HOURLY_CAP"): "流程重启 · 卡死自救",
    ("preset", "TITLE_WAIT_MINUTES"): "流程重启 · 卡死自救",
    ("preset", "LAUNCHER_WAIT_SEC"): "流程重启 · 卡死自救",
    ("preset", "LAUNCHER_TRIES"): "流程重启 · 卡死自救",
    ("preset", "WAIT_ON_RECONNECT"): "流程重启 · 卡死自救",
    ("preset", "RECONNECT_WAIT_MIN"): "流程重启 · 卡死自救",
    ("preset", "CURSOR_RESTORE"): "运行方式 · 后台运行",
    ("preset", "CURSOR_STEAL_GUARD"): "运行方式 · 后台运行",
}

# 原来这几个没写归属，掉进「其它」那个垃圾桶里了
GROUP_OF.update({
    ("opponent", "MIN_BID_AMOUNT"): "通用",
    ("opponent", "CHASE_STEP_RATIO"): "不退出模式",
    ("opponent", "RED_PIECE_BONUS"): "出价风格",
    ("opponent", "GOLD_PIECE_BONUS"): "出价风格",
    ("opponent", "INSTRUMENT_EFFECT_REQUIRED"): "每回合仪器（1-5 号，0=不用）",
    ("opponent", "INSTRUMENT_FAILURE_PAUSE"): "每回合仪器（1-5 号，0=不用）",
})
# 【大肥鱼】10 个档位补充归属（含两个新档：守望者 / 金锦鲤雕像，以及每档的『保留』开关）
GROUP_OF.update({
    "GATE_1100": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_OPEN": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_R2_MULT": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_R3_MULT": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_R4_MULT": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_R5_MULT": "守望者档 · 估价 110 万 ~ 131.452 万",
    "TIER_1100_KEEP": "守望者档 · 估价 110 万 ~ 131.452 万",
    "GATE_179": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_OPEN": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_R2_MULT": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_R3_MULT": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_R4_MULT": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_R5_MULT": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "LOW_TIER_KEEP": "永恒之心档 · 131.452 万 ~ 233.3333 万",
    "GATE_233": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_OPEN": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_R2_MULT": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_R3_MULT": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_R4_MULT": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_R5_MULT": "乐园巧克力档 · 估价 > 233.3333 万",
    "TIER_233_KEEP": "乐园巧克力档 · 估价 > 233.3333 万",
    "GATE_321": "家用电影机档 · 估价 > 321 万",
    "TIER_321_OPEN": "家用电影机档 · 估价 > 321 万",
    "TIER_321_R2_MULT": "家用电影机档 · 估价 > 321 万",
    "TIER_321_R3_MULT": "家用电影机档 · 估价 > 321 万",
    "TIER_321_R4_MULT": "家用电影机档 · 估价 > 321 万",
    "TIER_321_R5_MULT": "家用电影机档 · 估价 > 321 万",
    "TIER_321_KEEP": "家用电影机档 · 估价 > 321 万",
    "GATE_280": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_OPEN": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_R2_MULT": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_R3_MULT": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_R4_MULT": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_R5_MULT": "超级存储盘档 · 估价 > 512 万",
    "TIER_280_KEEP": "超级存储盘档 · 估价 > 512 万",
    "GATE_420": "翠刃档 · 估价 > 898 万",
    "TIER_420_OPEN": "翠刃档 · 估价 > 898 万",
    "TIER_420_R2_MULT": "翠刃档 · 估价 > 898 万",
    "TIER_420_R3_MULT": "翠刃档 · 估价 > 898 万",
    "TIER_420_R4_MULT": "翠刃档 · 估价 > 898 万",
    "TIER_420_R5_MULT": "翠刃档 · 估价 > 898 万",
    "TIER_420_KEEP": "翠刃档 · 估价 > 898 万",
    "GATE_588": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_OPEN": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_R2_MULT": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_R3_MULT": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_R4_MULT": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_R5_MULT": "碧波天垂档 · 估价 > 1123 万",
    "TIER_588_KEEP": "碧波天垂档 · 估价 > 1123 万",
    "GATE_620": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_OPEN": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_R2_MULT": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_R3_MULT": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_R4_MULT": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_R5_MULT": "夜光杯档 · 估价 > 1680 万",
    "TIER_620_KEEP": "夜光杯档 · 估价 > 1680 万",
    "GATE_666": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_OPEN": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_R2_MULT": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_R3_MULT": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_R4_MULT": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_R5_MULT": "Pendragon模型档 · 估价 > 2017 万",
    "TIER_666_KEEP": "Pendragon模型档 · 估价 > 2017 万",
    "GATE_22668": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_OPEN": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_R2_MULT": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_R3_MULT": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_R4_MULT": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_R5_MULT": "金锦鲤雕像档 · 估价 > 2266.8888 万",
    "TIER_22668_KEEP": "金锦鲤雕像档 · 估价 > 2266.8888 万",
})


# 一个 key 只在某一种模式下写了归属，切到另一种模式就查不到 → 掉「其它」。
# 这里建一份不分模式的反查表当兜底。
KEY_GROUP = {}
for _gk, _gv in GROUP_OF.items():
    if isinstance(_gk, tuple) and len(_gk) == 2:
        KEY_GROUP.setdefault(_gk[1], _gv)
    else:
        KEY_GROUP.setdefault(_gk, _gv)

# 名字碎成好几块的组，合成一块
GROUP_ALIAS = {
    "前两回合 · 跟价": "跟价 & 抢仓",
    "第 3 回合起 · 信息差闸门": "跟价 & 抢仓",
    "第 3~6 回合 · 跟价倍数": "跟价 & 抢仓",
    "跟价 · 超估价额度（抢仓）": "跟价 & 抢仓",
    "通用 · 所有档位都生效": "通用",
    "高价值仓（估价 > 233.3333 万，七档）": "高价值藏品以及特殊出价设置",
}

# 面板上组的先后顺序（没列到的排最后）
GROUP_ORDER = [
    "出价风格",
    "通用",
    "不退出模式",
    "跟价 & 抢仓",
    "高价值藏品以及特殊出价设置",
    "每回合仪器（1-5 号，0=不用）",
    "整仓识别（认到就不用仪器）",
    "流程重启 · 卡死自救",
    "运行方式 · 后台运行",
]
# 档位表放在大仓后面
TIER_TABLE_RANK = GROUP_ORDER.index("高价值藏品以及特殊出价设置")
SETTING_MAP.update({s[0]: s for s in PRESET_SETTINGS})

TIER_RULE = {
    "乐园巧克力档 · 估价 > 233.3333 万": (
        "GATE_233",
        "TIER_233_OPEN",
        "TIER_233_R2_MULT",
        "TIER_233_R3_MULT",
        "TIER_233_R4_MULT",
        "TIER_233_R5_MULT",
    ),
    "家用电影机档 · 估价 > 321 万": (
        "GATE_321",
        "TIER_321_OPEN",
        "TIER_321_R2_MULT",
        "TIER_321_R3_MULT",
        "TIER_321_R4_MULT",
        "TIER_321_R5_MULT",
    ),
    "超级存储盘档 · 估价 > 512 万": (
        "GATE_280",
        "TIER_280_OPEN",
        "TIER_280_R2_MULT",
        "TIER_280_R3_MULT",
        "TIER_280_R4_MULT",
        "TIER_280_R5_MULT",
    ),
    "翠刃档 · 估价 > 898 万": (
        "GATE_898",
        "TIER_420_OPEN",
        "TIER_420_R2_MULT",
        "TIER_420_R3_MULT",
        "TIER_420_R4_MULT",
        "TIER_420_R5_MULT",
    ),
    "碧波天垂档 · 估价 > 1123 万": (
        "GATE_588",
        "TIER_588_OPEN",
        "TIER_588_R2_MULT",
        "TIER_588_R3_MULT",
        "TIER_588_R4_MULT",
        "TIER_588_R5_MULT",
    ),
    "夜光杯档 · 估价 > 1680 万": (
        "GATE_1680",
        "TIER_620_OPEN",
        "TIER_620_R2_MULT",
        "TIER_620_R3_MULT",
        "TIER_620_R4_MULT",
        "TIER_620_R5_MULT",
    ),
    "Pendragon模型档 · 估价 > 2017 万": (
        "GATE_666",
        "TIER_666_OPEN",
        "TIER_666_R2_MULT",
        "TIER_666_R3_MULT",
        "TIER_666_R4_MULT",
        "TIER_666_R5_MULT",
    ),
}


def _f(key, dflt):
    try:
        return float(read_setting(key) or dflt)
    except Exception:
        return float(dflt)


def _f_optional(key):
    raw = read_setting(key).strip()
    if not raw:
        return None
    try:
        return float(raw)
    except Exception:
        return None


def _pretty_bid(price):
    try:
        price = int(price)
    except Exception:
        return price
    if price <= 0:
        return price
    best = 0
    if price >= 1000000:
        high = price // 1000000
        for rep in (888, 777, 555, 444, 333, 222, 111):
            cand = high * 1000000 + rep * 1000 + 888
            if cand <= price and cand > best:
                best = cand
        if best == 0:
            prev = (high - 1) * 1000000 + 888888 if high > 0 else 0
            best = prev if prev > 0 else price
    else:
        base = (price // 1000) * 1000
        for b in (base, base - 1000, base - 2000):
            for tail in (888, 777, 555, 444, 333, 222, 111, 521, 520):
                v = b + tail
                if v <= price and v > best:
                    best = v
        if best == 0:
            best = price
    if 0 < best <= price and best >= price * 0.9:
        return best
    return price // 10000 * 10000


def tier_chain_text(est, first, m2, m3, m4, m5):
    def later(label, mult):
        if mult is None:
            return "%s 倍率留空（保持首轮价/上轮价，不降价）" % label
        return "%s %.0f（估价×%s 取整）" % (label, _pretty_bid(int(est * mult)), mult)

    return ("第1回合 {p1:,.0f}（首轮价/预设价）｜{p2}｜{p3}｜{p4}｜{p5}").format(
        p1=first,
        p2=later("第2回合", m2),
        p3=later("第3回合", m3),
        p4=later("第4回合", m4),
        p5=later("第5、6回合", m5),
    )


def tier_ladder_text(group):
    if group == "通用 · 所有档位都生效":
        try:
            line = int(float(read_setting("EXIT_BELOW_PRICE") or 1000000))
            keep = read_setting("CHASE_TO_END") == "1"
            return (
                "这一组对下面所有档位都生效：第 1、2 回合不低于保底价；"
                "第 3 回合起，估价低于 {line:,.0f}（退出线）就退出本局；"
                "『拍到底』现在是【{keep}】；"
                "各档第 2 回合起按『估价 × 倍率』出价。"
            ).format(line=line, keep="开" if keep else "关")
        except Exception:
            return ""
    if group == "永恒之心档 · 131.452 万 ~ 233.3333 万":
        try:
            lo = int(float(read_setting("GATE_179") or 1314520))
            hi = int(float(read_setting("GATE_233") or 2333333))
            first = int(float(read_setting("LOW_TIER_OPEN") or 1145140))
            m2 = _f("LOW_TIER_R2_MULT", 1.3)
            m3 = _f("LOW_TIER_R3_MULT", 1.5)
            m4 = _f("LOW_TIER_R4_MULT", 1.8)
            m5 = _f("LOW_TIER_R5_MULT", 2.0)
            return (
                "价格梯队（永恒之心档 = 估价 > {lo:,.0f} 且 < {hi:,.0f}，"
                "第1回合统一卡价 {first:,.0f}；"
                "下面按触发估价 {lo:,.0f} 推算，实际估价越高这些价越高）："
                "{chain}　※ 第 2 回合起 = 『当回合估价 × 倍率』，"
                "算出来的数还会向下贴成规整数字；"
                "4 个倍率都能直接改。"
            ).format(
                lo=lo, hi=hi, first=first, chain=tier_chain_text(lo, first, m2, m3, m4, m5)
            )
        except Exception:
            return ""
    if group == "第 3~6 回合 · 跟价倍数":
        try:
            m2 = float(read_setting("R2_RIVAL_MULT") or 1.7)
            m3 = float(read_setting("R3_RIVAL_MULT") or 1.5)
            m4 = float(read_setting("R4_RIVAL_MULT") or 1.3)
            m5 = float(read_setting("R5_RIVAL_MULT") or 1.2)
            return (
                "跟价链（每一档都能在上面改）："
                "第2回合 = 对手第1回合最高 × {m2} ｜ "
                "第3回合 = 对手第2回合最高 × {m3}（能不能继续看上面『信息差闸门』那一组）｜ "
                "第4回合 = 对手第3回合最高 × {m4} ｜ "
                "第5、6回合 = 对手上一轮最高 × {m5}。"
                "所有出价都会往下贴成规整数字，并且不超过自己的估价"
                "（在下面『超估价额度』里填了额度才会放宽成 估价 + 额度）。"
            ).format(m2=m2, m3=m3, m4=m4, m5=m5)
        except Exception:
            return ""
    if group == "第 3 回合起 · 信息差闸门":
        try:
            gap = float(read_setting("INFO_ADVANTAGE_RATIO") or 1.0)
            line = int(float(read_setting("EXIT_BELOW_PRICE") or 1000000))
            keep = read_setting("CHASE_TO_END") == "1"
            return (
                "闸门规则【信息差优先】：第 3 回合起，只要【估价 ≥ 对手上一轮最高价 × {gap}】"
                "就算有信息差 → 不退出、照常按跟价倍数加价；低于这个倍数才退出。"
                "『第 3 回合退出线 {line:,.0f}』只在信息差没命中时兜底"
                "（闸门关掉 / 门槛填 0 / 读不到对手上轮价 / 高价值模式）。"
                "当前『拍到底』：{keep}。"
            ).format(gap=gap, line=line, keep="开" if keep else "关")
        except Exception:
            return ""
    rule = TIER_RULE.get(group)
    if not rule or len(rule) < 6:
        return ""
    try:
        lo = int(float(read_setting(rule[0]) or 0))
        preset = int(float(read_setting(rule[1]) or 0))
        return (
            "价格梯队（估价 > {lo:,.0f} 就是本档；按本档触发估价 {lo:,.0f} 推算，"
            "实际估价越高这些价越高）："
            "{chain}　※ 第 2 回合起 = 当回合估价 × 本档倍率，这一档的 4 个倍率单独可调，"
            "不和别的档共用；"
            "算出来的数会向下贴成规整数字（1,888,888 / 6,666,888 这种）。"
        ).format(
            lo=lo,
            chain=tier_chain_text(
                lo,
                preset,
                _f_optional(rule[2]),
                _f_optional(rule[3]),
                _f_optional(rule[4]),
                _f_optional(rule[5]),
            ),
        )
    except Exception:
        return ""


def main():
    os.makedirs(REC, exist_ok=True)
    load_cfg()
    repair_main_py()

    def _panel_excepthook(etype, value, tb):
        import traceback as _tb

        info = "".join(_tb.format_exception(etype, value, tb))
        try:
            with open(os.path.join(REC, "面板错误.log"), "a", encoding="utf-8") as fp:
                fp.write(
                    "\n[%s] 未捕获异常\n%s\n"
                    % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), info)
                )
        except Exception:
            pass
        try:
            QMessageBox.critical(
                None,
                "面板出错",
                "面板遇到一个错误（已写入 记录\\面板错误.log）：\n\n" + info[-800:],
            )
        except Exception:
            pass

    sys.excepthook = _panel_excepthook
    try:
        # High DPI 适配：不设这两行，2K/4K 屏上界面会小得看不清，
        # 或者被 Windows 用拉伸位图放大 —— 字整片发糊。
        for _attr_name in ("AA_EnableHighDpiScaling", "AA_UseHighDpiPixmaps"):
            _attr = getattr(Qt, _attr_name, None)
            if _attr is not None:
                try:
                    QApplication.setAttribute(_attr, True)
                except Exception:
                    pass
        # 分数缩放别取整：125% / 150% 要保留真实比例，
        # 取整会让界面在 125% 屏上突然跳大一圈。
        try:
            QApplication.setHighDpiScaleFactorRoundingPolicy(
                Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
            )
        except Exception:
            pass
        app = QApplication(sys.argv)
        app.setStyle(_ToggleProxyStyle(app.style()))   # 大肥鱼standby：自绘开关/箭头
        app.setApplicationName("即可落槌爱音版")
        win = Main()
        win.show()
        if os.environ.get("DFY_UPDATE_READY"):
            from 更新交接 import panel_ready

            QTimer.singleShot(0, lambda: panel_ready(APP_VERSION))
        elif os.environ.get("DFY_EXE_PATH"):
            try:
                from 更新交接 import install_stable_entry

                install_stable_entry(SELF_DIR)
            except OSError as exc:
                win.msg.setPlainText(f"固定启动文件创建失败，原来的启动文件仍可使用。\n{exc}")
        sys.exit(app.exec_())
    except Exception:
        import traceback

        info = traceback.format_exc()
        try:
            with open(os.path.join(REC, "面板错误.log"), "a", encoding="utf-8") as fp:
                fp.write(
                    "\n[%s]\n%s\n" % (datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"), info)
                )
        except Exception:
            pass
        try:
            QMessageBox.critical(
                None,
                "控制面板启动失败",
                "面板没能启动，错误已写到：\n记录\\面板错误.log\n\n" + info[-800:],
            )
        except Exception:
            pass


if __name__ == "__main__":
    main()
