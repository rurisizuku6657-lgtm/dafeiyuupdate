"""程序版本号 —— 全项目唯一来源。

界面.py、paimai.py、更新检查.py、发布.py 都从这里读，别再各写一份。

改版本号就改 APP_VERSION 这一行：
    0.2  → 面板显示「大肥鱼standby0.2」
    0.3  → 面板显示「大肥鱼standby0.3」

发布新版时：先把这里改成新版本号，再用 发布.py 打包。
"""

APP_VERSION = "0.3"

# 面板 / CMD / 更新按钮上显示的名字（版本号自动跟上）
APP_DISPLAY = "大肥鱼standby" + str(APP_VERSION)
