# -*- coding: utf-8 -*-
"""Pure calculator-core integration for the auction warehouse.

The existing main script still owns screen capture, OCR, recovery and bidding.
This module only turns a stitched 590x1449 warehouse image into structured
items and a value distribution.
"""
from __future__ import annotations

import math
import os
import sys
import time
import json
import random
import zlib
import copy

import numpy as np


HERE = os.path.dirname(os.path.abspath(__file__))
CORE_DIR = os.path.join(HERE, "vision_core")

if CORE_DIR not in sys.path:
    sys.path.insert(0, CORE_DIR)

os.environ.setdefault("OPENCV_LOG_LEVEL", "SILENT")
try:
    import cv2
    cv2.setLogLevel(0)
except Exception:
    pass

from recognizer_core import (  # noqa: E402
    ItemDatabase,
    match_color,
    recognize_frame,
)
from world_model import WorldModel  # noqa: E402


COLS = 10
ROWS = 25
FULL_GRID = (13.5, 15.0, 56.6)
MIN_MATCH_SCORE = 0.50
PEARL_PRIOR_STRENGTH = 8.0
PEARL_LOCAL_EVIDENCE = 1.0
PEARL_LOCAL_EVIDENCE_NO_SHAPE = 0.0
QUANTILE_SAMPLES = 4000
CONFIDENCE_PRIOR_FILE = "confidence_priors.json"
VALUE_CALIBRATION_FILE = "value_calibration.json"


def _weighted_price_stats(pairs):
    values = sorted(
        (float(price), max(0.05, float(weight)))
        for price, weight in pairs
        if price is not None and float(price) >= 0
    )
    if not values:
        return None
    weight_sum = sum(weight for _price, weight in values)
    mean = sum(price * weight for price, weight in values) / weight_sum
    variance = sum(
        weight * (price - mean) ** 2 for price, weight in values
    ) / weight_sum
    half = weight_sum / 2.0
    running = 0.0
    median = values[-1][0]
    for price, weight in values:
        running += weight
        if running >= half:
            median = price
            break
    return {
        "n": len(values),
        "min": values[0][0],
        "mean": mean,
        "median": median,
        "variance": variance,
    }


def visual_amount_gate(game_estimate, min_total, tolerance):
    """视觉金额闸门：只有「视觉最低显著高于游戏估价」才拒绝。

    视觉比估价低是常态（估价偏向保守），这种情况照常放行；
    高出容差说明这次识别很可能认错了，才把结果作废。
    """
    try:
        estimate = int(game_estimate or 0)
        visual_min = int(min_total or 0)
        tolerance = max(0, int(tolerance or 0))
    except (TypeError, ValueError, OverflowError):
        return False
    return bool(estimate > 0 and visual_min - estimate <= tolerance)


class WarehouseVision:
    def __init__(self):
        self.db = ItemDatabase(
            os.path.join(CORE_DIR, "items.xlsx"),
            os.path.join(CORE_DIR, "templates"),
        )
        self.model = WorldModel()
        self.db.use_set("1080p")
        self.priors = {"overall_size": {}, "color_size": {}}
        self.pearl_priors = {
            "games": 0, "overall_size": {}, "color_size": {},
            "version": 0, "generated_at": "",
        }
        self._pearl_priors_mtime = None
        self.confidence_priors = {}
        self._confidence_priors_mtime = None
        self.value_calibration = {}
        self._value_calibration_mtime = None
        self._load_priors()
        self._load_confidence_priors()
        self._load_value_calibration()
        self._by_color_size = {}
        self._all_by_size = {}
        for item in self.db.items:
            color = match_color(item.color)
            self._by_color_size.setdefault((color, item.w, item.h), []).append(item)
            self._all_by_size.setdefault((item.w, item.h), []).append(item)

    @staticmethod
    def _normalize_prior_counts(groups):
        out = {}
        for key, items in (groups or {}).items():
            clean_key = str(key).strip()
            if not isinstance(items, dict):
                continue
            target = out.setdefault(clean_key, {})
            for name, count in items.items():
                try:
                    target[str(name).strip()] = target.get(str(name).strip(), 0) + max(
                        0, int(round(float(count or 0)))
                    )
                except Exception:
                    continue
        return out

    def _load_priors(self):
        prior_path = os.path.join(CORE_DIR, "item_priors.json")
        try:
            with open(prior_path, encoding="utf-8") as fp:
                loaded = json.load(fp)
            if isinstance(loaded, dict):
                self.priors = {
                    **loaded,
                    "overall_size": self._normalize_prior_counts(
                        loaded.get("overall_size")
                    ),
                    "color_size": {
                        str(color): self._normalize_prior_counts(groups)
                        for color, groups in (loaded.get("color_size") or {}).items()
                    },
                }
        except Exception:
            pass
        pearl_path = os.path.join(CORE_DIR, "pearl_priors.json")
        try:
            self._pearl_priors_mtime = os.path.getmtime(pearl_path)
            with open(pearl_path, encoding="utf-8") as fp:
                loaded = json.load(fp)
            if isinstance(loaded, dict):
                self.pearl_priors = {
                    **loaded,
                    "overall_size": self._normalize_prior_counts(
                        loaded.get("overall_size")
                    ),
                    "color_size": {
                        str(color): self._normalize_prior_counts(groups)
                        for color, groups in (loaded.get("color_size") or {}).items()
                    },
                }
        except Exception:
            pass

    def _load_confidence_priors(self):
        confidence_path = os.path.join(CORE_DIR, CONFIDENCE_PRIOR_FILE)
        try:
            self._confidence_priors_mtime = os.path.getmtime(confidence_path)
            with open(confidence_path, encoding="utf-8") as fp:
                loaded = json.load(fp)
            if isinstance(loaded, dict):
                self.confidence_priors = loaded
        except Exception:
            self.confidence_priors = {}

    def _load_value_calibration(self):
        path = os.path.join(CORE_DIR, VALUE_CALIBRATION_FILE)
        try:
            self._value_calibration_mtime = os.path.getmtime(path)
            with open(path, encoding="utf-8") as stream:
                loaded = json.load(stream)
            if not isinstance(loaded, dict):
                raise ValueError("value calibration must be an object")
            if len(loaded.get("feature_mean") or []) != len(
                    loaded.get("feature_names") or []):
                raise ValueError("feature_mean length mismatch")
            if len(loaded.get("feature_scale") or []) != len(
                    loaded.get("feature_names") or []):
                raise ValueError("feature_scale length mismatch")
            if len(loaded.get("coefficients") or []) != (
                    len(loaded.get("feature_names") or []) + 1):
                raise ValueError("coefficients length mismatch")
            self.value_calibration = loaded
        except Exception as exc:
            self.value_calibration = {}
            self._value_calibration_mtime = None
            if str(exc):
                print("⚠️ 视觉价值校准模型不可用：%s" % exc)

    def _calibrated_total(self, details, round_num, game_estimate,
                          coverage_blocks):
        model = self.value_calibration
        if not model:
            return 0
        observed = [
            row for row in details
            if row.get("mean") is not None and row.get("median") is not None
        ]
        if not observed:
            return 0
        source_counts = {"exact": 0, "shape": 0, "no-shape": 0}
        for row in observed:
            source = str(row.get("source") or "")
            if source.startswith("no-shape"):
                source = "no-shape"
            if source in source_counts:
                source_counts[source] += 1
        count = max(1, len(observed))
        coverage = max(0.0, min(1.0, float(coverage_blocks or 0.0)))
        round_value = float(round_num or 0)
        log_mean = math.log1p(max(
            0.0, sum(float(row.get("mean") or 0) for row in observed)
        ))
        values = [
            math.log1p(max(0.0, float(game_estimate or 0))),
            log_mean,
            math.log1p(max(
                0.0, sum(float(row.get("median") or 0) for row in observed)
            )),
            coverage,
            round_value,
            math.log1p(float(count)),
            source_counts["exact"] / count,
            source_counts["shape"] / count,
            source_counts["no-shape"] / count,
            coverage * round_value,
            coverage * log_mean,
        ]
        mean = np.asarray(model["feature_mean"], dtype=float)
        scale = np.asarray(model["feature_scale"], dtype=float)
        coefficients = np.asarray(model["coefficients"], dtype=float)
        if len(values) != len(mean):
            return 0
        scale = np.where(np.abs(scale) < 1e-9, 1.0, scale)
        normalized = (np.asarray(values, dtype=float) - mean) / scale
        design = np.concatenate(([1.0], normalized))
        raw = math.expm1(float(design @ coefficients))
        corrected = raw * float(model.get("bias_correction") or 1.0)
        return max(0, int(round(corrected)))

    def _coverage_confidence_row(self, coverage):
        value = max(0.0, min(1.0, float(coverage or 0.0)))
        rows = self.confidence_priors.get("coverage_bins") or []
        for row in rows:
            try:
                lo = float(row.get("min", 0.0))
                hi = float(row.get("max", 1.01))
            except Exception:
                continue
            if lo <= value < hi or (hi > 1.0 and value <= 1.0):
                return row
        return {}

    def _source_confidence_row(self, source):
        sources = self.confidence_priors.get("sources") or {}
        if source in sources:
            return sources.get(source) or {}
        if source == "no-shape-fallback":
            return sources.get("no-shape") or {}
        return {}

    def _calibrate_detail_confidences(self, details, coverage):
        """Attach data-derived top-candidate confidence to each visual block.

        The calibration dataset showed that exact matches are already reliable,
        while shape/no-shape candidate recall changes strongly with coverage.
        This only records calibrated confidence; it does not promote an
        uncertain candidate into the authoritative item name.
        """
        coverage_row = self._coverage_confidence_row(coverage)
        global_row = self.confidence_priors.get("global") or {}
        global_top = max(
            1e-9, float(global_row.get("top_candidate_accuracy") or 0.0)
        )
        coverage_top = float(
            coverage_row.get("top_candidate_accuracy") or global_top
        )
        expected_correct = 0.0
        block_confidences = []
        for row in details:
            source = str(row.get("source") or "")
            if source == "exact" and row.get("item"):
                confidence = 1.0
            elif int(row.get("n") or 0) <= 0:
                confidence = 0.0
            else:
                source_row = self._source_confidence_row(source)
                source_top = float(
                    source_row.get("top_candidate_accuracy") or 0.0
                )
                source_factor = max(0.0, min(1.0, source_top / global_top))
                confidence = max(
                    0.0, min(1.0, coverage_top * source_factor)
                )
            row["top_candidate_confidence"] = round(confidence, 6)
            expected_correct += confidence
            block_confidences.append(confidence)
        return {
            "dataset_auctions": int(
                self.confidence_priors.get("auctions") or 0
            ),
            "dataset_samples": int(
                self.confidence_priors.get("samples") or 0
            ),
            "coverage_top_candidate_accuracy": round(coverage_top, 6),
            "expected_correct_top_candidates": round(expected_correct, 4),
            "mean_top_candidate_confidence": round(
                sum(block_confidences) / len(block_confidences), 6
            ) if block_confidences else 0.0,
        }

    def reset_auction(self):
        try:
            pearl_path = os.path.join(CORE_DIR, "pearl_priors.json")
            if (os.path.exists(pearl_path)
                    and os.path.getmtime(pearl_path) != self._pearl_priors_mtime):
                self._load_priors()
                print(
                    "🔄 真珠场先验已热更新：%s局 / %s件"
                    % (
                        self.pearl_priors.get("games", 0),
                        self.pearl_priors.get("item_instances", 0),
                    )
                )
        except Exception:
            pass
        try:
            confidence_path = os.path.join(CORE_DIR, CONFIDENCE_PRIOR_FILE)
            if (os.path.exists(confidence_path)
                    and os.path.getmtime(confidence_path)
                    != self._confidence_priors_mtime):
                self._load_confidence_priors()
                print(
                    "🔄 视觉置信校准已热更新：%s局 / %s样本"
                    % (
                        self.confidence_priors.get("auctions", 0),
                        self.confidence_priors.get("samples", 0),
                    )
                )
        except Exception:
            pass
        try:
            value_path = os.path.join(CORE_DIR, VALUE_CALIBRATION_FILE)
            if (os.path.exists(value_path)
                    and os.path.getmtime(value_path)
                    != self._value_calibration_mtime):
                self._load_value_calibration()
                print(
                    "🔄 视觉价值校准已热更新：%s局 / %s回合"
                    % (
                        self.value_calibration.get("training", {}).get(
                            "combined_auctions", 0
                        ),
                        self.value_calibration.get("training", {}).get(
                            "combined_rounds", 0
                        ),
                    )
                )
        except Exception:
            pass
        self.model.clear()

    def clone_for_analysis(self):
        """Create an isolated model while sharing the read-only item/template DB.

        Settlement screenshots must be analyzed independently from the live
        auction.  Reusing the loaded database avoids doubling the large
        template footprint, while a fresh WorldModel prevents late background
        work from changing the next auction's incremental recognition state.
        """
        clone = copy.copy(self)
        clone.model = type(self.model)()
        return clone

    @staticmethod
    def _overlap(a, b):
        return not (
            a["x"] + a["w"] <= b["x"]
            or b["x"] + b["w"] <= a["x"]
            or a["y"] + a["h"] <= b["y"]
            or b["y"] + b["h"] <= a["y"]
        )

    def _shape_fits(self, rect, width, height, others):
        if width < rect["w"] or height < rect["h"]:
            return False
        for ox in range(rect["x"] + rect["w"] - width, rect["x"] + 1):
            if ox < 0 or ox + width > COLS:
                continue
            for oy in range(rect["y"] + rect["h"] - height, rect["y"] + 1):
                if oy < 0 or oy + height > ROWS:
                    continue
                candidate = {"x": ox, "y": oy, "w": width, "h": height}
                if not any(self._overlap(candidate, other) for other in others):
                    return True
        return False

    def _candidate_items(self, rect, all_items):
        named = str(rect.get("item") or "")
        color = rect.get("color")
        if named:
            exact = [it for it in self.db.items if it.name == named]
            if exact:
                return exact, "exact", None

        others = [o for o in all_items if o is not rect and not o.get("noShape")]
        if rect.get("noShape"):
            base = [
                it for it in self.db.items
                if color is None or match_color(it.color) == color
            ]
            shapes = sorted({(it.w, it.h) for it in base if self._shape_fits(
                rect, it.w, it.h, others
            )})
            if shapes:
                shape_set = set(shapes)
                pool = [it for it in base if (it.w, it.h) in shape_set]
                return pool, "no-shape", (
                    "color:no-shape" if color else "all:no-shape"
                )
            return base, "no-shape-fallback", (
                "color:no-shape" if color else "all:no-shape"
            )

        pool = self._by_color_size.get((color, rect["w"], rect["h"]), [])
        if color is None:
            pool = self._all_by_size.get((rect["w"], rect["h"]), [])
        return pool, "shape", "color" if color else "all"

    def _weights_for(self, item, rect, kind):
        size = ("%dx%d" % (item.w, item.h)).strip()
        kind_text = str(kind or "")
        no_shape = kind_text.endswith(":no-shape")
        base_kind = kind_text.split(":", 1)[0]
        if base_kind == "color":
            color = rect.get("color")
            global_counts = (self.priors.get("color_size", {})
                             .get(color, {}).get(size, {}))
            pearl_counts = (self.pearl_priors.get("color_size", {})
                            .get(color, {}).get(size, {}))
        else:
            global_counts = self.priors.get("overall_size", {}).get(size, {})
            pearl_counts = self.pearl_priors.get("overall_size", {}).get(size, {})

        global_count = float(global_counts.get(item.name, 0) or 0)
        pearl_count = float(pearl_counts.get(item.name, 0) or 0)
        global_total = sum(float(v or 0) for v in global_counts.values())
        global_share = global_count / global_total if global_total > 0 else 0.0
        local_evidence = (
            PEARL_LOCAL_EVIDENCE_NO_SHAPE if no_shape
            else PEARL_LOCAL_EVIDENCE
        )
        return (
            1.0
            + local_evidence * pearl_count
            + PEARL_PRIOR_STRENGTH * global_share
        )

    def analyze(self, canvas, round_num, game_estimate, fresh=False):
        # 结算 / 训练打标注时不能继承上一局的识别状态；实时回合扫描保持增量（省内存也省时间）。
        if fresh:
            self.model.clear()
        started = time.perf_counter()
        known = {
            (o["x"], o["y"], o["w"], o["h"]): (o["item"], o["color"])
            for o in self.model.items if o.get("item")
        }
        recognized, scroll_rows = recognize_frame(
            canvas,
            self.db,
            min_match_score=MIN_MATCH_SCORE,
            known=known,
            row_offset=0,
            check_phase=False,
            grid=FULL_GRID,
            refine=False,
            rows=ROWS,
        )
        self.model.update(recognized, self.db)
        items = self.model.export()

        min_total = 0.0
        mean_total = 0.0
        variance_total = 0.0
        named_count = 0
        pool_sizes = []
        details = []
        sampled_pools = []
        area_total = 0
        area_named = 0
        for rect in items:
            area_total += max(1, int(rect["w"]) * int(rect["h"]))
            pool, source, weight_kind = self._candidate_items(rect, items)
            if source == "exact":
                weighted_pairs = [(pool[0].price, 1.0)] if pool else []
            else:
                weighted_pairs = [
                    (it.price, self._weights_for(it, rect, weight_kind))
                    for it in pool
                ]
            stats = _weighted_price_stats(weighted_pairs)
            if stats is None:
                details.append({
                    "x": rect["x"], "y": rect["y"],
                    "w": rect["w"], "h": rect["h"],
                    "color": rect["color"], "item": rect["item"],
                    "source": "no-data", "n": 0,
                    "templateAttempted": bool(rect.get("templateAttempted")),
                    "candidateCount": int(rect.get("candidateCount") or 0),
                    "secondScore": float(rect.get("secondScore") or 0.0),
                })
                continue
            if rect.get("item"):
                named_count += 1
                area_named += max(1, int(rect["w"]) * int(rect["h"]))
            min_total += stats["min"]
            mean_total += stats["mean"]
            variance_total += stats["variance"]
            pool_sizes.append(stats["n"])
            sampled_pools.append(weighted_pairs)
            candidates = sorted(
                [
                    {
                        "name": str(it.name),
                        "color": str(it.color),
                        "w": int(it.w),
                        "h": int(it.h),
                        "price": float(it.price),
                        "weight": round(float(weight), 4),
                    }
                    for it, (_price, weight) in zip(pool, weighted_pairs)
                ],
                key=lambda row: (-row["weight"], row["price"], row["name"]),
            )
            details.append({
                "x": rect["x"], "y": rect["y"],
                "w": rect["w"], "h": rect["h"],
                "color": rect["color"], "item": rect["item"],
                "no_shape": bool(rect.get("noShape")),
                "source": source, "n": stats["n"],
                "mean": round(stats["mean"], 2),
                "median": round(stats["median"], 2),
                "candidate_top": candidates,
                "templateAttempted": bool(rect.get("templateAttempted")),
                "candidateCount": int(rect.get("candidateCount") or 0),
                "secondScore": float(rect.get("secondScore") or 0.0),
            })

        std_total = math.sqrt(max(0.0, variance_total))
        fallback_p75 = mean_total + 0.67448975 * std_total
        totals = [0.0] * int(QUANTILE_SAMPLES)
        seed_payload = json.dumps(
            [
                int(round_num or 0),
                int(game_estimate or 0),
                [
                    [[round(p, 2), round(w, 4)] for p, w in pairs]
                    for pairs in sampled_pools
                ],
            ],
            ensure_ascii=False,
            separators=(",", ":"),
        )
        rng = random.Random(zlib.crc32(seed_payload.encode("utf-8")))
        for pairs in sampled_pools:
            prices = [float(p) for p, _ in pairs]
            cumulative = []
            running = 0.0
            for _, weight in pairs:
                running += max(1e-9, float(weight))
                cumulative.append(running)
            if not prices:
                continue
            draws = rng.choices(
                prices, cum_weights=cumulative, k=int(QUANTILE_SAMPLES)
            )
            for i, value in enumerate(draws):
                totals[i] += value
        if sampled_pools:
            totals.sort()

            def _q(frac, default):
                idx = min(
                    len(totals) - 1,
                    max(0, int(float(frac) * len(totals))),
                )
                return int(round(totals[idx] if totals else default))

            p10_total = _q(0.10, 0)
            p50_total = _q(0.50, mean_total)
            p75_total = _q(0.75, fallback_p75)
            p90_total = _q(0.90, fallback_p75)
        else:
            p10_total = p50_total = p75_total = p90_total = 0
        coverage_blocks = named_count / float(len(items)) if items else 0.0
        calibration = self._calibrate_detail_confidences(
            details, coverage_blocks
        )
        estimate = max(0, int(game_estimate or 0))
        tolerance = max(8000, int(round(estimate * 0.08))) if estimate else 0
        checksum_diff = int(round(min_total - estimate))
        # 闸门只看一个方向：视觉最低「显著高于」估价才拒绝；
        # 视觉比估价低是常态（估价本来就偏保守），不该因此把整批数据作废。
        checksum_ok = visual_amount_gate(estimate, min_total, tolerance)
        calibrated_value = self._calibrated_total(
            details, round_num, estimate, coverage_blocks
        )
        elapsed_ms = int((time.perf_counter() - started) * 1000)

        return {
            "version": 2,
            "round": int(round_num),
            "game_estimate": estimate,
            "items": details,
            "block_count": len(items),
            "named_count": named_count,
            "coverage_blocks": coverage_blocks,
            "coverage_area": (
                area_named / float(area_total) if area_total else 0.0
            ),
            "grid_columns": COLS,
            "grid_rows": ROWS,
            "grid_origin_x": FULL_GRID[0],
            "grid_origin_y": FULL_GRID[1],
            "grid_cell": FULL_GRID[2],
            "min_total": int(round(min_total)),
            "mean_total": int(round(mean_total)),
            "p10_total": int(p10_total),
            "p50_total": int(p50_total),
            "p75_total": int(round(p75_total)),
            "p90_total": int(p90_total),
            "calibrated_value": calibrated_value,
            "calibration_model_version": int(
                self.value_calibration.get("version") or 0
            ),
            "calibration_training_auctions": int(
                (self.value_calibration.get("training") or {}).get(
                    "combined_auctions", 0
                )
            ),
            "calibration_cv_mdape": float(
                (self.value_calibration.get("cross_validation") or {}).get(
                    "mdape", 0
                )
            ),
            "checksum_diff": checksum_diff,
            "checksum_tolerance": tolerance,
            "checksum_ok": checksum_ok,
            # 这次是不是「清空模型后重新认的」（结算打标注就是这样认的）
            "fresh_analysis": bool(fresh),
            # 校验用的那个游戏估价本身也存下来 —— 不存的话事后没法算
            # 「视觉比估价高多少」，报告页只能说「没有一条带估价」。
            "game_estimate": int(estimate),
            "scroll_rows": round(float(scroll_rows), 3),
            "pool_sizes": pool_sizes,
            "pearl_prior_games": int(self.pearl_priors.get("games") or 0),
            "pearl_prior_generated_at": str(
                self.pearl_priors.get("generated_at") or ""
            ),
            "elapsed_ms": elapsed_ms,
            "confidence_calibration": calibration,
        }
