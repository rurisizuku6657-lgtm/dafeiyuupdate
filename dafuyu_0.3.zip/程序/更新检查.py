"""检查有没有新版本 —— 只读，不下载、不改任何文件。

用法：
    python 更新检查.py              人话输出（自己手动跑用）
    python 更新检查.py --json       输出 JSON（界面调用用）
    python 更新检查.py --url 地址    临时指定清单地址，不读配置

清单地址存在 程序\\更新地址.json 里，改地址不用动代码。

退出码：
    0  检查成功（有没有新版本都算成功，看输出里的 has_new）
    1  网络或地址问题
    2  清单内容不对
"""

from __future__ import annotations

import json
import os
import re
import sys
import urllib.error
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(HERE, "更新地址.json")
TIMEOUT = 12.0
# Gitee 对没有 UA 的请求会直接拒，必须带一个像浏览器的
USER_AGENT = "NTE-Updater/1.0 (+anjin-auction)"


def 本地版本():
    try:
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        from 版本 import APP_VERSION

        return str(APP_VERSION).strip()
    except Exception:
        return ""


def 读配置():
    """返回 (清单地址, 配置问题说明)。"""
    if not os.path.isfile(CONFIG_FILE):
        return "", "找不到 程序\\更新地址.json"
    try:
        # utf-8-sig：Windows 记事本保存的 JSON 常带 BOM，用普通 utf-8 读会直接抛
        # 「Unexpected UTF-8 BOM」，群友自己改个地址就废了。
        with open(CONFIG_FILE, encoding="utf-8-sig") as fp:
            data = json.load(fp)
    except Exception as e:
        return "", f"更新地址.json 读不了：{e}"
    if not isinstance(data, dict):
        return "", "更新地址.json 格式不对（应该是键值对）"
    url = str(data.get("manifest_url") or "").strip()
    if not url:
        return "", "更新地址.json 里的 manifest_url 是空的"
    if not url.lower().startswith(("http://", "https://")):
        return "", "manifest_url 必须是 http:// 或 https:// 开头"
    return url, ""


def 拉清单(url):
    """返回 (清单字典, 错误说明)。"""
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            raw = resp.read(512 * 1024)  # 清单不该这么大，超了直接截断
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return None, f"清单地址 404（{url}）。地址写错了，或者仓库还没发布"
        return None, f"服务器返回 {e.code}（{url}）"
    except urllib.error.URLError as e:
        reason = str(getattr(e, "reason", e)).rstrip("。.")
        return None, f"连不上服务器：{reason}。检查网络，或者地址写错了"
    except Exception as e:
        return None, f"下载清单出错：{e}"
    try:
        text = raw.decode("utf-8-sig")
    except Exception:
        try:
            text = raw.decode("gb18030")
        except Exception:
            return None, "清单不是能识别的文本编码"
    try:
        data = json.loads(text)
    except Exception as e:
        head = text.strip().replace("\n", " ")[:120]
        return None, f"清单不是合法 JSON：{e}｜开头是：{head}"
    if not isinstance(data, dict):
        return None, "清单不是键值对"
    return data, ""


def 版本元组(v):
    """'1.2.10' → (1, 2, 10)；容错：非数字部分按 0。"""
    parts = []
    for chunk in str(v or "").strip().lstrip("vV").split("."):
        m = re.match(r"(\d+)", chunk)
        parts.append(int(m.group(1)) if m else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts)


def 比较版本(远端, 本地):
    """远端比本地新返回 1，一样返回 0，更旧返回 -1。"""
    a, b = 版本元组(远端), 版本元组(本地)
    return (a > b) - (a < b)


def 检查(url_override=""):
    result = {
        "ok": False,
        "local": 本地版本(),
        "remote": "",
        "has_new": False,
        "notes": [],
        "package_url": "",
        "published_at": "",
        "error": "",
    }
    url = url_override.strip()
    if not url:
        url, cfg_err = 读配置()
        if cfg_err:
            result["error"] = cfg_err
            return result, 2
    data, err = 拉清单(url)
    if err:
        result["error"] = err
        return result, 1

    remote = str(data.get("version") or "").strip()
    if not remote:
        result["error"] = "清单里没有 version 字段"
        return result, 2

    result["ok"] = True
    result["remote"] = remote
    result["package_url"] = str(data.get("package_url") or "").strip()
    result["published_at"] = str(data.get("published_at") or "").strip()
    notes = data.get("notes") or data.get("changelog") or []
    if isinstance(notes, str):
        notes = [notes]
    result["notes"] = [str(x) for x in notes if str(x).strip()]
    local = result["local"]
    if not local:
        result["error"] = "读不到本地版本号（程序\\版本.py 是不是丢了？）"
        return result, 2
    result["has_new"] = 比较版本(remote, local) > 0
    return result, 0


def 人话(result, code):
    local = result.get("local") or "?"
    if code != 0:
        return f"❌ 检查失败\n\n{result.get('error') or '未知错误'}"
    remote = result.get("remote")
    if result.get("has_new"):
        lines = [f"🆕 有新版本：v{local} → v{remote}"]
        if result.get("published_at"):
            lines.append(f"发布时间：{result['published_at']}")
        notes = result.get("notes") or []
        if notes:
            lines.append("\n这一版更新内容：")
            lines.extend(f"  · {n}" for n in notes)
        if result.get("package_url"):
            lines.append(f"\n下载地址：\n{result['package_url']}")
        return "\n".join(lines)
    return f"✅ 已是最新版本（v{local}）"


def main(argv):
    url = ""
    as_json = False
    args = list(argv[1:])
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--json":
            as_json = True
        elif a == "--url" and i + 1 < len(args):
            url = args[i + 1]
            i += 1
        elif a in ("-h", "--help"):
            print(__doc__)
            return 0
        i += 1

    result, code = 检查(url)
    if as_json:
        payload = dict(result)
        payload["exit_code"] = code
        print(json.dumps(payload, ensure_ascii=False))
    else:
        print(人话(result, code))
    return code


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    sys.exit(main(sys.argv))
