"""下载并应用更新 —— 会改文件的只有这一步，所以每一步都先备份、能还原。

用法：
    python 更新下载.py --apply          下载最新版并覆盖（界面调用这个）
    python 更新下载.py --apply --no-keep 覆盖后把备份删掉（省空间，但出问题没法还原）
    python 更新下载.py --check-only     只下载+校验+解压，不覆盖

设计原则：
  1. 先下载到临时目录，sha256 对不上就不往下走
  2. 解压只允许落在临时目录里（防 zip slip）
  3. 覆盖之前把 程序\\ 整个备份成 程序_备份_<时间戳>\\
  4. 覆盖之后逐个校验关键文件，缺一个就自动还原
  5. 只碰 程序\\ 和 素材\\，绝不碰 python\\、记录\\、参数配置.json

退出码：
    0  成功
    1  网络/清单问题
    2  校验失败（sha256 或包内容不对）
    3  覆盖失败（已经自动还原）
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import time
import urllib.error
import urllib.request
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = HERE
for _d in (HERE, os.path.dirname(HERE)):
    if os.path.isdir(os.path.join(_d, "python")):
        BASE = _d
        break

UPDATE_DIR = os.path.join(BASE, "记录", "更新")
STAGE_DIR = os.path.join(UPDATE_DIR, "staging")
DOWNLOAD_DIR = os.path.join(UPDATE_DIR, "download")

TIMEOUT = 90.0
CHUNK = 256 * 1024
USER_AGENT = "NTE-Updater/1.0 (+anjin-auction)"

# 覆盖之后必须存在的文件；少一个就认为包不完整，直接还原
REQUIRED = (
    os.path.join("程序", "paimai.py"),
    os.path.join("程序", "界面.py"),
    os.path.join("程序", "版本.py"),
)

# 只覆盖这两层，别的一个都不许动
ALLOWED_TOP = ("程序", "素材")


def _log(msg):
    print(msg, flush=True)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as fp:
        for chunk in iter(lambda: fp.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def _inside(root, target):
    """target 是不是真的在 root 里面（防 .. 和绝对路径逃逸）。"""
    root = os.path.abspath(root)
    target = os.path.abspath(target)
    try:
        return os.path.commonpath([root, target]) == root
    except Exception:
        return False


def _rm(path):
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
        elif os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def _read_manifest():
    cfg_path = os.path.join(HERE, "更新地址.json")
    if not os.path.isfile(cfg_path):
        return None, "找不到 程序\\更新地址.json"
    try:
        # utf-8-sig：Windows 记事本保存的 JSON 常带 BOM，普通 utf-8 会直接报
        # 「Unexpected UTF-8 BOM」，群友手动改地址就废了。
        with open(cfg_path, encoding="utf-8-sig") as fp:
            cfg = json.load(fp)
        urls = []
        for _k in ("manifest_urls", "manifest_url"):
            _v = cfg.get(_k)
            if isinstance(_v, str) and _v.strip():
                urls.append(_v.strip())
            elif isinstance(_v, (list, tuple)):
                for _x in _v:
                    if isinstance(_x, str) and _x.strip():
                        urls.append(_x.strip())
    except Exception as e:
        return None, f"更新地址.json 读不了：{e}"
    _seen_u = set()
    urls = [u for u in urls if not (u in _seen_u or _seen_u.add(u))]
    if not urls:
        return None, "更新地址.json 里的 manifest_url(s) 是空的"
    url = urls[0]
    data = None
    last_err = ""
    for _u in urls:
        req = urllib.request.Request(_u, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(req, timeout=20) as resp:
                raw = resp.read(1024 * 1024)
        except urllib.error.HTTPError as e:
            last_err = f"清单地址返回 {e.code}（{_u}）"
            continue
        except urllib.error.URLError as e:
            last_err = f"连不上清单地址：{getattr(e, 'reason', e)}（{_u}）"
            continue
        except Exception as e:
            last_err = f"拉清单出错：{e}（{_u}）"
            continue
        try:
            data = json.loads(raw.decode("utf-8-sig"))
        except Exception as e:
            last_err = f"清单不是合法 JSON：{e}（{_u}）"
            data = None
            continue
        if not isinstance(data, dict):
            last_err = f"清单不是键值对（{_u}）"
            data = None
            continue
        break
    if data is None:
        return None, last_err or "拉清单失败"
    if len(urls) > 1:
        _log(f"   （清单有 {len(urls)} 个地址，使用可用的那个）")
    return data, ""


def _download(url, target, expected_size=0):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    os.makedirs(os.path.dirname(target), exist_ok=True)
    part = target + ".part"
    _rm(part)
    total = 0
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp, open(part, "wb") as fp:
            try:
                _want = int(resp.headers.get("Content-Length") or 0)
            except Exception:
                _want = 0
            if not _want:
                _want = int(expected_size or 0)
            _next_pct = 10
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                fp.write(chunk)
                total += len(chunk)
                if _want:
                    pct = int(total * 100 / _want)
                    if pct >= _next_pct and _next_pct <= 100:
                        _log(f"   … 已下载 {min(pct, 100)}%（{total}/{_want} 字节）")
                        _next_pct = min(100, (pct // 10 + 1) * 10)
        if expected_size and total != expected_size:
            _rm(part)
            return 0, f"文件大小不对：期望 {expected_size} 字节，实际 {total} 字节"
        os.replace(part, target)
        return total, ""
    except urllib.error.HTTPError as e:
        _rm(part)
        return 0, f"下载失败，服务器返回 {e.code}"
    except urllib.error.URLError as e:
        _rm(part)
        return 0, f"下载失败，连不上：{getattr(e, 'reason', e)}"
    except Exception as e:
        _rm(part)
        return 0, f"下载失败：{e}"


def _safe_extract(archive, destination):
    """解压到 destination，任何一条越界的路径都直接拒绝。"""
    _rm(destination)
    os.makedirs(destination, exist_ok=True)
    bad = []
    with zipfile.ZipFile(archive) as zf:
        for info in zf.infolist():
            name = info.filename
            if name.endswith("/"):
                continue
            target = os.path.join(destination, name)
            if not _inside(destination, target):
                bad.append(name)
    if bad:
        return f"压缩包里有 {len(bad)} 个越界路径，已拒绝解压（比如 {bad[0]}）"
    try:
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(destination)
    except Exception as e:
        return f"解压失败：{e}"
    return ""


def _find_package_root(stage):
    """包内一般是 即可落槌_爱音版\\程序\\...，把那一层找出来。"""
    if os.path.isdir(os.path.join(stage, "程序")):
        return stage
    for name in sorted(os.listdir(stage)):
        cand = os.path.join(stage, name)
        if os.path.isdir(cand) and os.path.isdir(os.path.join(cand, "程序")):
            return cand
    return None


def _copy_tree(src, dst, skip_rel=()):
    """把 src 里的东西覆盖到 dst（按文件覆盖，不删 dst 多出来的旧文件）。

    skip_rel：要跳过的相对路径（统一用 / 分隔），比如用户自己的参数文件 ——
    覆盖更新绝不能把用户改过的参数改回默认值。
    """
    skip = {str(s).replace("\\", "/").strip("/").lower() for s in skip_rel if s}
    count = 0
    skipped = []
    for root, dirs, files in os.walk(src):
        rel = os.path.relpath(root, src)
        rel_posix = "" if rel == "." else rel.replace("\\", "/")
        # 顺手跳过解释器缓存
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        target_root = dst if not rel_posix else os.path.join(dst, *rel_posix.split("/"))
        os.makedirs(target_root, exist_ok=True)
        for name in files:
            if name.lower().endswith((".pyc", ".pyo")):
                continue
            file_rel = (rel_posix + "/" + name) if rel_posix else name
            if file_rel.lower() in skip:
                skipped.append(file_rel)
                continue
            s = os.path.join(root, name)
            d = os.path.join(target_root, name)
            try:
                shutil.copy2(s, d)
                count += 1
            except Exception as e:
                raise RuntimeError(f"复制 {name} 失败：{e}")
    if skipped:
        _log("   … 保留用户自己的文件：" + "、".join(sorted(set(skipped))))
    return count


def apply_update(keep_backup=True):
    """返回 (成功与否, 人话说明, 退出码)。"""
    data, err = _read_manifest()
    if err:
        return False, err, 1

    remote = str(data.get("version") or "").strip()
    # 支持多个下载源：package_urls（数组，按顺序回退）优先，其次 package_url
    _pkg_list = []
    for _key in ("package_urls", "package_url"):
        _v = data.get(_key)
        if isinstance(_v, str) and _v.strip():
            _pkg_list.append(_v.strip())
        elif isinstance(_v, (list, tuple)):
            for _x in _v:
                if isinstance(_x, str) and _x.strip():
                    _pkg_list.append(_x.strip())
    _seen_pkg = set()
    _pkg_list = [p for p in _pkg_list if not (p in _seen_pkg or _seen_pkg.add(p))]
    want_sha = str(data.get("sha256") or "").strip().upper()
    want_size = int(data.get("size") or 0)

    if not _pkg_list:
        return False, "清单里没有 package_url —— 作者还没把安装包传上去", 1
    for _p in _pkg_list:
        if not _p.lower().startswith(("http://", "https://")):
            return False, f"下载地址不是 http(s)：{_p}", 1

    try:
        if HERE not in sys.path:
            sys.path.insert(0, HERE)
        from 版本 import APP_VERSION

        local = str(APP_VERSION)
    except Exception:
        local = "?"

    _log(f"📦 准备更新：v{local} → v{remote or '?'}")
    if len(_pkg_list) > 1:
        _log(f"   共 {len(_pkg_list)} 个下载源，失败会自动换下一个")

    os.makedirs(DOWNLOAD_DIR, exist_ok=True)
    zip_path = os.path.join(DOWNLOAD_DIR, "update.zip")
    _log("⬇️ 正在下载…")
    _ok_dl = False
    _last_err = ""
    for _idx, _pkg in enumerate(_pkg_list, 1):
        _log(f"   源 {_idx}/{len(_pkg_list)}：{_pkg}")
        size, err = _download(_pkg, zip_path, want_size)
        if err:
            _last_err = err
            _log(f"   ❌ {err}")
            continue
        if want_sha:
            _log("🔐 校验 sha256…")
            got = _sha256(zip_path)
            if got != want_sha:
                _last_err = (
                    "下载的文件和清单里记的 sha256 对不上（这个源的文件可能没传完整）。\n"
                    f"清单：{want_sha}\n实际：{got}"
                )
                _rm(zip_path)
                _log("   ❌ sha256 对不上，换下一个源")
                continue
            _log("   sha256 一致")
        else:
            _log("   ⚠️ 清单里没写 sha256，跳过校验")
        _ok_dl = True
        break
    if not _ok_dl:
        return False, "所有下载源都失败了。\n\n最后一个错误：" + (_last_err or "未知"), 1
    _log(f"   下载完成，{size} 字节")

    _log("📂 解压…")
    err = _safe_extract(zip_path, STAGE_DIR)
    if err:
        return False, err, 2

    root = _find_package_root(STAGE_DIR)
    if root is None:
        return False, "压缩包里找不到「程序」文件夹，这不像是个更新包", 2
    for rel in REQUIRED:
        if not os.path.isfile(os.path.join(root, rel)):
            return False, f"更新包里缺少 {rel}，包不完整，没敢覆盖", 2
    _log("   包内容检查通过")

    # ---- 备份 ----
    stamp = time.strftime("%Y%m%d_%H%M%S")
    backups = []
    for top in ALLOWED_TOP:
        src = os.path.join(BASE, top)
        if not os.path.isdir(src):
            continue
        if top != "程序":
            continue  # 素材太大，不备份；坏了重下全包
        dst = os.path.join(BASE, f"{top}_备份_{stamp}")
        _log(f"💾 备份 {top} → {os.path.basename(dst)}")
        try:
            # 跳过 __pycache__ 和 .pyc：那是解释器缓存，删了会自己重建，
            # 而且正在被占用时 copytree 会抛 WinError 5，把整个备份搞失败。
            shutil.copytree(
                src,
                dst,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"),
            )
            backups.append((dst, src))
        except Exception as e:
            _rm(dst)  # 别留半截备份目录
            return False, f"备份 {top} 失败，为了安全没敢动文件：{e}", 3

    # ---- 覆盖 ----
    try:
        for top in ALLOWED_TOP:
            src = os.path.join(root, top)
            if not os.path.isdir(src):
                continue
            dst = os.path.join(BASE, top)
            # 用户的参数文件必须留存：包里的 参数配置.json 只是默认值
            _skip = ("参数配置.json",) if top == "程序" else ()
            n = _copy_tree(src, dst, skip_rel=_skip)
            _log(f"✅ {top}：覆盖了 {n} 个文件")
    except Exception as e:
        _log(f"❌ 覆盖出错：{e}，正在还原…")
        ok_restore, why = _restore(backups)
        if ok_restore:
            return False, f"覆盖失败（{e}），已经还原到更新前的状态。", 3
        return False, f"覆盖失败（{e}），还原也失败了：{why}\n请手动把 {backups[0][0]} 改回 程序 目录。", 3

    # ---- 覆盖后自检 ----
    missing = [rel for rel in REQUIRED if not os.path.isfile(os.path.join(BASE, rel))]
    if missing:
        _log(f"❌ 覆盖后缺少 {missing}，正在还原…")
        ok_restore, why = _restore(backups)
        if ok_restore:
            return False, f"覆盖完发现缺少 {missing[0]}，已经还原。", 3
        return False, f"覆盖完缺少 {missing[0]}，还原也失败了：{why}", 3

    if not keep_backup:
        for dst, _src in backups:
            _rm(dst)

    _rm(STAGE_DIR)
    _rm(zip_path)

    try:
        # utf-8-sig：万一 版本.py 被人用记事本另存过带了 BOM，
        # 第一行就不是以 APP_VERSION 开头了，这里统一吃掉 BOM。
        with open(os.path.join(BASE, "程序", "版本.py"), encoding="utf-8-sig") as fp:
            new_ver = fp.read()
        for line in new_ver.splitlines():
            if line.startswith("APP_VERSION"):
                new_ver = line.split("=", 1)[1].split("#")[0].strip().strip('"').strip("'")
                break
    except Exception:
        new_ver = remote or "?"

    keep = [os.path.basename(d) for d, _s in backups]
    tip = f"\n旧版本备份在：{', '.join(keep)}（确认没问题可以删掉）" if keep else ""
    return True, f"v{local} → v{new_ver} 更新完成。\n重启面板后生效。{tip}", 0


def _restore(backups):
    try:
        for dst, src in backups:
            if os.path.isdir(src):
                shutil.rmtree(src, ignore_errors=True)
            if os.path.isdir(dst):
                shutil.copytree(dst, src)
        return True, ""
    except Exception as e:
        return False, str(e)


def main(argv):
    apply = "--apply" in argv
    check_only = "--check-only" in argv
    # 默认保留备份：更新出问题时要能一键还原。
    # 以前这里写反了（不传 --keep 就把备份删掉），等于「以为有备份，其实没有」。
    keep_backup = "--no-keep" not in argv

    if not apply and not check_only:
        print(__doc__)
        return 0

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    if check_only:
        data, err = _read_manifest()
        if err:
            print(f"❌ {err}")
            return 1
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    ok, msg, code = apply_update(keep_backup=keep_backup)
    print(("✅ " if ok else "❌ ") + msg)
    return code


if __name__ == "__main__":
    sys.exit(main(sys.argv))
