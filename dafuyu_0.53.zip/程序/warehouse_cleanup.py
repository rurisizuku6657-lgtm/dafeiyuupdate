# -*- coding: utf-8 -*-
"""Pure planning helpers for permanent collection-warehouse cleanup."""

from __future__ import annotations


def build_sell_plan(items, keep_names, price_by_name=None):
    """Split exact recognized items into sell and keep decisions.

    Unknown, partial, or truncated items are always kept.  Duplicate items are
    independent entries and are all sold when their exact name is not kept.
    """
    allowed_keep = {
        str(name).strip() for name in (keep_names or []) if str(name).strip()
    }
    price_by_name = dict(price_by_name or {})
    sell = []
    keep = []
    for row in items or []:
        if not isinstance(row, dict):
            continue
        row = dict(row)
        name = str(row.get("item") or "").strip()
        if (
            not name
            or bool(row.get("truncated"))
            or bool(row.get("partial"))
            or bool(row.get("no_shape"))
        ):
            keep.append({
                "item": name,
                "reason": "unknown_or_incomplete",
                **row,
            })
            continue
        if name in allowed_keep:
            keep.append({
                "item": name,
                "reason": "selected_keep_item",
                **row,
            })
            continue
        try:
            price = float(price_by_name.get(name))
            row["catalog_price"] = price
        except Exception:
            pass
        sell.append({
            "item": name,
            "reason": "exact_non_keep_item",
            "requires_popup_value_check": True,
            **row,
        })
    return sell, keep


def popup_value_decision(readings, max_value):
    """Classify two independent value OCR reads without guessing.

    A missing, unstable, or boundary-crossing reading is kept.  Only two
    matching readings strictly below the limit are eligible for sale.
    """
    try:
        limit = int(max_value)
        values = [None if value is None else int(value) for value in readings]
    except Exception:
        return {
            "decision": "keep",
            "reason": "value_ocr_failed",
            "popup_values": list(readings or []),
        }
    if len(values) < 2 or any(value is None for value in values):
        return {
            "decision": "keep",
            "reason": "value_ocr_failed",
            "popup_values": values,
        }
    first, second = values[0], values[1]
    if first >= limit or second >= limit:
        return {
            "decision": "keep",
            "reason": "value_at_or_above_limit",
            "popup_value": max(first, second),
            "popup_values": values,
        }
    if first != second:
        return {
            "decision": "keep",
            "reason": "value_ocr_unstable",
            "popup_value": first,
            "popup_values": values,
        }
    return {
        "decision": "sell",
        "reason": "two_matching_values_below_limit",
        "popup_value": first,
        "popup_values": values,
    }


def assign_item_to_page(item, page_infos, row_height):
    """Map an item to the page containing most of its visible area.

    Multi-cell items may cross a 100-cell page boundary.  Click the center of
    the visible intersection instead of assuming the item's global center is
    visible on one particular page.
    """
    if not item or not page_infos:
        return None
    item_top = float(item.get("y") or 0) * float(row_height)
    item_bottom = (
        float(item.get("y") or 0) + float(item.get("h") or 1)
    ) * float(row_height)
    item_height = max(1.0, item_bottom - item_top)
    best = None
    for index, page in enumerate(page_infos):
        top = float(page.get("canvas_y") or 0)
        view_h = float(page.get("view_h") or 0)
        bottom = top + view_h
        overlap = max(0.0, min(item_bottom, bottom) - max(item_top, top))
        if overlap < min(item_height * 0.35, float(row_height) * 0.5):
            continue
        visible_mid = (max(item_top, top) + min(item_bottom, bottom)) / 2.0
        page_mid = top + view_h / 2.0
        rank = (overlap, -abs(visible_mid - page_mid))
        if best is None or rank > best[0]:
            best = (rank, index, visible_mid, top)
    if best is None:
        return None
    _rank, page_index, visible_mid, page_top = best
    page = page_infos[page_index]
    local_x = (
        float(item.get("x") or 0) + float(item.get("w") or 1) / 2.0
    ) * float(row_height)
    local_y = visible_mid - page_top
    return {
        "page_index": int(page_index),
        "thumb_top": int(page.get("thumb_top") or 0),
        "x": int(round(local_x)),
        "y": int(round(local_y)),
    }


def sell_position(item, page_infos, row_height):
    """Prefer page-local recognition coordinates over stitched coordinates."""
    if item.get("page_index") is not None:
        try:
            page_index = int(item["page_index"])
            local_x = int(item["local_x"])
            local_y = int(item["local_y"])
            if 0 <= page_index < len(page_infos):
                return {
                    "page_index": page_index,
                    "thumb_top": int(
                        page_infos[page_index].get("thumb_top") or 0
                    ),
                    "x": local_x,
                    "y": local_y,
                }
        except (KeyError, TypeError, ValueError):
            pass
    return assign_item_to_page(item, page_infos, row_height)


def adjusted_page_click(placed, actual_thumb_top, planned_thumb_top,
                        content_px_per_thumb_px):
    """Correct a local click when slider placement differs slightly."""
    if not placed:
        return None
    delta = float(actual_thumb_top) - float(planned_thumb_top)
    y = (
        float(placed["y"])
        - delta * float(content_px_per_thumb_px)
    )
    return int(round(placed["x"])), int(round(y))
