# -*- coding: utf-8 -*-
"""Pure planning helpers for permanent collection-warehouse cleanup."""

from __future__ import annotations

import re


RED_SALE_COLORS = frozenset(("红色", "特殊红色"))
SALE_NAME_OCR_ALIASES = {"一簇幽火": frozenset(("簇幽火",))}


def inspect_sale_popup(image):
    """Return the sale button and whether the popup stripe is red."""
    import cv2
    import numpy as np

    rgb = np.asarray(image.resize((620, 530)))
    dark = rgb.max(axis=2) < 85
    # The centered pill has four dark borders, pale fill and a dark label.
    for x0, y0, x1, y1 in ((260, 366, 360, 379), (260, 428, 360, 440),
                           (171, 393, 183, 413), (437, 393, 449, 413)):
        if dark[y0:y1, x0:x1].mean() < .16:
            return None
    if ((rgb[390:415, 190:270].min(axis=2) > 145).mean() < .8
            or not .10 <= dark[385:420, 275:345].mean() <= .52):
        return None

    # Check only for red in the stripe under the value. The hue wraps at zero.
    red = False
    for left, right in ((275, 385), (425, 540)):
        hsv = cv2.cvtColor(rgb[224:235, left:right], cv2.COLOR_RGB2HSV)
        hue, saturation, value = cv2.split(hsv)
        red_pixels = ((hue <= 8) | (hue >= 165)) & (saturation >= 140) & (value >= 45)
        red |= red_pixels.mean() >= .30
    button = tuple(round(v * scale) for v, scale in zip(
        (174, 369, 447, 436), (image.width / 620, image.height / 530) * 2))
    return button, red


def read_sale_labels(lines, image_height, item_name, normalize):
    """Read a uniquely identified item, price and button from popup OCR."""
    lines = [(re.sub(r"\s+", "", text), box) for text, box in lines]
    buttons = [box for text, box in lines if text == "出售" and box[1] >= image_height * .55]
    if len(buttons) != 1:
        return None
    button = buttons[0]
    labels = [(text, box) for text, box in lines if box[3] < button[1]]

    def name_key(text):
        # 仓库模板和出售弹窗对品种分隔线的写法不同。
        return re.sub(r"(?<=[\u4e00-\u9fff])[-‐‑－–—](?=[\u4e00-\u9fff])", "", normalize(text))

    expected_name = name_key(item_name)
    accepted_names = {expected_name, *SALE_NAME_OCR_ALIASES.get(expected_name, ())}
    names = [box for text, box in labels if name_key(text) in accepted_names]
    if len(names) != 1:
        return None
    number = r"(?:[0-9]{1,3}(?:[,，'’][0-9]{3})+|[0-9]+)"
    price_line = re.compile(rf"(?:(?:实际|当前)?价值[:：]?)?({number})")
    amounts = []
    for text, box in labels:
        match = price_line.fullmatch(text)
        if match:
            amounts.append((match[1], box))
    if len(amounts) != 1:
        return None
    raw, amount_box = amounts[0]
    value = int(re.sub(r"[^0-9]", "", raw))
    return (value, button, [names[0], amount_box, button]) if value > 0 else None


def align_sale_page(reference, current):
    """Use unchanged sections of the grid to locate the live page."""
    import cv2
    import numpy as np

    if reference.size != current.size or reference.width < 260 or reference.height < 260:
        return None
    saved = np.asarray(reference)
    live = np.asarray(current)
    votes = []
    for y in range(24, reference.height - 90 - 18, 90):
        for x in range(12, reference.width - 90 - 4, 90):
            template = saved[y:y + 90, x:x + 90]
            if template.std(axis=(0, 1)).max() < 14:
                continue
            search = live[y - 18:y + 108, x - 4:x + 94]
            scores = cv2.matchTemplate(search, template, cv2.TM_CCOEFF_NORMED)
            _, peak, _, (dx, dy) = cv2.minMaxLoc(scores)
            scores[max(0, dy - 2):dy + 3, max(0, dx - 2):dx + 3] = -1
            if peak >= .94 and peak - float(scores.max()) >= .015:
                votes.append((dx - 4, dy - 18))
    if len(votes) < 3:
        return None
    dx, dy = (int(round(v)) for v in np.median(votes, axis=0))
    agreeing = sum(abs(x - dx) <= 1 and abs(y - dy) <= 1 for x, y in votes)
    return (dx, dy) if agreeing >= 3 and agreeing >= .8 * len(votes) else None


def match_sale_slot(reference, current, box, page_offset):
    """Match the item's structure around the registered position."""
    import cv2
    import numpy as np

    x0, y0, x1, y1 = box
    dx, dy = page_offset or (0, 0)
    mx_limit, my_limit = (3, 3) if page_offset is not None else (4, 18)
    sx = max(0, x0 + dx - mx_limit)
    sy = max(0, y0 + dy - my_limit)
    ex = min(current.width, x1 + dx + mx_limit)
    ey = min(current.height, y1 + dy + my_limit)
    if ex - sx < x1 - x0 or ey - sy < y1 - y0:
        return None
    expected = np.asarray(reference.crop(box))
    if expected.std(axis=(0, 1)).max() < 9:
        return None
    scores = cv2.matchTemplate(np.asarray(current.crop((sx, sy, ex, ey))), expected,
                               cv2.TM_CCOEFF_NORMED)
    _, peak, _, (mx, my) = cv2.minMaxLoc(scores)
    if page_offset is None:
        # Nearby peaks can belong to the same wide icon.
        scores[max(0, my - 5):my + 6, max(0, mx - 5):mx + 6] = -1
        if peak < .94 or peak - float(scores.max()) < .06:
            return None
    return (sx + mx - x0, sy + my - y0) if peak >= .88 else None


def sale_cells_empty(page, x, y, columns, rows, cell_size, *, offset):
    """Check the interior of every cell the item occupied."""
    import numpy as np

    if columns < 1 or rows < 1:
        return False
    dx, dy = offset or (0, 0)
    # If no unchanged anchors remain, require the full plausible center area
    # to be empty in every cell, including at either end of the scroll error.
    rx, ry = (8, 8) if offset is not None else (12, 26)
    for col in range(columns):
        cx = round(x + dx + (col - (columns - 1) / 2) * cell_size)
        for row in range(rows):
            cy = round(y + dy + (row - (rows - 1) / 2) * cell_size)
            if not (rx <= cx <= page.width - rx and ry <= cy <= page.height - ry):
                return False
            interior = np.asarray(page.crop((cx - rx, cy - ry, cx + rx, cy + ry)))
            if (interior.max(axis=2) > 48).mean() > .02 or np.ptp(interior, axis=2).mean() > 10:
                return False
    return True


def build_sell_plan(items, keep_names, price_by_name=None):
    """Split exact recognized items into sell and keep decisions.

    Unnamed or no-shape items are always kept.  Duplicate items are
    independent entries and are all sold when their exact name is not kept.
    """
    allowed_keep = {
        str(name).strip() for name in (keep_names or []) if str(name).strip()
    }
    price_by_name = dict(price_by_name or {})
    sell = []
    keep = []
    for row in items or []:
        if not isinstance(row, dict):
            continue
        row = dict(row)
        name = str(row.get("item") or "").strip()
        if not name or bool(row.get("no_shape")):
            keep.append({
                "item": name,
                "reason": "unknown_or_incomplete",
                **row,
            })
            continue
        if name in allowed_keep:
            keep.append({
                "item": name,
                "reason": "selected_keep_item",
                **row,
            })
            continue
        try:
            price = float(price_by_name.get(name))
            row["catalog_price"] = price
        except Exception:
            pass
        sell.append({
            "item": name,
            "reason": "exact_non_keep_item",
            "requires_popup_value_check": row.get("color") in RED_SALE_COLORS,
            **row,
        })
    return sell, keep


def assign_item_to_page(item, page_infos, row_height):
    """Map an item to the page containing most of its visible area.

    Multi-cell items may cross a 100-cell page boundary.  Click the center of
    the visible intersection instead of assuming the item's global center is
    visible on one particular page.
    """
    if not item or not page_infos:
        return None
    item_top = float(item.get("y") or 0) * float(row_height)
    item_bottom = (
        float(item.get("y") or 0) + float(item.get("h") or 1)
    ) * float(row_height)
    item_height = max(1.0, item_bottom - item_top)
    best = None
    for index, page in enumerate(page_infos):
        top = float(page.get("canvas_y") or 0)
        view_h = float(page.get("view_h") or 0)
        bottom = top + view_h
        overlap = max(0.0, min(item_bottom, bottom) - max(item_top, top))
        if overlap < min(item_height * 0.35, float(row_height) * 0.5):
            continue
        visible_mid = (max(item_top, top) + min(item_bottom, bottom)) / 2.0
        page_mid = top + view_h / 2.0
        rank = (overlap, -abs(visible_mid - page_mid))
        if best is None or rank > best[0]:
            best = (rank, index, visible_mid, top)
    if best is None:
        return None
    _rank, page_index, visible_mid, page_top = best
    page = page_infos[page_index]
    local_x = (
        float(item.get("x") or 0) + float(item.get("w") or 1) / 2.0
    ) * float(row_height)
    local_y = visible_mid - page_top
    return {
        "page_index": int(page_index),
        "thumb_top": int(page.get("thumb_top") or 0),
        "x": int(round(local_x)),
        "y": int(round(local_y)),
    }


def sell_position(item, page_infos, row_height):
    """Prefer page-local recognition coordinates over stitched coordinates."""
    if item.get("page_index") is not None:
        try:
            page_index = int(item["page_index"])
            local_x = int(item["local_x"])
            local_y = int(item["local_y"])
            if 0 <= page_index < len(page_infos):
                return {
                    "page_index": page_index,
                    "thumb_top": int(
                        page_infos[page_index].get("thumb_top") or 0
                    ),
                    "x": local_x,
                    "y": local_y,
                }
        except (KeyError, TypeError, ValueError):
            pass
    return assign_item_to_page(item, page_infos, row_height)


def adjusted_page_click(placed, actual_thumb_top, planned_thumb_top,
                        content_px_per_thumb_px):
    """Correct a local click when slider placement differs slightly."""
    if not placed:
        return None
    delta = float(actual_thumb_top) - float(planned_thumb_top)
    y = (
        float(placed["y"])
        - delta * float(content_px_per_thumb_px)
    )
    return int(round(placed["x"])), int(round(y))


def merge_page_items(items):
    """Merge only matching, complete observations of the same warehouse cells."""
    groups = {}
    for row in items:
        if not row["item"] or row["truncated"] or row["partial"] or row["no_shape"]:
            continue
        key = row["x"], row["y"], row["w"], row["h"]
        groups.setdefault(key, []).append(row)

    accepted = []
    ambiguous = 0
    for (x, y, w, h), matches in groups.items():
        if (len({row["item"] for row in matches}) != 1
                or any((x, y, w, h) != other and x < other[0] + other[2]
                       and other[0] < x + w and y < other[1] + other[3]
                       and other[1] < y + h for other in groups)):
            ambiguous += 1
            continue
        accepted.append(max(matches, key=lambda row: row["score"]))
    return sorted(accepted, key=lambda row: (row["page_index"], row["local_y"], row["local_x"])), ambiguous


def supplemental_sale_pages(items, visible_rows, total_rows):
    """Group named items only seen at page edges into a few overlapping views."""
    def key(row):
        return tuple(row[k] for k in ("item", "x", "y", "w", "h"))

    complete = {key(row) for row in items
                if not (row["partial"] or row["truncated"] or row["no_shape"])}
    pending = {key(row) for row in items if row["partial"] and not row["no_shape"]} - complete
    last_start = total_rows - visible_rows
    groups = []
    for item in sorted(pending, key=lambda item: (item[2], item[0], item[1])):
        _, _, y, _, h = item
        if h >= visible_rows - 1 or y < 0 or y + h > total_rows:
            continue
        if groups and groups[-1][0] + .75 <= y and y + h <= groups[-1][0] + visible_rows - .75:
            groups[-1][1].add(item)
        else:
            start = min(last_start, max(0, round(y + h / 2 - visible_rows / 2)))
            groups.append((start, {item}))
    return groups


def locate_supplemental_page(canvas, page, expected_y):
    """Register a shifted live view against the original warehouse scan."""
    import cv2
    import numpy as np

    x_margin, y_margin = 12, 30
    template = np.asarray(page.crop((x_margin, y_margin, page.width - x_margin,
                                     page.height - y_margin)))
    low = max(0, round(expected_y) - 24)
    high = min(canvas.height - page.height, round(expected_y) + 24)
    if low > high or template.std(axis=(0, 1)).max() < 14:
        return None
    search = np.asarray(canvas.crop((x_margin, low + y_margin, page.width - x_margin,
                                     high + page.height - y_margin)))
    scores = cv2.matchTemplate(search, template, cv2.TM_CCOEFF_NORMED).ravel()
    best = int(scores.argmax())
    peak = scores[best]
    scores[max(0, best - 3):best + 4] = -1
    return low + best if peak >= .88 and peak - scores.max() >= .018 else None
