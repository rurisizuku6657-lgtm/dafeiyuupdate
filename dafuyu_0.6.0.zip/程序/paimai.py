# -*- coding: utf-8 -*-
import sys
import io
import os
import logging
import json
import random
import traceback
import ctypes
from ctypes import wintypes
from datetime import datetime, timedelta
import time
import hashlib
from collections import OrderedDict
from contextlib import contextmanager
import re
import threading
import keyboard
import pygetwindow as gw
import pyautogui
import cv2
import numpy as np

try:
    import warehouse_cleanup
except Exception:  # 老版本没有这个模块也不影响主流程
    warehouse_cleanup = None
from difflib import SequenceMatcher

# Initialize PaddleOCR's log controls before importing/constructing it.
os.environ.setdefault("FLAGS_log_level", "3")
os.environ.setdefault("GLOG_minloglevel", "2")
os.environ.setdefault("PADDLEOCR_LOG_LEVEL", "ERROR")
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")
from paddleocr import PaddleOCR
import win32gui
import win32api
import win32con
import win32process
import pygame
from dataclasses import dataclass, field
from functools import wraps

for _quiet_logger in ("ppocr", "paddle", "paddleocr"):
    logging.getLogger(_quiet_logger).setLevel(logging.ERROR)

# 程序版本号：唯一来源是 程序\版本.py（界面.py 也从那里读）。
# 以前 paimai.py 里根本没有版本号，群友发日志过来只能靠日期猜是哪一版。
try:
    if os.path.dirname(os.path.abspath(__file__)) not in sys.path:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from 版本 import APP_VERSION, APP_DISPLAY
except Exception:
    APP_VERSION = "?"
    APP_DISPLAY = "大肥鱼standby（版本未知）"

_STRING_PANEL_CONSTANTS = ("BID_MODE",)


def 自修字符串配置():
    try:
        path = __file__
        if not os.path.isabs(path):
            path = os.path.abspath(path)
        with open(path, encoding="utf-8") as fh:
            src = fh.read()
        lines = src.split("\n")
        healed = []
        for name in _STRING_PANEL_CONSTANTS:
            pat = re.compile(r"^%s[ \t]*=[ \t]*([A-Za-z_]\w*)(.*)$" % re.escape(name))
            for i, line in enumerate(lines):
                m = pat.match(line)
                if not m:
                    continue
                bare = m.group(1)
                lines[i] = re.sub(
                    r"^(" + re.escape(name) + r"[ \t]*=[ \t]*)" + re.escape(bare),
                    r'\1"' + bare + '"',
                    line,
                    count=1,
                )
                healed.append("%s=%s" % (name, bare))
                break
        fixed = "\n".join(lines)
        if fixed != src:
            tmp = path + ".tmp_fix"
            with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
                fh.write(fixed)
            os.replace(tmp, path)
            return healed
    except Exception:
        pass
    return []


class _SelfHealOk(Exception):
    """重执行走到尾部时用它干净退出第一遍。"""


def 修完再启动():
    global _SELF_HEAL_DONE
    path = os.path.abspath(__file__)
    healed = 自修字符串配置()
    if not healed:
        return
    try:
        g = globals()
        g["_SELF_HEAL_DONE"] = True
        exec(compile(open(path, encoding="utf-8").read(), path, "exec"), g)
    except _SelfHealOk:
        pass
    finally:
        raise SystemExit(0)


if not globals().get("_SELF_HEAL_DONE"):
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", line_buffering=True)
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", line_buffering=True)
    except Exception:
        pass
    修完再启动()

FAILSAFE_ENABLED = 0
pyautogui.FAILSAFE = bool(FAILSAFE_ENABLED)

audio_available = False
try:
    pygame.mixer.init()
    audio_available = True
    print("✅ 音频初始化成功，警报功能可用。")
except Exception as e:
    print(f"⚠️ 音频初始化失败，将无法播放警报声音: {e}")
    print("⚠️ 脚本将继续运行，但不会响铃。")

_HERE = os.path.dirname(os.path.abspath(__file__))
SCRIPT_DIR = _HERE
for _d in (_HERE, os.path.dirname(_HERE)):
    if os.path.isdir(os.path.join(_d, "python")) or os.path.isdir(os.path.join(_d, "素材")):
        SCRIPT_DIR = _d
        break
os.chdir(SCRIPT_DIR)
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import runtime_control as rc

CONTROL_AUTH = rc.OperationAuthority()

NUMERIC_STYLE = "white"
NUMERIC_READER = None
NUMERIC_READER_ERROR = ""
NUMERIC_CONFIG = {}
NUMERIC_CONFIG_LOADED = False
NUMERIC_DEBUG_IMAGES = 0
NUMERIC_FIELD_LIMITS = {
    "estimate": (3, 10),
    "funds": (4, 12),
    "final_price": (1, 12),
    "actual_value": (1, 12),
    "profit": (1, 12),
}
TEMPLATE_AUTHORITY_MIN_SCORE = 0.93
TEMPLATE_AUTHORITY_MIN_MARGIN = 0.06


def 读数字配置():
    """Load optional user-editable numeric settings.

    Runtime defaults stay strict if this file is absent or malformed.
    """
    global NUMERIC_CONFIG, NUMERIC_CONFIG_LOADED, NUMERIC_STYLE
    if NUMERIC_CONFIG_LOADED:
        return NUMERIC_CONFIG
    NUMERIC_CONFIG_LOADED = True
    path = os.path.join(SCRIPT_DIR, "素材", "数字识别配置.json")
    try:
        with open(path, encoding="utf-8") as fp:
            config = json.load(fp)
        if isinstance(config, dict):
            NUMERIC_CONFIG = config
            NUMERIC_STYLE = str(config.get("style", NUMERIC_STYLE) or "white")
    except FileNotFoundError:
        pass
    except Exception as e:
        print(f"⚠️ 数字识别配置无效，使用内置严格默认值：{e}")
    return NUMERIC_CONFIG


def 存数字调试图(file_name, image_bgr):
    """Save OCR crop only when explicitly enabled for development."""
    if int(globals().get("NUMERIC_DEBUG_IMAGES", 0) or 0) != 1:
        return False
    try:
        path = os.path.join(SCREENSHOT_DIR, file_name)
        ok, encoded = cv2.imencode(".png", image_bgr)
        if ok:
            encoded.tofile(path)
            return True
    except Exception:
        pass
    return False


def 数字识别器():
    """Lazily load the editable digit-template bank.

    A missing or damaged pack is reported once and treated as unavailable;
    the old OCR path remains as a compatibility fallback.
    """
    global NUMERIC_READER, NUMERIC_READER_ERROR
    if NUMERIC_READER is not None:
        return NUMERIC_READER
    if NUMERIC_READER_ERROR:
        return None
    读数字配置()
    if not bool(NUMERIC_CONFIG.get("enabled", True)):
        NUMERIC_READER_ERROR = "disabled by 素材/数字识别配置.json"
        print("ℹ️ 数字模板校验已在配置中关闭，数字读取回退 OCR")
        return None
    try:
        from numeric_reader import VisualNumericReader, default_template_root

        NUMERIC_READER = VisualNumericReader(
            default_template_root(SCRIPT_DIR),
            style=NUMERIC_STYLE,
        )
        print(f"✅ 数字模板库已加载（样式 {NUMERIC_STYLE}）")
    except Exception as e:
        NUMERIC_READER_ERROR = str(e)
        print(f"⚠️ 数字模板库不可用，数字读取暂回退 OCR：{e}")
    return NUMERIC_READER


def 数字模板判定(image, expected_value=None, expected_count=None):
    """Return (available, accepted, decision) for one image."""
    reader = 数字识别器()
    if reader is None:
        return False, True, None
    try:
        decision = reader.recognize(
            image,
            expected_count=expected_count,
            expected_value=expected_value,
        )
        return True, decision.ok, decision
    except Exception as e:
        print(f"⚠️ 数字模板校验异常，按不可用处理：{e}")
        return False, True, None


def 数字库概要(decision):
    if decision is None:
        return "模板未执行"
    return "模板 %s（%s，最低分 %.3f，最小差 %.3f）" % (
        decision.digits or "未读出",
        "通过" if decision.ok else "拒绝",
        decision.min_score,
        decision.min_margin,
    )


def 数字字段范围(field):
    读数字配置()
    configured = NUMERIC_CONFIG.get("digit_limits", {}) if isinstance(NUMERIC_CONFIG, dict) else {}
    values = configured.get(field, NUMERIC_FIELD_LIMITS.get(field, (1, 12)))
    try:
        return max(1, int(values[0])), max(1, int(values[1]))
    except Exception:
        return NUMERIC_FIELD_LIMITS.get(field, (1, 12))


def 数字权威阈值():
    读数字配置()
    values = (
        NUMERIC_CONFIG.get("template_authority", {}) if isinstance(NUMERIC_CONFIG, dict) else {}
    )
    try:
        min_score = float(values.get("min_score", TEMPLATE_AUTHORITY_MIN_SCORE))
        min_margin = float(values.get("min_margin", TEMPLATE_AUTHORITY_MIN_MARGIN))
    except Exception:
        min_score, min_margin = (
            TEMPLATE_AUTHORITY_MIN_SCORE,
            TEMPLATE_AUTHORITY_MIN_MARGIN,
        )
    return min_score, min_margin


def 按模板读数字(image, field, ocr_candidates=None):
    """Read an amount with the template as the primary source.

    OCR is retained for field context and as a fallback only when the visual
    result is not authoritative.  A clear template read wins a conflict.
    Returns ``(digits, source, decision)``.
    """
    digits_candidates = []
    for candidate in ocr_candidates or []:
        digits = re.sub(r"\D", "", str(candidate or ""))
        if digits and digits not in digits_candidates:
            digits_candidates.append(digits)
    reader = 数字识别器()
    if reader is None:
        return (
            digits_candidates[0] if digits_candidates else "",
            "ocr (template unavailable)",
            None,
        )
    min_digits, max_digits = 数字字段范围(field)
    try:
        decision = reader.recognize(
            image,
            min_digits=min_digits,
            max_digits=max_digits,
        )
    except Exception as e:
        print(f"⚠️ {field} 模板读取异常，回退 OCR：{e}")
        return (digits_candidates[0] if digits_candidates else "", "ocr (template error)", None)

    visual = getattr(decision, "digits", "") if decision is not None else ""
    authority_score, authority_margin = 数字权威阈值()
    if visual and visual in digits_candidates:
        return visual, "template+ocr", decision

    if decision is not None and decision.ok:
        if not digits_candidates or (
            decision.min_score >= authority_score and decision.min_margin >= authority_margin
        ):
            return visual, "template", decision

    if digits_candidates:
        return digits_candidates[0], "ocr fallback", decision
    return "", "no reliable read", decision


def 确认数字候选(image, candidates):
    """Require the visual template bank to confirm at least one OCR candidate.

    Returns ``(available, matched, decision)``.  ``available=False`` means
    the optional template pack could not run and the caller should retain its
    compatibility fallback.
    """
    clean = []
    for candidate in candidates or []:
        digits = re.sub(r"\D", "", str(candidate or ""))
        if digits and digits not in clean:
            clean.append(digits)
    reader = 数字识别器()
    if reader is None:
        return False, True, None
    best = None
    for candidate in clean:
        try:
            decision = reader.recognize(
                image,
                expected_count=len(candidate),
                expected_value=candidate,
            )
        except Exception as e:
            print(f"⚠️ 数字模板校验异常：{e}")
            return False, True, None
        if best is None or decision.min_score > best.min_score:
            best = decision
        if decision.ok:
            return True, True, decision
    return True, False, best


# 所有会直接操作游戏键鼠的路径共享同一把可重入锁，包括点击、按键、
# 整仓翻页拖拽和后台滚轮。
GAME_ACTION_LOCK = threading.RLock()


def 执行游戏动作(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        with GAME_ACTION_LOCK:
            return fn(*args, **kwargs)

    return wrapped


RUNLOG_DIR = os.path.join(SCRIPT_DIR, "记录")
os.makedirs(RUNLOG_DIR, exist_ok=True)

SCREENSHOT_DIR = os.path.join(RUNLOG_DIR, "报错截图")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

LOG_ROOT = os.path.join(RUNLOG_DIR, "日志")
HIGH_VALUE_SHOT_ROOT = os.path.join(RUNLOG_DIR, "高价值截图")
LOW_VALUE_SHOT_ROOT = os.path.join(RUNLOG_DIR, "低价值截图")
OVERRIDE_RUN_LOG = None
OVERRIDE_CONSOLE_LOG = None
OVERRIDE_LOG_DIR = None
OVERRIDE_AUCTION_RECORD = None
OVERRIDE_HIGH_VALUE_DIR = None


def 当天目录(kind):
    try:
        d = os.path.join(RUNLOG_DIR, kind, datetime.now().strftime("%Y-%m-%d"))
        os.makedirs(d, exist_ok=True)
        return d
    except Exception:
        return os.path.join(RUNLOG_DIR, kind)


def 运行日志路径():
    return OVERRIDE_RUN_LOG or os.path.join(当天目录("日志"), "运行日志.txt")


def 控制台日志路径():
    return OVERRIDE_CONSOLE_LOG or os.path.join(当天目录("日志"), "控制台输出.txt")


def 报错日志路径():
    d = OVERRIDE_LOG_DIR or 当天目录("日志")
    return os.path.join(d, "报错日志.txt"), os.path.join(d, "报错日志.jsonl")


def 报错截图目录():
    d = OVERRIDE_LOG_DIR or 当天目录("日志")
    path = os.path.join(d, "报错截图")
    try:
        os.makedirs(path, exist_ok=True)
    except Exception:
        pass
    return path


def 拍卖记录路径():
    return OVERRIDE_AUCTION_RECORD or os.path.join(当天目录("日志"), "拍卖记录.txt")


def 高价值截图目录():
    if OVERRIDE_HIGH_VALUE_DIR:
        try:
            os.makedirs(OVERRIDE_HIGH_VALUE_DIR, exist_ok=True)
        except Exception:
            pass
        return OVERRIDE_HIGH_VALUE_DIR
    return 当天目录("高价值截图")


HIGH_VALUE_SCREENSHOT_DIR = HIGH_VALUE_SHOT_ROOT


def 高价值分析目录():
    return 当天目录("高价值分析图")


def 低价值截图目录():
    return 当天目录("低价值截图")


class _TeeStream:

    def __init__(self, *streams):
        self._streams = streams

    def write(self, s):
        for st in self._streams:
            try:
                st.write(s)
            except Exception:
                pass
        return len(s or "")

    def flush(self):
        for st in self._streams:
            try:
                st.flush()
            except Exception:
                pass

    def isatty(self):
        try:
            return self._streams[0].isatty()
        except Exception:
            return False

    def fileno(self):
        return self._streams[0].fileno()

    @property
    def encoding(self):
        return getattr(self._streams[0], "encoding", "utf-8")

    def __getattr__(self, name):
        return getattr(self._streams[0], name)


class _DailyFileWriter:

    def __init__(self, path_getter, header=None):
        self._path_getter = path_getter
        self._header = header
        self._date = None
        self._fp = None

    def _roll(self):
        today = datetime.now().strftime("%Y-%m-%d")
        if self._fp is not None and today == self._date:
            return
        try:
            if self._fp is not None:
                self._fp.close()
        except Exception:
            pass
        path = self._path_getter()
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            if os.path.exists(path) and os.path.getsize(path) > 20 * 1024 * 1024:
                os.replace(path, path + ".old")
        except Exception:
            pass
        try:
            self._fp = open(path, "a", encoding="utf-8", buffering=1)
            if self._header:
                self._fp.write(
                    "\n"
                    + "=" * 70
                    + "\n[{}] {}\n".format(
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"), self._header
                    )
                    + "=" * 70
                    + "\n"
                )
        except Exception:
            self._fp = None
        self._date = today

    def write(self, s):
        try:
            self._roll()
            if self._fp is not None:
                self._fp.write(s)
        except Exception:
            pass
        return len(s or "")

    def flush(self):
        try:
            if self._fp is not None:
                self._fp.flush()
        except Exception:
            pass

    def close(self):
        try:
            if self._fp is not None:
                self._fp.close()
        except Exception:
            pass
        self._fp = None


CONSOLE_LOG_FILE = None
_stream_keepalive = (sys.stdout, sys.stderr, None)
# 自检和离线分析脚本只是 import 这个模块，不该往当天的
# 『控制台输出.txt』里写一段"初始化记录"（实测每跑一次自检就多 9 行）。
# 这些脚本在 import 之前设 PAIMAI_NO_CONSOLE_LOG=1 就整个跳过；正常挂机不受影响。
if os.environ.get("PAIMAI_NO_CONSOLE_LOG") != "1":
    try:
        _console_writer = _DailyFileWriter(控制台日志路径, header="控制台输出开始")
        _console_writer._roll()
        _stream_keepalive = (sys.stdout, sys.stderr, _console_writer)
        sys.stdout = _TeeStream(sys.stdout, _console_writer)
        sys.stderr = _TeeStream(sys.stderr, _console_writer)
    except Exception:
        pass

MATERIAL_DIR = "素材"

os.environ["FLAGS_log_level"] = "3"

RUN_LOG_FILE = os.path.join(RUNLOG_DIR, "运行日志.txt")


_RECORD_FAIL_AT = [0.0]


def _提示记录失败(what, exc):
    """记录写不进去时喊一声。

    以前这类失败被 except: pass 完全吞掉 —— 日志少了、训练数据缺行，
    事后翻记录只会看到「那天很正常」。限流 60 秒，不刷屏。
    """
    try:
        now = time.time()
        if now - _RECORD_FAIL_AT[0] < 60.0:
            return
        _RECORD_FAIL_AT[0] = now
        print(f"⚠️ 记录写入失败（{what}）：{exc} —— 60 秒内不再提示")
    except Exception:
        pass


def 写日志(msg):
    line = "[{}] {}".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line)
    try:
        path = 运行日志路径()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fp:
            fp.write(line + "\n")
    except Exception as exc:
        _提示记录失败("运行日志", exc)


RUNLOG_ON = 1
SHOT_ON = 0  # 发布包保留记录，但不保存常规对局截图
RUNLOG_DIR = os.path.join(SCRIPT_DIR, "记录")
RUNLOG_JSONL = os.path.join(RUNLOG_DIR, "试验记录.jsonl")
RUNLOG_TXT = os.path.join(RUNLOG_DIR, "试验记录.txt")
try:
    os.makedirs(RUNLOG_DIR, exist_ok=True)
except Exception:
    pass

RUNLOG_ROUNDS = []
RUNLOG_SEEN_PRICES = []
_RUNLOG_BID_DECISIONS = {}
RUNLOG_AUCTION_NO = 0
RUNLOG_START_TS = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
# 本次运行的唯一编号：局号只在一次运行内唯一，重启会从 1 开始重数，
# 报表按局号分组就会把不同次的记录串到一起（实测不同时段都出现「局89」）。
RUN_ID = datetime.now().strftime("%Y%m%d_%H%M%S")
RUNLOG_OCR = {}
SHOT_DIR = os.path.join(RUNLOG_DIR, "截图")
SHOT_KEEP_MAX = 300  # 0 = 全部保留；发布包使用 300，且 SHOT_ON=0
RUNLOG_STATS = {
    "auctions": 0,
    "won": 0,
    "lost": 0,
    "quit": 0,
    "profit": 0,
    "losing_bets": 0,
    "steps_failed": 0,
    "cost": 0,
    "net_profit": 0,
}
AUCTION_COST = 0
AUCTION_COST_ITEMS = []
AUCTION_COST_KEYS = set()
try:
    os.makedirs(SHOT_DIR, exist_ok=True)
except Exception:
    pass


def 存回合截图(tag, region=None, note=None):
    if RUNLOG_ON != 1 or SHOT_ON != 1:
        return ""
    try:
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_tag = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(tag))[:40]
        name = f"{ts}_a{RUNLOG_AUCTION_NO}_{safe_tag}.jpg"
        path = os.path.join(SHOT_DIR, name)
        img = 抓一帧(region=region) if region else 抓一帧()
        img.convert("RGB").save(path, "JPEG", quality=70)
        记回合事件(
            "shot", human=f"📷 截图 {name}" + (f"（{note}）" if note else ""), tag=tag, file=name
        )
        清旧截图()
        return name
    except Exception:
        return ""


def 清旧截图():
    try:
        if not SHOT_KEEP_MAX or int(SHOT_KEEP_MAX) <= 0:
            return
        files = sorted(os.listdir(SHOT_DIR))
        if len(files) <= SHOT_KEEP_MAX:
            return
        for f in files[: len(files) - SHOT_KEEP_MAX // 2]:
            try:
                os.remove(os.path.join(SHOT_DIR, f))
            except Exception:
                pass
    except Exception:
        pass


def 回合截图区域():
    try:
        w = 游戏窗口范围()
        return (w[0], w[1], w[2], w[3]) if w else None
    except Exception:
        return None


CAPTURE_ENABLED = 0
CAPTURE_MAX_PAGES = 8
CAPTURE_HOTKEY = "backslash"
CAPTURE_JPEG_QUALITY = 92
# 实测：格子横线 y≈208~780、竖线 x≈1313.5 起每 56.3 一条（1370/1426/…/1877）。
# 原来左边取 1345，正好把最左那一列切掉了（实测有 80x204 这种"半个钟"的块）
# → 现在左边拉到 1300，右边到 1890（含那根滚动条），下边到 793，保证整行整列都在框里。
GRID_BOX = (1300, 193, 590, 600)
GRID_SCROLLBAR_X = 1887
GRID_SCROLL_UP_Y = 218
GRID_SCROLL_DOWN_Y = 768
GRID_SCROLL_TOP_Y = 236
GRID_SCROLL_BOTTOM_Y = 761  # 实测：滑块滑到底时上沿 542，滑块长 219 → 542+219=761
# 实测（10-11，用 1920x1080 原始截图精确量的，不是裁图）：
# · 藏格的横线：…265 324 381 437 493 550 606 663 719 774 → 行高 56.56px，
# 第一条横线在 y≈208.4（格子区域约 y 208~780）；竖线：1370 1426 1483 1538 1596
# 1651 1709 1764 1821 1877 → 列宽 56.3px，格子左边界 x≈1370；
# · 滚动条中心 x=1887（第3屏那一列也扫出 1887 ✓）；滑块长固定 220px；
# ▲ 在 y≈218、▼ 在 y≈768，轨道内区 y≈226~764；
# · 【关键】点一下"滑块下面"的轨道 = 往下翻一整屏（10 行 = 566px）：
# 同仓三连拍里滑块分别在 226 / 436 / 542（位移 210 / 106），
# 换算成内容位移正好是 10 行 / 15 行（整仓 25 行，最后一屏夹在底部、和上一屏重叠 5 行）。
# 所以翻页**只用点**，不用拖；拼接按"一屏 = 10 行"接，最后一屏再用画面比对校正。
GRID_THUMB_TOP = 226
GRID_THUMB_BOTTOM = 445
GRID_ROW_H = 56.6  # 一个格子的边长（实测 56.56）
GRID_PAGE_ROWS = 10  # 一屏显示几行（实测 10）
GRID_PAGE_PX = int(round(GRID_ROW_H * GRID_PAGE_ROWS))  # 一屏 = 566px
GRID_TOTAL_ROWS = 25  # 整个仓 10 列 × 25 行（翻两下、看三屏就该到齐）
# 整仓的"内容高度"：一屏 600px + 滑块走完全程对应仓里 15 行（15×56.6=849px）= 1449px。
# 注意：1449px 里只有 25×56.6=1415px 是格子，多出来的 34px 是格子上下的留白，
# 所以"1449/56.6=25.6"是像素折算的行数，**不是行数**（行数是 25）。
GRID_SCROLL_ROWS = GRID_TOTAL_ROWS - GRID_PAGE_ROWS
GRID_FULL_PX = GRID_BOX[3] + int(round(GRID_SCROLL_ROWS * GRID_ROW_H))
GRID_THUMB_LEN = 219  # 滑块长（实测 445−226）
GRID_FRAME_BOTTOM = 18  # 面板底部那条固定边框有几行（实测页内 582~599 三页一模一样）
# 格子原点（框内坐标）：第一列左边界 1313.5−1300、第一行横线 208−193；一列 56.35、一行 56.6
GRID_X0 = 13.5
GRID_COL_W = 56.35
GRID_Y0 = 15.0
OVERRIDE_CAPTURE_DIR = None

# 藏品模板采集（10-11：只认红/金两档，紫/蓝/绿/白一律不管；测试期不加面板参数）
TEMPLATE_CAPTURE_ENABLED = 0  # 发布包关闭自动藏品模板采集
TEMPLATE_CAPTURE_ROUND = 3  # 只在第 3 回合抓（这时小吱把 8 件都揭示出来了，信息最全）
# 指纹相似度 ≥ 它就算"见过"，不重复存。
# 0.92 → 0.85：改成"抠出画再缩"的指纹后，同一件 0.99~1.00、不同藏品 ≤0.60，
# 留 0.85 才吃得下"火焰/发光"这种每帧略有不同的动态藏品（实测火花塞 0.882），
# 原来 0.92 会导致同一件被反复存成新藏品（一上午多存 126 张重复照）。
TEMPLATE_DUP_SCORE = 0.85
TEMPLATE_KEEP_SAT = 0.35  # 底色饱和度低于它 → 白/灰档，不要
TEMPLATE_KEEP_HUE = (52.0, 335.0)  # 色相落在这区间 → 紫/蓝/绿，不要


def 截图目录():
    if OVERRIDE_CAPTURE_DIR:
        try:
            os.makedirs(OVERRIDE_CAPTURE_DIR, exist_ok=True)
        except Exception:
            pass
        return OVERRIDE_CAPTURE_DIR
    return 当天目录("取图")


def 抓整仓图():
    try:
        win = 游戏窗口范围()
        if win is None:
            return None
        left, top, _, _ = win
        x, y, w, h = GRID_BOX
        return 抓一帧(region=(left + x, top + y, w, h))
    except Exception as e:
        print(f"⚠️ 取图：截藏品格失败 {e}")
        return None


def 图差(a, b):
    try:
        import numpy as np

        if a is None or b is None:
            return 999.0
        ga = np.array(a.convert("L"), dtype=np.int16)
        gb = np.array(b.convert("L"), dtype=np.int16)
        if ga.shape != gb.shape:
            return 999.0
        return float(np.abs(ga - gb).mean())
    except Exception:
        return 999.0


def 整仓滚动范围(img=None):
    try:
        import numpy as np

        shot = img if img is not None else 抓整仓图()
        if shot is None:
            return None
        g = np.array(shot.convert("L"), dtype=np.int16)
        cx = GRID_SCROLLBAR_X - GRID_BOX[0]
        if cx < 0 or cx >= g.shape[1]:
            return None
        ys = np.where(g[:, cx] > 150)[0]
        if len(ys) < 10:
            return None
        segs, s, prev = [], ys[0], ys[0]
        for y in ys[1:]:
            if y - prev > 4:
                segs.append((s, prev))
                s = y
            prev = y
        segs.append((s, prev))
        a, b = max(segs, key=lambda t: t[1] - t[0])
        if b - a < 8:
            return None
        return (a + GRID_BOX[1], b + GRID_BOX[1])
    except Exception:
        return None


def 整仓滚一屏(down=True, step_frac=0.34):
    """把藏品格往下（或往上）走一步，默认走全部行程的 1/3（≈5 行，保证两页有大量重叠）。

    判据是"滑块真的动了没有"（不受动画影响）。
    做法按"动作最少"排序，**一步只做一个动作**，成功就停、不成功试下一个，最多 3 个动作：
        ⓿ 点轨道空白处（一次点击、最省事；要离滑块 ≥60px，否则等于点在滑块上）
        ① 拖滑块（实测就这个界面认拖动：一拖正好 ~5 行，能一小步一小步走）
        ② 点 ▲/▼ 箭头（一次，不再连点；实测它是一下跳到底）
        ③ 滚轮（在藏格品中间滚；实测只挪 1px，纯兜底）
    三个都不行就返回 False，上层会停下并写进日志，不再继续瞎点。

    为什么以前"点轨道"一次都没动：老代码把点击位置夹在 [GRID_SCROLL_UP_Y+14, GRID_SCROLL_DOWN_Y-14]
    = [232, 754] 里，而滑块顶就是 226、底边能到 752 —— 7 次点击全落在滑块自己身上。
    现在改成"离滑块 60px 以上才算点到空白轨道"，点不到就不点，直接走下一步。
    """
    if not running:
        # 用户按了 F11/F12 / 面板点了停止：立刻撒手，一格都别再滚
        return False, "已停止"
    rng = 整仓滚动范围()
    win = 游戏窗口范围()
    if rng is None or win is None:
        return False, "认不出滑块"
    left, top, _, _ = win
    thumb_len = rng[1] - rng[0]
    travel_top, travel_bot = GRID_THUMB_TOP, max(GRID_THUMB_TOP, GRID_SCROLL_BOTTOM_Y - thumb_len)
    step = max(6, int((travel_bot - travel_top) * step_frac))
    want = rng[0] + (step if down else -step)
    want = max(travel_top, min(travel_bot, want))
    # 滑块换算成"仓里走了几行"：滑块 226~542 这段行程 = 仓里正好 15 行
    _rows_per_px = GRID_SCROLL_ROWS / max(1.0, float(travel_bot - travel_top))

    # 已经贴到头了就别点了 —— 到时候点轨道、拖滑块、点箭头、滚轮四样全是白做，白等两三秒
    if down and rng[0] >= travel_bot - 12:
        return False, "已经到底"
    if (not down) and rng[0] <= travel_top + 12:
        return False, "已经到顶"

    def moved():
        """滑块有没有"真的"移动 ≥12px（≈1/4 行）。

        以前只要动 1 像素就算成功 —— 实测滚轮只会把滑块挪 1px，
        于是每一步都"成功"却原地打转，最后抓了 12 页重复画面（590x4300）。必须要求有意义的位移。
        """
        r = 整仓滚动范围()
        return (r is not None) and (abs(r[0] - rng[0]) >= 12)

    def _log(desc, ok, at=None):
        r = 整仓滚动范围()
        d = (r[0] - rng[0]) if r else 0
        print(
            "🖱️ 翻页[%s]%s：滑块 %d → %s（≈ %+.1f 行）%s"
            % (
                desc,
                "" if at is None else " 鼠标到 (%d, %d)" % at,
                rng[0],
                (r[0] if r else "认不出"),
                d * _rows_per_px,
                "  ✅" if ok else "  ✗",
            )
        )

    # ⓿ 点轨道空白处（点在滑块外面的轨道上，界面会翻一屏；离滑块太近会被当成摸滑块，所以要留 60px）
    _gap = 60
    _ty = (rng[1] + _gap) if down else (rng[0] - _gap)
    _room = (_ty <= GRID_SCROLL_DOWN_Y - 14) if down else (_ty >= GRID_SCROLL_UP_Y + 14)
    if _room:
        _tx = left + GRID_SCROLLBAR_X
        安全点击(_tx, top + int(_ty))
        time.sleep(0.35)
        if moved():
            _log("点轨道", True, (_tx, top + int(_ty)))
            return True, "点轨道"
        _log("点轨道", False, (_tx, top + int(_ty)))

    # ① 拖滑块（实测这个界面**就认拖动**：一拖正好 ~5 行，是唯一能"一小步一小步"走的办法）
    try:
        x = left + GRID_SCROLLBAR_X
        y_from = top + (rng[0] + rng[1]) // 2
        y_to = top + want + thumb_len // 2
        if 后台模式开着吗():
            后台拖动(x, y_from, x, y_to, steps=12, gap=0.03)
        else:
            前台拖拽(x, y_from, x, y_to, steps=12, gap=0.025)
        time.sleep(0.35)
        if moved():
            _log("拖滑块", True, pyautogui.position())
            return True, "拖滑块"
        _log("拖滑块", False, pyautogui.position())
    except Exception as e:
        print(f"⚠️ 取图：拖滑块失败 {e}")
    # ② 点一下 ▲/▼ 箭头（只点一次；实测它是一下跳到底，所以只当兜底）
    sx, sy = left + GRID_SCROLLBAR_X, top + (GRID_SCROLL_DOWN_Y if down else GRID_SCROLL_UP_Y)
    安全点击(sx, sy)
    time.sleep(0.35)
    try:
        cur = pyautogui.position()
    except Exception:
        cur = (-1, -1)
    if moved():
        _log("点%s箭头" % ("▼" if down else "▲"), True, cur)
        return True, "点箭头"
    _log("点%s箭头" % ("▼" if down else "▲"), False, cur)
    # ③ 滚轮（实测只挪 1px，纯兜底）
    cx = left + GRID_BOX[0] + GRID_BOX[2] // 2
    cy = top + GRID_BOX[1] + GRID_BOX[3] // 2
    try:
        if 后台模式开着吗():
            for _ in range(8):
                后台滚轮(cx, cy, -1 if down else 1)
                time.sleep(0.1)
        else:
            for _ in range(8):
                if not 前台滚轮(cx, cy, -6 if down else 6):
                    break
                time.sleep(0.1)
        time.sleep(0.3)
    except Exception as e:
        print(f"⚠️ 取图：滚轮失败 {e}")
    _log("滚轮×8", moved())
    return (moved(), "滚轮")


def 整仓滚到顶():
    """一直往上走，直到滑块不再动（到顶）。返回走过几步。"""
    n = 0
    for _ in range(10):
        if not running:
            break  # 用户按了暂停/彻底停止/面板停止，别再滚了
        r = 整仓滚动范围()
        if r is not None and r[0] <= GRID_THUMB_TOP + 12:
            break  # 已经在最上面了，别再点（省掉一串无意义操作）
        ok, _how = 整仓滚一屏(down=False)
        if not ok:
            break
        n += 1
    return n


# ======================================================================
# 整仓按颜色数每档品质有几块（红块加成要用）。
# 这一整块是本地版本自己加的，更新包里没有 —— 合并时原样搬过来。
# ======================================================================
def 稳定整仓图(max_wait=3.0, tol=1.5):
    """等格子区画面不再变化了再交图。

    滚完立刻截会拍到还在滑的过渡帧（块位置是糊的），数出来就会忽多忽少。
    先给它一点起步时间，再连续比对到画面静止为止。
    """
    try:
        if not running:
            return None  # 已经暂停/停止，连图都别截
        time.sleep(0.25)
        prev = 抓整仓图()
        if prev is None:
            return None
        t0 = time.time()
        while time.time() - t0 < max_wait:
            if not running:
                return None  # 停止/暂停时别在这儿耗着等画面静止
            time.sleep(0.25)
            cur = 抓整仓图()
            if cur is None:
                return prev
            if 图差(prev, cur) <= tol:
                return cur
            prev = cur
        return prev
    except Exception:
        return 抓整仓图()


def 整仓滚了多少():
    """当前滚到第几行，换算成像素。滑块顶端位置线性映射到滚动行数。"""
    try:
        r = 整仓滚动范围()
        if r is None:
            return 0.0
        thumb_len = max(1.0, float(r[1] - r[0]))
        travel_top = float(GRID_THUMB_TOP)
        travel_bot = float(max(GRID_THUMB_TOP, GRID_SCROLL_BOTTOM_Y - thumb_len))
        if travel_bot - travel_top < 8:
            return 0.0
        frac = (float(r[0]) - travel_top) / (travel_bot - travel_top)
        frac = max(0.0, min(1.0, frac))
        return frac * float(GRID_SCROLL_ROWS) * float(GRID_ROW_H)
    except Exception:
        return 0.0


def 整仓到底了吗():
    try:
        r = 整仓滚动范围()
        if r is None:
            return True
        thumb_len = max(1.0, float(r[1] - r[0]))
        travel_bot = float(max(GRID_THUMB_TOP, GRID_SCROLL_BOTTOM_Y - thumb_len))
        return float(r[0]) >= travel_bot - 12
    except Exception:
        return True


def 认品质块(arr, x, y, w, h):
    """一块藏品是什么品质；暗格（还没揭开）返回 None。

    颜色取四个角（中间是藏品图案，会把颜色染乱）。
    """
    try:
        import numpy as np
        import cv2

        if w < 12 or h < 12:
            return None
        sub = arr[y : y + h, x : x + w]
        hh, ww = sub.shape[:2]
        m = max(3, min(hh, ww) // 5)
        pts = np.concatenate(
            [
                sub[:m, :m].reshape(-1, 3),
                sub[:m, -m:].reshape(-1, 3),
                sub[-m:, :m].reshape(-1, 3),
                sub[-m:, -m:].reshape(-1, 3),
            ]
        )
        r, g, b = [float(v) for v in np.median(pts, axis=0)]
        hsv = cv2.cvtColor(np.uint8([[[int(b), int(g), int(r)]]]), cv2.COLOR_BGR2HSV)[0][0]
        H, S, V = int(hsv[0]), int(hsv[1]), int(hsv[2])
        if V < 55:
            return None  # 还没揭开的暗格
        if S < 45:
            return "白"
        if H < 9 or H >= 168:
            return "红"
        if H < 45:
            return "金"
        if H < 90:
            return "绿"
        if H < 135:
            return "蓝"
        return "紫"
    except Exception:
        return None


def 数整仓品质块(img=None, scroll=None):
    """数整仓每档品质各有几块，返回 {'红': 3, '金': 7, ...}。

    大仓一屏放不下，会自动往下滚、一屏屏数到底（滚到哪一行按滑块位置换算），
    跨屏重复的那半块用"绝对纵坐标已经数过"来跳过。
    给了 img 就只数这一张图、不碰界面。
    """
    try:
        import numpy as np

        if img is not None:
            scroll = False
        if scroll is None:
            scroll = True

        pages = []
        scrolled = 0
        if not scroll:
            one = img if img is not None else 稳定整仓图()
            if one is None:
                return {}
            pages.append((0.0, one))
        else:
            整仓滚到顶()
            for _p in range(5):
                if not running:
                    break
                page = 稳定整仓图()
                if page is None:
                    break
                pages.append((整仓滚了多少(), page))
                if 整仓到底了吗():
                    break
                ok, _how = 整仓滚一屏(down=True)
                if not ok:
                    break
                scrolled += 1

        out = {}
        covered = -1e18
        for _i, (off, page) in enumerate(pages, 1):
            arr = np.asarray(page.convert("RGB"))
            _n = 0
            for x, y, w, h in 认格子(page):
                cy_abs = off + y + h / 2.0
                if cy_abs < covered:
                    continue  # 上一屏已经数过这一块
                q = 认品质块(arr, x, y, w, h)
                if q:
                    out[q] = out.get(q, 0) + 1
                    _n += 1
            covered = max(covered, off + float(GRID_BOX[3]))
            if scroll:
                print(f"   · 第 {_i} 屏（滚动 {off:.0f}px）数到 {_n} 块")
        if scrolled:
            # 数完滑回顶部，不让仓停在半截：下一回合开头本就要回顶，提前做掉画面更连贯
            整仓滚到顶()
            歇一下(0.25)
            print(f"🔄 数品质：滚了 {scrolled} 步，共数 {len(pages)} 屏 → {out}")
        return out
    except Exception as e:
        print(f"⚠️ 数品质块失败 {e}")
        return {}


def 金红加价(bid_amount_str, round_num, estimate=None):
    """按仓里红 / 金藏品的块数往上加钱，返回新的出价字符串。

    第 1、2 回合不加：现在第 1 回合不数品质（信息最少，改做仓库视觉识别），
    第 3 回合才数，数据从第 3 回合开始才有。

    估价按每件藏品的最低价算，红档被低估得最狠（中位 25 万），
    金档本身就不值几个钱（中位 2.4 万），所以两边给的份额不一样。
    两个参数都是 0、或者一块都没数到，原样返回。

    加完价必须再守一次 HARD_CAP_MULT（estimate 传估价时才夹）：这个函数在
    ``智能出价`` 之后跑，那道硬顶已经在里面夹过一遍了，以前这里直接
    ``base + extra`` 就返回，第 3 回合起有四成出价被加价顶破硬顶
    （实测 150 次/天，最狠 1,110,260 → 1,310,260，2.00x 变 2.36x）。
    """
    # 第 1、2 回合不参与（还没有数品质的数据）
    try:
        if int(round_num or 0) <= 2:
            return bid_amount_str
    except Exception:
        pass
    # 目标藏品价是独立价（优先级最高），不再叠加金红加价
    try:
        if _SPECIAL_BID_ACTIVE[0]:
            return bid_amount_str
    except Exception:
        pass
    try:
        _red = int(RED_PIECE_BONUS or 0)
        _gold = int(GOLD_PIECE_BONUS or 0)
    except Exception:
        return bid_amount_str
    if (_red <= 0 and _gold <= 0) or not bid_amount_str:
        return bid_amount_str
    try:
        # 同一局只数一次仓：滚屏截图一屏一屏数很慢，加价却每回合都要问。
        # 紧迫危机只有 20 秒，数一次仓要滚 4 次、认 3 屏（实测吃掉 8~10 秒），
        # 数完回合计时已经走完，所以紧迫危机一律不加价，先把价出出去。
        if 快没时间了吗():
            print("⚡ 紧迫危机：跳过金红加价（滚屏太慢，先保证出价）")
            try:
                记回合事件(
                    "urgent_skip_piece_bonus",
                    human="⚡ 紧迫危机跳过金红加价",
                    round=round_num,
                )
            except Exception:
                pass
            return bid_amount_str
        # 慢机器省时模式：金红加价要滚整仓数红/金块（点轨道滚屏 8~10 秒），
        # 这个开关开了就一并跳过，只按普通价出（不叠加金红加价）。
        if 本机很慢吗():
            print("🐢 本机较慢 → 跳过金红加价的数仓，不加价（省时）")
            return bid_amount_str
        _q = 数这一局的仓()
    except Exception:
        _q = {}
    if not isinstance(_q, dict):
        _q = {}
    nred = int(_q.get("红", 0) or 0)
    ngold = int(_q.get("金", 0) or 0)
    if nred <= 0 and ngold <= 0:
        return bid_amount_str
    try:
        base = int(str(bid_amount_str).replace(",", ""))
    except Exception:
        return bid_amount_str
    extra = nred * _red + ngold * _gold
    if extra <= 0:
        return bid_amount_str
    new_value = base + extra
    # 硬顶：加价也要守「估价 × HARD_CAP_MULT」。和 智能出价 里那道同一个口径
    # （第 3 回合起才生效），不然就是两道闸松一道。
    _hard = 0
    try:
        _est = int(estimate or 0)
    except Exception:
        _est = 0
    if _est > 0 and int(round_num or 0) >= 3:
        try:
            _hm = float(HARD_CAP_MULT or 0)
        except Exception:
            _hm = 0.0
        if _hm > 0:
            _hard = int(_est * _hm)
    if _hard > 0 and new_value > _hard:
        # 加价不降价：base 已经是 智能出价 夹过的价，硬顶没有余量就原样留着。
        if _hard > base:
            print(f"🔴 加价后 {new_value:,} 超估价 {_hm:g} 倍硬顶 {_hard:,} → 压回 {_hard:,}")
            new_value = _hard
        else:
            print(f"🔴 估价 {_hm:g} 倍硬顶 {_hard:,} 已无余量 → 这次不加价，保持 {base:,}")
            new_value = base
    _cnt = []
    if nred:
        _cnt.append(f"红 {nred} 块")
    if ngold:
        _cnt.append(f"金 {ngold} 块")
    _txt = " + ".join(_cnt)
    _applied = int(new_value) - int(base)
    if _applied <= 0:
        print(f"🔴 {_txt} → 硬顶已满，这次没加价（保持 {base:,}）")
    elif _applied < extra:
        print(
            f"🔴 {_txt} → 出价加 {_applied:,}（本应 {extra:,}，"
            f"硬顶夹掉 {extra - _applied:,}；{base:,} → {new_value:,}）"
        )
    else:
        print(f"🔴 {_txt} → 出价加 {extra:,}（{base:,} → {new_value:,}）")
    try:
        记回合事件(
            "piece_bonus",
            human=f"🔴 {_txt}，加价 {_applied:,}"
            + (f"（硬顶夹掉 {extra - _applied:,}）" if _applied < extra else ""),
            round=round_num,
            red=nred,
            gold=ngold,
            price=str(new_value),
            bonus_wanted=extra,
            bonus_applied=_applied,
        )
    except Exception:
        pass
    try:
        写日志(f"🔴 {_txt} → 加价 {_applied:,}（{base:,} → {new_value:,}）")
    except Exception:
        pass
    return str(new_value)


def 存抓拍图(img, tag, fmt="png"):
    try:
        ts = datetime.now().strftime("%H%M%S")
        safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(tag))[:40]
        d = 截图目录()
        name = f"{ts}_a{RUNLOG_AUCTION_NO}_{safe}.{'png' if fmt == 'png' else 'jpg'}"
        path = os.path.join(d, name)
        if fmt == "png":
            img.convert("RGB").save(path, "PNG")
        else:
            img.convert("RGB").save(path, "JPEG", quality=CAPTURE_JPEG_QUALITY)
        return name
    except Exception as e:
        print(f"⚠️ 取图：保存失败 {e}")
        return ""


def 滑块换算像素(d):
    """滑块走了 d 像素 ↔ 仓里上下走了多少像素（线性换算）。

    实测：滑块 226→542（316px）正好是仓里 15 行（15×56.6=849px）。
    这条是**数字**，比"拿画面比对自己找接缝"可靠得多 —— 两套一模一样的三连拍，
    画面比对一套接成 1449px、另一套接成 1392px（少一整行）；用滑块算两套都是 1449。
    """
    travel = max(1.0, (GRID_SCROLL_BOTTOM_Y - GRID_THUMB_LEN) - GRID_THUMB_TOP)
    return d * (GRID_SCROLL_ROWS * GRID_ROW_H) / travel


def 整仓条带像素(imgs):
    """右边藏格品面板顶部那条"固定边框"有多高 —— 它不跟着内容滚。

    实测（同一个仓的三张图）：每张最上面 19 行像素完全一样
    （灰度 8,8,29,28,28,29,13,12,13,…），那是面板顶边框，不是仓里的东西。
    翻页拼图时如果照原样贴上去，它正好盖住接缝处的内容、把跨缝的藏品切成两块 ——
    模板库里那些"半截"藏品就是这么来的。所以先量出来，贴的时候跳过它。
    两页开头不一样（量不出）就返回 0，维持老做法。
    """
    try:
        if len(imgs) < 2:
            return 0
        a = np.asarray(imgs[0].convert("L"), dtype=np.float64)
        b = np.asarray(imgs[1].convert("L"), dtype=np.float64)
        n = 0
        for y in range(min(60, a.shape[0], b.shape[0])):
            if abs(a[y] - b[y]).mean() < 4.0:
                n += 1
            else:
                break
        return n if 8 <= n <= 45 else 0
    except Exception:
        return 0


def 页面位置(canvas_gray, page_gray, expect, right_cut=30, band=0):
    """这一页该放在整仓图的哪个 y？在 expect 上下 6 行里找最贴的，返回 (y, 贴合分)。

    为什么要往下多找 6 行：翻到底那一页会被"夹"在底部、和上一页重叠半屏（实测重叠 5 行），
    它的位置会比"按一屏估"早好几行。
    band：这一页顶部有几行是"不跟着滚的固定边框"，比对时要跳过（否则把边框和内容比，白拉低分）。
    """
    best = (int(expect), -1.0)
    for k in range(-6, 3):
        off = int(expect) + int(round(k * GRID_ROW_H))
        if off < 0:
            continue
        a0, b0 = off + band, band
        ov = min(canvas_gray.shape[0] - a0, page_gray.shape[0] - b0)
        if ov < 80:
            continue
        a = canvas_gray[a0 : a0 + ov, 0 : max(1, canvas_gray.shape[1] - right_cut)]
        b = page_gray[b0 : b0 + ov, 0 : max(1, page_gray.shape[1] - right_cut)]
        score = 1.0 - float(np.abs(a.astype(np.float64) - b.astype(np.float64)).mean()) / 40.0
        if score > best[1]:
            best = (off, score)
    return best


def 竖向拼接(imgs, thumbs=None):
    """把"一屏一屏往下翻"的几页接成一张整仓图。返回 (图, 用上了几张)。

    每页放哪儿：**优先用滑块位置算**（thumbs：每页抓图时滑块在哪）。
    滑块读了数字就是准的（实测两套同样的三连拍，滑块 226/436/542）；
    只有滑块没读到，才退回"按一屏 566px 估 + 画面比对 ±6 行"。
    贴的时候跳过每页顶部那条固定边框（见 整仓条带像素），否则接缝处的藏品会被切成两块。
    """
    try:
        from PIL import Image

        if not imgs:
            return None, 0
        W, H = imgs[0].size
        band = 整仓条带像素(imgs)
        canvas_gray = np.asarray(imgs[0].convert("L"), dtype=np.uint8)
        offsets = [0]
        _t0 = thumbs[0] if (thumbs and len(thumbs) == len(imgs) and thumbs[0] > 0) else -1
        for i, cur in enumerate(imgs[1:], start=1):
            off = None
            if _t0 > 0 and thumbs[i] > 0:  # 滑块读数可用 → 直接用数字算
                off = int(round(offsets[0] + 滑块换算像素(thumbs[i] - _t0)))
            if off is None:  # 读数没有 → 老办法（画面比对）
                expect = offsets[-1] + GRID_PAGE_PX
                off, score = 页面位置(
                    canvas_gray, np.asarray(cur.convert("L"), dtype=np.uint8), expect, band=band
                )
                if score < 0.55:
                    off = expect
            need = off + H
            if need > canvas_gray.shape[0]:
                pad = np.full(
                    (need - canvas_gray.shape[0], canvas_gray.shape[1]),
                    int(canvas_gray[-1, :].mean()),
                    dtype=np.uint8,
                )
                canvas_gray = np.vstack([canvas_gray, pad])
            canvas_gray[off + band : off + H, :] = np.asarray(cur.convert("L"), dtype=np.uint8)[
                band:H, :
            ]
            offsets.append(int(off))
        canvas = Image.new("RGB", (W, offsets[-1] + H))
        for i, (img, off) in enumerate(zip(imgs, offsets)):
            rgb = img.convert("RGB")
            if i and band:  # 第 2 页起：顶部固定边框不要贴，留着上一页的内容
                canvas.paste(rgb.crop((0, band, W, H)), (0, off + band))
            else:
                canvas.paste(rgb, (0, off))
        # 面板底部还有一条 18 行的固定边框（实测页内 582~599 三页像素一样）。
        # 上一页的边框头一行会留在接缝上，看过去就是一条 1px 黑线（实测亮度 18.7、旁边 47）。
        # 用上下两行的平均把它抹平 —— 这两行分别是接缝上下两侧的真实内容，抹完接缝就看不出来了。
        if band and len(offsets) > 1:
            cv = np.asarray(canvas).copy()
            for prev in offsets[:-1]:
                yy = int(prev) + int(H) - GRID_FRAME_BOTTOM
                if 0 < yy < cv.shape[0] - 1:
                    cv[yy] = (
                        (cv[yy - 1].astype(np.uint16) + cv[yy + 1].astype(np.uint16)) // 2
                    ).astype(np.uint8)
            canvas = Image.fromarray(cv)
        print(
            "   各页放在 y=%s（= %s 行）%s"
            % (
                offsets,
                [round(o / GRID_ROW_H, 1) for o in offsets],
                "" if not band else "，跳过顶部固定边框 %dpx" % band,
            )
        )
        return canvas, len(imgs)
    except Exception as e:
        print(f"⚠️ 取图：拼图失败 {e}")
        return None, 0


def 认格子(img, min_size=40, bright=75, right_cut=12, drop_empty=True):
    """找出图里每个藏品（比暗底格子亮的一块），返回 [(x, y, w, h), ...]。

    实测：一张对局截图能切出十几个块，尺寸都是格子的整数倍（一个藏品占 1×1 或多格）；
    其中那些"空灰格"（没揭示的格子）是纯灰、几乎没颜色也没花纹，当模板没用，默认丢掉：
    实测空灰格 饱和度 ≤0.05、灰度std ≤22；真有东西的格子 饱和度 ≥0.5，
    或者（白壳那种白东西）灰度std >50 —— 所以规则是「饱和度>0.15 或 灰度std>33」。

    right_cut 25 → 12：25 那把滚动条连它左边的格子一起切了，
    最右一列的藏品因此被削掉 12px、成了"半个"（实测那三页里就有一块 42x53 的碎块）。
    滚动条中心在 x=1887（框内 587），切掉右 12px（578~590）照样能盖住它。
    """
    try:
        import numpy as np
        import cv2

        gray = np.asarray(img.convert("L"), dtype=np.uint8)
        rgb = np.asarray(img.convert("RGB"), dtype=np.float64)
        W = gray.shape[1]
        work = gray.copy()
        if right_cut and W > right_cut:
            work[:, W - right_cut :] = 0
        mask = (work > bright).astype(np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        n, _lab, stats, _cent = cv2.connectedComponentsWithStats(mask, 8)
        out = []
        for i in range(1, n):
            x, y, w, h, _area = (int(v) for v in stats[i])
            if w < min_size or h < min_size:
                continue
            if drop_empty:
                sub = gray[y : y + h, x : x + w].astype(np.float64)
                r = rgb[y : y + h, x : x + w, 0]
                gg = rgb[y : y + h, x : x + w, 1]
                b = rgb[y : y + h, x : x + w, 2]
                mx = np.maximum(np.maximum(r, gg), b)
                mi = np.minimum(np.minimum(r, gg), b)
                sat = float(((mx - mi) / np.maximum(mx, 1.0)).mean())
                if sat < 0.15 and sub.std() < 33:
                    continue
            out.append((x, y, w, h))
        # 同一块藏品的底色可能被中间的图案切成两三块（时钟实测被切成 2 块），
        # 这里把"互相有重叠"的块并成一个（只是挨着但不重叠的，是两块不同的藏品，不动）。
        merged = True
        while merged:
            merged = False
            for i in range(len(out)):
                for j in range(i + 1, len(out)):
                    ax, ay, aw, ah = out[i]
                    bx, by, bw, bh = out[j]
                    ox = min(ax + aw, bx + bw) - max(ax, bx)
                    oy = min(ay + ah, by + bh) - max(ay, by)
                    # 只有"交集面积超过小块一半"才算同一块（原来 6px 就并，
                    # 会把紧挨着的另一件藏品并进来）。
                    inter = max(0, ox) * max(0, oy)
                    if inter > 0.5 * min(aw * ah, bw * bh):
                        out[i] = (
                            min(ax, bx),
                            min(ay, by),
                            max(ax + aw, bx + bw) - min(ax, bx),
                            max(ay + ah, by + bh) - min(ay, by),
                        )
                        out.pop(j)
                        merged = True
                        break
                if merged:
                    break
        out.sort(key=lambda t: (t[1], t[0]))
        return out
    except Exception as e:
        print(f"⚠️ 取图：找格子失败 {e}")
        return []


def 匹配藏品模板(img, min_score=0.80):
    """拿 素材\\item_*.png 去认这张图里有没有认识的藏品，返回 [(名字, 相似度, (x,y)), ...]。

    模板还没攒的时候返回空列表（不报错）—— 以后把切出来的格子命名成
    素材\\item_群友.png / item_高玩.png / item_臭鱼.png 就能直接用了。
    """
    out = []
    try:
        import numpy as np
        import cv2

        names = []
        for d in (os.path.join(SCRIPT_DIR, "素材"), SCRIPT_DIR):
            if os.path.isdir(d):
                names += [
                    os.path.join(d, f)
                    for f in os.listdir(d)
                    if f.lower().startswith("item_") and f.lower().endswith(".png")
                ]
        if not names:
            return out
        big = cv2.cvtColor(np.asarray(img.convert("RGB"))[:, :, ::-1], cv2.COLOR_BGR2GRAY)
        for p in names:
            t = 读图(p)
            if t is None:
                continue
            tg = cv2.cvtColor(t, cv2.COLOR_BGR2GRAY)
            if tg.shape[0] > big.shape[0] or tg.shape[1] > big.shape[1]:
                continue
            res = cv2.matchTemplate(big, tg, cv2.TM_CCOEFF_NORMED)
            _, score, _, loc = cv2.minMaxLoc(res)
            if score >= min_score:
                out.append(
                    (
                        os.path.splitext(os.path.basename(p))[0].replace("item_", ""),
                        round(float(score), 3),
                        (int(loc[0]), int(loc[1])),
                    )
                )
        out.sort(key=lambda t: -t[1])
    except Exception as e:
        print(f"⚠️ 取图：认藏品出错 {e}")
    return out


def 大红截图目录():
    """认到大红时留档的地方：记录\\大红图\\"""
    d = os.path.join(SCRIPT_DIR, "记录", "大红图")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def 存大红截图(chest_img, name, score, extra=""):
    """认到大红就留一张：仓那一块原样存下来，名字和分数写进文件名。"""
    try:
        tag = datetime.now().strftime("%Y%m%d_%H%M%S")
        safe_name = "".join(c for c in str(name) if c not in '\\/:*?"<>|').strip() or "未知"
        fname = "a%d_%s_疑似%s_%03d%s.PNG" % (
            int(RUNLOG_AUCTION_NO or 0),
            tag,
            safe_name,
            int(round(float(score or 0) * 1000)),
            ("_" + extra) if extra else "",
        )
        path = os.path.join(大红截图目录(), fname)
        if hasattr(chest_img, "save"):
            chest_img.save(path)
        else:
            import numpy as np
            import cv2

            arr = np.asarray(chest_img)
            ok, buf = cv2.imencode(".PNG", arr)
            if not ok:
                raise RuntimeError("编码失败")
            buf.tofile(path)  # 中文路径得这么写
        print(f"📸 大红截图已存: {path}")
        return path
    except Exception as e:
        print(f"⚠️ 存大红截图失败: {e}")
        return None


_WHITE_LIST_ENGINE = [None]
_WHITE_LIST_ENGINE_ERROR = [""]


@执行游戏动作
def 抓整个仓(max_pages=None, prepass=True, back_to_top=True):
    """整仓取图：**先空手翻到底**，**再往回翻、一页一页截图**，拼成一张完整仓图（内存里，不存盘）。

    以前是"从上往下翻、翻一页截一页"：新露出来的那几格藏品图案
    还在淡入/加载（实测同一格几秒内从灰底板变成画好的图案），截到的是半成品 ——
    拼进整仓图后模板匹配认不出来，看起来就像"仓里没这件货"。
    现在先翻到底（这一趟把图案全催出来），回程再截：那时候每一格都已经画好了。
    翻页只用**点击**（点轨道 = 翻一屏，实测一屏 = 10 行）；抓完在最上面，不影响后面读估价。
    """
    if 游戏窗口范围() is None:
        return None
    # 先把"窗口在哪、客户区多大、截图多大"记一行。
    # 只要这三样跟坐标对得上（客户区 1920x1080、截图 1920x1080），就能排除"坐标体系不一致"。
    try:
        _w = 游戏窗口范围()
        _s = 抓整仓图()
        print(
            "🔎 取图自检：游戏窗口在屏幕 (%d, %d)、客户区 %dx%d；藏格品截图 %s"
            % (_w[0], _w[1], _w[2], _w[3], (None if _s is None else _s.size))
        )
    except Exception as _e_geo:
        print(f"🔎 取图自检失败: {_e_geo}")
    整仓滚到顶()
    time.sleep(0.3)
    # ① 先翻到底，不截图 —— 这一趟专门把底下藏品的图案"催"出来
    #    结算界面不用这一趟（那时图案早就画好了），传 prepass=False 直接跳过，省 5~10 秒
    if prepass:
        _down = 0
        _how_dn = ""
        for _ in range(12):
            ok, _how_dn = 整仓滚一屏(down=True)
            if not ok:
                break
            _down += 1
        if _down == 0:
            print("⚠️ 取图：藏格品滚不动（%s）→ 只能抓到当前这一屏" % _how_dn)
        else:
            print("⬇️ 取图：先翻到底（%d 步）→ 再往回翻着截图（这时图案都画好了）" % _down)
    # ② 回程：往上翻一屏截一屏
    limit = int(max_pages or CAPTURE_MAX_PAGES)
    imgs = []
    thumbs = []
    for i in range(1, limit + 1):
        img = 抓整仓图()
        if img is None:
            break
        imgs.append(img)
        r = 整仓滚动范围()
        thumbs.append(r[0] if r else -1)
        ok, how = 整仓滚一屏(down=False)
        if not ok:
            break
    if not imgs:
        print("⚠️ 取图：一页都没截到（可能不在拍卖界面）→ 这次抓不到整仓")
        return None
    imgs.reverse()  # 回程是"从下往上"抓的，拼图得反过来（第 0 页是最上面）
    thumbs.reverse()
    if back_to_top:
        整仓滚到顶()
    canvas, used = 竖向拼接(imgs, thumbs)
    if canvas is not None and len(imgs) > 1:
        _cov = min(100.0, canvas.height * 100.0 / GRID_FULL_PX)
        print(
            f"🧩 整仓拼接：{len(imgs)} 页 → {canvas.width}x{canvas.height}"
            f"（整仓应为 {GRID_FULL_PX}px = {GRID_TOTAL_ROWS} 行 + 留白 → 覆盖 {_cov:.0f}%）"
            f"（滑块位置 {thumbs}）"
        )
    return canvas


DOG_GRID_BOX = (1265, 272, 590, 564)  # 1920×1080 客户区里的右侧 10×60 仓库
DOG_GRID_WIDTH = 565  # 去掉右侧滚动条后的有效仓格宽度
DOG_TOTAL_ROWS = 60
DOG_ROW_H = 56.4
DOG_SCROLL_TOP = 7
DOG_SCROLL_BOTTOM = 563


def 狗叫图整仓截图():
    win = 游戏窗口范围()
    if win is None:
        return None
    left, top, width, height = win
    x, y, w, h = DOG_GRID_BOX
    sx = int(round(x * width / 1920.0))
    sy = int(round(y * height / 1080.0))
    sw = int(round(w * width / 1920.0))
    sh = int(round(h * height / 1080.0))
    return 抓一帧(region=(left + sx, top + sy, sw, sh))


def 狗叫图滑块位置(img=None):
    """返回 (滚动条在图内 x, 滑块顶, 滑块底)；只认右侧窄条里的长亮线。"""
    try:
        import numpy as np

        shot = img if img is not None else 狗叫图整仓截图()
        if shot is None:
            return None
        gray = np.asarray(shot.convert("L"), dtype=np.int16)
        best = None
        for cx in range(max(1, gray.shape[1] - 32), gray.shape[1]):
            ys = np.where(gray[:, cx] > 150)[0]
            if len(ys) < 10:
                continue
            start = prev = int(ys[0])
            for raw_y in ys[1:]:
                y = int(raw_y)
                if y - prev > 4:
                    if prev - start >= 20 and (best is None or prev - start > best[2] - best[1]):
                        best = (cx, start, prev)
                    start = y
                prev = y
            if prev - start >= 20 and (best is None or prev - start > best[2] - best[1]):
                best = (cx, start, prev)
        return best
    except Exception:
        return None


def 狗叫图滑块范围(img=None):
    hit = 狗叫图滑块位置(img)
    if hit is None:
        return None
    return (hit[1], hit[2])


def 滚动条置顶(desired_top):
    """拖动右侧滑块，返回拖动后的滑块范围。"""
    shot = 狗叫图整仓截图()
    hit = 狗叫图滑块位置(shot)
    win = 游戏窗口范围()
    if hit is None or win is None:
        return None
    local_x, old_top, old_bottom = hit
    thumb_len = old_bottom - old_top
    target_top = max(DOG_SCROLL_TOP, min(DOG_SCROLL_BOTTOM - thumb_len, int(round(desired_top))))
    left, top, width, height = win
    sx = int(round(DOG_GRID_BOX[0] * width / 1920.0))
    sy = int(round(DOG_GRID_BOX[1] * height / 1080.0))
    scale_y = height / 1080.0
    x = int(round(left + sx + local_x))
    y1 = int(round(top + sy + (old_top + old_bottom) / 2.0))
    y2 = int(round(top + sy + (target_top + thumb_len / 2.0)))
    try:
        if 后台模式开着吗():
            后台拖动(x, y1, x, y2, steps=14, gap=0.025)
        else:
            前台拖拽(x, y1, x, y2, steps=14, gap=0.02)
        time.sleep(0.38)
        now = 狗叫图整仓截图()
        return 狗叫图滑块范围(now)
    except Exception as e:
        print("⚠️ 炫耀家底：拖动仓库滚动条失败 %s" % e)
        return None


def 狗叫图页面偏移(prev_img, cur_img, expected):
    """在两屏的重叠区里找回真实位移，消掉滑块换算的 1～2 像素误差。"""
    try:
        import numpy as np

        prev_g = np.asarray(prev_img.convert("L"), dtype=np.int16)
        cur_g = np.asarray(cur_img.convert("L"), dtype=np.int16)
        h = min(prev_g.shape[0], cur_g.shape[0])
        w = min(538, prev_g.shape[1], cur_g.shape[1])
        expected = int(round(expected))
        best = (expected, None)
        for shift in range(max(24, expected - 16), min(h - 40, expected + 16) + 1):
            overlap = h - shift
            if overlap < 40:
                continue
            a = prev_g[shift : shift + overlap, :w]
            b = cur_g[:overlap, :w]
            diff = float(np.abs(a - b).mean())
            score = diff + abs(shift - expected) * 0.02
            if best[1] is None or score < best[1]:
                best = (shift, score)
        if best[1] is None:
            return expected
        return best[0]
    except Exception:
        return int(round(expected))


def 狗叫图抓完整仓():
    """先翻到底催出图片，再回程逐屏截图，按滑块位置拼成 10×60 整仓图。"""
    first = 狗叫图整仓截图()
    hit = 狗叫图滑块位置(first)
    if hit is None:
        print("❌ 炫耀家底：没有识别到右侧仓库滚动条，请先停留在藏品仓库页面")
        return None

    rng = 滚动条置顶(DOG_SCROLL_TOP)
    if rng is None or abs(rng[0] - DOG_SCROLL_TOP) > 8:
        print("❌ 炫耀家底：仓库没有滚到顶部（请确认游戏窗口可用，且脚本以管理员身份运行）")
        return None
    thumb_len = rng[1] - rng[0]
    travel_bottom = DOG_SCROLL_BOTTOM - thumb_len
    canvas_h = int(round(DOG_TOTAL_ROWS * DOG_ROW_H))
    view_h = DOG_GRID_BOX[3]
    content_travel = max(1, canvas_h - view_h)
    thumb_travel = max(1, travel_bottom - DOG_SCROLL_TOP)

    # 先一路翻到底，让灰格里的藏品图案完成加载；去程不截图。
    cur = rng[0]
    for _ in range(12):
        if cur >= travel_bottom - 3:
            break
        nxt = 滚动条置顶(min(travel_bottom, cur + thumb_travel / 6.0))
        if nxt is None or abs(nxt[0] - cur) < 3:
            break
        cur = nxt[0]
    bottom_rng = 滚动条置顶(DOG_SCROLL_BOTTOM)
    time.sleep(0.55)
    if bottom_rng is None or bottom_rng[0] <= DOG_SCROLL_TOP + 20:
        滚动条置顶(DOG_SCROLL_TOP)
        print("❌ 炫耀家底：仓库滚动条无法拖动（请以管理员身份运行脚本）")
        return None
    travel_bottom = bottom_rng[0]
    thumb_travel = max(1, travel_bottom - DOG_SCROLL_TOP)
    print("⬇️ 炫耀家底：已先翻到底，开始从下往上逐屏截图")

    # 每屏间隔 8 行，始终保留 2 行重叠。固定落点比按比例连续滑更稳，
    # 最后再用画面重叠区校正到像素级；这样换页处不会留水平接缝。
    page_rows = [50, 42, 34, 26, 18, 10, 2, 0]
    pages = []
    for row_start in page_rows:
        target = DOG_SCROLL_TOP + (float(row_start) / max(1, DOG_TOTAL_ROWS - 10) * thumb_travel)
        rng = 滚动条置顶(target)
        if rng is None:
            break
        time.sleep(0.22)
        shot = 狗叫图整仓截图()
        if shot is not None:
            pages.append((shot, row_start, rng[0]))

    if len(pages) < 2:
        滚动条置顶(DOG_SCROLL_TOP)
        print("❌ 炫耀家底：可截图页数不足，仓库滚动没有生效")
        return None

    from PIL import Image

    pages.reverse()  # 回程抓图 → 改成从上到下
    canvas = Image.new("RGB", (DOG_GRID_WIDTH, canvas_h + 1))
    ys = [0]
    expected_prev = 0
    for shot, row_start, _thumb_top in pages[1:]:
        expected_cur = int(round(row_start * DOG_ROW_H))
        shift = 狗叫图页面偏移(pages[len(ys) - 1][0], shot, expected_cur - expected_prev)
        ys.append(ys[-1] + shift)
        expected_prev = expected_cur
    for (shot, _row_start, _thumb_top), y in zip(pages, ys):
        if y >= canvas.height:
            continue
        page = shot.convert("RGB").crop((0, 0, DOG_GRID_WIDTH, view_h))
        if y + view_h > canvas.height:
            page = page.crop((0, 0, DOG_GRID_WIDTH, canvas.height - y))
        canvas.paste(page, (0, y))
    滚动条置顶(DOG_SCROLL_TOP)
    coverage = min(100.0, (max(ys) + view_h) * 100.0 / canvas_h)
    print(
        "🧩 炫耀家底拼接：%d 屏 → %dx%d（覆盖 %.0f%%，各屏 y=%s）"
        % (len(pages), canvas.width, canvas.height, coverage, sorted(ys))
    )
    return canvas


def 生成狗叫图(save_dir=None):
    """一次性生成完整仓库图，并保存到启动脚本所在目录。"""
    if 游戏窗口范围() is None:
        print("❌ 炫耀家底：找不到异环游戏窗口")
        return ""
    print("🐕 炫耀家底：开始完整翻仓…")
    canvas = 狗叫图抓完整仓()
    if canvas is None:
        print("❌ 炫耀家底：翻页或拼接失败，没有生成图片")
        return ""
    try:
        out_dir = os.path.abspath(save_dir or SCRIPT_DIR)
        os.makedirs(out_dir, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        path = os.path.join(out_dir, "炫耀家底_%s.png" % stamp)
        seq = 2
        while os.path.exists(path):
            path = os.path.join(out_dir, "炫耀家底_%s_%d.png" % (stamp, seq))
            seq += 1
        canvas.convert("RGB").save(path, "PNG")
        print("✅ 炫耀家底生成完成：%s" % path)
        print("   图片尺寸：%dx%d，保存目录就是点我启动.bat 所在文件夹" % canvas.size)
        return path
    except Exception as e:
        print("❌ 炫耀家底：保存失败 %s" % e)
        return ""


CHEST_KEEP = 60  # 整仓图只留最近这么多张，免得越攒越多


def 存这一仓(canvas, round_num=0):
    """把拼好的整仓图存一份（人眼/面板都能直接看，不用再从对局截图里找）。

    CHEST_SAVE_ENABLED = 0 时整个不存 —— 这是测试期拿来核对拼接的，
    正式实装不需要往 记录\\整仓图\\ 里堆图。打包时会把它强制成 0。
    """
    if int(CHEST_SAVE_ENABLED or 0) != 1:
        return ""
    try:
        d = os.path.join(RUNLOG_DIR, "整仓图", datetime.now().strftime("%Y-%m-%d"))
        os.makedirs(d, exist_ok=True)
        name = "整仓_%s_a%d_r%s.png" % (
            datetime.now().strftime("%H%M%S"),
            RUNLOG_AUCTION_NO,
            round_num or 0,
        )
        canvas.convert("RGB").save(os.path.join(d, name), "PNG")
        olds = sorted(f for f in os.listdir(d) if f.startswith("整仓_"))
        for f in olds[:-CHEST_KEEP]:
            try:
                os.remove(os.path.join(d, f))
            except Exception:
                pass
        print("🖼️ 整仓图已存：%s" % os.path.join(d, name))
        return os.path.join(d, name)
    except Exception as e:
        print(f"⚠️ 整仓图保存失败（不影响流程）: {e}")
        return ""


def 现在抓(why="手动取图"):
    if CAPTURE_ENABLED != 1:
        return []
    win = 游戏窗口范围()
    if win is None:
        print("⚠️ 取图：找不到游戏窗口")
        return []
    saved = []
    try:
        full = 抓一帧(region=(win[0], win[1], win[2], win[3]))
        n = 存抓拍图(full, "整屏", fmt="jpg")
        if n:
            saved.append(n)
    except Exception as e:
        print(f"⚠️ 取图：截整屏失败 {e}")
    img = 抓整仓图()
    if img is not None:
        n = 存抓拍图(img, "藏品格")
        if n:
            saved.append(n)
    print(f"📷 取图（{why}）：存了 {len(saved)} 张 → {截图目录()}")
    for f in saved:
        print(f"   · {f}")
    if saved:
        记回合事件(
            "capture", human=f"📷 取图 {len(saved)} 张（{why}）", files=saved, dir=截图目录()
        )
    return saved


def 像卖掉了的面板(canvas):
    """这张整仓图是不是"结算界面那批已卖掉的货"（每件上面盖了个粉色的勾）。

    实测那个勾的颜色很特别：R≈248 / G≈70 / B≈142。
    正常仓里的粉猪(R240 G160 B190)、红电话(R230 G60 B70)、紫铃铛(R150 G90 B200) 都沾不上边；
    结算界面是**每件货都盖一个勾**，所以整张仓图上会攒出成片（一个勾 ≈230 像素）。
    按整张图数：中招时 >1500，正常仓（哪怕有几个粉色藏品）顶多几百 —— 取 1000 当界线，并把实测值写进日志。
    """
    try:
        a = np.asarray(canvas.convert("RGB")).astype(np.int16)
        R, G, B = a[:, :, 0], a[:, :, 1], a[:, :, 2]
        m = (R > 235) & (G > 45) & (G < 100) & (B > 120) & (B < 175)
        n = int(m.sum())
        print("🔎 取图自检：结算界面那种粉勾的像素 = %d（超过 1000 就判定截到结算界面了）" % n)
        return n > 1000
    except Exception:
        return False


def 吸附格范围(x, y, w, h, tol=10):
    """把切出来的框对齐到格子边界；对不上就别用（说明这块被切过）。

    藏品的框是"按亮点连通域"找的，而格子边框是暗线，会吃掉几个像素 —— 所以量出来的框
    总比整格小一点点，±10px 以内算正常，直接对齐到格子线上（顺带把模板修得更整齐）。
    超过 10px 就说明这块被截断了（比如跨过拼图接缝、或者贴在最右一列被切掉一截），
    **这种模板永远匹配不上一整件藏品，直接不收**。返回对齐后的 (x, y, w, h) 或 None。
    """
    try:
        c0 = int(round((x - GRID_X0) / GRID_COL_W))
        c1 = int(round((x + w - GRID_X0) / GRID_COL_W))
        r0 = int(round((y - GRID_Y0) / GRID_ROW_H))
        r1 = int(round((y + h - GRID_Y0) / GRID_ROW_H))
        if c1 <= c0 or r1 <= r0 or c0 < 0 or r0 < 0:
            return None
        X = int(round(GRID_X0 + c0 * GRID_COL_W))
        Y = int(round(GRID_Y0 + r0 * GRID_ROW_H))
        W = int(round((c1 - c0) * GRID_COL_W))
        Hh = int(round((r1 - r0) * GRID_ROW_H))
        if abs(X - x) > tol or abs(Y - y) > tol or abs(W - w) > tol or abs(Hh - h) > tol:
            return None
        return (X, Y, W, Hh)
    except Exception:
        return None


def 模板目录():
    r"""藏品模板库：单独一个文件夹，攒够了挑出来命名成 素材\item_xxx.png 就能被认出来。"""
    d = os.path.join(RUNLOG_DIR, "藏品模板")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def 格子底色(img):
    """取方块"四角内侧"的颜色中位数，当它的底色 色相/饱和度。

    原来取的是外圈一圈 —— 但方块的边框是另一层颜色（暗红砖的边框偏粉），
    实测 23 块里只有 1 块能被认成红/金，等于白过滤。改成取四角内侧一小块的中位数之后，
    认出的 8 块跟人眼看到的红/金完全对得上。
    """
    try:
        a = cv2.cvtColor(np.asarray(img.convert("RGB"))[:, :, ::-1], cv2.COLOR_BGR2HSV).astype(
            np.float64
        )
        h, w = a.shape[:2]
        k = max(4, int(min(h, w) * 0.24))
        dy, dx = max(1, int(h * 0.16)), max(1, int(w * 0.16))
        ps = [
            a[dy : dy + k, dx : dx + k],
            a[dy : dy + k, w - dx - k : w - dx],
            a[h - dy - k : h - dy, dx : dx + k],
            a[h - dy - k : h - dy, w - dx - k : w - dx],
        ]
        p = np.concatenate([q.reshape(-1, 3) for q in ps if q.size], 0)
        return float(np.median(p[:, 0])) * 2.0, float(np.median(p[:, 1])) / 255.0
    except Exception:
        return 0.0, 0.0


def 这格要吗(img):
    """是不是"红/金"两档（要留）。紫、蓝、绿、白/灰一律不要。

    实测（42 张对局截图、84 个方块）：红/金方块 饱和度 0.60~0.83、色相 <52 或 >335；
    紫/蓝/绿/白的饱和度要么很低（白灰），要么色相落在 52~335 之间。
    另外还要"里面真有东西"：没揭示的纯色空砖（只有底色、里面啥也没有）当模板没用，也丢掉。
    """
    h, s = 格子底色(img)
    if not (s > TEMPLATE_KEEP_SAT and (h < TEMPLATE_KEEP_HUE[0] or h > TEMPLATE_KEEP_HUE[1])):
        return False
    try:
        g = np.asarray(img.convert("L"), dtype=np.float64)
        hh, ww = g.shape[:2]
        dy, dx = max(1, int(hh * 0.18)), max(1, int(ww * 0.18))
        inner = g[dy : hh - dy, dx : ww - dx]
        if inner.size == 0 or float(inner.std()) < 12:
            return False  # 纯色空砖（没揭示的格子）→ 不要
    except Exception:
        pass
    return True


def 格子指纹(img, size=16):
    """把一块藏品缩成 16x16 归一化指纹；纯色（没内容）的返回 None。

    原来直接拿"整块图（含格子底色和边框）"缩。同一件藏品换一局重抓，
    边框/留白差几个像素，指纹就从 1.00 掉到 0.78~0.92 —— 跟"不同藏品最高 0.919"撞在一起，
    于是同一件被反复当成新藏品存下来（实测一上午多存了 126 张重复照）。
    现在先把"画"抠出来（中值滤背景 → 取最大连通块 → 裁紧）再缩：
    同一件 ≈1.00，不同藏品明显更低，去重才真的管用。
    """
    try:
        a = np.asarray(img.convert("RGB"))
        bg = cv2.medianBlur(np.ascontiguousarray(a), 41)
        d = np.abs(a.astype(np.int16) - bg.astype(np.int16)).max(axis=2)
        mk = cv2.morphologyEx((d > 22).astype(np.uint8), cv2.MORPH_CLOSE, np.ones((5, 5), np.uint8))
        mk = cv2.morphologyEx(mk, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
        n, lab, st, _c = cv2.connectedComponentsWithStats(mk, 8)
        if n >= 2:
            i = max(range(1, n), key=lambda q: st[q][4])
            x, y, w, h = (int(v) for v in st[i][:4])
            if w >= 16 and h >= 16:
                a = a[y : y + h, x : x + w]
        g = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY)
        if float(g.std()) < 8:
            return None
        g = cv2.resize(g, (size, size), interpolation=cv2.INTER_AREA).astype(np.float64)
        return ((g - g.mean()) / (g.std() + 1e-6)).reshape(-1)
    except Exception:
        return None


def 最像的指纹(a, b, rng=1):
    """两张指纹的相似度，允许在指纹上错 1 格（相当于原图错 3~4 像素），取最高。"""
    try:
        A = a.reshape(16, 16)
        best = -1.0
        for dy in range(-rng, rng + 1):
            for dx in range(-rng, rng + 1):
                B = np.roll(np.roll(b.reshape(16, 16), dy, 0), dx, 1)
                v = float((A * B).sum() / (np.linalg.norm(A) * np.linalg.norm(B) + 1e-9))
                if v > best:
                    best = v
        return best
    except Exception:
        return 0.0


_template_fp_cache = {"files": [], "fps": []}
_template_done = [-1]  # 记下"这一局已经采集过了"，同一局不再重复抓


def 读模板指纹():
    """模板库里已有藏品的指纹（库变了才重算）。"""
    d = 模板目录()
    try:
        files = sorted(f for f in os.listdir(d) if f.lower().endswith(".png"))
    except Exception:
        files = []
    if files != _template_fp_cache["files"]:
        fps = []
        for f in files:
            try:
                bgr = 读图(os.path.join(d, f))
                if bgr is None:
                    continue
                g = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
                if float(g.std()) < 8:
                    continue
                g = cv2.resize(g, (16, 16), interpolation=cv2.INTER_AREA).astype(np.float64)
                fps.append(((g - g.mean()) / (g.std() + 1e-6)).reshape(-1))
            except Exception:
                continue
        _template_fp_cache["files"], _template_fp_cache["fps"] = files, fps
    return _template_fp_cache["fps"]


def 收集模板(round_num=0):
    """第 3 回合把整个仓抓齐 → 切出每个方块 → 只留红/金 → 没见过的存进 记录\\藏品模板\\。

    去重靠 16x16 指纹（同一藏品游戏渲染是一模一样的图，实测相似度 1.000；
    不同藏品最高 0.85 上下），阈值 TEMPLATE_DUP_SCORE。返回 (新存的文件, 见过几个, 切出几块)。
    """
    new_files, seen, tiles, cut = [], 0, 0, 0
    canvas = 抓整个仓()  # 里面已经翻页 + 拼接好了
    if canvas is None:
        return new_files, seen, tiles
    if 像卖掉了的面板(canvas):
        print("⚠️ 这一仓看着是结算界面（货上盖着粉色的勾）→ 这一仓不收，避免把结算图当模板")
        return new_files, seen, tiles
    存这一仓(canvas, round_num)
    boxes = [b for b in 认格子(canvas)]
    tiles = len(boxes)
    if not boxes:
        return new_files, seen, tiles
    try:
        hits = 匹配藏品模板(canvas)  # 素材里放了 item_xxx.png 就能顺便认出来
        if hits:
            print("🔍 认出藏品：" + "、".join(f"{n}({s})" for n, s, _ in hits))
    except Exception:
        pass
    d = 模板目录()
    fps = list(读模板指纹())
    try:
        seq = (
            max(
                [int(f[2:6]) for f in os.listdir(d) if f.startswith("藏品") and f[2:6].isdigit()]
                or [0]
            )
            + 1
        )
    except Exception:
        seq = 1
    for x, y, w, h in boxes:
        sb = 吸附格范围(x, y, w, h)
        if sb is None:
            cut += 1
            continue  # 被切过的一块：存了也没用，不收
        x, y, w, h = sb
        box = (x, y, x + w, y + h)  # 已经对齐到格子线，不用再外扩
        tile = canvas.crop(box)
        if not 这格要吗(tile):
            continue  # 紫/蓝/绿/白 直接不管
        fp = 格子指纹(tile)
        if fp is None:
            continue
        if any(最像的指纹(fp, k) >= TEMPLATE_DUP_SCORE for k in fps):
            seen += 1
            continue
        name = "藏品%04d_a%d_r%s.png" % (seq, RUNLOG_AUCTION_NO, round_num or 0)
        try:
            tile.convert("RGB").save(os.path.join(d, name), "PNG")
        except Exception:
            continue
        seq += 1
        fps.append(fp)
        new_files.append(name)
    if cut:
        print("✂️ 藏品模板：有 %d 块被切过（对不上整格），没收进库" % cut)
    if new_files:
        try:
            with io.open(os.path.join(d, "_索引.txt"), "a", encoding="utf-8") as fh:
                fh.write(
                    "%s  第%d局 第%s回合  新增 %d 个：%s\n"
                    % (
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        RUNLOG_AUCTION_NO,
                        round_num or 0,
                        len(new_files),
                        "、".join(new_files),
                    )
                )
        except Exception:
            pass
    return new_files, seen, tiles


def 可能要收模板(round_num):
    """只在设定回合（默认第 3 回合）自动抓一次整仓攒藏品模板。失败不影响流程。"""
    if TEMPLATE_CAPTURE_ENABLED != 1 or int(round_num) != int(TEMPLATE_CAPTURE_ROUND):
        return
    # 同一局只采集一次：实测日志里一局会走到这里 2 次以上，
    # 每次都白花几秒去翻页截图。
    if _template_done[0] == RUNLOG_AUCTION_NO:
        return
    _template_done[0] = RUNLOG_AUCTION_NO
    try:
        new, seen, tiles = 收集模板(round_num)
        if tiles:
            print(
                f"🧩 藏品模板：这一仓切出 {tiles} 块红/金方块，其中 {len(new)} 块是新藏品"
                f"（{seen} 块以前收过）→ {模板目录()}"
            )
            for f in new:
                print(f"   + {f}")
    except Exception as e:
        print(f"⚠️ 藏品模板采集失败（不影响流程）: {e}")


MEM_LOW_WARN_MB = 1500  # 系统可用内存低于这个数，心跳里提醒（2026-11-08 那次 OOM 就是这个信号）


def 记录心跳线程():
    while True:
        try:
            time.sleep(300)
            # 内存：脚本自己的工作集 + 系统还剩多少。
            # 2026-11-08 05:32 那次日志里冒出 OpenCV「分配 16MB 失败」，
            # 事后看不出当时到底是谁把内存吃光了，所以心跳里一直记着。
            _mem = {}
            try:
                import psutil

                _m = psutil.Process().memory_info()
                _mem = {
                    "self_mb": int(_m.rss // 1048576),
                    "private_mb": int(getattr(_m, "private", _m.rss) // 1048576),
                    "sys_avail_mb": int(psutil.virtual_memory().available // 1048576),
                }
            except Exception:
                _mem = {}
            _mem_txt = ""
            if _mem:
                _mem_txt = (
                    f"｜内存 {_mem['self_mb']}MB"
                    f"（系统可用 {_mem['sys_avail_mb']}MB）"
                )
            记回合事件(
                "heartbeat",
                human=(
                    f"💓 心跳：第 {RUNLOG_AUCTION_NO} 局，本局已出价 {len(RUNLOG_ROUNDS)} 次"
                    f"｜累计 成交 {RUNLOG_STATS['won']} / 他人 {RUNLOG_STATS['lost']}"
                    f" / 退出 {RUNLOG_STATS['quit']}｜总收益 {RUNLOG_STATS['profit']:,}"
                    f"｜总成本 {RUNLOG_STATS.get('cost', 0):,}"
                    f"｜净收益 {RUNLOG_STATS.get('net_profit', 0):,}"
                    f"｜脚本运行中={running}" + _mem_txt
                ),
                auction_no=RUNLOG_AUCTION_NO,
                rounds_in_auction=len(RUNLOG_ROUNDS),
                stats=dict(RUNLOG_STATS),
                running=running,
                smart_bidding=BID_AUTO_PRICE,
                memory=_mem,
            )
            if _mem and _mem["sys_avail_mb"] < MEM_LOW_WARN_MB:
                _w = (
                    f"⚠️ 系统可用内存只剩 {_mem['sys_avail_mb']} MB"
                    f"（脚本自己 {_mem['self_mb']} MB），截图和 OCR 可能会分配失败"
                )
                print(_w)
                写日志(_w)
        except Exception:
            pass


_runlog_ended = [False]


def 记录一轮结束(reason="进程退出"):
    if RUNLOG_ON != 1 or _runlog_ended[0]:
        return
    _runlog_ended[0] = True
    try:
        _err_total = sum(ERROR_COUNT.values()) if ERROR_COUNT else 0
        _err_top = sorted(ERROR_COUNT.items(), key=lambda kv: -kv[1])[:5]
        记回合事件(
            "session_end",
            human=(
                f"⏹️ 本次运行结束（{reason}）：共 {RUNLOG_STATS['auctions']} 局，"
                f"我拍到 {RUNLOG_STATS['won']}、他人拍走 {RUNLOG_STATS['lost']}、"
                f"中途退出 {RUNLOG_STATS['quit']}，总收益 {RUNLOG_STATS['profit']:,}，"
                f"总成本 {RUNLOG_STATS.get('cost', 0):,}，"
                f"净收益 {RUNLOG_STATS.get('net_profit', 0):,}｜"
                f"本次运行报错 {_err_total} 条"
                + (("（" + "、".join(f"{k}×{v}" for k, v in _err_top) + "）") if _err_top else "")
            ),
            reason=reason,
            stats=dict(RUNLOG_STATS),
            error_total=_err_total,
            error_kinds=dict(ERROR_COUNT),
        )
    except Exception:
        pass


import atexit as _atexit

if os.environ.get("PAIMAI_SELFTEST") != "1":
    _atexit.register(记录一轮结束)


def 记回合事件(kind, human=None, **fields):
    if RUNLOG_ON != 1:
        return
    try:
        if kind == "round_start":
            报错上下文更新(round=fields.get("round"), estimate=fields.get("value"))
        elif kind == "bid_submitted":
            报错上下文更新(last_bid=fields.get("price_raw"))
        elif kind in ("opponent_bids", "panel_read"):
            报错上下文更新(
                last_panel=fields.get("raw") or fields.get("opponents"),
                last_panel_round=fields.get("round"),
            )
        elif kind in ("exit_low_value", "exit_small_gap"):
            报错上下文更新(last_exit=kind, estimate=fields.get("estimate"))
    except Exception:
        pass
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rec = {"ts": ts, "type": kind, "auction_no": RUNLOG_AUCTION_NO}
    rec.update(fields)
    if human:
        rec["human"] = human
    try:
        with open(RUNLOG_JSONL, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception as exc:
        _提示记录失败("试验记录.jsonl", exc)
    if human:
        try:
            with open(RUNLOG_TXT, "a", encoding="utf-8") as fp:
                fp.write("[{}] {}\n".format(ts, human))
        except Exception as exc:
            _提示记录失败("试验记录.txt", exc)


def 记录新一局():
    global RUNLOG_ROUNDS, RUNLOG_AUCTION_NO, AUCTION_COST, AUCTION_COST_ITEMS, AUCTION_COST_KEYS
    global RUNLOG_SEEN_PRICES, OPPONENT_MAX_SEEN, PREV_ROUND_OPP_MAX, PANEL_BIDS
    global LAST_ESTIMATE
    _AUCTION_FINISHED[0] = False
    _SETTLEMENT_EXIT_FAILS[0] = 0
    RUNLOG_AUCTION_NO += 1
    RUNLOG_ROUNDS = []
    RUNLOG_SEEN_PRICES = []
    _RUNLOG_BID_DECISIONS.clear()
    RUNLOG_OCR.clear()
    AUCTION_COST = 0
    AUCTION_COST_ITEMS = []
    AUCTION_COST_KEYS = set()
    OPPONENT_MAX_SEEN = 0
    PREV_ROUND_OPP_MAX = 0
    PANEL_BIDS = {}
    LAST_ESTIMATE = 0  # 新的一局：估价护栏从头算
    _NO_EXIT_LAST_BID[0] = 0
    _BID_WINDOW_STATE.update(
        urgent=False,
        seconds=None,
        status_text="",
        source="",
        round=0,
        observed_at=0.0,
        auction_no=RUNLOG_AUCTION_NO,
    )
    仓库视觉重置()
    return RUNLOG_AUCTION_NO


def 记一局成本(key, amount, label):
    global AUCTION_COST
    # 撞果盘的局一律不记账（"撞果盘没有任何花费，不要统计成本"）：
    # 撞的那些局本来就不走这里；命中后打完的那一局现在也一起不记（入场费/仪器费都不算）。
    if _GP_BONUS_MODE[0]:
        return
    try:
        amt = int(amount)
    except Exception:
        return
    if amt <= 0 or key in AUCTION_COST_KEYS:
        return
    try:
        AUCTION_COST_KEYS.add(key)
        AUCTION_COST += amt
        AUCTION_COST_ITEMS.append(f"{label} {amt:,}")
    except Exception:
        pass


# ============================================================================
# 分辨率护栏：客户区不是 1920x1080 就说明白 + 响警报（别空转）
# 背景：某晚 21:33 实测，游戏变成「窗口模式 1600x900」后，
# 脚本所有坐标/模板全部错位 → 找不到拍卖大厅，却一直在"等 Enter 图标"里打转。
# ============================================================================
RESOLUTION_EXPECT_W = 1920
RESOLUTION_EXPECT_H = 1080
RESOLUTION_TOL = 4
_RES_GUARD = {"ts": 0.0}
_RES_BAD_STREAK = [0]


def 分辨率对吗(w, h):
    """游戏客户区是不是脚本要的 1920x1080（读不到/bizarre 的值一律当"没问题"，别误拦）。"""
    try:
        return (
            abs(int(w) - RESOLUTION_EXPECT_W) <= RESOLUTION_TOL
            and abs(int(h) - RESOLUTION_EXPECT_H) <= RESOLUTION_TOL
        )
    except Exception:
        return True


def 分辨率守卫(w, h, where="启动自检", force=False):
    """客户区尺寸不对：打印怎么修 + 响警报（120 秒一次，避免刷屏）。返回 True = 尺寸不对。"""
    if 分辨率对吗(w, h):
        return False
    now = time.time()
    if not force and (now - _RES_GUARD["ts"]) < 120:
        return True
    _RES_GUARD["ts"] = now
    print(
        "   ⚠️ 游戏客户区是 %dx%d，脚本按 %dx%d 设计 → 所有坐标和模板都会错位，"
        "找不到拍卖大厅 / 出价面板（%s）" % (w, h, RESOLUTION_EXPECT_W, RESOLUTION_EXPECT_H, where)
    )
    print(
        "      👉 请在游戏里改成 %dx%d：设置 → 画面/显示 → 分辨率选 %d×%d，"
        "显示模式选『全屏』或『无边框窗口』；"
        % (RESOLUTION_EXPECT_W, RESOLUTION_EXPECT_H, RESOLUTION_EXPECT_W, RESOLUTION_EXPECT_H)
    )
    print("         改完点面板【开始挂机】重来一遍就行（不用重开面板）。")
    try:
        写日志(
            "⚠️ 分辨率不对：游戏客户区 %dx%d（脚本要 %dx%d）"
            % (w, h, RESOLUTION_EXPECT_W, RESOLUTION_EXPECT_H)
        )
    except Exception:
        pass
    try:
        异步报警()
    except Exception:
        pass
    return True


def 检查环境():
    """启动自检。返回 False = 客户区尺寸不对（先别跑，等把游戏调成 1920x1080）。"""
    print("🔎 启动自检：")
    _ok_res = True
    try:
        _elev = bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        _elev = False
    if _elev:
        print("   ✅ 以管理员身份运行（点击不会被系统拦）")
    else:
        print(
            "   ⚠️ 不是管理员运行！如果游戏是管理员启动的，脚本的点击会被 Windows 拦掉，"
            "表现为“脚本在跑但游戏没反应”。请关掉脚本，右键『点我启动.bat』→ 以管理员身份运行。"
        )
        记报错(
            "not_elevated",
            "脚本不是以管理员身份运行，点击可能被系统拦掉（游戏若为管理员启动）",
            shot=False,
            throttle=300,
        )
    _bg_want = False
    try:
        _bg_want = int(str(BACKGROUND_RUN).strip() or 0) == 1
    except Exception:
        _bg_want = False
    if _bg_want and not 后台模式开着吗():
        # 面板里开着但没权限：后台模式开着吗() 已经自动退回前台模式了，这里把话说清楚
        print("   🖥 后台模式：面板里是【开】，但脚本没有管理员权限 → 本次自动按【前台模式】跑")
        print("      想用后台模式：用『点我启动.bat』启动，UAC 弹窗点【是】。")
        记报错(
            "bg_need_admin",
            "后台模式已开但脚本不是管理员运行，本次已自动退回前台模式",
            shot=False,
            throttle=300,
        )
    elif 后台模式开着吗():
        print(
            "   🖥 后台模式：开 —— 游戏窗口可以被浏览器等完全盖住，脚本不抢前台、"
            "不会点到你正在用的窗口"
        )
        print("      前提：① 必须管理员运行 ② 游戏窗口不能最小化（用“被别的窗口盖住”代替）")
        print("      代价：异环只认真实鼠标指针位置，所以每次点击指针会闪一下（约 0.1 秒）")
        try:
            后台取色检查()
        except Exception:
            pass
    else:
        print("   🖥 后台模式：关（脚本会像以前一样把游戏窗口拉到最前台来跑）")
    try:
        win = 游戏窗口范围()
        if win is None:
            print(f"   ⚠️ 暂未找到游戏窗口「{WINDOW_TITLE}」，请先打开游戏（找到后会自动继续）")
            记报错(
                "window_missing",
                f"启动自检时找不到游戏窗口「{WINDOW_TITLE}」",
                shot=False,
                throttle=300,
            )
        else:
            w, h = win[2], win[3]
            if 分辨率守卫(w, h, "启动自检", force=True):
                记报错(
                    "resolution_mismatch",
                    f"游戏客户区是 {w}x{h}，脚本按 1920x1080 设计，坐标可能不准"
                    f"（如果这个尺寸像别的窗口，多半是窗口认错了）",
                    shot=False,
                    extra={"w": w, "h": h},
                )
                _ok_res = False
            else:
                print(f"   ✅ 游戏客户区 {w}x{h}（匹配 1920x1080）")
    except Exception as e:
        print(f"   ⚠️ 窗口检测失败: {e}")
        记报错("window_check_fail", f"启动自检窗口检测失败: {e}", exc=e, shot=False)

    if RESTART_ON_STUCK == 1:
        _ar_ok, _ar_info = 重启准备好了()
        if _ar_ok:
            print(
                f"   ✅ 卡死自救已就绪：{int(STUCK_MINUTES)} 分钟没进展就"
                f"自动重开游戏（{_ar_info}）"
            )
        else:
            print(
                f"   ⚠️ 卡死自救开不了：{_ar_info} → 卡住时不会自动重开"
                f"（控制面板 →② 参数 → 流程重启 · 卡死自救 里填）"
            )
    else:
        # 以前这里什么都不打印 → 关掉自救的人根本不知道自己没保险。
        # 实测另一台电脑就因为这个，掉回登录页后干等 1.8 小时。现在明确报出来。
        print(
            "   ⚠️ 卡死自救：关着的 —— 游戏崩了 / 掉回登录页 / 弹窗挡屏时不会自动重开，"
            "会一直干等，直到你发现"
        )
        print("      建议打开：控制面板 →② 参数 →『流程重启 · 卡死自救』→ 卡死自动重启")
        记报错(
            "autorestart_off",
            "卡死自救是关的：卡住时不会自动恢复，可能干等很久没人知道",
            shot=False,
            throttle=600,
        )

    tiers = [
        GATE_666,
        GATE_1680,
        GATE_588,
        GATE_898,
        GATE_280,
        GATE_321,
        GATE_233,
        GATE_179,
    ]
    bad = [(tiers[i], tiers[i + 1]) for i in range(len(tiers) - 1) if tiers[i] <= tiers[i + 1]]
    if bad:
        print(f"   ❌ 价格档位阈值必须严格递减，请检查配置: {bad}")
    else:
        print("   ✅ 价格档位阈值顺序正常（" + " > ".join(f"{t:,}" for t in tiers) + "）")

    needed = [
        "auction_hall.png",
        "login_page.png",
        "enter_icon.png",
        "urban_leisure.png",
        "instant_hammer.png",
        "super_instrument_intro.png",
        "buy_and_use.png",
        "confirm_buy.png",
        "count_0.png",
        "count_1.png",
        "bid_digit_check.png",
        "launcher_start.png",
        "inst_1.png",
        "inst_2.png",
        "inst_3.png",
        "inst_4.png",
        "inst_5.png",
        "inst_close.png",
        "btn_bid.png",
        "btn_confirm.png",
        "step_sell.png",
        "step_exit.png",
        "step_skip.png",
        "step_confirm_high_bid.png",
        "step_esc.png",
        "step_confirm_exit.png",
        "step_confirm_consume.png",
        "step_close_tip.png",
        "step_cancel.png",
        "step_monthly_card.png",
        "venue_dark.png",
        "net_reconnect.png",
        "step1.png",
        "step2.png",
        "step3.png",
        "step4.png",
        "step5.png",
        "step6.png",
        "step7.png",
        "step8.png",
        "num_0.png",
        "num_1.png",
        "num_2.png",
        "num_3.png",
        "num_4.png",
        "num_5.png",
        "num_6.png",
        "num_7.png",
        "num_8.png",
        "num_9.png",
        "num_0000.png",
    ]
    missing = [n for n in needed if not os.path.exists(素材路径(n))]
    if missing:
        print(f"   ❌ 缺少模板素材，相关步骤会失败: {', '.join(missing)}")
        print(
            f"      （把 {len(missing)} 个文件放回 {os.path.join(SCRIPT_DIR, '素材')}\\ 或脚本目录即可）"
        )
        记报错(
            "material_missing",
            f"缺少 {len(missing)} 个模板素材: {', '.join(missing[:10])}"
            + ("…" if len(missing) > 10 else ""),
            shot=False,
            extra={"missing": missing},
        )
    else:
        try:
            _where = os.path.relpath(os.path.dirname(素材路径(needed[0])), SCRIPT_DIR)
            _where = "脚本目录" if _where == "." else _where
        except Exception:
            _where = "脚本目录"
        print(f"   ✅ 模板素材齐全（{len(needed)} 个关键素材，位于 {_where}）")

    try:
        import paddleocr as _po

        print(
            "   ℹ️ 依赖版本: paddleocr={}, cv2={}, numpy={}, python={}".format(
                getattr(_po, "__version__", "?"),
                cv2.__version__,
                np.__version__,
                sys.version.split()[0],
            )
        )
    except Exception as e:
        print(f"   ⚠️ 依赖版本读取失败: {e}")

    # 版本号单独打一行、放最前面也重复打一次：群友发日志常常只截开头，
    # 这行掉了就没法判断他跑的是哪一版。
    print(f"   🏷️ 程序版本: {APP_DISPLAY}")

    if FAILSAFE_ENABLED != 1:
        print("   ℹ️ 鼠标急停保险当前关闭（需要时把 FAILSAFE_ENABLED 改为 1）")

    # 客户区尺寸不对时返回 False：__main__ 里会先不跑（等把游戏调回 1920x1080）
    return _ok_res


WINDOW_TITLE = "异环"
THRESHOLD = 0.85
UI_DELAY = 0.8
ENSURE_FOREGROUND = 1

# ---- 后台模式（面板主界面可开关）------------------------
# 打开后：截图改成直接向游戏窗口要画面、点击改成"把光标挪过去+发窗口消息"，
# 于是游戏窗口可以被浏览器等完全盖住、脚本也不抢前台，你能正常用电脑。
# 两个硬前提（实测得出）：① 必须管理员身份运行；② 游戏窗口不能被最小化。
# 代价：异环是虚幻引擎，只认【真实鼠标指针位置】，所以每次点击指针会闪一下
# （挪过去 → 点 → 挪回来，约 0.1 秒），这是引擎层面绕不开的。
BACKGROUND_RUN = 1  # 1 = 后台模式（面板主界面那个开关）
CURSOR_YIELD_USER = 1  # 用户操作期间，前后台鼠标动作都让行
CURSOR_RESTORE = 1  # 1 = 每次后台点击后把鼠标指针还原到你原来的位置
CURSOR_STEAL_GUARD = 1  # 1 = 防游戏把鼠标吸到屏幕中心（异环后台时会这样）
BACKGROUND_ACTIVATE = 1  # 1 = 点击前给游戏窗口发 WM_ACTIVATE（假激活）
BACKGROUND_GUARD_GAP = 0.02  # 光标保护线程的轮询间隔（秒）

# 点击速度三档（面板主界面可切）：
# 1 = 稳妥：和最早那版前台点击一模一样的节奏（一次约 0.23 秒），最不容易漏点
# 2 = 标准：现在后台在用的节奏（一次约 0.10 秒）【默认】
# 3 = 极速：再快一截（一次约 0.07 秒），仍然留了"发完消息等游戏处理"的安全余量
# 默认改成"标准"（2）
CLICK_SPEED = 2
_CLICK_TIERS = {
    # 档位: (光标挪到位后等待, 按住时长, 弹起后等待, 前台模式的光标滑行时间)
    1: (0.100, 0.050, 0.080, 0.100),
    2: (0.035, 0.020, 0.040, 0.050),
    3: (0.020, 0.012, 0.035, 0.020),
}


def 点击节奏():
    """按档位返回 (挪到位后等待, 按住时长, 弹起后等待, 前台滑行时间)。
    弹起后那段等待不能省：游戏是异步处理点击消息的，等太短会把点击落到
    "光标已经被还回去"的位置上，等于点错地方。"""
    try:
        tier = int(str(CLICK_SPEED).strip() or 2)
    except Exception:
        tier = 2
    return _CLICK_TIERS.get(tier, _CLICK_TIERS[2])


MAX_CRASH_RETRY = 5
ROUND_LOOSE_FALLBACK = 0

BID_PAUSE_SKIP_ENABLED = 1

AUCTION_HALL_IMAGE = "auction_hall.png"
LOGIN_RECOVER_ENABLED = 1
LOGIN_PAGE_IMAGE = "login_page.png"
LOGIN_PAGE_THRESHOLD = 0.70
ENTER_WAIT_CHUNK = 30
LOGIN_BTN_X = 948
LOGIN_BTN_Y = 880
ENTER_ICON_IMAGE = "enter_icon.png"
ENTER_ICON_THRESHOLD = 0.6
URBAN_LEISURE_IMAGE = "urban_leisure.png"
INSTANT_HAMMER_IMAGE = "instant_hammer.png"
LOGIN_MAX_WAIT = 120
AFTER_ENTER_WAIT = 2
URBAN_LEISURE_MAX_WAIT = 10
AFTER_URBAN_WAIT = 1
AFTER_M_CLICK_X1 = 115
AFTER_M_CLICK_Y1 = 968
AFTER_M_CLICK_X2 = 1627
AFTER_M_CLICK_Y2 = 893
AUCTION_HALL_WAIT = 10
SETTLEMENT_HALL_WAIT = 20
SETTLEMENT_HALL_POLL_INTERVAL = 0.35

RESTART_ON_STUCK = 1
LAUNCH_LINK = ""  # 默认留空 → 走「没填」分支，不猜路径；真实值放 参数配置.json
STUCK_MINUTES = 5
RESTART_HOURLY_CAP = 5
LAUNCHER_START_IMAGE = "launcher_start.png"
LAUNCHER_BUTTON_THRESHOLD = 0.70
LAUNCHER_TRIES = 0
LAUNCHER_WAIT_SEC = 30
GAME_BOOT_WAIT_MAX = 300
TITLE_WAIT_MINUTES = 10
TITLE_SCREEN_CHECK_GAP = 2
KILL_GAME_WAIT = 8

WAIT_ON_RECONNECT = 1
RECONNECT_WAIT_MIN = 3
NET_RECONNECT_IMAGE = "net_reconnect.png"
NET_RECONNECT_THRESHOLD = 0.90
NET_RECONNECT_CHECK_INTERVAL = 1.5
_NET_WAIT_FLOOR_SEC = 30

SUPER_INSTRUMENT_INTRO_IMAGE = "super_instrument_intro.png"
BUY_AND_USE_IMAGE = "buy_and_use.png"
CONFIRM_BUY_IMAGE = "confirm_buy.png"
FALLBACK_CLICK_X = 452
FALLBACK_CLICK_Y = 865
FALLBACK_STEP1_CLICK_X = 1281
FALLBACK_STEP1_CLICK_Y = 787
FALLBACK_INTRO_WAIT = 0.5
RETRY_WAIT = 1

COUNT_REGION_LEFT = 315
COUNT_REGION_TOP = 374
COUNT_REGION_RIGHT = 431
COUNT_REGION_BOTTOM = 417
COUNT_0_IMAGE = "count_0.png"
COUNT_1_IMAGE = "count_1.png"
CLOSE_INSTRUMENT_X = 1093
CLOSE_INSTRUMENT_Y = 161

TOOL_R1 = 4
TOOL_R2 = 2
TOOL_R3 = 0
TOOL_R4 = 0
TOOL_R5 = 0
INSTRUMENT_IMAGES = {
    1: "inst_1.png",
    2: "inst_2.png",
    3: "inst_3.png",
    4: "inst_4.png",
    5: "inst_5.png",
}
INSTRUMENT_CLOSE_IMAGE = "inst_close.png"
INSTRUMENT_EFFECT_MIN_WAIT = 0.5   # 大肥鱼：原 1.2
INSTRUMENT_EFFECT_MAX_WAIT = 3.0  # 大肥鱼：原 11
INSTRUMENT_EFFECT_POLL_INTERVAL = 0.3
INSTRUMENT_EFFECT_STABLE_WINDOW = 1.0  # 大肥鱼：原 2.5
INSTRUMENT_FIRST_ROUND_STABLE_WINDOW = 2.0
# 第 3 回合的 2 号仪器会逐件揭示藏品，估价可能在短停顿后又继续上涨。
# 正常回合 2.5 秒；该特殊组合再多等一段（4.0 秒 ≈ 原来的 2.5×1.6），
# 避免把逐件揭示的中间值当成终值。
INSTRUMENT_DETAIL_STABLE_WINDOW = 4.0
INSTRUMENT_DETAIL_MIN_OBSERVE = 1.2
ESTIMATE_POST_SETTLE_WINDOW = 0.8
ESTIMATE_POST_SETTLE_MAX_WAIT = 3.0
INSTRUMENT_NAMES = {
    1: "特殊鉴定仪器",
    2: "超级品鉴仪器",
    3: "超级尺寸仪器",
    4: "超级鉴定仪器",
    5: "金品计数仪器",
}
INSTRUMENT_ROW_Y0 = 281
INSTRUMENT_ROW_STEP = 131.67
INSTRUMENT_ROW_BOX = (0, -46, 780, 92)
INSTRUMENT_LIST_BOX = (0, 150, 800, 760)
# 本局是否真的消耗过仪器（用过一个以上就是 True）。
# 暂停/恢复后回到大厅，如果这个标记还立着，就**不能走"直接匹配"的捷径** ——
# 那条捷径会跳过【一键补全/购买】，于是下一局空着手上场（用户实测的"不补充仪器"）。
_INSTRUMENTS_CONSUMED = [False]

TOOL_PRICES = "50000,10000,10000,10000,20000"
# 当前用的仪器组。面板「快捷设置」里能一键切，切的时候会把 TOOL_PRICES 一起改写。
# 两套组的 2/3/4 号仪器和价格完全一样，只有 1 号（至尊鉴定，10万）和
# 5 号（九格均价，7万）不同，所以现在只用 2/3/4 号的配置换组不影响成本。
INSTRUMENT_GROUP = "SUPER_APPRAISAL"
# 不退出模式（CHASE_TO_END=1）下要不要「绝不降价」。
#   1（默认，和以前行为一致）= 每回合至少按 CHASE_STEP_RATIO 往上递增，绝不回落
#   0 = 允许按智能估价回落（想压价的时候用）
NO_EXIT_NO_DOWNGRADE = 1

# ── 整仓识别（把整仓翻一遍，认出指定藏品；认到了这一回合就不用仪器，省下巨物）──
SCAN_AT_ROUND = 0  # 第几回合整仓识别（0 = 不识别；你现在巨物在第 2 回合）
SCAN_TIMING = 0  # 0 = 用仪器之前识别；1 = 用仪器之后识别
SCAN_ITEM_NAMES = "储钱小哼,万有星仪,绝对是亲手钓的鱼"  # 要认的藏品名，逗号隔开
SCAN_SKIP_TOOL = 0  # 1 = 认到了本回合就不用仪器；0 = 照常用（只记日志）
SCAN_MIN_SCORE = 0.80  # 认出藏品的相似度门槛
SCAN_SCALES = (0.85, 1.0, 1.15)  # 模板缩放比例（同尺寸模板用 1.0 就够，留点余量）
CHEST_SAVE_ENABLED = 0  # 发布包关闭整仓测试存图


def 仪器价目表():
    default = {1: 50000, 2: 10000, 3: 10000, 4: 10000, 5: 20000}
    try:
        raw = str(TOOL_PRICES or "").replace("，", ",").replace(" ", ",")
        nums = [int(float(x)) for x in raw.split(",") if x.strip() != ""]
        if len(nums) >= 5:
            return {i + 1: max(0, nums[i]) for i in range(5)}
    except Exception:
        pass
    return default


# 出价金额校验框（全库 1135 张出价图实测后重新定的）：
# 左边 1050→1090：原来左边那一小条压在【上轮出价】按钮的浅色边上（会被 OCR 当成杂字），
# 切掉后框内只剩"黑底 + 白字"；数字最左也才到 x=1222，左边还留 132px 给更长的金额。
# 上边 745→733：数字最高的一次离框顶只剩 2px，往上留 12px 边，免得把数字顶切掉。
# 下边 825→833：数字最低的一次下沿到过离框顶 53px，往下留一点边；小字那行照样靠"取最高行"丢掉。
# 右边 1450 不动：数字最右只到 1416，还留 34px。
BID_AMOUNT_CHECK_LEFT = 1090
BID_AMOUNT_CHECK_TOP = 733
BID_AMOUNT_CHECK_RIGHT = 1450
BID_AMOUNT_CHECK_BOTTOM = 833
# 读数前先二值化：亮度 > 它 → 纯白，其余 → 纯黑。
# 实测该区域背景亮度仅 2~5、白字为 255，二值化后切分干净，残留灰边一并去除。
BID_AMOUNT_BIN_THRESHOLD = 150
# 估价也照出价金额那套加固：二值化 + 中英双模型 + 读两遍确认；
# 另外加一条铁律 —— **估价只会涨、最多不变（掉下去一定是读错）**，
# 但"一下子涨很多"是正常的（扫到高价值物品），绝不拦。
ESTIMATE_BIN_THRESHOLD = 150  # 估价那块：深底白字，切一刀（实测 40/40 张截图两模型都读得一样）
ESTIMATE_CONFIRM_GAP = 0.5  # 两次读数之间隔多久（和出价金额同一个节奏）
# 估价单遍放行：模板高置信时跳过"第二遍确认"，省一次抓图+识别（约 0.6~0.9 秒）
ESTIMATE_SINGLE_PASS_SCORE = 0.99
ESTIMATE_SINGLE_PASS_MARGIN = 0.10
# 两帧都吻合才使用此门槛，保留对相似数字的差值要求。
ESTIMATE_DOUBLE_TEMPLATE_SCORE = 0.98
ESTIMATE_DOUBLE_TEMPLATE_MARGIN = 0.12
# 资金缓存：资金只会因入场费/结算变化几万块，而决策只在"出价接近资金"时才受它影响，
# 所以同一个读数可以复用这么久（0 = 每次重读）
FUNDS_CACHE_SEC = 60
ESTIMATE_READ_ATTEMPTS = 3  # 一遍最多重读几次
# "估价只涨不跌"要留一点容差：游戏在"用完仪器"那一刻会自己重算，
# 实测会掉 1~2%（10-18 05:23 那局 1,008,154 → 990,876 = -1.7%，被严格规则判成读错、白退一局）。
# 掉超过这个比例才算读错（读丢一位是 -90%，一样拦得住）。
ESTIMATE_MAX_DROP_RATIO = 0.10
CLEAR_BID_X = 980
CLEAR_BID_Y = 964
BID_AMOUNT_RETRY_MAX = 3
READ_TOLERANCE = 0.5
BID_AMOUNT_CONFIRM_GAP = 0.12  # 读到一致后再隔这么久读第二遍，两遍都一致才算通过（读数稳定）
SETTLE_SLOW_WARN_MS = 20000

VALUE_LEFT = 1426
VALUE_TOP = 138
VALUE_RIGHT = 1859
VALUE_BOTTOM = 189

ROUND_LEFT = 811
ROUND_TOP = 153
ROUND_RIGHT = 1028
ROUND_BOTTOM = 205
# 单数字模板只能看“第”和“回”之间的数字，不能把整行中文交给模板切字。
# 坐标相对回合区域；实测 1~5 回合 179 张截图全部可切分。
ROUND_DIGIT_LEFT = 124
ROUND_DIGIT_TOP = 8
ROUND_DIGIT_RIGHT = 146
ROUND_DIGIT_BOTTOM = 44
ROUND_ESTIMATE_MIN_WAIT = 1.2
ROUND_ESTIMATE_POLL_INTERVAL = 0.3
# 估价快读的两遍间隔：隔这么久再截一张，两次读出同一串数字就当已经稳定，
# 不用再干等 STABLE_WINDOW 那 2.5 秒 —— 省下的两秒正好留给竞拍倒计时。
# 复用上面那个 ESTIMATE_CONFIRM_GAP（0.5 秒），不另设：半截估价的坑比这重要。
ROUND_ESTIMATE_MAX_WAIT = 9.0
ROUND_ESTIMATE_STABLE_WINDOW = 2.5
# 第 3 回合有两件情报仪器、逐件揭示，估价会连着涨几次 → 给它更长的稳定窗口和总上限。
ROUND3_ESTIMATE_STABLE_WINDOW = 3.5
ROUND3_ESTIMATE_MAX_WAIT = 11.0

NAME_LEFT = 220
NAME_TOP = 265
NAME_RIGHT = 403
NAME_BOTTOM = 323

FINAL_PRICE_LEFT = 107
FINAL_PRICE_TOP = 448
FINAL_PRICE_RIGHT = 449
FINAL_PRICE_BOTTOM = 581

ACTUAL_VALUE_LEFT = 471
ACTUAL_VALUE_TOP = 437
ACTUAL_VALUE_RIGHT = 803
ACTUAL_VALUE_BOTTOM = 578

PROFIT_LEFT = 851
PROFIT_TOP = 457
PROFIT_RIGHT = 1185
PROFIT_BOTTOM = 575

HIGH_BID_OFFSET_X = 1148
HIGH_BID_OFFSET_Y = 710
HIGH_BID_CONFIRM_VERIFY = 1
RED_DOT_OFFSET_X = 1835
RED_DOT_OFFSET_Y = 810

BID_REGION_LEFT = 375
BID_REGION_TOP = 503
BID_REGION_RIGHT = 1096
BID_REGION_BOTTOM = 1010
BID_DIGIT_CHECK_IMAGE = "bid_digit_check.png"
BID_PANEL_CLOSE_X = 1345
BID_PANEL_CLOSE_Y = 509
BID_KEY_POSITIONS = {
    "0": (1062, 1126),
    "1": (1063, 743),
    "2": (1231, 741),
    "3": (1399, 743),
    "4": (1061, 869),
    "5": (1229, 869),
    "6": (1398, 868),
    "7": (1062, 998),
    "8": (1229, 998),
    "9": (1399, 996),
}

# 新版本场地栏和出价倒计时。均为 1920x1080 客户区坐标。
AUCTION_STATUS_REGION = (680, 900, 560, 120)
BID_TIMER_REGION = (815, 35, 290, 70)
URGENT_CRISIS_MAX_SECONDS = 23
URGENT_CRISIS_ASSUMED_SECONDS = 20
# 紧迫危机还是照常买仪器（仪器是主要情报来源，USR 要求每回合都必须用），
# 只把"等仪器生效"的时间压短，别把 20 秒窗口吃光。
URGENT_SKIP_INSTRUMENT = 0
# 紧迫局 20 秒：仪器照买，但"等它生效"从 6 秒压到 2 秒。
# 原来给 4 秒，实测第1回合读到 15~16 秒、判完紧迫到真正出价要 12~16 秒，
# 一半时间喂给了"开仪器页→点仪器→等生效"这三步。
# 仪器面板本来就比估价快得多，2 秒还没变化基本就是这台仪器不改估价，
# 再等也只是把出价窗口等没，所以压到 2。
URGENT_INSTRUMENT_MAX_WAIT = 2.0
URGENT_INSTRUMENT_MIN_REMAINING = 21
# ── 紧迫危机专用节奏（用户 11-18 定）──
#   每回合：用仪器 → 停 3.3 秒 → 读价 → 直接出价（不识别、不数品质、不读对手）。
#   第 3 回合特殊：停 3.5 秒再读价。
#   用仪器前倒计时不足 10 秒 → 跳过仪器，沿用上轮出价/保底价。
URGENT_READ_WAIT = 3.3
# 普通局（3~5 回合）：用完仪器固定停这么久再读一次估价。
# 以前是"轮询等生效(最多4.5s) + 预算紧张快读 + 尾帧复核" → 同一个数字读三遍。
INSTRUMENT_READ_WAIT_NORMAL = 3.7
URGENT_READ_WAIT_ROUND3 = 3.7
URGENT_SKIP_INSTRUMENT_BELOW = 10.0
# 紧迫危机里等估价：普通局 9 秒、第 3 回合 16 秒，20 秒窗口根本不够。
# 稳定窗口 1.8 秒（再短容易在数字跳变中途被认下），读取上限 6 秒，
# 并且给"读对手出价→算价→找按钮→点数字→确认"留 8 秒。
URGENT_ESTIMATE_STABLE_WINDOW = 1.8
URGENT_ESTIMATE_MAX_WAIT = 4.0
# 留给"读对手出价→算价→找按钮→点数字→确认"的时间。
# 8 → 9 → 10：定位按钮、等面板都按紧迫值给，这边同步放宽，等估价会更早停。
URGENT_BID_RESERVE_SECONDS = 10.0
# 常规局（标准对局/天黑了/加倍/闪耀之心/福利多多）只压上限、不压稳定窗口：
# 日志实测估价要 3.7~3.9 秒才真稳，稳定窗口压到 1.5 秒会在
# 「小吱技能揭示到一半、数字刚好停住」的时候被认下，读到半截估价（45 万 → 实际 90 万）。
FAST_ESTIMATE_STABLE_WINDOW = 2.5
FAST_ESTIMATE_MAX_WAIT = 6.0
URGENT_CRISIS_KEYWORDS = ("紧迫危机", "紧迫")

# ============================================================================
# 低配电脑兼容：按"本机实测速度 + 当前剩余时间"决定要不要降级/放弃这一注
# ----------------------------------------------------------------------------
# 背景：你机器上 28 秒就出完价，低配机器可能只剩十几秒甚至几秒 ——
#       时间不够时与其硬跑把流程拖崩，不如主动少出这一注、等下一回合。
# ============================================================================
LOWSPEC_ENABLED = 1                 # 低配兼容总开关（1 = 开）
LOWSPEC_BID_RESERVE_SEC = 3.0       # 出价后至少还要留这么多秒余量
LOWSPEC_TIGHT_RATIO = 1.6           # 剩余 < 本机出价耗时 × 这个倍数 → 进入省时模式
_SPEED_K = [1.0]                    # 本机速度系数（1.0 = 参考机；越大越慢）
# 低配机优化：机器慢到这个系数以上，就跳过「查举报」「数品质」这类重动作。
# 这两个动作只影响"省点钱/记颜色"，慢机器上花 4~10 秒会把出价窗口吃光。
SLOW_PC_SKIP_HEAVY = 1              # 1 = 跳过查举报/数品质；0 = 照做（开关直控，不再看抓帧速度）
SLOW_PC_K_THRESHOLD = 2.0           # 抓一帧耗时是参考机 2 倍以上 = 慢机器
_BID_COST_EMA = [0.0]               # 本机出价耗时（秒，滑动平均）
_BID_COST_SAMPLES = [0]
MACHINE_SPEED_FILE = os.path.join(RUNLOG_DIR, "机器速度.json")   # 本机速度档案

# 各档位的开口价（估价超过它就进这一档）。
# 注意 GATE_233 和后面的 BIG_LOT_GATE 数值相同（2333333）但用途无关：
# 这里管「分到哪一档」，那边管「算不算大额仓」。改一个不会动另一个，
# 需要两边一致时请分别改，别指望它们联动。
GATE_666 = 20171210
GATE_588 = 11235813
GATE_280 = 5121024
GATE_321 = 3210000
GATE_233 = 2333333
GATE_179 = 1314520          # 永恒之心档（1,314,520）
GATE_898 = 8989898          # 翠刃档（原来是 8,980,000，按游戏内 8,989,898 对齐）
GATE_1680 = 16800000        # 夜光杯档
GATE_1100 = 1100000         # 守望者档（1,100,000）—— 比永恒之心还低一档
GATE_22668 = 22668888       # 金锦鲤雕像档（22,668,888）—— 目前最贵一档


LOW_TIER_OPEN = 1145140
LOW_TIER_R2_MULT = 0.9
LOW_TIER_R3_MULT = 1.2
LOW_TIER_R4_MULT = 1.5
LOW_TIER_R5_MULT = 1.8

TIER_280_OPEN = 2721000
TIER_420_OPEN = 3777777
# 这三档开口价同为 4100000 不是复制粘贴漏改：它们本来就是同一个价位区间，
# 区别在后续回合的倍率（TIER_588_R2_MULT 等）。调价请逐档确认。
TIER_588_OPEN = 4100000
TIER_620_OPEN = 4100000
TIER_666_OPEN = 4100000
# 拍中目标藏品后自动清理仓库（0 = 关；1 = 开）
# 结算页【当前估价】低于这个数 → 勾红圈全卖；高于/等于 → 不勾红圈，回大厅后清仓
# （0 = 关掉这套，行为等同于"总是勾红圈全卖"的老做法）
CLEAN_SELL_ALL_BELOW = 0
# 不进入仓库出售藏品（1 = 打开）：不管结算价多高，都不进仓库清仓卖东西
CLEAN_SKIP_SELL = 0
# 本次结算走的是"留红货 + 回大厅清仓"吗（结算时置位，回大厅消费）
_CLEAN_AFTER_AUCTION = [False]

AUTO_CLEAN_TARGET_ENABLED = 0
# 清仓时红色藏品的弹窗价值低于这个数才卖。
AUTO_CLEAN_MAX_VALUE = 1000000
# 各档「保留藏品」开关：1 = 拍到这档藏品后不卖它（清仓时跳过）
LOW_TIER_KEEP = 0
TIER_1100_KEEP = 0
TIER_233_KEEP = 0
TIER_321_KEEP = 0
TIER_280_KEEP = 0
TIER_420_KEEP = 0
TIER_588_KEEP = 0
TIER_620_KEEP = 0
TIER_666_KEEP = 0
TIER_22668_KEEP = 0

# ============================================================================
# 仓库清理（保留藏品）—— 逻辑搬自 EvilNte，接口换成本脚本自己的
#   ① 保留名单：档位表里每个 *_KEEP 开关 = 这档藏品不卖
#   ② 触发：AUTO_CLEAN_TARGET_ENABLED = 1 且「我拍到 + 命中保留藏品」
#   ③ 判定：warehouse_cleanup.build_sell_plan（认不准的一律保留）
#   ④ 售卖：非红色直接卖，红色核对名称和价值
# 注意：下面 4 个客户端坐标是按 1920×1080 客户区写的，**尚未在本机标定**，
#       干跑（AUTO_CLEAN_DRY_RUN=1）时不会用到；开真卖前必须实测校准。
# ============================================================================
# 结算时按「保留藏品」判定要不要跳过点红点（1 = 开，0 = 只走老的 FAST_SETTLE 阈值）
RED_DOT_SKIP_BY_TARGET = 1
# 最近一局结算里认到的保留藏品（留给"排队清仓"用）
_LAST_TARGET_HITS = []

AUTO_CLEAN_SELL_ENABLED = 0   # 1 = 真的卖（面板「真卖」开关）；0 = 只出计划
AUTO_CLEAN_DRY_RUN = 1                  # 1 = 只扫描出计划、不点出售（默认；先跑通再改 0）
COLLECTION_WAREHOUSE_CLOSE_CLIENT = (1835, 58)
COLLECTION_ITEM_POPUP_CLIENT = (650, 330, 620, 530)
COLLECTION_SELL_ANIMATION_WAIT = 0.5
CLEANUP_DEBUG_DIR = os.path.join(RUNLOG_DIR, "清仓调试")
_CLEANUP_PAGE_CACHE = OrderedDict()

# 只保留、不参与出价的三样藏品（守望者 / 永恒之心 / 乐园巧克力）——
# 用户要求：这三样不再有"特殊首轮价/R2~R5"出价，只在清仓时按「保留」开关决定卖不卖。
KEEP_ONLY_ITEMS = {
    "1100": "守望者",
    "low": "永恒之心",
    "233": "乐园巧克力",
    "YANYUN": "烟云盏",
    "SHOUTI": "古旧手提箱",
}

# 烟云盏 / 古旧手提箱：只保留、不参与出价（清仓保留名单开关）
TIER_YANYUN_KEEP = 0
TIER_SHOUTI_KEEP = 0

# 档位 → 该档对应的藏品名（保留开关就是"这件不卖"）
ITEM_BY_TIER = {
    "321": "家用电影机",
    "280": "超级存储盘",
    "420": "翠刃",
    "588": "碧波天垂",
    "620": "夜光杯",
    "666": "Pendragon模型",
    "22668": "金锦鲤雕像",
}

TIER_233_OPEN = 1888999
TIER_321_OPEN = 2199999
# 新增两档（守望者 / 金锦鲤雕像）：首轮价按同型档位取，倍率统一 1.1（用户定）
TIER_1100_OPEN = 1000000
TIER_1100_R2_MULT = 1.1
TIER_1100_R3_MULT = 1.1
TIER_1100_R4_MULT = 1.1
TIER_1100_R5_MULT = 1.1
TIER_22668_OPEN = 8800000
TIER_22668_R2_MULT = 1.1
TIER_22668_R3_MULT = 1.1
TIER_22668_R4_MULT = 1.1
TIER_22668_R5_MULT = 1.1

TIER_280_R2_MULT = 0.7
TIER_280_R3_MULT = 1.0
TIER_280_R4_MULT = 1.1
TIER_280_R5_MULT = 1.2
TIER_420_R2_MULT = 0.6
TIER_420_R3_MULT = 0.8
TIER_420_R4_MULT = 0.9
TIER_420_R5_MULT = 1.1
TIER_588_R2_MULT = 0.7
TIER_588_R3_MULT = 1.0
TIER_588_R4_MULT = 1.1
TIER_588_R5_MULT = 1.2
TIER_620_R2_MULT = 0.6
TIER_620_R3_MULT = 0.8
TIER_620_R4_MULT = 0.9
TIER_620_R5_MULT = 1.1
TIER_666_R2_MULT = 0.6
TIER_666_R3_MULT = 0.8
TIER_666_R4_MULT = 0.9
TIER_666_R5_MULT = 1.1
TIER_233_R2_MULT = "0.7"
TIER_233_R3_MULT = "0.9"
TIER_233_R4_MULT = "1.1"
TIER_233_R5_MULT = "1.2"
TIER_321_R2_MULT = "0.7"
TIER_321_R3_MULT = "0.9"
TIER_321_R4_MULT = "1.1"
TIER_321_R5_MULT = "1.2"

# 后续回合按估价封顶 = 关。估价只是每件藏品的最低价，
# 出到估价的 1.2~1.8 倍照样是大赚（红档最低 3 万、平均 280 万），封顶等于白让机会。
# 面板上已经不显示它了（想要更狠的封顶，把 HARD_CAP_MULT 填 1.0 就行），
# 常量留着是为了自检里那几条断言还能跑。
TIER_CAP_BY_PRICE = 0

BID_AUTO_PRICE = 1
BID_MODE = "opponent"

# 出价风格：
#   0 = 拿仓模式：第 3 回合起最多可以顶到 min(估价+额度, 估价×1.5)，估价低也一路追
#   1 = 求稳模式：第 3 回合起最多只出到估价，估价低于收手线就退
# 前两回合两种模式完全一样 —— 都照常出开局保底价。
SAFE_MODE = 0

# 求稳模式的超估价上限：第 3~4 回合最多 估价 × 1.2，第 5 回合起放宽到 1.3。
# 拿仓模式不看这两个数。
SAFE_CAP_RATIO = 1.2
SAFE_CAP_RATIO_LATE = 1.3

# 图鉴模式已经删掉 —— "按仓里东西值多少钱出价"这件事改由整仓视觉干
# （WAREHOUSE_VISION_*），更细；面板上那个位置换成了「拍卖辅助」入口，
# 就是去看整仓视觉算出来的结果。

# 超估价硬顶：任何路径算出来的价都不许超过 估价 × 这个数。
# 这是唯一一把刀 —— 原来「追到底 2 倍」和「超价额度 1.5 倍」两条
# 也都在这把刀之外重复夹过一次，默认配置下根本轮不到它们，已经删掉。
# 0 = 关（那就完全按各条路径自己算）。
# 1.5 是按实盘定的：出价 ≤1.5 倍的 172 局净赚 8263 万，
# 超过 1.5 倍的 165 局只赚 361 万，里面 >2 倍的 71 局还是净亏。
HARD_CAP_MULT = 1.5

# 对手溢价闸：第 3 回合起，出价最多比「对手上一轮最高」多这个倍数。
# 实盘 234 局里，我的成交价中位数是对手最高价的 1.43 倍 —— 高出四成。
# 压到 1.3 能省下约 2882 万，压到 1.2 能省 4183 万。0 = 关。
RIVAL_PREMIUM_CAP = 1.3

RIVAL_CAP_RATIO = 1.00
RIVAL_MARGIN = 0.05
INFO_ADVANTAGE_RATIO = 0.8
BAIL_IF_OUTBID = 0
# 出价上限 = 估价 × 这个比例。注意：跟价模式（BID_MODE="opponent"）下，
# 上限在后面会被改写成「估价本身」，也就是 1.0 倍 —— 这个 1.30 只在
# 固定价/档位模式生效。写在这里容易被误读成「跟价模式也出到 1.3 倍」。
BID_CAP_RATIO = 1.30
BID_MARGIN = 0.03
# 最低估价门槛：估价低于它就整局放弃。
# 跟 EXIT_BELOW_PRICE（退出线）管的是同一件事，这里留 0 表示关 ——
# 现在实际由 EXIT_BELOW_PRICE=500000 把关。两个都开也不冲突（谁更严谁生效），
# 但没必要同时开，容易让人以为改了这个会有效果。
MIN_PRICE_GATE = 0
# 最低出价保险：算出来的价低于这个数时抬上来（只抬不压，不突破当轮上限）
MIN_BID_AMOUNT = 200000

# 第 1 回合「先出一半」：估价高于保底价时，不把估价整笔亮出去，只出估价的一半。
# 0 = 关（老样子：按估价向下贴整）；1 = 开。
# 面板上已经不显示这两个了，常量留着给自检用。
ROUND12_HALF_ENABLED = 0
ROUND12_FIRST_HALF_RATIO = 0.5

# 不退出模式的防亏刹车：从第 N 回合起，如果保底链要求的价已经高过估价的这个比例，
# 而且对手根本没在跟（对手参考价低 / 没读到），就别自己抬自己，本局收手。
NO_EXIT_GUARD_ENABLED = 0
NO_EXIT_GUARD_START_ROUND = 3
NO_EXIT_GUARD_MIN_VALUE_RATIO = 0.90
NO_EXIT_GUARD_MAX_OPP_SUPPORT = 1.50

# 仪器必须确认生效：用完仪器后要等估价变了才算成功。
# 只有列在这里的仪器才等（1 号、5 号本来就不改估价，陪它们等是浪费时间）。
INSTRUMENT_EFFECT_REQUIRED = "2,3,4"
# 等不到估价变化时：0 = 记一笔继续读完整估价（默认）；1 = 直接暂停脚本，别拿旧估价出价。
INSTRUMENT_FAILURE_PAUSE = 0

# 前两回合保底价，两种给法：
#   ① 填了 OPENING_PRICE_RANGE（形如 500000-600000）→ 每局在区间里随机一个，
#      尾数自动贴成 …9999。每局开局价都不一样，对面不容易从出价模式认出是脚本。
#   ② 留空 → 用下面这个固定价。
OPENING_PRICE_RANGE = ""
OPENING_PRICE_1 = 599999
# 兼容旧代码/分析脚本的常量名；运行时选出的当前局保底价写在这里。
FLOOR_PRICE_NOW = OPENING_PRICE_1
_AUCTION_FLOOR_BID = [OPENING_PRICE_1]


def 保底价区间():
    """解析 OPENING_PRICE_RANGE；没填、或者写得不像区间 → 返回 None。"""
    raw = str(globals().get("OPENING_PRICE_RANGE", "") or "").strip()
    if not raw:
        return None
    for a, b in (("，", ","), ("~", "-"), ("—", "-"), ("－", "-"), ("到", "-")):
        raw = raw.replace(a, b)
    # 允许写成「50万-60万」「50w-60w」
    raw = raw.replace("万", "0000").replace("w", "0000").replace("W", "0000")
    m = re.fullmatch(r"(\d[\d,]*)\s*-\s*(\d[\d,]*)", raw)
    if not m:
        # 也认「500000，600000」这种逗号分隔（但千分位写法不会走到这儿）
        m = re.fullmatch(r"(\d+)\s*,\s*(\d+)", raw)
    if not m:
        return None
    try:
        lo = int(m.group(1).replace(",", ""))
        hi = int(m.group(2).replace(",", ""))
    except Exception:
        return None
    if lo <= 0 or hi <= 0:
        return None
    return (min(lo, hi), max(lo, hi))


def 区间保底价(lo, hi):
    """在 [lo, hi] 里挑一个 …9999 结尾的价（例：50~60 万 → 509999…599999）。"""
    try:
        lo, hi = int(lo), int(hi)
    except Exception:
        return 0
    cands = []
    v = (lo // 10000) * 10000 + 9999
    while v <= hi:
        if v >= lo:
            cands.append(v)
        v += 10000
    if not cands:
        return lo
    return random.choice(cands)


def 保底价候选():
    """区间没填时用的固定保底价（原来的四个候选已经并成一个）。"""
    try:
        v = int(globals().get("OPENING_PRICE_1") or 0)
    except Exception:
        v = 0
    return [v if v > 0 else 599999]


def 进程内存MB():
    """当前进程占多少内存（MB）。用来盯长跑有没有越吃越多。"""
    try:
        import psutil

        return round(psutil.Process().memory_info().rss / 1048576.0, 1)
    except Exception:
        return 0.0


# 内存超过这个数就自己停手。昨晚跑到 15.5 GB 把整台机拖死过一次，
# 重开一次脚本只要两秒，整机死机要重启十几分钟 —— 怎么算都是停划算。
MEMORY_LIMIT_MB = 2048

# 内存诊断：记下每笔分配的来源（只留 5 层栈，开销小）。
# 平时不统计，只有内存超过 600 MB 才拍快照打日志。
try:
    import tracemalloc as _tracemalloc

    _tracemalloc.start(5)
except Exception:
    pass


def 内存熔断():
    """内存吃太多就停挂机，别把整台电脑拖死。"""
    _m = 进程内存MB()
    if _m <= 0 or _m < MEMORY_LIMIT_MB:
        return False
    msg = (
        f"内存 {_m:.0f} MB 超过上限 {MEMORY_LIMIT_MB} MB → 自动停挂机。"
        f"这版跑久了会堆内存，停一下重新点【开始挂机】就清干净了"
    )
    print("🛑 " + msg)
    try:
        写日志("🛑 " + msg)
        记报错("memory_limit", msg, shot=False)
    except Exception:
        pass
    return True


# ---- 定期重建挂机进程 ----
# 泄漏疑似在 Paddle/OpenCV 的 C++ 层，Python 里找不到、也清不掉。
# 干脆学人家的做法：到点了就在【拍卖大厅】这个安全点把进程镜像换掉，
# Python 堆、Paddle 推理缓存、OpenCV 临时内存全跟着旧进程一起没了。
# 不关游戏、不动窗口，新进程起来接着认大厅。
PROCESS_REBUILD_ENABLED = 1
PROCESS_REBUILD_EVERY_AUCTIONS = 60    # 打满这么多局就洗一次
PROCESS_REBUILD_MEM_MB = 1500          # 内存到这么多才洗（800 太敏感：实测 2 局就到 850MB）
PROCESS_REBUILD_RETRY_SECONDS = 60     # 重建失败后至少隔这么久再试
_PROCESS_REBUILD_LAST_ATTEMPT = [0.0]


def 进程该重建了吗():
    if int(PROCESS_REBUILD_ENABLED or 0) != 1:
        return False
    now = time.time()
    if now - float(_PROCESS_REBUILD_LAST_ATTEMPT[0] or 0.0) < float(
        PROCESS_REBUILD_RETRY_SECONDS or 60
    ):
        return False
    done = int(globals().get("auction_count", 0) or 0)
    if done >= int(PROCESS_REBUILD_EVERY_AUCTIONS or 0):
        return True
    if int(PROCESS_REBUILD_MEM_MB or 0) > 0 and 进程内存MB() >= int(PROCESS_REBUILD_MEM_MB):
        # 先主动回收一次再决定：Paddle/OpenCV 的临时对象回收后经常能降几百 MB
        try:
            import gc
            gc.collect()
        except Exception:
            pass
        _mem2 = 进程内存MB()
        if _mem2 < int(PROCESS_REBUILD_MEM_MB):
            print(f"🧠 内存 {_mem2} MB（回收后）低于阈值 {PROCESS_REBUILD_MEM_MB} MB → 不重建进程")
            return False
        return True
    return False


def 重建挂机进程():
    """在大厅安全点把挂机进程洗一遍。成功就换掉镜像（不会返回），失败返回 False。"""
    if not running or not 进程该重建了吗():
        return False
    _PROCESS_REBUILD_LAST_ATTEMPT[0] = time.time()
    _done = int(globals().get("auction_count", 0) or 0)
    _mem = 进程内存MB()
    msg = f"已完成 {_done} 局、内存 {_mem} MB → 在拍卖大厅重建挂机进程（不关游戏）"
    print("♻️ " + msg)
    try:
        写日志("♻️ " + msg)
        记回合事件(
            "process_rebuild",
            human="♻️ " + msg,
            auctions_completed=_done,
            memory_mb=_mem,
            safe_point="auction_hall",
        )
    except Exception:
        pass
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    try:
        argv = [os.path.abspath(__file__)]
        for arg in sys.argv[1:]:
            if arg != "--auto":
                argv.append(arg)
        if "--auto" not in argv:
            argv.append("--auto")
        # 不 chdir：execv 会沿用当前工作目录，面板启动时就定好了（项目根），
        # 换到别处会让代码里的相对路径（素材 / 记录）全对不上。
        os.execv(sys.executable, [sys.executable] + argv)
    except Exception as exc:
        print(f"⚠️ 进程重建失败，继续当前进程：{exc}")
        try:
            写日志(f"⚠️ 进程重建失败，继续当前进程：{exc}")
        except Exception:
            pass
    return False


def 选保底价():
    """每局开始时随机一次，并在本局后续回合复用同一个保底价。"""
    global FLOOR_PRICE_NOW
    rng = 保底价区间()
    if rng:
        price = 区间保底价(rng[0], rng[1])
        print(f"🎲 开局保底价：{rng[0]:,}~{rng[1]:,} 里随机到 {price:,}")
    else:
        price = int(random.choice(保底价候选()))
    _AUCTION_FLOOR_BID[0] = price
    FLOOR_PRICE_NOW = price
    return price


def 当前保底价():
    """当前局的保底价；未开局时用第一个配置项做安全兜底。"""
    try:
        price = int(_AUCTION_FLOOR_BID[0] or 0)
    except Exception:
        price = 0
    return price if price > 0 else 保底价候选()[0]


# 紧迫危机跳过仪器时，本轮直接出这个价（由 取出价金额 最前面接管）
_URGENT_REUSE_BID = [0]


def 紧迫沿用出价(round_num):
    """沿用本局上一回合的出价；没有（比如第1回合）就用本局的开局保底价。"""
    try:
        prev = int(MY_BIDS.get(int(round_num) - 1) or 0)
    except Exception:
        prev = 0
    if prev > 0:
        print(f"⚡ 紧迫危机：沿用第{int(round_num) - 1}回合的出价 {prev:,}")
        return prev
    try:
        floor = int(当前保底价() or 0)
    except Exception:
        floor = 0
    print(f"⚡ 紧迫危机：没有上轮出价 → 用开局保底价 {floor:,}")
    return floor


_NO_EXIT_LAST_BID = [0]
_BID_WINDOW_STATE = {
    "urgent": False,
    "seconds": None,
    "status_text": "",
    "source": "",
    "round": 0,
    "observed_at": 0.0,
    "auction_no": 0,
}


def 乘完向上取整(price, step):
    """Return ceil(price * step) without floating-point truncation surprises."""
    scaled = float(price) * float(step)
    whole = int(scaled)
    return whole if scaled <= whole + 1e-9 else whole + 1


def 保底价贴整(price):
    """向上贴到最近的 …999，保证规整的同时不跌破倍率目标。"""
    try:
        price = int(price)
    except Exception:
        return price
    if price <= 0:
        return price
    value = price // 1000 * 1000 + 999
    if value < price:
        value += 1000
    return value


def 防亏守卫该停吗(round_num, value, floor_bid, target, opp_ref):
    """不退出模式的防亏刹车：没人抢、又要出到远超估价 → 本局收手。

    只在 NO_EXIT_GUARD_ENABLED=1 时生效；默认关闭（不退出模式要真拍到底，
    提前退出会丢掉结算真值仓的样本）。
    """
    try:
        if int(NO_EXIT_GUARD_ENABLED or 0) != 1:
            return False
        if int(round_num or 0) < int(NO_EXIT_GUARD_START_ROUND or 3):
            return False
        value = int(value or 0)
        floor = int(floor_bid or 0)
        target = int(target or 0)
        opponent = int(opp_ref or 0)
        if target <= 0:
            return False
        if floor > 0 and value < floor:
            return True
        value_too_low = value < int(target * float(NO_EXIT_GUARD_MIN_VALUE_RATIO or 0.9))
        no_opponent_support = (
            opponent <= 0
            or target > int(opponent * float(NO_EXIT_GUARD_MAX_OPP_SUPPORT or 1.5))
        )
        return bool(value_too_low and no_opponent_support)
    except Exception:
        return False


def 保底链要求(round_num):
    """不退出模式的逐回合保底链。

    第 1 回合使用本局随机保底；此后每回合至少比已提交的上一注高
    ``CHASE_STEP_RATIO``。如果上一注没提交成功，仍按开局保底
    连续递增，保证不会在漏一回合后回到低价。
    """
    rnd = max(1, int(round_num or 1))
    try:
        step = max(1.0, float(CHASE_STEP_RATIO or 1.05))
    except Exception:
        step = 1.05
    base = int(当前保底价() or 0)
    nominal = base
    for _ in range(1, rnd):
        nominal = 保底价贴整(乘完向上取整(nominal, step))
    prev = int(_NO_EXIT_LAST_BID[0] or 0)
    try:
        prev = max(prev, int(globals().get("MY_BIDS", {}).get(rnd - 1, 0) or 0))
    except Exception:
        pass
    if rnd > 1 and prev > 0:
        prev_target = 保底价贴整(乘完向上取整(prev, step))
        nominal = max(nominal, prev_target)
    return max(1, int(nominal))


R1_FUNDS_KEEP = 0.02
FLOOR_CAP_BY_PRICE = 0
FLOOR_MIN = 100000
EXIT_BELOW_PRICE = 500000
CHASE_TO_END = 1
CHASE_STEP_RATIO = 1.05
PREMIUM_RATIO = 1.20
TIDY_BID = 1

# 数仓里金 / 红藏品各有几块，每块往上加多少。
# 游戏估价按每件藏品的【最低价】算：红档最低 3 万、中位 25 万、平均 272 万；
# 金档最低 5555、中位 2.4 万、平均 4.85 万 —— 所以红给得多、金给得少。
# 只加不压，估价额度上限照旧。
# 相关函数：数整仓品质块 / 金红加价。
RED_PIECE_BONUS = 50000
GOLD_PIECE_BONUS = 10000

COST_ENTRY_FEE = 20000
COST_TOOL_R1 = 10000
COST_TOOL_R2 = 50000
USE_ROUND2_INSTRUMENT = 1

DARK_VENUE_IMAGE = "venue_dark.png"
DARK_VENUE_REGION = (700, 900, 520, 100)
NIGHT_USE_TIER = 1
NIGHT_CAP_BY_PRICE = 1
DARK_VENUE_USE_FLOOR_BID = 1

# ============================================================================
# ============================================================================
# 仓库清理（保留藏品）—— 干跑：只扫描 + 出计划，不点任何东西
# ============================================================================
def 清仓_保留名单():
    """把档位表里打开的「保留」开关翻成藏品名清单。"""
    names = []
    for tier, name in list((ITEM_BY_TIER or {}).items()) + list((KEEP_ONLY_ITEMS or {}).items()):
        key = "LOW_TIER_KEEP" if tier == "low" else ("TIER_%s_KEEP" % tier)
        try:
            on = int(float(globals().get(key, 0) or 0)) == 1
        except Exception:
            on = False
        if on and name:
            names.append(str(name))
    return names


def 清仓_开关开着吗():
    try:
        return int(float(AUTO_CLEAN_TARGET_ENABLED or 0)) == 1
    except Exception:
        return False


def 结算命中保留藏品(actual_value=0):
    """结算界面里认一遍仓，看有没有「保留名单」里的藏品。

    两路证据：
      ① 出价阶段扫仓的缓存（_WAREHOUSE_VISION_ROUNDS，如果开着整仓视觉）
      ② 结算界面把右侧仓滚完拼成一张长图，再交给识别引擎认名字
    返回命中的藏品名列表；出任何错都返回已拿到的（失败绝不等于"要跳过红点"）。
    """
    global _LAST_TARGET_HITS
    keep = set(清仓_保留名单())
    if not keep:
        return []
    hits = []

    def _add(name):
        name = str(name or "").strip()
        if not name:
            return
        for k in keep:
            if 藏品同名(name, k) and k not in hits:
                hits.append(k)          # 统一成保留名单里的标准名
                return

    # ① 出价阶段的扫描缓存（同一局的仓，对局里已经认过一次就够定论了）
    _scanned_rounds = []
    try:
        for _rnd, scan in sorted((_WAREHOUSE_VISION_ROUNDS or {}).items()):
            if not isinstance(scan, dict):
                continue
            if not (scan.get("items") or scan.get("block_count")):
                continue          # 这一回合没真扫成（跳过/失败）
            _scanned_rounds.append(int(_rnd))
            for row in (scan.get("items") or []):
                _add(row.get("item"))
    except Exception:
        pass

    # 对局中已经成功识别过这批货 → 结果就是定论：
    #   命中就直接结算，没命中就直接判"没有"，**不再扫一遍结算仓**（省 10~20 秒）。
    if _scanned_rounds:
        _LAST_TARGET_HITS = list(hits)
        _rds = "、".join("第%d回合" % r for r in _scanned_rounds)
        if hits:
            print("🧾 结算仓命中（对局中 %s 已认出）：%s" % (_rds, "、".join(hits)))
            try:
                记回合事件(
                    "settlement_target_match",
                    human="🧾 结算仓命中保留藏品：" + "、".join(hits),
                    matched=hits,
                    actual_value=int(actual_value or 0),
                    from_cache=True,
                )
            except Exception:
                pass
        else:
            print("🧾 结算仓：对局中 %s 已识别过，没有命中保留藏品 → 直接判定，不再扫仓" % _rds)
        return list(hits)

    # ①-b 兜底（价格判据）：结算时读到的「实际价值」如果够到某个"保留档位"的门槛，
    #     就按命中处理 —— 这条不依赖对局里的视觉识别是否成功，
    #     实测就靠它才没把 594 万的超级存储盘当普通货点红点卖掉。
    try:
        _av = int(actual_value or 0)
        if _av > 0:
            _tier = 查档位(_av)
            if isinstance(_tier, (tuple, list)):   # 查档位 返回 (档位, 门槛)
                _tier = _tier[0] if _tier else None
            if _tier:
                _keep_key = "LOW_TIER_KEEP" if _tier == "low" else ("TIER_%s_KEEP" % _tier)
                try:
                    _keep_on = int(float(globals().get(_keep_key, 0) or 0)) == 1
                except Exception:
                    _keep_on = False
                if _keep_on:
                    _nm = (ITEM_BY_TIER or {}).get(_tier)
                    if _nm:
                        print(f"🧾 结算兜底：实际价值 {_av:,} 够到保留档位「{_nm}」"
                              f"（{_tier}）→ 判命中，不点红点")
                        _LAST_TARGET_HITS = [_nm]
                        return [_nm]
    except Exception as _ebk:
        print(f"⚠️ 结算兜底判定失败（按未命中继续）: {_ebk}")

    # ② 对局中压根没触发过识别（估价没到门槛/紧迫跳过/提前退出）
    #    → 按用户要求：视为"没有命中"，**不再扫结算仓**。
    #    理由是这批货的构成在对局里已经由估价门槛判断过了，结算再扫一遍纯浪费时间。
    print("🧾 结算仓：对局中没有触发过仓库识别 → 视为未命中保留藏品，不扫仓")
    _LAST_TARGET_HITS = []
    return []

    _LAST_TARGET_HITS = list(hits)
    if hits:
        try:
            记回合事件(
                "settlement_target_match",
                human="🧾 结算仓命中保留藏品：" + "、".join(hits),
                matched=hits,
                actual_value=int(actual_value or 0),
            )
        except Exception:
            pass
    else:
        print("🧾 结算仓：没有命中保留藏品")
    return hits


COLLECTION_HALL_ENTRY_REGION = (0, 620, 1100, 460)   # 大厅里"藏品仓库"入口大致范围
COLLECTION_HALL_ENTRY_FALLBACK = (466, 1005)          # 找不到时按坐标兜底


def 清仓_在藏品仓库吗():
    """真的在「藏品仓库」页吗？

    注意：不能只看"有没有滑块"——拍卖大厅右侧也有滚动条，
    以前就是靠滑块判断，结果站在大厅也被当成"已在仓库"，
    后面直接抓图 → 只抓到 1 页 → 清仓中止（实测踩过）。
    所以先排除大厅画面，再看滑块。
    """
    try:
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            return False
        import collection_capture as _cc
        return _cc.滑块位置(None, 游戏窗口范围, 抓一帧) is not None
    except Exception:
        return False


def 清仓_进仓库():
    """从拍卖大厅进入「藏品仓库」。成功返回 True。"""
    if 清仓_在藏品仓库吗():
        print("🧹 清仓：已经在藏品仓库页")
        return True
    if not 画面有吗(AUCTION_HALL_IMAGE, timeout=2):
        # 有些 UI 状态下大厅模板认不到（被资产条挡住等），但底部「藏品仓库」入口还在 → 也算在大厅
        if not 画面有吗("藏品仓库入口.png", timeout=1):
            print("⚠️ 清仓：当前不在拍卖大厅（也找不到藏品仓库入口）")
            return False
        print("ℹ️ 清仓：大厅模板没认到，但底部有「藏品仓库」入口 → 认为就在大厅")
    clicked = False
    # 入口区域是"客户区相对坐标"，而 找到就点/识别找字并点 要的是"屏幕绝对坐标"，
    # 这里必须先加窗口偏移，否则会跑去屏幕左上角找（实测踩过：永远超时）。
    _win0 = 游戏窗口范围()
    _entry_region = (_win0[0] + COLLECTION_HALL_ENTRY_REGION[0],
                     _win0[1] + COLLECTION_HALL_ENTRY_REGION[1],
                     COLLECTION_HALL_ENTRY_REGION[2],
                     COLLECTION_HALL_ENTRY_REGION[3]) if _win0 else COLLECTION_HALL_ENTRY_REGION
    # ① 整屏（客户区）里找模板：这样匹配坐标天然就是客户区坐标，不用再猜区域偏移。
    try:
        _tpl = 读图片模板("藏品仓库入口.png")
        if _tpl is not None:
            _found, _cx, _cy = 最佳模板匹配(抓灰度图(), _tpl)
            if _found:
                # 模板是"图标+文字"，文字不响应点击 → 往上压 25px 点在图标本体上
                _px = _win0[0] + _cx
                _py_ = _win0[1] + _cy - 25
                print(f"✅ 清仓：找到「藏品仓库」入口 → 点击坐标 ({_px}, {_py_})")
                安全点击(_px, _py_)
                clicked = True
    except Exception as exc:
        print(f"⚠️ 清仓：整屏找入口失败（{exc}）")
    # ①b 区域模板匹配兜底
    if not clicked:
        try:
            if 找到就点("藏品仓库入口.png", "打开藏品仓库", region=_entry_region, timeout=2):
                clicked = True
        except Exception as exc:
            print(f"⚠️ 清仓：模板找入口失败（{exc}）")
    # ② OCR 找字
    if not clicked:
        try:
            clicked = bool(识别找字并点(("藏品仓库",), _entry_region, "打开藏品仓库", retry=2))
        except Exception:
            clicked = False
    # ③ 固定坐标兜底
    if not clicked:
        win = 游戏窗口范围()
        if win is not None:
            print("ℹ️ 清仓：文字/模板都没命中，按固定坐标点入口")
            安全点击(win[0] + COLLECTION_HALL_ENTRY_FALLBACK[0],
                     win[1] + COLLECTION_HALL_ENTRY_FALLBACK[1])
            clicked = True
    if not clicked:
        return False
    if not 歇一下(1.2):
        return False
    if 清仓_在藏品仓库吗():
        print("🧹 清仓：已进入藏品仓库")
        return True
    # 模板是"图标 + 文字"，点中心可能点在文字上（不响应）→ 再往上试图标本体
    _w2 = 游戏窗口范围()
    if _w2 is not None and clicked:
        for _dy in (20, 40, 55):
            print(f"ℹ️ 清仓：入口没反应，试着点图标上方 {_dy}px")
            安全点击(_w2[0] + COLLECTION_HALL_ENTRY_FALLBACK[0],
                     _w2[1] + COLLECTION_HALL_ENTRY_FALLBACK[1] - _dy)
            if not 歇一下(1.0):
                return False
            if 清仓_在藏品仓库吗():
                print("🧹 清仓：已进入藏品仓库")
                return True
    print("⚠️ 清仓：点了入口，但没确认进到藏品仓库")
    return False


def 清仓_出仓库():
    """关掉藏品仓库，回到拍卖大厅。"""
    try:
        if _等鼠标让行结束() != "READY":
            return False
        epoch = _USER_MOUSE_EPOCH
        win = 游戏窗口范围()
        if win is None:
            return False
        if not 清仓_在藏品仓库吗():
            return False
        x, y, _, _ = 清仓_窗口区域(win, (*COLLECTION_WAREHOUSE_CLOSE_CLIENT, 0, 0))
        if 游戏窗口范围() != win or not _按新画面点击(x, y, epoch):
            return False
        if not 歇一下(0.8):
            return False
        for _ in range(10):
            if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
                return True
            if not 歇一下(0.4):
                return False
    except Exception:
        pass
    return False


def 清仓_窗口区域(win, box):
    left, top, width, height = win
    x, y, w, h = box
    return (left + round(x * width / 1920), top + round(y * height / 1080),
            round(w * width / 1920), round(h * height / 1080))


def 清仓_读文字(region, min_confidence=0.80):
    image = 抓一帧(region=region).convert("RGB")
    result = ocr.ocr(cv2.cvtColor(np.asarray(image), cv2.COLOR_RGB2BGR), cls=False)
    lines = []
    for points, (text, confidence) in ((result[0] if result else None) or []):
        if confidence < min_confidence:
            continue
        xs, ys = zip(*points)
        box = (int(min(xs)), int(min(ys)), int(max(xs)) + 1, int(max(ys)) + 1)
        lines.append((str(text).strip(), box))
    return image, lines


def 清仓_文字点击(region, image, box, win, *, verify_boxes=None):
    x0, y0, x1, y1 = box
    if not running or 暂停时等着() in ("STOP", "SKIP") or 游戏窗口范围() != win:
        return False
    if _等鼠标让行结束(check_bid_pause=True) != "READY":
        return False
    epoch = _USER_MOUSE_EPOCH
    current = 抓一帧(region=region).convert("RGB")
    if 游戏窗口范围() != win or any(
        image.crop(check).tobytes() != current.crop(check).tobytes()
        for check in (verify_boxes or [box])
    ):
        return False
    return _按新画面点击(region[0] + (x0 + x1) // 2, region[1] + (y0 + y1) // 2, epoch)


def 清仓_读出售弹窗(region, item_name, wc):
    image, lines = 清仓_读文字(region, min_confidence=0.55)
    parsed = wc.read_sale_labels(lines, image.height, item_name, _规范藏品名)
    if parsed is None:
        print(f"⚠️ 清仓：无法复核弹窗（截图 {image.width}×{image.height}），OCR 文字及坐标 {lines!r}")
        清仓_保存复核图(image, "出售弹窗")
        return image, None, None, None
    value, button, boxes = parsed
    return image, value, button, boxes


def 清仓_保存复核图(image, label):
    try:
        os.makedirs(CLEANUP_DEBUG_DIR, exist_ok=True)
        path = os.path.join(CLEANUP_DEBUG_DIR, f"{label}_{time.time_ns()}.png")
        image.save(path)
        print(f"📸 清仓复核截图：{path}")
    except OSError as exc:
        print(f"⚠️ 清仓：复核截图未保存（{exc}）")


def 清仓_关奖励层():
    if not 多尺度看图有没有(SELL_CLOSE_TIP_IMAGE, timeout=2):
        return False
    if not 多尺度找图并点(SELL_CLOSE_TIP_IMAGE, "关闭藏品出售奖励", timeout=1):
        return False
    return (歇一下(0.35) and not 多尺度看图有没有(SELL_CLOSE_TIP_IMAGE, timeout=0)
            and 清仓_在藏品仓库吗())


def 清仓_执行计划(plan, pages, wc):
    """逐项核对当前位置与弹窗，返回 (已确认出售数, 可安全回大厅)。"""
    import collection_capture as cc

    sold = 0
    saved_mismatches = set()
    for row in plan["sell"]:
        if (not running or 暂停时等着() in ("STOP", "SKIP")
                or _等鼠标让行结束(check_bid_pause=True) != "READY" or not 清仓_在藏品仓库吗()):
            return sold, False
        name = row["item"]
        if any(藏品同名(name, keep) for keep in 清仓_保留名单()):
            print(f"⏭️ 清仓：当前设置保留「{name}」")
            continue
        win = 游戏窗口范围()
        if win is None:
            return sold, False
        epoch = _USER_MOUSE_EPOCH
        page_index = row["page_index"]
        expected = int(plan["page_infos"][page_index]["thumb_top"])
        with _已核对鼠标画面(epoch):
            position = cc.跳滑块(游戏窗口范围, 抓一帧, 安全点击, expected,
                                  drag_fn=_清仓拖拽, tolerance=0.75)
        if not position or position[0] != expected:
            print(f"⚠️ 清仓：未准确回到目标页，跳过「{name}」")
            continue
        x, y = row["local_x"], row["local_y"]
        if not (19 <= x < pages[page_index].width - 19 and 19 <= y < pages[page_index].height - 19):
            print(f"⚠️ 清仓：「{name}」的坐标太靠近页面边缘，跳过")
            continue
        patch = (x - 19, y - 19, x + 20, y + 20)
        shot = cc.抓页图(游戏窗口范围, 抓一帧)
        if shot is None or 游戏窗口范围() != win:
            return sold, False
        reference_page = pages[page_index]
        current_page = cc.归一页(shot)
        page_offset = wc.align_sale_page(reference_page, current_page)
        offset = wc.match_sale_slot(reference_page, current_page, patch, page_offset)
        if offset is None:
            print(f"⚠️ 清仓：第 {page_index + 1} 页格子图像无法复核，跳过「{name}」"
                  f"（坐标 {x},{y}，滑块 {position[0]}，页面偏移 {page_offset}）")
            if page_index not in saved_mismatches:
                清仓_保存复核图(current_page, f"复核第{page_index + 1}页")
                saved_mismatches.add(page_index)
            continue
        dx, dy = offset
        gx, gy, _, _ = cc.DOG_GRID_BOX
        px, py, _, _ = 清仓_窗口区域(win, (
            gx + x + dx, gy - cc.DOG_PAGE_MARGIN_Y + cc.DOG_PAGE_TOP_IN_CAPTURE + y + dy, 0, 0))
        if not _按新画面点击(px, py, epoch):
            print(f"⚠️ 清仓：物品点击未确认，停止本次出售（{name}）")
            return sold, False
        if not 歇一下(0.45) or 游戏窗口范围() != win:
            return sold, False
        region = 清仓_窗口区域(win, COLLECTION_ITEM_POPUP_CLIENT)
        image = 抓一帧(region=region).convert("RGB")
        popup = wc.inspect_sale_popup(image)
        if popup is None:
            print(f"⚠️ 清仓：「{name}」的出售按钮未确认，停止本次出售")
            清仓_保存复核图(image, "品质出售弹窗")
            return sold, False
        button, popup_is_red = popup
        if popup_is_red or row.get("color") in wc.RED_SALE_COLORS:
            image, value, button, boxes = 清仓_读出售弹窗(region, name, wc)
            if value is None:
                print(f"⚠️ 清仓：弹窗未确认「{name}」及其价值，停止本次出售")
                return sold, False
            limit = _热读参数("AUTO_CLEAN_MAX_VALUE", plan["max_item_value"])
            if not 0 < value < limit:
                print(f"⏭️ 清仓：「{name}」价值 {value:,}，达到清仓上限 {limit:,}，停止本次出售")
                return sold, False
        else:
            boxes = [button, (round(image.width * .085), round(image.height * .13),
                              round(image.width * .90), round(image.height * .50))]
        if any(藏品同名(name, keep) for keep in 清仓_保留名单()):
            print(f"⏭️ 清仓：「{name}」现在设为保留，停止本次出售")
            return sold, False
        # 核对画面仍是此前确认过的同一个出售弹窗。
        if not 清仓_文字点击(region, image, button, win, verify_boxes=boxes):
            print(f"⚠️ 清仓：出售前画面变化或点击未确认（{name}）")
            return sold, False
        if not 歇一下(COLLECTION_SELL_ANIMATION_WAIT) or not 清仓_关奖励层():
            print(f"⚠️ 清仓：未确认「{name}」的出售反馈，停止本次出售")
            return sold, False
        # 奖励层关闭后，在同一页正向确认原物品的占用格已空。
        post_scroll = cc.滑块位置(None, 游戏窗口范围, 抓一帧)
        post = cc.抓页图(游戏窗口范围, 抓一帧)
        post_page = cc.归一页(post) if post is not None else None
        post_offset = wc.align_sale_page(current_page, post_page) if post_page is not None else None
        actual_thumb = round(post_scroll[1] * 1080 / win[3]) if post_scroll is not None else None
        if (post_page is None or actual_thumb != expected or 游戏窗口范围() != win
                or not wc.sale_cells_empty(post_page, x + dx, y + dy, row["w"], row["h"],
                                           cc.DOG_ROW_H, offset=post_offset)):
            print(f"⚠️ 清仓：已点击出售，但未确认「{name}」的占用格已空"
                  f"（滑块 {actual_thumb}/{expected}，页面偏移 {post_offset}）")
            if post_page is not None:
                清仓_保存复核图(post_page, f"出售后第{page_index + 1}页")
            return sold, False
        sold += 1
        print(f"🧹 已确认出售：{name}（第 {sold} 件）")
    return sold, True


def 清仓_一键整理():
    win = 游戏窗口范围()
    if win is None or not 清仓_在藏品仓库吗():
        return False
    image, lines = 清仓_读文字(win)
    buttons = [box for text, box in lines if re.sub(r"\s+", "", text) == "一键整理"]
    if len(buttons) != 1 or not 清仓_文字点击(win, image, buttons[0], win):
        print("⚠️ 清仓：未能唯一确认「一键整理」按钮")
        return False
    if not 歇一下(0.5) or 游戏窗口范围() != win or not 清仓_在藏品仓库吗():
        print("⚠️ 清仓：整理点击后未确认仓库画面")
        return False
    _, after = 清仓_读文字(win)
    if not any(re.sub(r"\s+", "", text) == "一键整理" for text, _ in after):
        print("⚠️ 清仓：整理后未确认回到仓库操作界面")
        return False
    print("🧹 清仓：已点击「一键整理」，仓库界面已恢复")
    return True


def _热读参数(key, default=0):
    """清仓/结算这类开关改成**每次用时现读**参数文件，面板一拨就生效，不用重启挂机。"""
    try:
        with open(PARAM_FILE, encoding="utf-8") as fh:
            data = json.load(fh)
        if isinstance(data, dict) and key in data:
            return int(float(data.get(key)))
    except Exception:
        pass
    try:
        return int(float(globals().get(key, default) or default))
    except Exception:
        return int(default)


def _清仓滚轮(cx, cy, n):
    if 后台模式开着吗():
        return 后台滚轮(cx, cy, n)
    # 回顶可快滚，下翻时每次只走一格，避免跳过两页之间的重叠区。
    return 前台滚轮(cx, cy, int(n) * 6 if n > 0 else int(n))


def _清仓拖拽(x1, y1, x2, y2):
    if 后台模式开着吗():
        return 后台拖拽(x1, y1, x2, y2)
    return 前台拖拽(x1, y1, x2, y2)


def _取清仓模块():
    """拿 warehouse_cleanup 模块：先用顶部导入的，没有就按文件路径再加载一次。

    之前只在文件开头 try import，一旦那一次失败（不同启动方式 sys.path 不一样），
    整个清仓就永远显示"缺少 warehouse_cleanup 模块"。
    """
    global warehouse_cleanup
    if warehouse_cleanup is not None:
        return warehouse_cleanup
    try:
        import importlib.util as _ilu
        _p = os.path.join(_HERE, "warehouse_cleanup.py")
        if not os.path.isfile(_p):
            print(f"⚠️ 清仓模块文件不存在：{_p}")
            return None
        _spec = _ilu.spec_from_file_location("warehouse_cleanup", _p)
        _m = _ilu.module_from_spec(_spec)
        _spec.loader.exec_module(_m)
        warehouse_cleanup = _m
        print("🧹 清仓模块已按文件路径补加载成功")
    except Exception as _e:
        print(f"⚠️ 清仓模块加载失败：{_e}")
    return warehouse_cleanup


def 清仓_识别一页(page, info, cc, wv, engine):
    row_offset = int(info["row_start"])
    top = info.get("canvas_y") == 0
    bottom = (info.get("canvas_y", 0) + page.height
              >= round(cc.DOG_TOTAL_ROWS * cc.DOG_ROW_H))
    scroll_start = info.get("scroll_start")
    key = (id(engine.db), page.mode, page.size, hashlib.sha256(page.tobytes()).digest(),
           row_offset, top, bottom, scroll_start, wv.MIN_MATCH_SCORE, cc.DOG_ROW_H, cc.DOG_TOTAL_ROWS)
    if key in _CLEANUP_PAGE_CACHE:
        _CLEANUP_PAGE_CACHE.move_to_end(key)
        return _CLEANUP_PAGE_CACHE[key], True
    rows, _ = wv.recognize_frame(
        page, engine.db, min_match_score=wv.MIN_MATCH_SCORE, known=None,
        row_offset=row_offset, check_phase=False, grid=(0.0, 0.0, cc.DOG_ROW_H),
        refine=True, rows=10, top_edge_complete=top, bottom_edge_complete=bottom,
        total_rows=cc.DOG_TOTAL_ROWS, scroll_start=scroll_start,
    )
    _CLEANUP_PAGE_CACHE[key] = rows
    while len(_CLEANUP_PAGE_CACHE) > 48:
        _CLEANUP_PAGE_CACHE.popitem(last=False)
    return rows, False


def 清仓_识别记录(row, name, page_index):
    return {
        "item": name,
        "color": row.color or "",
        "x": int(row.x),
        "y": int(row.y),
        "w": int(row.w),
        "h": int(row.h),
        "score": round(float(row.score), 4),
        "truncated": bool(row.truncated),
        "partial": bool(row.partial),
        "no_shape": bool(row.no_shape),
        "page_index": page_index,
        "local_x": int(row.click_x),
        "local_y": int(row.click_y),
    }


def 清仓_补拍贴边(candidates, canvas, pages, page_infos, wc, cc, recognize, window_fn):
    if not candidates:
        return []
    thumb_start = page_infos[0]["thumb_top"]
    thumb_travel = page_infos[-1]["thumb_top"] - thumb_start
    content_travel = page_infos[-1]["canvas_y"]
    if thumb_travel <= 0 or content_travel <= 0:
        return []
    window = window_fn()
    epoch = _USER_MOUSE_EPOCH
    recovered = []
    for start, expected_items in candidates:
        if (window is None or 暂停时等着() in ("STOP", "SKIP")
                or window_fn() != window or not 清仓_在藏品仓库吗()):
            break
        target = round(thumb_start + start * cc.DOG_ROW_H * thumb_travel / content_travel)
        with _已核对鼠标画面(epoch):
            position = cc.跳滑块(window_fn, 抓一帧, 安全点击, target,
                                  drag_fn=_清仓拖拽, tolerance=2)
        if position is None:
            continue
        captured = cc._抓扫描页(window_fn, 抓一帧, window, start, position[0], True)
        if captured is None:
            continue
        shot, _, actual = captured
        page = cc.归一页(shot)
        expected_y = (actual - thumb_start) * content_travel / thumb_travel
        canvas_y = wc.locate_supplemental_page(canvas, page, expected_y)
        if canvas_y is None:
            continue
        info = {"row_start": start, "thumb_top": actual, "canvas_y": canvas_y,
                "view_h": page.height, "scroll_start": canvas_y / cc.DOG_ROW_H}
        index = len(pages)
        try:
            rows = recognize(page, info, index)
        except Exception as exc:
            print(f"⚠️ 清仓：贴边补拍识别失败（滑块 {actual}，{exc}）")
            continue
        confirmed = [row for row in rows
                     if not (row["truncated"] or row["partial"] or row["no_shape"])
                     and tuple(row[k] for k in ("item", "x", "y", "w", "h")) in expected_items]
        if not confirmed:
            continue
        pages.append(page)
        page_infos.append(info)
        recovered.extend(confirmed)
        清仓_保存复核图(page, f"贴边补拍第{index + 1}页")
        print("🧹 清仓：贴边补拍确认 " + "、".join(row["item"] for row in confirmed))
    return recovered


def 清仓_扫描并出计划(dry_run=None, confirm_sale=None):
    """抓整仓 → 逐页认物品 → 生成「卖 / 留」计划。

    干跑只扫描和写计划。测试入口可在计划生成后回调确认，再复用本次扫描结果。
    """
    global last_activity_ts
    started = time.monotonic()
    _wc = _取清仓模块()
    if _wc is None:
        print("⚠️ 清仓：缺少 warehouse_cleanup 模块（已尝试按文件路径加载）")
        return None
    if dry_run is None:
        # 面板「真卖」开关为准；没开就只出计划
        try:
            dry_run = int(float(AUTO_CLEAN_SELL_ENABLED or 0)) != 1
        except Exception:
            dry_run = bool(int(AUTO_CLEAN_DRY_RUN or 0))
    _opened_by_us = False
    if not 清仓_在藏品仓库吗():
        if not 清仓_进仓库():
            print("⚠️ 清仓：这次没进到藏品仓库，跳过清仓")
            return None
        _opened_by_us = True
    keep_names = 清仓_保留名单()

    def _清仓规范名(n):
        """把识别出的名字对齐到保留名单里的标准名（存/储、空格等差异都算同一件）。

        之前 build_sell_plan 是严格按字面比对，导致「超级储存盘」对不上「超级存储盘」，
        结果被列进"出售"清单 —— 只靠价格上限兜住，差点把保留藏品卖掉（实测踩过）。
        """
        t = str(n or "").strip()
        for k in keep_names:
            if 藏品同名(t, k):
                return k
        return t
    print("🧹 清仓扫描开始：保留名单 [%s]｜非红色直接卖｜红色单件价值须低于 %s｜%s"
          % ("、".join(keep_names) if keep_names else "（空）",
             format(int(AUTO_CLEAN_MAX_VALUE or 0), ","),
             "干跑（不卖）" if dry_run else "真卖"))

    try:
        import collection_capture as _cc
    except Exception as exc:
        print(f"⚠️ 清仓：collection_capture 不可用（{exc}）")
        return None
    res = None
    scan_started = time.monotonic()
    scan_epoch = _USER_MOUSE_EPOCH
    scan_window = 游戏窗口范围()

    def 扫描窗口():
        轮询面板控件()
        if not running or (CURSOR_YIELD_USER and scan_epoch != _USER_MOUSE_EPOCH):
            return None
        return scan_window if 游戏窗口范围() == scan_window else None

    try:
        with _已核对鼠标画面(scan_epoch):
            res = _cc.分页抓整仓_滚轮(扫描窗口, 抓一帧, _清仓滚轮, require_complete=True)
    except Exception as exc:
        print(f"⚠️ 清仓：滚轮抓图失败（{exc}）")
    if not res and _等鼠标让行结束() == "READY" and 清仓_在藏品仓库吗():
        scan_epoch = _USER_MOUSE_EPOCH
        scan_window = 游戏窗口范围()
        try:
            with _已核对鼠标画面(scan_epoch):
                res = _cc.分页抓整仓(扫描窗口, 抓一帧, 安全点击,
                                      drag_fn=_清仓拖拽, require_complete=True)
        except Exception as exc:
            print(f"⚠️ 清仓：点滑块抓图也失败（{exc}）")
    if not res or 扫描窗口() is None:
        print("⚠️ 清仓：未确认完整扫描，本次不出售")
        if _opened_by_us and running and not 清仓_出仓库():
            print("⚠️ 清仓：扫描中止后未确认回到竞拍大厅")
        return None
    canvas, page_infos, pages = res
    capture_seconds = time.monotonic() - scan_started
    last_activity_ts = time.time()

    try:
        import sys as _sys
        if os.path.join(_HERE, "vision_core") not in _sys.path:
            _sys.path.insert(0, os.path.join(_HERE, "vision_core"))
        import warehouse_vision as _wv
    except Exception as exc:
        print(f"⚠️ 清仓：识别内核加载失败（{exc}）")
        return None
    engine = 取仓库视觉(force=True)
    if engine is None:
        print("⚠️ 清仓：整仓识别引擎不可用")
        return None

    # 把每页也存下来，万一某页识别失败能离线排查
    try:
        os.makedirs(CLEANUP_DEBUG_DIR, exist_ok=True)
        _stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        for _i, _pg in enumerate(pages):
            _pg.convert("RGB").save(
                os.path.join(CLEANUP_DEBUG_DIR, "页%d_%s.png" % (_i + 1, _stamp)), "PNG"
            )
    except Exception:
        pass

    details = []
    keep_unknown = 0
    cache_hits = 0
    recognize_started = time.monotonic()
    for page_index, (page, info) in enumerate(zip(pages, page_infos)):
        if not running or 暂停时等着() in ("STOP", "SKIP"):
            return None
        page_started = time.monotonic()
        try:
            rows, from_cache = 清仓_识别一页(page, info, _cc, _wv, engine)
        except Exception as exc:
            print(f"⚠️ 清仓：第 {page_index + 1} 页识别失败，本次不出售（{exc}）")
            if _opened_by_us and running:
                清仓_出仓库()
            return None
        cache_hits += int(from_cache)
        last_activity_ts = time.time()
        named = 0
        for row in rows:
            name = str(getattr(row, "item_name", "") or "").strip()
            if not name:
                keep_unknown += 1
                continue
            named += 1
            details.append(清仓_识别记录(row, _清仓规范名(name), page_index))
        print(f"🧠 清仓：第 {page_index + 1} 页认出 {len(rows)} 件（具名 {named}），"
              f"{'复用缓存' if from_cache else '重新识别'}，{time.monotonic() - page_started:.2f} 秒")

    def 识别补拍页(page, info, index):
        rows, _ = 清仓_识别一页(page, info, _cc, _wv, engine)
        return [清仓_识别记录(row, _清仓规范名(row.item_name), index)
                for row in rows if row.item_name]

    targets = _wc.supplemental_sale_pages(
        details, round(pages[0].height / _cc.DOG_ROW_H), _cc.DOG_TOTAL_ROWS)
    try:
        details.extend(清仓_补拍贴边(targets, canvas, pages, page_infos, _wc, _cc,
                                   识别补拍页, 扫描窗口))
    except Exception as exc:
        print(f"⚠️ 清仓：贴边补拍未完成（{exc}）")
    if 扫描窗口() is None or 暂停时等着() in ("STOP", "SKIP"):
        print("⚠️ 清仓：扫描结束前窗口或操作状态变化，本次不出售")
        return None
    recognize_seconds = time.monotonic() - recognize_started
    distinct_items, ambiguous = _wc.merge_page_items(details)
    filtered = len(details) - len(distinct_items)
    print(f"🧹 清仓：合并重复或排除不完整记录 {filtered} 条，其中位置冲突 {ambiguous} 组")
    price_by_name = {}
    try:
        for item in engine.db.items:
            _pn = _清仓规范名(str(item.name))
            price_by_name[_pn] = float(getattr(item, "price", 0) or 0)
            price_by_name[str(item.name)] = float(getattr(item, "price", 0) or 0)
    except Exception:
        pass
    sell_rows, keep_rows = _wc.build_sell_plan(
        distinct_items, keep_names, price_by_name=price_by_name
    )
    plan = {
        "dry_run": bool(dry_run),
        "keep_names": keep_names,
        "max_item_value": int(AUTO_CLEAN_MAX_VALUE or 0),
        "pages": len(pages),
        "named_blocks": len(distinct_items),
        "unnamed_blocks": keep_unknown,
        "excluded_or_merged": filtered,
        "cache_hits": cache_hits,
        "capture_seconds": round(capture_seconds, 3),
        "recognize_seconds": round(recognize_seconds, 3),
        "sell_count": len(sell_rows),
        "keep_count": len(keep_rows),
        "sell": sell_rows,
        "keep": keep_rows,
        "page_infos": page_infos,
        "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }
    try:
        os.makedirs(CLEANUP_DEBUG_DIR, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        plan_path = os.path.join(CLEANUP_DEBUG_DIR, "清仓计划_%s.json" % stamp)
        with open(plan_path, "w", encoding="utf-8") as fh:
            json.dump(plan, fh, ensure_ascii=False, indent=2)
        try:
            canvas.convert("RGB").save(os.path.join(CLEANUP_DEBUG_DIR, "整仓_%s.png" % stamp), "PNG")
        except Exception:
            pass
        print("🧹 清仓计划已写出：%s" % plan_path)
    except Exception as exc:
        print(f"⚠️ 清仓：写计划文件失败 {exc}")
    print("🧹 清仓计划：%d 页 / 认出 %d 件（另有 %d 件认不出→保留）→ 计划出售 %d 件、保留 %d 件"
          % (len(pages), len(distinct_items), keep_unknown, len(sell_rows), len(keep_rows)))
    for row in sell_rows[:12]:
        print("     · 卖 %-14s 参考价 %s" % (row.get("item") or "?", format(int(row.get("catalog_price") or 0), ",")))
    if len(sell_rows) > 12:
        print("     · …另有 %d 件" % (len(sell_rows) - 12))
    sold = 0
    organized = False
    warehouse_ready = True
    action_started = time.monotonic()
    if confirm_sale is not None:
        dry_run = not sell_rows or not confirm_sale(plan)
        plan["dry_run"] = dry_run
    if not dry_run and sell_rows:
        try:
            sold, warehouse_ready = 清仓_执行计划(plan, pages, _wc)
            if warehouse_ready and sold == len(sell_rows):
                organized = 清仓_一键整理()
                warehouse_ready = organized
            else:
                print(f"ℹ️ 清仓：确认出售 {sold}/{len(sell_rows)} 件，跳过「一键整理」")
        except Exception as exc:
            warehouse_ready = False
            print(f"⚠️ 清仓：执行出错，已停止后续点击（{exc}）")
    if warehouse_ready and running and (_opened_by_us or organized):
        if not 清仓_出仓库():
            print("⚠️ 清仓：未确认回到竞拍大厅")
    print(f"⏱️ 清仓：抓图 {capture_seconds:.2f} 秒，识别 {recognize_seconds:.2f} 秒"
          f"（缓存 {cache_hits}/{len(pages)} 页），执行与返回 {time.monotonic() - action_started:.2f} 秒，"
          f"合计 {time.monotonic() - started:.2f} 秒")
    plan["confirmed_sold"] = sold
    plan["organized"] = organized
    try:
        记回合事件("cleanup_plan",
                   human="🧹 清仓计划：卖 %d / 留 %d（%s）" % (len(sell_rows), len(keep_rows), "干跑" if dry_run else "真卖"),
                   sell_count=len(sell_rows), keep_count=len(keep_rows), dry_run=bool(dry_run),
                   keep_names=keep_names, confirmed_sold=sold, organized=organized,
                   cache_hits=cache_hits, recognize_seconds=round(recognize_seconds, 3))
    except Exception:
        pass
    return plan


# 自动撞果盘（独立功能：面板第⑥页【自动撞果盘】，配置+开关都在一起）
# 干什么：按【北京时间】每分钟第 ENTER_AT_SECOND 秒点一次【开始匹配】→ 进局后看场地效果
# ① 场地效果 = 福利多多，且左边玩家名字命中数 ≥ WAIT_NAME_MIN
# → 不退出对局 + 响警报 + 把挂机停下来（停在这个局里，等你手动玩）
# ② 其它情况（不是福利多多 / 名字不够 / 没认出来）→ 退出对局，等下一个整分钟的 X 秒再来
# 不影响正常流程：只有面板点了【启动撞果盘】（写 记录\_面板_撞果盘.flag = 1）才走这套；
# 开关是关的（或文件不存在）时，主循环和以前一模一样。
# ============================================================================
NTP_TIME_SOURCE = 1  # 1 = 联网校时（北京时间，不看本机时间准不准）；0 = 直接用本机时间
ENTER_AT_SECOND = (
    ""  # 每分钟的第几秒点【开始匹配】（例：20 → xx:xx:20；**0/留空 = 不按时间，连续撞**）
)
WAIT_NAMES = ""  # 想等的玩家名字（最多 10 个；面板分框填写，内部用分隔符保存）
WAIT_NAME_MIN = 0  # 名字至少命中几个才留下（不退出对局）
# "等房间"和"读场地"分开算（以前只有后面这一项，会把加载时间算进去 → 必然误判）：
# · 等房间画面出现：最多 ROOM_WAIT_SEC 秒（代码常量）。实测进局要 20~59 秒（中位 32 秒），
# 场地效果和房间画面是同一个界面，所以这段加载时间不该算进"判场地"的预算。
# · 房间到了以后再读场地效果：VENUE_WAIT_SEC 秒（面板上那一项）。
ROOM_WAIT_SEC = 90
VENUE_WAIT_SEC = 5  # 房间出现后再等几秒读【场地效果】（读不到就按"不是福利多多"处理）
# 为了"快认快退"：房间画面出现后先给这么多秒把场地栏画出来，
# 之后改成读一次场地栏那行字 —— 只要读出来是"别的场地"，立刻退出，不用死等到 VENUE_WAIT_SEC。
FAST_JUDGE_SEC = 1.2
# 到点前提前几秒"预备"：先把前面几步点完（进仪器组合页 → 点【开始匹配】），
# 停在最后一个界面（确认扣除入场费弹窗）上；到点只按最后一下 → 卡点更准（不用边找边点）。
PREP_SEC = 8
# 撞到「福利多多 + 名字对上」之后，替你自动出的那一注（占位用）。
# 注意：这【不是】面板上那个『前两回合保底价』（四项每局随机），撞果盘单独用这个数，默认 520。
# 0 = 只响警报、不出价。
BONUS_KEEP_BID = 520
# 运行时标志：True = 正在打"撞果盘撞到的福利多多局"（这时每回合固定出 BONUS_KEEP_BID、
# 不用仪器、不做整仓识别；打完自动清掉）。不写进面板，纯内部状态。
_GP_BONUS_MODE = [False]
BONUS_VENUE_IMAGE = "venue_bonus.png"  # 福利多多模板（在 素材\ 里）
BONUS_THRESHOLD = (
    0.92  # 福利多多匹配阈值（实测：真福利多多 1.00，最像的别的场地『标准对局』0.81）
)
WAIT_NAME_ROWS = (190, 350, 510, 672)  # 左边 4 个玩家名字胶囊的 y（相对游戏客户区 1920x1080）
WAIT_NAME_X = 138  # 名字胶囊的 x / 宽 / 高
WAIT_NAME_W = 216
WAIT_NAME_H = 42
WAIT_NAME_RATIO = 0.50  # 名字允许约 50% 字符相似（防止 OCR/输入错一位就误退）
HALL_WAIT_SEC = 40  # 退出对局后最多等几秒回到拍卖大厅
LATE_OK_SEC = 1.5  # 等时间时最多允许"晚"多少秒也算到点（电脑卡一下不至于白等一分钟）
RESYNC_SEC = 600  # 联网校时：多久重新对一次表（秒）
NTP_HOSTS = ("ntp.aliyun.com", "cn.pool.ntp.org", "time.windows.com")
HTTP_HOSTS = ("http://www.baidu.com", "http://www.taobao.com", "http://www.qq.com")


R2_RIVAL_MULT = 1.2

# 跟价模式·超估价额度（只在"跟价算出来的价被估价夹回"这一个点上生效）：
# 第 x 回合起，出价上限 = 估价 + 额度。额度 0 = 完全等于旧行为（出价不超过估价）。
# 上面那道 HARD_CAP_MULT 会再统一压一次，这里不用自己夹。
OVER_PRICE_ROOM = 500000
OVER_PRICE_FROM_R = 3

# 大额判定门槛（估价超过它算大仓，走大额策略）。
# 跟 GATE_233 数值相同但用途无关，见上面那组 GATE 的注释。
BIG_LOT_GATE = 2333333
# 大仓时判断「对手也看上了」的门槛，原来是个可调参数，定下来就用 0.25。
BIG_LOT_RIVAL_RATIO = 0.25

ROUND3_GAP_RATIO = 1.0
R3_RIVAL_MULT = 1.2
R4_RIVAL_MULT = 1.15
R5_RIVAL_MULT = 1.1

READ_RIVAL_BIDS = 1
PANEL_LEFT = 100
PANEL_TOP = 240
PANEL_RIGHT = 700
PANEL_BOTTOM = 820
PANEL_ROW_Y = (306, 466, 625, 786)
PANEL_SLOT_X = (181, 258, 336, 413, 491)
PANEL_CELL_W = 48
PANEL_CELL_H = 28
PANEL_OCR_SCALE = 3
PANEL_BID_MIN = 1
PANEL_BID_MAX = 100000000

PANEL_READ_RETRY_OFFSETS = (-9, -5, 5, 9)
PANEL_EMPTY_AS_GIVEUP = 0
PANEL_VALUE_BOX_DX0, PANEL_VALUE_BOX_DX1 = -44, 44
PANEL_VALUE_BOX_DY0, PANEL_VALUE_BOX_DY1 = -20, 24
OPPONENT_OUTLIER_FILTER = 0
PANEL_ROW_MATCH_TOL = 0.01
PANEL_ROW_MATCH_MIN = 2000

FAST_SETTLE = 1
# 「实际价值超过多少就跳过点红点」。默认 250 万，参数文件里调成了 5121024；
# 跟 GATE_280 同值纯属巧合（那是 U 盘档开口价），两者没有任何联动。
FAST_SETTLE_VALUE = 2500000

# 大红白名单（RED_KEEP_*）整套已经删了 —— 那八个勾加认仓太挑环境，
# 实际用不上；「跳过点红点」现在只看上面两个阈值。

ALARM_ENABLED = 1
ALARM_THRESHOLD = 5000000
ALARM_FILE = "alarm.mp3"
ALARM_LOOP = 8
ALARM_VOLUME = 0.45            # 警报音量（0.0~1.0；0.45 = 45%）
ALARM_PAUSE_SCRIPT = 0

SELL_CLOSE_TIP_ENABLED = 1
SELL_CLOSE_TIP_IMAGE = "step_close_tip.png"
SELL_CLOSE_TIP_WAIT = 1
SELL_CLOSE_TIP_DETECT_TIMEOUT = 6

WAIT_SUPER_INSTRUMENT = 4.5   # 大肥鱼：第2~5回合"用完道具 → 识别到估价"的总预算 4.5 秒
# 注意：第1回合是另一条规则 —— 用完道具后固定停 3 秒再数仓（见 走第1回合）。
# 这个预算只作用于第2~5回合：点使用仪器 → 等生效 → 读估价，全部加起来不超过 4.5 秒。
INSTRUMENT_TO_EST_BUDGET = 4.5
WAIT_SPECIAL_INSTRUMENT = 3.0  # 大肥鱼：原来 7
MIN_WAIT_AFTER_BID = 3
MIN_WAIT_AFTER_BID_URGENT = 0.3
NEXT_ROUND_POLL_INTERVAL = 0.7
BID_PANEL_READY_TIMEOUT = 3.0
BID_PANEL_ANIMATION_GRACE_TIMEOUT = 3.2
# 普通局每按一个数字键之间隔多久。
# 坐标快速输入默认 0.04 秒，看着像机器在抢；慢一点更像真人、也不容易漏键。
# 0.18：六位数一共省 0.4 秒，间隔还是人手的节奏。
# 紧迫危机（20 秒窗口）仍用 0.04，别为了像真人把窗口吃掉。
BID_DIGIT_CLICK_GAP = 0.10
BID_DIGIT_CLICK_GAP_URGENT = 0.04
# ── 出价输入「成组键」（移植自 v1 的 keypad_zero_group）──────────────────
# 连续 4 个 0 用一次「0000」键点掉，少点几次；点错由后面的金额校验兜底重打。
#   1 = 启用（默认；万一 0000 键定位不到，会自动回退成逐位输入，行为同旧版）
#   0 = 完全回到逐位输入（旧行为）
# 只影响「点哪个键」，点击仍然走 安全点击 → 后台点击，后台模式不受影响。
BID_ZERO_GROUP = 1
# ── 出价金额校验提速 ─────────────────────────────────────────────
# 数字模板判定只要几十毫秒，OCR 单次 0.7~0.9 秒（还要跑两个模型）。
# 所以默认「模板优先」：模板判过就直接放行，模板不可用/对不上才走 OCR 复核。
#   1 = 模板优先（默认）；0 = 老行为（每次校验都 OCR）
BID_VERIFY_TEMPLATE_FIRST = 1
# 大肥鱼：出价金额校验总开关。0 = 不校验（打完数字直接点确认，省 0.7~1.5 秒/回合）。
# 想恢复就改回 1（代码都在，没删）。
BID_AMOUNT_VERIFY_ENABLED = 0
# 单遍放行门槛：模板第一遍就判过、而且最低分/最小差都够高时，不再复读第二遍。
# （实测日志里正常局是 0.994/0.183、0.995/0.153，坏读数在 0.92 以下，这个门槛够稳）
BID_VERIFY_SINGLE_PASS_SCORE = 0.99
BID_VERIFY_SINGLE_PASS_MARGIN = 0.10
# 金额校验的调试图（记录\数字调试\debug_bid_amount*.png）默认不存；
# 排查模板读错时临时改成 1。每次校验能省两次落盘。
BID_AMOUNT_DEBUG_SAVE = 0
# 确认出价之后等多久再校验弹窗（普通局 0.4 秒；以前 1.0 秒纯属干等）
BID_AFTER_CONFIRM_WAIT = 0.25
BID_AFTER_CONFIRM_WAIT_URGENT = 0.2
# 只有出价 ≥ 这个数才可能弹「疑似异常过高」：低于它的局只做一次单帧探测（不等待），
# 省掉每局固定 1 秒的轮询。
HIGH_BID_CHECK_MIN_AMOUNT = 2000000
# 高价局等弹窗的时长（照旧 1 秒，别为了省时间把 ≥200 万的弹窗漏掉）
HIGH_BID_VERIFY_WAIT = 1.0
# ── 闪退秒级自救（移植自 v1 的 window.is_alive 检测）────────────
#   1 = 开（游戏窗口+进程都没了 → 立刻自救重启，不必等 STUCK_MINUTES 分钟）
#   0 = 关（只靠 5 分钟卡死自救）
WINDOW_LOST_WATCH = 1
WINDOW_LOST_POLL_SEC = 0.5     # 多久查一次
WINDOW_LOST_CONFIRM_HITS = 3   # 连续几次（约 1.5 秒）都查不到才算真没了
MAX_WAIT_FOR_NEXT_ROUND = 45
# ── 每日 05:00 的月卡弹窗：04:50 起不开新局，等「每日定时点击」把它点完再继续 ──
# 月卡界面每天 05:00 前后自动弹出来盖住画面（"每日定时点击"就是去点它的：
# 04:59:00 起每 10 秒一个节拍、盯到 05:05:00；点掉就继续，
# 盯到头还没点掉就激活一下游戏、用新画面重新识别再点）。守着的时候脚本**一次都不点游戏**，
# 所以后台抓到的画面可能一直是旧帧 —— 这正是 10-15/10-16 两次"没看到弹窗"的原因。
# 这段时间开新局必被打断：实测 10-03~10-13 有 20 次"估价异常 / 回合号识别失败"退局、
# 白亏 62 万，其中 7 次正好落在 05:00:0x~05:00:5x。
DAILY_CLICK_HOLD_FROM_MIN = 4 * 60 + 50  # 当天第几分钟起不开新局（04:50）
DAILY_CLICK_HOLD_MAX = 30 * 60  # 最多守这么久（防意外死等）
# 原来是"点完再等 2 分钟"；现在改成"点掉就正常继续流程"，所以收尾等待 = 0。
DAILY_CLICK_AFTER_WAIT = 0  # 定时点击点完之后再多等这么久（秒）再开局（0 = 不等）
_DAILY_WAIT = [False]  # 守着的时候置 True：看门狗不许把这段当卡死
_SETTLEMENT_HALL_WAIT = [False]  # 结算后20秒等大厅：暂缓看门狗，但不触发恢复

LIMIT_TO_GAME_WINDOW = 1

DAILY_CLICK_ENABLED = 1
# 04:59:00 开始盯、盯到 05:05:00，每 10 秒一个节拍：
# 认到月卡弹窗 → 点设定位置（卡片底部「点击领取今日奖励」）→ 立刻确认有没有点掉；
# 点掉 → 正常继续流程；盯到 05:05 还没点掉 → 激活一下游戏（拉前台，逼它吐出**新**画面，
# 免得后台抓到的是旧帧）再识别一次，弹窗还在就点掉，然后继续游戏。
DAILY_CLICK_HOUR = 4
DAILY_CLICK_MINUTE = 59
DAILY_CLICK_SECOND = 0
DAILY_CLICK_END_HOUR = 5  # 盯到 05:05:00 收工（之后走"激活游戏再认一次"）
DAILY_CLICK_END_MINUTE = 5
DAILY_CLICK_END_SECOND = 0
DAILY_CLICK_POLL_INTERVAL = 10  # 每 10 秒一个节拍（原来是憋 300 秒轮询 + 一次连点 5 下）
DAILY_CLICK_TICK_CLICKS = 1  # 一个节拍里点几下（每 10 秒点一次）
DAILY_CLICK_ACTIVATE_WAIT = 60  # 激活游戏之后最多再认这么久（秒）
DAILY_CLICK_ACTIVATE_INTERVAL = 3  # 激活之后每 3 秒再认一次
DAILY_CLICK_X = 666
DAILY_CLICK_Y = 165
# 原来死点 (666,165) —— 实测那是一片空背景（跟月卡标题的相似度 0.010），
# 点了等于没点，弹窗还盖在画面上，导致 05:02 之后 6 分钟开不了局（10-14 那次卡顿）。
# 现在改成"用模板找到弹窗上该点的东西再点"，点完还会确认弹窗是不是真的没了。
# 用现成的两张模板（用户指定的参照，素材里本来就有、别处也在用）：
# step_monthly_card.png = 月卡弹窗那张「异晶开采凭证」标题
# step_close_tip.png    = 「点击空白区域关闭」那行提示（出售流程里就是点它来关提示的）
DAILY_CARD_IMAGE = "step_monthly_card.png"
DAILY_CARD_CENTER_DY = 390  # 标题中心 → 卡片中心（实测 141 → 531，点这儿=领奖）
DAILY_CARD_HINT_DY = 835  # 标题中心 → 底部「点击领取今日奖励」（实测 141 → 976，备用点击点）
DAILY_REWARD_TIP_IMAGE = "step_close_tip.png"
DAILY_REWARD_APPEAR_WAIT = 3  # 点完月卡后，等奖励弹窗冒出来最多等这么久（秒）
# 两个弹窗都点"那行字"本身：
# 月卡卡片 → 点底部「点击领取今日奖励」；领奖弹窗 → 点底部「点击空白区域关闭」。
# 点不掉时轮着试备用点（就是最早那版写死的坐标）。
# 以下是游戏客户区坐标；真正点击前会由 客户区转屏幕() 加上窗口位置。
DAILY_BACKUP_X = 666
DAILY_BACKUP_Y = 165
# 盲点位置：**不看识别结果**，04:59–05:05 每 10 秒直接点这里一下。
# 为什么敢盲点：这段时间脚本已经退出对局、专门守着月卡，这个位置（卡片底部
# 「点击领取今日奖励」，标题实测在 (959,141)，+835 = 976）不会点到别的按钮；
# 要是在对局里就会点到别的东西 —— 所以 in_auction（正在拍卖）时这一拍直接跳过不点，
# 04:50 起不开新局的那段守候就是为了保证"点的时候人不在局里"。
# 盲点的意义：后台抓图在游戏长时间没人碰时会一直读到旧帧、模板认不到弹窗，
# 但**游戏照样收得到这一下点击** —— 10-15/10-16 就是"认不到 → 没点 → 弹窗还在"卡住的。
# DAILY_BLIND_X/Y 同样是游戏客户区坐标（1920x1080 画面内），不是桌面坐标。
# 点击时实时换算成桌面绝对坐标，窗口移动、副屏、左侧负坐标屏都能命中。
DAILY_BLIND_X = 959
DAILY_BLIND_Y = 976
DAILY_BLIND_SETTLE = 0.6  # 盲点之后等这么久再抓图（让游戏把这一下处理掉）

DAILY_CLICK_TIMES = 5  # 一次识别里连点几下（激活游戏后的那一段用这个）
DAILY_CLICK_INTERVAL = 3  # 连点之间的间隔（秒）
DAILY_CLICK_CHECK_INTERVAL = 5  # 定时点击线程多久醒一次看看到点没（秒）
DAILY_CLICK_WAIT_MAX = 300  # 等"正在拍卖中"结束 / 画面静止的最长时间（秒）
DAILY_CLICK_BIDDING_WAIT = 45  # 正在拍卖时最多等这么久再动手（避开出价阶段，秒）
DAILY_CLICK_REQUIRE_RUNNING = 0

FUNDS_CHECK_ENABLED = 1
FUNDS_LEFT = 1413
FUNDS_TOP = 48
FUNDS_RIGHT = 1863
FUNDS_BOTTOM = 99
FUNDS_HALL_LEFT = 1030  # 大厅顶部「我的资产」位置与拍卖房间不同
FUNDS_HALL_TOP = 30
FUNDS_HALL_RIGHT = 1510
FUNDS_HALL_BOTTOM = 110
STOP_BELOW_FUNDS = 5000000
MATCH_STEP4_FAIL_LIMIT = 10
MATCH_STEP4_FAIL_WINDOW = 600
MATCH_STEP4_TIMEOUT = 12
# "找不到【确认扣除入场费】"累计到上限后，先自救几轮再说：
# 1 = 先关游戏重开一轮，重开完还是这样才停下等人（0 = 老行为：直接停下）。
# 起因：10-03 实测连续 102 次、35 分钟都卡在这个点上，最后只能手动按【停止】才结束。
MATCH_STEP4_RESCUE_ROUNDS = 1

# 流程B「退不出去」熔断 + 断点续接等待推进：
# 起因：11-05 13:14~17:08 连撞 95 次。断点续接看到「竞拍第1回合 / 00:00 / 出价键灰」，
# 直接 关拍卖("exit") → 流程B的 ESC 点了没反应、确认框也不出来，
# 21 秒后又回到同一个画面，循环 4 小时（那天收益从 8 万/局掉到 3 万/局）。
# EXIT_FAIL_LIMIT          连续几次退不出去就动手（默认 3 次）
# EXIT_FAIL_WINDOW         累计窗口秒数（默认 300 = 5 分钟）
# EXIT_FAIL_RESCUE_ROUNDS  自救几轮（关游戏重开），之后停下等人
# RESUME_ADVANCE_WAIT      断点续接发现出价窗口已过时，先等几秒看界面会不会自己推进
EXIT_FAIL_LIMIT = 3
EXIT_FAIL_WINDOW = 300
EXIT_FAIL_RESCUE_ROUNDS = 1
RESUME_ADVANCE_WAIT = 10.0

BIG_LOT_SHOT = 1
SCREENSHOT_TIER1_THRESHOLD = 5121024
SCREENSHOT_TIER1_NAME = "u盘"
SCREENSHOT_TIER2_THRESHOLD = 8980000
SCREENSHOT_TIER2_NAME = "匕首"
SCREENSHOT_TIER3_THRESHOLD = 11235813
SCREENSHOT_TIER3_NAME = "碧波"
SCREENSHOT_TIER4_THRESHOLD = 16800000
SCREENSHOT_TIER4_NAME = "夜光杯"
SCREENSHOT_TIER5_THRESHOLD = 20171210
SCREENSHOT_TIER5_NAME = "锦鲤跑车"

# 我拍到的、但没够到高价值线的局，也存一份图，放 记录\低价值截图\日期\。
# 只截【我拍到的】——别人拍走的每局都截，一天几百张，没必要。
LOW_VALUE_SCREENSHOT_ENABLED = 1
LOW_VALUE_SHOT_NAME = "低价值"
LOW_VALUE_SHOT_KEEP = 1000
# 按张数管不住体积：一张整屏 PNG 能有 1.5MB，1000 张就是 1.5GB。
# 这里按总量兜一道，超了就从最老的删起。
LOW_VALUE_SHOT_MAX_MB = 120
# 日志同理。它是所有排查问题的第一手材料，留 40MB 足够翻最近的。
LOG_MAX_MB = 40

# 藏品图鉴价格表：每件藏品的「品质 / 名字 / 价格」。
# 来源是游戏图鉴截图的 OCR（图鉴按价格从高到低排），给结算做个客观参照：
# 同样是"实际价值 500 万"，听数字没概念，说"图鉴第 8 名"就有概念了。
# 表缺了/读坏了都不影响主流程，CATALOG_ITEMS 空着就跳过这一段。
CATALOG_PATH = os.path.join(_HERE, "藏品价格表.csv")
if not os.path.exists(CATALOG_PATH):
    CATALOG_PATH = os.path.join(SCRIPT_DIR, "藏品价格表.csv")
CATALOG_ITEMS = []  # [(价格, 品质, 名字)]，按价格降序


def 读藏品图鉴():
    global CATALOG_ITEMS
    try:
        import csv as _csv

        items = []
        with open(CATALOG_PATH, "r", encoding="utf-8-sig") as f:
            for row in _csv.DictReader(f):
                try:
                    items.append((int(row["价格"]), row.get("品质", ""), row.get("名字", "")))
                except Exception:
                    continue
        items.sort(key=lambda x: -x[0])
        CATALOG_ITEMS = items
    except Exception:
        CATALOG_ITEMS = []
    return CATALOG_ITEMS


读藏品图鉴()


def 图鉴品级(value):
    """这个价值相当于图鉴里第几名的单品；比最贵的还贵时返回 (1, 最贵那件, 价格)。"""
    for idx, (p, q, n) in enumerate(CATALOG_ITEMS, 1):
        if value >= p:
            return idx, n, p
    return None, None, None


VALUE_WIDTH = VALUE_RIGHT - VALUE_LEFT
VALUE_HEIGHT = VALUE_BOTTOM - VALUE_TOP
ROUND_WIDTH = ROUND_RIGHT - ROUND_LEFT
ROUND_HEIGHT = ROUND_BOTTOM - ROUND_TOP
NAME_WIDTH = NAME_RIGHT - NAME_LEFT
NAME_HEIGHT = NAME_BOTTOM - NAME_TOP
FINAL_PRICE_WIDTH = FINAL_PRICE_RIGHT - FINAL_PRICE_LEFT
FINAL_PRICE_HEIGHT = FINAL_PRICE_BOTTOM - FINAL_PRICE_TOP
ACTUAL_VALUE_WIDTH = ACTUAL_VALUE_RIGHT - ACTUAL_VALUE_LEFT
ACTUAL_VALUE_HEIGHT = ACTUAL_VALUE_BOTTOM - ACTUAL_VALUE_TOP
PROFIT_WIDTH = PROFIT_RIGHT - PROFIT_LEFT
PROFIT_HEIGHT = PROFIT_BOTTOM - PROFIT_TOP
FUNDS_WIDTH = FUNDS_RIGHT - FUNDS_LEFT
FUNDS_HEIGHT = FUNDS_BOTTOM - FUNDS_TOP
FUNDS_HALL_WIDTH = FUNDS_HALL_RIGHT - FUNDS_HALL_LEFT
FUNDS_HALL_HEIGHT = FUNDS_HALL_BOTTOM - FUNDS_HALL_TOP
BID_REGION_WIDTH = BID_REGION_RIGHT - BID_REGION_LEFT
BID_REGION_HEIGHT = BID_REGION_BOTTOM - BID_REGION_TOP
COUNT_REGION_WIDTH = COUNT_REGION_RIGHT - COUNT_REGION_LEFT
COUNT_REGION_HEIGHT = COUNT_REGION_BOTTOM - COUNT_REGION_TOP
BID_AMOUNT_CHECK_WIDTH = BID_AMOUNT_CHECK_RIGHT - BID_AMOUNT_CHECK_LEFT
BID_AMOUNT_CHECK_HEIGHT = BID_AMOUNT_CHECK_BOTTOM - BID_AMOUNT_CHECK_TOP

alarm_stop_flag = False
alarm_thread = None

high_first_round = None
low_first_round = None

daily_click_next_time = None

bid_interrupt_state = 0
bid_state_lock = threading.Lock()
# 最终“确认出价”是一次不可分割的提交动作：
# 从找确认按钮到记录已提交期间，暂停热键要等这一小段完成，避免出现
# “按钮已经点了、程序却把它当成未出价暂停”的状态错位。
bid_commit_lock = threading.RLock()

in_auction = False
last_activity_ts = 0.0
# 一局只允许记账一次；结算后若退出失败，只继续尝试退出，绝不重新识别并重复写记录。
_AUCTION_FINISHED = [False]
_SETTLEMENT_EXIT_FAILS = [0]

def _models_base():
    """返回 models 的父目录。

    Paddle 的 C++ 层读不了带中文的绝对路径（实测直接 NotFound），只能喂相对
    路径；相对路径又跟着 cwd 走。所以这里自己挑一份、自己切 cwd，不指望
    调用方正好在哪个目录启动。

    优先上一层的 models（发布结构是 根\\程序\\界面.py，模型在根），再退到自己
    这一层（平铺结构）。两份都在时选带英文模型的那份 —— 金额复核要用 en。
    """
    cands = [os.path.dirname(SCRIPT_DIR), SCRIPT_DIR]
    usable = [d for d in cands
              if os.path.isfile(os.path.join(d, "models", "det", "inference.pdmodel"))
              and os.path.isfile(os.path.join(d, "models", "rec", "inference.pdmodel"))]
    for d in usable:
        if os.path.isdir(os.path.join(d, "models", "rec", "en")):
            return d
    return usable[0] if usable else SCRIPT_DIR


_MODELS_BASE = _models_base()
MODEL_DIR = os.path.join(_MODELS_BASE, "models")
det_dir = os.path.join(MODEL_DIR, "det")
rec_dir = os.path.join(MODEL_DIR, "rec")
cls_dir = os.path.join(MODEL_DIR, "cls")
en_rec_dir = os.path.join(rec_dir, "en", "en_PP-OCRv4_rec_infer")

_CWD_BACKUP = os.getcwd()
try:
    os.chdir(_MODELS_BASE)
    print("⏳ 正在初始化 PaddleOCR，请稍候...")
    if os.path.exists(det_dir) and os.path.exists(rec_dir):
        print("✅ 发现本地模型，正在加载离线模型...")
        ocr = PaddleOCR(
            use_angle_cls=True,
            lang="ch",
            det_model_dir=os.path.join("models", "det"),
            rec_model_dir=os.path.join("models", "rec"),
            cls_model_dir=os.path.join("models", "cls"),
            show_log=False,
        )
    else:
        print("⚠️ 未找到本地 models 文件夹，将使用默认联网模式...")
        ocr = PaddleOCR(use_angle_cls=True, lang="ch", show_log=False)
    print("✅ PaddleOCR 初始化完成！")
finally:
    os.chdir(_CWD_BACKUP)

LAST_AMOUNT_ALT = ""
LAST_BID_AMOUNT_IMAGE = None
LAST_BID_TEMPLATE_DECISION = None
amount_ocr_alt = None
if os.path.exists(en_rec_dir):
    try:
        print("⏳ 正在加载英文识别模型（复核金额用）...")
        _cwd2 = os.getcwd()
        try:
            os.chdir(_MODELS_BASE)
            amount_ocr_alt = PaddleOCR(
                use_angle_cls=True,
                lang="en",
                det_model_dir=os.path.join("models", "det"),
                rec_model_dir=os.path.join("models", "rec", "en", "en_PP-OCRv4_rec_infer"),
                cls_model_dir=os.path.join("models", "cls"),
                show_log=False,
            )
        finally:
            os.chdir(_cwd2)
        print("✅ 英文识别模型加载完成（金额会双模型交叉验证）")
    except Exception as e:
        print(f"⚠️ 英文识别模型加载失败（不影响主流程）: {e}")
        amount_ocr_alt = None
else:
    print("ℹ️ 没找到 models\\rec\\en，金额只用中文模型识别")

running = False
auction_count = 0
current_rounds = []

LAST_OPPONENT_BIDS = []
SECOND_HISTORY = []
OPPONENT_MAX_SEEN = 0
PREV_ROUND_OPP_MAX = 0
PANEL_READ_FAIL_STREAK = 0
LAST_OPPONENT_RAW = []
MY_BIDS = {}
MY_PANEL_ROW = None
LAST_PANEL_GRID = {}
LAST_PANEL_MY_ROW = None
LAST_REFINED_ROWS = set()
LAST_PANEL_DARK = False
NO_BID_REASON = ""
_MATCH_STEP4_FAIL_STREAK = 0
_MATCH_STEP4_FAIL_LAST = 0.0
_MATCH_STEP4_LOW_FUNDS_STREAK = 0
# "找不到【确认扣除入场费】"到上限后已经自救过几轮
# （成功开出新局就清零；MATCH_STEP4_RESCUE_ROUNDS = 1 表示一轮自救还不成就停下等人）
_MATCH_STEP4_RESCUE_DONE = 0
# 流程B「退不出去」熔断用的计数：
# 11-05 实测 13:14~17:08 连撞 95 次—— ESC 按钮点了没反应、确认框也不出来，
# 21 秒一轮，脚本以为是"本局结束"就再退一次，无限循环刷了 4 小时。
# 连续 EXIT_FAIL_LIMIT 次退不出去 → 先自救重开一轮；自救也不行就停下载机等人。
_EXIT_FAIL_STREAK = 0
_EXIT_FAIL_LAST = 0.0
_EXIT_FAIL_RESCUE_DONE = 0
# 本局已经确认过的估价（估价只涨不跌：新读数低于它 = 读错）
LAST_ESTIMATE = 0
TIER_FIRST_ROUND = {}

# ============================================================================
# 普通倍率：按【估价区间】给倍率（没有识别到目标藏品时用）
#   NORMAL_MULT_1_MAX ~ 4_MAX 是四道分界，NORMAL_MULT_1_RATE~5_RATE 是五段的倍率。
#   倍率写成"百分比整数"：30 表示 ×1.3（估价 × (1 + 30/100)）。
#   0/空 = 这一段不启用。
# ============================================================================
NORMAL_MULT_1_HI = 0        # 第1段：估价 ≤ 此值
# 倍率写成"百分比整数"：130 表示 估价×1.3（100=原价）
NORMAL_MULT_1_RATE = 0
NORMAL_MULT_2_LO = 0        # 第2段：(LO, HI]
NORMAL_MULT_2_HI = 0
NORMAL_MULT_2_RATE = 0
NORMAL_MULT_3_LO = 0
NORMAL_MULT_3_HI = 0
NORMAL_MULT_3_RATE = 0
NORMAL_MULT_4_LO = 0
NORMAL_MULT_4_HI = 0
NORMAL_MULT_4_RATE = 0
NORMAL_MULT_5_LO = 0        # 第5段：(LO, HI]（原来第5段是"以上"，现改成区间）
NORMAL_MULT_5_HI = 3000000
NORMAL_MULT_5_RATE = 0
NORMAL_MULT_6_LO = 3000001   # 第6段（新增）
NORMAL_MULT_6_HI = 6000000
NORMAL_MULT_6_RATE = 125
NORMAL_MULT_7_LO = 6000001   # 第7段：估价 > 此值（最后的"以上"）
NORMAL_MULT_7_RATE = 125
_SPECIAL_BID_ACTIVE = [False]   # 本回合是否用了"目标藏品价"（金红加价就不再参与）
LAST_PANEL_RANKS = {}
PANEL_BIDS = {}

ERROR_LOG_TXT = None
ERROR_LOG_JSONL = None
ERROR_SHOT_MAX = 300
ERROR_CONTEXT = {}
ERROR_COUNT = {}
_error_state = {"shots": 0, "recent": {}}


def 报错上下文更新(**kw):
    try:
        ERROR_CONTEXT.update(kw)
    except Exception:
        pass


def 报错上下文快照():
    ctx = dict(ERROR_CONTEXT)
    try:
        w = 游戏窗口范围()
        ctx["window"] = list(w) if w else None
    except Exception:
        ctx["window"] = None
    try:
        ctx["auction_no"] = RUNLOG_AUCTION_NO
        ctx["stats"] = dict(RUNLOG_STATS)
        ctx["running"] = bool(globals().get("running"))
        ctx["mode"] = globals().get("BID_MODE")
    except Exception:
        pass
    return ctx


def 报错截图名(kind):
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(kind))[:24]
    name = f"报错_{ts}_a{RUNLOG_AUCTION_NO}_{safe}.jpg"
    path = os.path.join(报错截图目录(), name)
    i = 2
    while os.path.exists(path):
        name = f"报错_{ts}_a{RUNLOG_AUCTION_NO}_{safe}_{i}.jpg"
        path = os.path.join(报错截图目录(), name)
        i += 1
    return name, path


def 清到容量(root, max_mb, protect_hours=0):
    """按总占用清：超了就从最老的删起，直到落回上限以内。返回删了几个。

    跟「清最新的」分工不同 —— 那个按张数管，遇到单张特别大的图（整屏
    PNG 一张 1.5MB）就管不住体积。这里直接盯总字节，才是能真正兜住的那个。

    protect_hours：这么小时内改过的文件别碰。日志正在往里写，删了句柄就废了。
    """
    try:
        limit = float(max_mb) * 1024 * 1024
        if limit <= 0 or not os.path.isdir(root):
            return 0
        items = []
        total = 0
        for base, _dirs, files in os.walk(root):
            for f in files:
                p = os.path.join(base, f)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                items.append((st.st_mtime, st.st_size, p))
                total += st.st_size
        if total <= limit:
            return 0
        items.sort()
        removed = 0
        safe_before = time.time() - float(protect_hours) * 3600.0 if protect_hours else 0.0
        for _t, size, p in items:
            if total <= limit:
                break
            if protect_hours and _t >= safe_before:
                continue
            try:
                os.remove(p)
            except OSError:
                continue
            total -= size
            removed += 1
        if removed:
            print(f"🧹 记录减肥：{os.path.basename(root)} 删了 {removed} 个旧文件")
        return removed
    except Exception:
        return 0


def 清最新的(root, keep, prefix="", recursive=False):
    try:
        items = []
        if recursive:
            for base, _dirs, files in os.walk(root):
                for f in files:
                    if f.startswith(prefix) or not prefix:
                        p = os.path.join(base, f)
                        items.append((os.path.getmtime(p), p))
        else:
            for f in os.listdir(root):
                if prefix and not f.startswith(prefix):
                    continue
                p = os.path.join(root, f)
                if os.path.isfile(p):
                    items.append((os.path.getmtime(p), p))
        if len(items) <= keep:
            return
        items.sort()
        for _t, p in items[: len(items) - keep]:
            try:
                os.remove(p)
            except Exception:
                pass
    except Exception:
        pass


def 清旧报错图(keep=300):
    清最新的(报错截图目录(), keep, prefix="报错_")
    清最新的(os.path.join(RUNLOG_DIR, "日志"), keep, prefix="报错_", recursive=True)


def 报错日志开头(extra=""):
    try:
        path, _ = 报错日志路径()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fp:
            fp.write("\n" + "=" * 70 + "\n")
            fp.write(
                "[{}] 本次运行开始 {}\n".format(datetime.now().strftime("%Y-%m-%d %H:%M:%S"), extra)
            )
            fp.write("=" * 70 + "\n")
    except Exception:
        pass


def 记报错(kind, msg, exc=None, extra=None, shot=True, level="错误", throttle=0):
    try:
        now = time.time()
        prev = _error_state["recent"].get(kind, 0)
        if throttle and now - prev < throttle:
            return ""
        _error_state["recent"][kind] = now
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ERROR_COUNT[kind] = ERROR_COUNT.get(kind, 0) + 1
        n = ERROR_COUNT[kind]
        ctx = 报错上下文快照()
        tb = ""
        if exc is not None:
            try:
                tb = "".join(traceback.format_exception(type(exc), exc, exc.__traceback__))
            except Exception:
                tb = str(exc)
        shot_name = ""
        if shot:
            if _error_state["shots"] >= ERROR_SHOT_MAX:
                shot_name = "(已达本次运行截图上限 %d 张)" % ERROR_SHOT_MAX
            else:
                try:
                    name, path = 报错截图名(kind)
                    region = 回合截图区域()
                    img = 抓一帧(region=region) if region else 抓一帧()
                    img.convert("RGB").save(path, "JPEG", quality=75)
                    _error_state["shots"] += 1
                    shot_name = name
                    清旧报错图()
                except Exception:
                    shot_name = "(截图失败)"
        ctx_bits = []
        if ctx.get("round"):
            ctx_bits.append("第%s回合" % ctx["round"])
        if ctx.get("estimate"):
            ctx_bits.append("估价 %s" % "{:,}".format(int(ctx["estimate"])))
        if ctx.get("last_bid"):
            ctx_bits.append("最近出价 %s" % ctx["last_bid"])
        line_body = "[{}] {}｜第{}局{}｜{}{}{}".format(
            level,
            kind,
            RUNLOG_AUCTION_NO,
            ("／" + "／".join(ctx_bits)) if ctx_bits else "",
            msg,
            ("｜截图={}".format(shot_name)) if shot_name else "",
            ("｜这是第 {} 次".format(n)) if n > 1 else "",
        )
        try:
            写日志(line_body)
        except Exception:
            pass
        try:
            _etxt, _ = 报错日志路径()
            os.makedirs(os.path.dirname(_etxt), exist_ok=True)
            with open(_etxt, "a", encoding="utf-8") as fp:
                fp.write("[{}] {}\n".format(ts, line_body))
                if tb:
                    fp.write("     堆栈: " + tb.strip().replace("\n", " | ")[:900] + "\n")
        except Exception as exc:
            _提示记录失败("报错日志", exc)
        rec = {
            "ts": ts,
            "type": "error",
            "kind": kind,
            "level": level,
            "seq": n,
            "message": str(msg),
            "screenshot": shot_name,
            "context": ctx,
            "traceback": tb[-2000:],
        }
        if extra:
            rec["extra"] = extra
        try:
            _, _ejson = 报错日志路径()
            os.makedirs(os.path.dirname(_ejson), exist_ok=True)
            with open(_ejson, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception:
            pass
        try:
            记回合事件(
                "error",
                human=(
                    "❗ {}：{}".format(level, msg)
                    + ("（截图 {}）".format(shot_name) if shot_name else "")
                ),
                kind=kind,
                level=level,
                seq=n,
                screenshot=shot_name,
                extra=extra,
                traceback_text=tb[-800:],
            )
        except Exception:
            pass
        return shot_name
    except Exception as exc:
        _提示记录失败("记报错", exc)
        return ""


def 装上报错钩子():
    def _hook(exc_type, exc, tb):
        try:
            记报错(
                "uncaught",
                "未捕获异常：{}: {}".format(getattr(exc_type, "__name__", exc_type), exc),
                exc=exc,
                level="严重",
            )
        except Exception:
            pass
        try:
            traceback.print_exception(exc_type, exc, tb)
        except Exception:
            pass

    try:
        sys.excepthook = _hook
    except Exception:
        pass
    try:

        def _thook(args):
            try:
                记报错(
                    "thread_uncaught",
                    "后台线程未捕获异常：{}: {}".format(
                        getattr(args.exc_type, "__name__", args.exc_type), args.exc_value
                    ),
                    exc=args.exc_value,
                    level="严重",
                )
            except Exception:
                pass

        threading.excepthook = _thook
    except Exception:
        pass


装上报错钩子()


def 素材路径(name):
    try:
        if os.path.isabs(name):
            return name
        p = os.path.join(SCRIPT_DIR, name)
        if os.path.exists(p):
            return p
        alt = os.path.join(SCRIPT_DIR, MATERIAL_DIR, os.path.basename(name))
        return alt if os.path.exists(alt) else p
    except Exception:
        return name


def 读图(file_path):
    try:
        if not os.path.isabs(file_path):
            file_path = 素材路径(file_path)
        data = np.fromfile(file_path, dtype=np.uint8)
        if data.size == 0:
            return None
        return cv2.imdecode(data, cv2.IMREAD_COLOR)
    except Exception as e:
        print(f"⚠️ 读取图片异常: {e}")
        return None


_TEMPLATE_CACHE = {}


def 读图片模板(image_name):
    gray = _TEMPLATE_CACHE.get(image_name)
    if gray is None:
        img = 读图(image_name)
        if img is None:
            print(f"⚠️ 模板图片缺失或读取失败: {image_name}")
            记报错(
                "material_missing",
                f"素材缺失或读取失败: {image_name}",
                shot=False,
                throttle=120,
                extra={"material": image_name},
            )
            return None
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        _TEMPLATE_CACHE[image_name] = gray
    return gray


def 抓灰度图(region=None):
    # 一律走 抓一帧：它内部会处理"逻辑坐标/物理分辨率"不一致（4K+缩放机器）的问题。
    # 以前 region 为空时直接 pyautogui.screenshot()，在 4K 屏上截到 3840x2160，
    # 模板是 1920 尺度 → 所有识别都失败（实测踩过）。
    shot = 抓一帧(region=region) if region else 抓一帧()
    # 少拷一次：asarray 直接借内存，ascontiguousarray 才真复制
    arr = np.asarray(shot)
    if arr.ndim == 3:
        if arr.shape[2] == 4:
            arr = arr[:, :, :3]
        arr = arr[:, :, ::-1]
    img = np.ascontiguousarray(arr)
    return cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def 最佳模板匹配(gray_screen, template_gray, threshold=None):
    if threshold is None:
        threshold = THRESHOLD
    th, tw = template_gray.shape[:2]
    if gray_screen.shape[0] < th or gray_screen.shape[1] < tw:
        return False, 0, 0
    res = cv2.matchTemplate(gray_screen, template_gray, cv2.TM_CCOEFF_NORMED)
    _, max_val, _, max_loc = cv2.minMaxLoc(res)
    if max_val < threshold:
        return False, 0, 0
    return True, max_loc[0] + tw // 2, max_loc[1] + th // 2


FLOW_SCREEN_SCALES = (
    1.0,
    0.96,
    0.98,
    1.02,
    1.04,
    1.06,
    1.08,
    1.10,
    0.92,
    1.14,
    1.18,
    1.20,
    1.25,
    0.90,
    0.85,
    0.80,
)


def 多尺度最佳匹配(gray_screen, template_gray, threshold=None, scales=None):
    """多尺度模板匹配：兼容 Windows 缩放/画面尺寸略有差异的情况。

    返回 (found, center_x, center_y, scale, score)。坐标是 gray_screen 内坐标。
    """
    if threshold is None:
        threshold = THRESHOLD
    if not scales:
        scales = FLOW_SCREEN_SCALES
    best = (False, 0, 0, 1.0, -1.0)
    th0, tw0 = template_gray.shape[:2]
    for scale in scales:
        try:
            if abs(float(scale) - 1.0) < 1e-6:
                tpl = template_gray
            else:
                tw = max(8, int(round(tw0 * float(scale))))
                th = max(8, int(round(th0 * float(scale))))
                tpl = cv2.resize(
                    template_gray,
                    (tw, th),
                    interpolation=cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC,
                )
            th, tw = tpl.shape[:2]
            if gray_screen.shape[0] < th or gray_screen.shape[1] < tw:
                continue
            res = cv2.matchTemplate(gray_screen, tpl, cv2.TM_CCOEFF_NORMED)
            _, max_val, _, max_loc = cv2.minMaxLoc(res)
            if max_val > best[4]:
                best = (
                    max_val >= threshold,
                    max_loc[0] + tw // 2,
                    max_loc[1] + th // 2,
                    float(scale),
                    float(max_val),
                )
        except Exception as e:
            print("⚠️ 多尺度模板匹配 %s 失败: %s" % (scale, e))
    return best


def 多尺度找图并点(
    image_name, step_desc, region=None, timeout=4, threshold=None, scales=None
):
    """多尺度找图并点击；用于弹窗这类可能被 Windows 缩放影响的界面。"""
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        return False
    start = time.time()
    while running:
        wait_started = time.monotonic()
        if _等鼠标让行结束() != "READY":
            return False
        start += time.monotonic() - wait_started
        try:
            epoch = _USER_MOUSE_EPOCH
            actual_region = region if region is not None else 默认截图范围()
            gray = 抓灰度图(actual_region)
            found, cx, cy, scale, score = 多尺度最佳匹配(
                gray, template_gray, threshold=threshold, scales=scales
            )
            if found:
                ox = actual_region[0] if actual_region else 0
                oy = actual_region[1] if actual_region else 0
                print(
                    "🖱️ [多尺度] %s：%s（scale %.2f，相似度 %.3f）"
                    % (step_desc, image_name, scale, score)
                )
                if _按新画面点击(ox + cx, oy + cy, epoch):
                    return True
                if _BG_STATE.get("click_outcome") == "uncertain":
                    return False
        except Exception as e:
            print("⚠️ [多尺度] 检测 %s 出错: %s" % (image_name, e))
            return False
        if timeout <= 0 or time.time() - start >= timeout:
            return False
        if not 歇一下(0.4):
            return False
    return False


def 多尺度看图有没有(image_name, timeout=0, threshold=None, region=None):
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        return False
    start = time.time()
    while running:
        try:
            actual_region = region if region is not None else 默认截图范围()
            gray = 抓灰度图(actual_region)
            found, _x, _y, _scale, _score = 多尺度最佳匹配(
                gray, template_gray, threshold=threshold
            )
            if found:
                return True
        except Exception:
            return False
        if timeout <= 0 or time.time() - start >= timeout:
            return False
        if not 歇一下(0.4):
            return False
    return False


def 取窗口句柄():
    hwnd = win32gui.FindWindow(None, WINDOW_TITLE)
    if hwnd and not 是不是自己窗口(win32gui.GetWindowText(hwnd)):
        return hwnd
    best, best_area = None, -1
    for h, _t, _w, _h in 游戏窗口列表():
        # 启动器窗口标题是「异环启动器」，同样以「异环」开头、尺寸也是 1920x1080，
        # 会被误当成游戏窗口 —— 一旦认成它，后面就会一直对着启动器画面等标题画面，
        # 等满十分钟再关掉重开，循环到上限停机。这里直接排掉。
        if "启动器" in (_t or ""):
            continue
        area = int(_w) * int(_h)
        if area > best_area:
            best, best_area = h, area
    return best


OWN_WINDOW_KEYWORDS = (
    "控制面板",
    "面板错误",
    # 面板标题里带这个名字，识别时别把自家面板当成游戏窗口去点。
    "即可落槌",
)


def 是不是自己窗口(title):
    t = title or ""
    return any(k in t for k in OWN_WINDOW_KEYWORDS)


def 开始脚本():
    global running, _MATCH_STEP4_FAIL_STREAK, _MATCH_STEP4_FAIL_LAST, _MATCH_STEP4_LOW_FUNDS_STREAK
    if not running:
        time.sleep(0.5)
        if running:
            return
        running = True
        if CURSOR_YIELD_USER:
            _启动鼠标输入监测()
        print("\n👉 [启动] 脚本已激活，开始执行全新自动化流程！")
        if 后台模式开着吗():
            后台守护启动()
            print(
                "   🖥 后台模式已开：游戏窗口可以被别的窗口完全盖住；"
                "但不要最小化它，另外脚本必须是管理员运行。"
            )
        碰一下进度("脚本启动")


def 暂停脚本():
    global running
    if running:
        with bid_commit_lock:
            if not running:
                return
            running = False
        print("\n⏹️ [暂停] 脚本已安全暂停当前流程；按 F11 继续、F10 重新开始、F12 彻底停止。")


_LAST_SPACE_TOGGLE_TS = [0.0]
SPACE_TOGGLE_DEBOUNCE_SEC = 0.35

# ======================================================================
# 参数文件
# ======================================================================
# 面板保存参数时写的是 程序\参数配置.json，不再直接改这个源文件。
# 好处：源码永远是干净的，就算配置文件写坏了也只是参数乱了，脚本还能开。
# 文件不存在就当没改过，全部用下面源码里的默认值。
PARAM_FILE = os.path.join(_HERE, "参数配置.json")


# 上一次读参数时「JSON 里有、但代码里还找不到同名常量」的键。
# 参数文件是在模块靠前的位置读的，那时后面的常量还没定义，globals() 里是 None，
# 会被静默跳过。第二次（文件末尾）补读能救回来；两次都救不回来说明真的写错了，
# 启动时直接报出来，别让它在配置里装死。
_PARAM_MISSING = []


def 读参数文件(path=None, quiet=False):
    """读参数文件，覆盖同名常量。返回读到的字典（读不到就是空）。"""
    p = path or PARAM_FILE
    if os.environ.get("PAIMAI_SELFTEST") == "1":
        return {}          # 自检永远用源码默认值，不受用户改过的参数影响
    if not os.path.isfile(p):
        return {}
    try:
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception as e:
        print(f"⚠️ 参数文件读不了（{e}），这一轮按源码里的默认值跑")
        return {}
    if not isinstance(data, dict):
        print("⚠️ 参数文件不是键值对，忽略")
        return {}
    applied = 0
    missing = []
    for k, v in data.items():
        if not isinstance(k, str) or not re.match(r"^[A-Z][A-Z0-9_]*$", k):
            continue
        cur = globals().get(k)
        if cur is None or callable(cur) or isinstance(cur, (dict, list, tuple)):
            if cur is None:
                missing.append(k)
            continue
        try:
            if isinstance(cur, bool):
                globals()[k] = v if isinstance(v, bool) else bool(int(float(v)))
            elif isinstance(cur, int):
                globals()[k] = int(float(v))
            elif isinstance(cur, float):
                globals()[k] = float(v)
            elif isinstance(cur, str):
                globals()[k] = str(v)
            else:
                continue
            applied += 1
        except Exception:
            print(f"⚠️ 参数 {k} 的值 {v!r} 不对，跳过")
    _PARAM_MISSING[:] = missing
    if applied and not quiet:
        print(f"⚙️ 从 {os.path.basename(p)} 读了 {applied} 个参数")
    return data


读参数文件()


def 切换脚本():
    """F11 一键暂停/继续：空闲时开始，运行中安全暂停，暂停后再按继续。

    用按下触发并自行去抖：比 trigger_on_release 的全局钩子更可靠；
    同时挡住 Windows 按住按键产生的自动重复。
    """
    now = time.monotonic()
    if now - _LAST_SPACE_TOGGLE_TS[0] < SPACE_TOGGLE_DEBOUNCE_SEC:
        return
    _LAST_SPACE_TOGGLE_TS[0] = now
    if running:
        暂停脚本()
    else:
        开始脚本()


def 启动热键轮询兜底():
    """GetAsyncKeyState 轮询 F10/F11/F12 —— keyboard 钩子在某些环境下收不到键。

    优点：不依赖键盘钩子、不受 UIPI（管理员窗口）影响，只要脚本进程在跑就能读到按键。
    """
    import ctypes as _ct

    VK = {"f10": 0x79, "f11": 0x7A, "f12": 0x7B}
    _state = {k: False for k in VK}

    def _loop():
        while True:
            try:
                for name, vk in VK.items():
                    down = bool(_ct.windll.user32.GetAsyncKeyState(vk) & 0x8000)
                    if down and not _state[name]:
                        _state[name] = True
                        try:
                            if name == "f10":
                                开始挂机热键()
                            elif name == "f11":
                                切换脚本()
                            else:
                                彻底停止脚本()
                        except SystemExit:
                            return
                        except Exception as exc:
                            print(f"⚠️ 热键 {name.upper()} 处理出错: {exc}")
                    elif not down and _state[name]:
                        _state[name] = False
            except Exception:
                pass
            time.sleep(0.08)

    try:
        threading.Thread(target=_loop, daemon=True, name="hotkey-poll").start()
        print("⌨️ 热键轮询已启动（F10 开始 / F11 暂停继续 / F12 彻底停止）")
    except Exception as exc:
        print(f"⚠️ 热键轮询启动失败（还是用 keyboard 钩子）: {exc}")


def 开始挂机热键():
    """F10：开始挂机（已经在跑就不动，避免重复启动）。"""
    if running:
        print("\nℹ️ [F10] 脚本已经在运行，忽略。")
        return
    开始脚本()


def 彻底停止脚本():
    """F12：彻底停止脚本（整个进程退出，和面板那个按钮等价）。"""
    global running
    print("\n🛑 [F12] 彻底停止脚本：进程即将退出。")
    try:
        写日志("F12 彻底停止脚本：进程退出")
    except Exception:
        pass
    running = False
    time.sleep(0.4)
    os._exit(0)


def 跳过这次出价():
    global bid_interrupt_state
    if BID_PAUSE_SKIP_ENABLED != 1:
        return
    with bid_state_lock:
        if bid_interrupt_state == 0:
            bid_interrupt_state = 1
            print(
                "\n⏸️ [暂停] 出价流程已暂停，脚本停在原地。再次按 - 键将恢复并跳过出价，进入下一回合检测"
            )
        elif bid_interrupt_state == 1:
            bid_interrupt_state = 2
            print("\n▶️ [恢复] 出价流程恢复运行，即将跳过出价进入下一回合检测")


def 暂停时等着():
    global bid_interrupt_state
    if BID_PAUSE_SKIP_ENABLED != 1:
        return None
    while True:
        with bid_state_lock:
            state = bid_interrupt_state
        if state == 0:
            return None
        if state == 2:
            with bid_state_lock:
                bid_interrupt_state = 0
            return "SKIP"
        if not running:
            with bid_state_lock:
                bid_interrupt_state = 0
            return "STOP"
        time.sleep(0.1)


def 等用户操作():
    """脚本是不是在"等用户动手"——现在只有一种：出价阶段按了【-】暂停。

    这种等待是用户主动的，不算卡死。看门狗要跳过它，
    否则暂停超过"多久没进展算卡死"的分钟数，就会把游戏关掉重启（实测反馈）。
    每日月卡时段（04:50 起等【每日定时点击】跑完 + 2 分钟）也不算卡死：
    最长能守到半小时，不豁免的话「卡死自救」中途就把游戏关了。
    """
    try:
        if _SETTLEMENT_HALL_WAIT[0]:
            return True
        if _DAILY_WAIT[0]:
            return True
        if int(BID_PAUSE_SKIP_ENABLED or 0) != 1:
            return False
        with bid_state_lock:
            return int(bid_interrupt_state) == 1
    except Exception:
        return False


def 异步报警():
    global alarm_stop_flag, alarm_thread
    if not audio_available:
        print("⚠️ 音频系统不可用，跳过警报播放")
        return

    def _play():
        global alarm_stop_flag
        try:
            _alarm_path = 素材路径(ALARM_FILE)
            if not os.path.exists(_alarm_path):
                print(f"⚠️ 警报文件 {ALARM_FILE} 不存在，跳过播放")
                return
            for i in range(ALARM_LOOP):
                if alarm_stop_flag:
                    break
                pygame.mixer.music.load(_alarm_path)
                try:
                    pygame.mixer.music.set_volume(max(0.0, min(1.0, float(ALARM_VOLUME))))
                except Exception:
                    pass
                pygame.mixer.music.play()
                while pygame.mixer.music.get_busy():
                    time.sleep(0.1)
                    if alarm_stop_flag:
                        pygame.mixer.music.stop()
                        break
                if alarm_stop_flag:
                    break
                if i < ALARM_LOOP - 1:
                    time.sleep(0.2)
        except Exception as e:
            print(f"⚠️ 警报播放失败: {e}")
        finally:
            alarm_stop_flag = False

    alarm_stop_flag = False
    alarm_thread = threading.Thread(target=_play, daemon=True)
    alarm_thread.start()


def 停报警():
    global alarm_stop_flag
    alarm_stop_flag = True
    if audio_available:
        pygame.mixer.music.stop()
    print("\n🔇 警报已手动停止！")


# 热键注册 + 松开鼠标，只在**真正运行脚本**时做，不在"被导入"时做。
# 以前这两句写在模块顶层：自检（它要 import 本文件）一跑就会执行一次 pyautogui.mouseUp()，
# 等于把用户正按着的鼠标键松开 —— 实测反馈"自检会抢鼠标"就是这个原因。
if __name__ == "__main__":
    # 启动时给日志瘦一次身。日志是排查问题的第一手材料，但不能无限长 ——
    # 实测 8 天就攒到 85MB，其中一天刷屏刷出 50MB。
    清到容量(LOG_ROOT, LOG_MAX_MB, protect_hours=1)
    # 热键：F10 = 开始挂机，F11 = 安全暂停/继续（按下触发 + 0.35 秒去抖），F12 = 彻底停止。
    # 不用 trigger_on_release：部分环境里单键松开事件收不到。
    # F10/F11/F12 已移到面板进程（面板常驻，全局轮询，不依赖焦点）；脚本进程只留 =/-/\ 这些。
    keyboard.add_hotkey("=", 停报警)
    if BID_PAUSE_SKIP_ENABLED == 1:
        keyboard.add_hotkey("-", 跳过这次出价)
    if CAPTURE_ENABLED == 1:
        for _hk in (CAPTURE_HOTKEY, "\\"):
            try:
                keyboard.add_hotkey(_hk, 现在抓)
                break
            except Exception:
                continue

_HWND_CACHE = None


def 缓存窗口句柄(refresh=False):
    global _HWND_CACHE
    if refresh or _HWND_CACHE is None or not win32gui.IsWindow(_HWND_CACHE):
        _HWND_CACHE = 取窗口句柄()
    else:
        # 缓存里存的是启动器窗口时也要重挑一次：重启流程里启动器先出现、
        # 游戏窗口后出现，缓存一旦停在启动器上，后面整段都会盯着启动器。
        try:
            if "启动器" in (win32gui.GetWindowText(_HWND_CACHE) or ""):
                _HWND_CACHE = 取窗口句柄()
        except Exception:
            pass
    return _HWND_CACHE


def 确保在游戏窗口():
    if ENSURE_FOREGROUND != 1:
        return True
    hwnd = 缓存窗口句柄()
    if hwnd is None:
        return False
    if 窗口提到前面(hwnd):
        return True
    try:
        fg = win32gui.GetForegroundWindow()
        print(
            f"⚠️ 前台窗口是「{win32gui.GetWindowText(fg)}」，不是游戏「{WINDOW_TITLE}」——请点一下游戏画面让它到最前"
        )
    except Exception:
        pass
    return False


@执行游戏动作
def 窗口提到前面(hwnd):
    if hwnd is None or not win32gui.IsWindow(hwnd):
        return False
    try:
        if win32gui.GetForegroundWindow() == hwnd:
            return True
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
            time.sleep(0.25)
        win32api.keybd_event(win32con.VK_MENU, 0, 0, 0)
        win32api.keybd_event(win32con.VK_MENU, 0, win32con.KEYEVENTF_KEYUP, 0)
        win32gui.SetForegroundWindow(hwnd)
        if win32gui.GetForegroundWindow() == hwnd:
            return True
        fg = win32gui.GetForegroundWindow()
        try:
            tid_fg = win32process.GetWindowThreadProcessId(fg)[0]
            tid_me = win32api.GetCurrentThreadId()
            win32process.AttachThreadInput(tid_fg, tid_me, True)
            win32gui.BringWindowToTop(hwnd)
            win32gui.SetForegroundWindow(hwnd)
            win32process.AttachThreadInput(tid_fg, tid_me, False)
        except Exception:
            pass
    except Exception as e:
        print(f"⚠️ 拉起游戏窗口失败: {e}")
    for _ in range(10):
        if win32gui.GetForegroundWindow() == hwnd:
            return True
        time.sleep(0.05)
    return False


def 游戏提窗口(timeout=15, verbose=True):
    if 后台模式开着吗():
        hwnd = 取窗口句柄()
        if hwnd:
            if verbose:
                print("🖥 后台模式：不抢前台（游戏窗口可以一直待在别的窗口后面）")
            return True
    start = time.time()
    while time.time() - start < timeout:
        hwnd = 取窗口句柄()
        if hwnd:
            if 窗口提到前面(hwnd):
                if verbose:
                    print("🪟 已把游戏窗口抓到最前台")
                    try:
                        记回合事件("foreground", human="🪟 已把游戏窗口抓到最前台")
                    except Exception:
                        pass
                return True
            if verbose:
                print("⚠️ 尝试把游戏窗口拉到前台没成功（可能被系统限制），脚本仍会继续")
            return False
        time.sleep(0.5)
    if verbose:
        print(f"⚠️ 等了 {timeout} 秒还是没找到游戏窗口「{WINDOW_TITLE}」")
        try:
            记报错(
                "window_missing",
                f"开始挂机前 {timeout} 秒内没找到游戏窗口「{WINDOW_TITLE}」",
                shot=False,
                throttle=60,
            )
        except Exception:
            pass
    return False
    return False


# ============================================================================
# 后台运行的具体实现
# 截图：不问屏幕，直接向游戏窗口要画面（PrintWindow，只抓客户区）
# → 游戏窗口被浏览器等完全盖住也能读；最小化不行（Windows 的限制）
# 点击：发 WM_ACTIVATE 假激活 → 把真实光标挪到目标 → 发 WM_LBUTTONDOWN/UP
# → 把光标挪回你原来的位置（不抢前台、不会点到你正在用的窗口）
# 这套做法在本机实测通过（1920x1080）。
# ============================================================================
_BG_LOCK = threading.RLock()
_BG_DC = {}
_BG_WARNED = set()
_BG_STATE = {
    "guard_thread": None,
    "guard_stop": None,
    "last_pos": None,
    "was_outside": False,
    "ignore_until": 0.0,
    "capture_n": 0,
    "capture_ms": 0.0,
    "click_n": 0,
    "activate_n": 0,
    "placed": None,
    "prev_sample": None,
    "last_reset": 0.0,
    "fires": [],
    "guard_off_until": 0.0,
}


class _BgBmpHeader(ctypes.Structure):
    _fields_ = [
        ("biSize", ctypes.c_uint32),
        ("biWidth", ctypes.c_int32),
        ("biHeight", ctypes.c_int32),
        ("biPlanes", ctypes.c_uint16),
        ("biBitCount", ctypes.c_uint16),
        ("biCompression", ctypes.c_uint32),
        ("biSizeImage", ctypes.c_uint32),
        ("biXPelsPerMeter", ctypes.c_int32),
        ("biYPelsPerMeter", ctypes.c_int32),
        ("biClrUsed", ctypes.c_uint32),
        ("biClrImportant", ctypes.c_uint32),
    ]


class _BgBmpInfo(ctypes.Structure):
    _fields_ = [("bmiHeader", _BgBmpHeader), ("bmiColors", ctypes.c_uint32 * 3)]


def 后台模式开着吗():
    """后台模式是否真的能用：面板开关开了 + 脚本有管理员权限。
    提权正常的两条路（点我启动.bat 自提权 / 面板启动脚本时 ShellExecute runas）都在，
    所以正常情况一定是管理员；万一用户把 UAC 点了"否"，这里会自动退回前台模式 ——
    否则发给游戏窗口的消息会被 Windows 拦掉，表现成"点了没反应"，
    那还不如老老实实按老办法（真鼠标点击，前台模式不需要管理员）跑。"""
    try:
        want = int(str(BACKGROUND_RUN).strip() or 0) == 1
    except Exception:
        want = False
    if not want:
        return False
    if not 是不是管理员():
        后台模式提示(
            "no_admin",
            "⚠️ 后台模式已开，但脚本不是以管理员身份运行 → 本次自动按【前台模式】跑"
            "（不这样的话发给游戏的消息会被 Windows 拦掉，点了没反应）。"
            "想用后台模式：用『点我启动.bat』启动、UAC 弹窗点【是】。",
        )
        return False
    return True


_IS_ADMIN = [None]


def 是不是管理员():
    """脚本有没有管理员权限（只查一次，缓存起来）"""
    if _IS_ADMIN[0] is None:
        try:
            _IS_ADMIN[0] = bool(ctypes.windll.shell32.IsUserAnAdmin())
        except Exception:
            _IS_ADMIN[0] = False
    return _IS_ADMIN[0]


def 后台模式提示(key, msg):
    """同一条提示只打印一次，免得刷屏"""
    if key not in _BG_WARNED:
        _BG_WARNED.add(key)
        print(msg)


# 颜色自检失败时置 True：之后所有截图都改走"屏幕截图"（前台），
# 因为后台抓图跟屏幕颜色差太多时，模板匹配会大面积失效（实测会卡在仪器页/入场费弹窗）。
# 颜色校准：后台抓图 vs 屏幕截图 的每通道 增益/偏移（校完再拿去匹配，模板就认得到了）
_BG_CAL = {"ok": False, "gain": (1.0, 1.0, 1.0), "offset": (0.0, 0.0, 0.0)}
# 连续认不到模板的次数：连续失败很多次才临时改用前台截图（而不是一有色差就切）
_MATCH_FAIL_STREAK = [0]
# 临时前台截图（配合上面的失败计数：认到了就退回后台）
_FORCE_FOREGROUND_SHOT = [False]


def _apply_bg_cal(arr):
    """把后台截图的颜色按校准参数拉回屏幕颜色（BGR）。"""
    try:
        if not _BG_CAL["ok"] or arr is None:
            return arr
        g = _BG_CAL["gain"]
        o = _BG_CAL["offset"]
        out = arr.astype(np.float32)
        out[:, :, 0] = out[:, :, 0] * g[0] + o[0]
        out[:, :, 1] = out[:, :, 1] * g[1] + o[1]
        out[:, :, 2] = out[:, :, 2] * g[2] + o[2]
        return np.clip(out, 0, 255).astype(np.uint8)
    except Exception:
        return arr


def 后台取色检查():
    """后台抓图 和 屏幕截图 比一比颜色：开了 HDR / 显卡滤镜 / 护眼模式时两者会不一样，
    照出来的图跟模板对不上、识别率就会掉。只在游戏当前没被遮挡时检查（否则没法比）。"""
    if not 后台模式开着吗():
        return
    try:
        hwnd = 缓存窗口句柄()
        win = 游戏窗口范围()
        if not hwnd or win is None:
            return
        if win32gui.GetForegroundWindow() != hwnd:
            print(
                "   🎨 颜色自检：游戏不在最前台（被别的窗口盖着），跳过——"
                "后台模式本来就不需要它在前台"
            )
            return
        arr = 后台截图(hwnd)
        if arr is None:
            print("   🎨 颜色自检：拿不到后台画面，跳过")
            return
        shot = pyautogui.screenshot(region=(win[0], win[1], win[2], win[3]))
        scr = np.ascontiguousarray(np.array(shot)[:, :, ::-1])
        if scr.shape != arr.shape:
            print("   🎨 颜色自检：两种截图尺寸不一样（%s / %s），跳过" % (arr.shape, scr.shape))
            return
        diff = float(np.abs(arr.astype(np.int16) - scr.astype(np.int16)).mean())
        b1, b2 = float(arr.mean()), float(scr.mean())
        print(
            "   🎨 颜色自检：后台抓图 vs 屏幕截图 = 平均色差 %.1f（亮度 %.0f 对 %.0f）"
            % (diff, b1, b2)
        )
        if diff > 25 or abs(b1 - b2) > 30:
            # 不做"一有色差就切前台"了：先算每通道的增益/偏移，把后台图颜色拉回屏幕颜色。
            try:
                _g, _o = [], []
                for ch in range(3):
                    a = arr[:, :, ch].astype(np.float32)
                    b = scr[:, :, ch].astype(np.float32)
                    am, bm = float(a.mean()), float(b.mean())
                    asd, bsd = float(a.std()), float(b.std())
                    gain = (bsd / asd) if asd > 1.0 else 1.0
                    gain = max(0.5, min(2.0, gain))
                    _g.append(gain)
                    _o.append(bm - gain * am)
                _BG_CAL["gain"] = tuple(_g)
                _BG_CAL["offset"] = tuple(_o)
                _BG_CAL["ok"] = True
                print(
                    "   🎨 已建立颜色校准：增益 (%.2f, %.2f, %.2f)｜偏移 (%.0f, %.0f, %.0f)"
                    % (_g[0], _g[1], _g[2], _o[0], _o[1], _o[2])
                )
                _cal = _apply_bg_cal(arr)
                _diff2 = float(
                    np.abs(_cal.astype(np.int16) - scr.astype(np.int16)).mean()
                )
                print("   🎨 校准后色差：%.1f（校准前 %.1f）" % (_diff2, diff))
                if _diff2 <= 25:
                    print("   ✅ 颜色已经对齐，后台模式照常用（不用切前台）")
                else:
                    print(
                        "   ⚠️ 校准后差别仍偏大（可能是 HDR 这类非线性变化）。"
                        "先继续用后台；只有连续认不到模板时才会临时切前台截图。"
                    )
            except Exception as _ec:
                print(f"   ⚠️ 颜色校准失败（继续原样用后台截图）: {_ec}")
            记报错(
                "bg_color_mismatch",
                "后台抓图与屏幕截图颜色差异偏大（HDR/滤镜/护眼模式？）",
                shot=False,
                throttle=600,
            )
        else:
            print("   ✅ 两者一致，后台模式不会影响识图")
    except Exception as e:
        print("   🎨 颜色自检跳过：%s" % e)


def 后台释放画布():
    with _BG_LOCK:
        c = _BG_DC
        try:
            if c.get("bmp"):
                ctypes.windll.gdi32.DeleteObject(c["bmp"])
            if c.get("mdc"):
                ctypes.windll.gdi32.DeleteDC(c["mdc"])
            if c.get("hdc") and c.get("hwnd"):
                ctypes.windll.user32.ReleaseDC(c["hwnd"], c["hdc"])
        except Exception:
            pass
        c.clear()


# 截图耗时统计（只统计 PrintWindow；BitBlt 快通道已按用户要求移除）
_BG_FAST = {"pw_ms": 0.0, "pw_n": 0}


def 后台截图(hwnd):
    """向游戏窗口要画面：PrintWindow(flag=3 = 只抓客户区 + 渲染全部内容)。
    返回 BGR numpy (h,w,3)；窗口最小化/不可见/失败时返回 None。
    实测：被别的窗口完全盖住照样能拿到实时画面。"""
    try:
        if not win32gui.IsWindow(hwnd) or win32gui.IsIconic(hwnd):
            return None
        r = win32gui.GetClientRect(hwnd)
        w, h = int(r[2] - r[0]), int(r[3] - r[1])
        if w <= 0 or h <= 0:
            return None
        t0 = time.time()
        with _BG_LOCK:
            c = _BG_DC
            if c.get("hwnd") != hwnd or c.get("w") != w or c.get("h") != h:
                后台释放画布()
                hdc = ctypes.windll.user32.GetWindowDC(hwnd)
                mdc = ctypes.windll.gdi32.CreateCompatibleDC(hdc)
                bmp = ctypes.windll.gdi32.CreateCompatibleBitmap(hdc, w, h)
                c.update({"hwnd": hwnd, "w": w, "h": h, "hdc": hdc, "mdc": mdc, "bmp": bmp})
            old = ctypes.windll.gdi32.SelectObject(c["mdc"], c["bmp"])
            _tp = time.time()
            ok = ctypes.windll.user32.PrintWindow(hwnd, c["mdc"], 3)
            if ok:
                _BG_FAST["pw_n"] += 1
                _BG_FAST["pw_ms"] = (_BG_FAST["pw_ms"] * 0.8
                                     + (time.time() - _tp) * 1000.0 * 0.2)
            bi = _BgBmpInfo()
            hdr = bi.bmiHeader
            hdr.biSize = ctypes.sizeof(_BgBmpHeader)
            hdr.biWidth = w
            hdr.biHeight = -h  # 负数 = 从上到下，不镜像
            hdr.biPlanes = 1
            hdr.biBitCount = 32
            hdr.biCompression = 0
            buf = ctypes.create_string_buffer(w * h * 4)
            ctypes.windll.gdi32.GetDIBits(c["mdc"], c["bmp"], 0, h, buf, ctypes.byref(bi), 0)
            ctypes.windll.gdi32.SelectObject(c["mdc"], old)
        if not ok:
            return None
        # DIB 里的字节顺序是 B,G,R,A —— 只取前三个就是 BGR（和 pyautogui 那条路一致）。
        # 原来这里写的是 [:, :, 2::-1]，那是 RGB；下游又按 BGR 用，
        # 结果后台模式下所有截图都变成 R/B 反的（用纯蓝窗口实测出来的）。
        arr = np.frombuffer(buf, dtype=np.uint8).reshape(h, w, 4)[:, :, :3].copy()
        arr = _apply_bg_cal(arr)
        _BG_STATE["capture_n"] += 1
        _BG_STATE["capture_ms"] += (time.time() - t0) * 1000.0
        # 每 200 次打一行截图统计，方便确认快通道有没有在起作用
        try:
            _n = _BG_FAST["pw_n"]
            if _n and _n % 200 == 0:
                print("📸 截图统计：PrintWindow %d 次（均 %.0f ms）"
                      % (_BG_FAST["pw_n"], _BG_FAST["pw_ms"]))
        except Exception:
            pass
        return arr
    except Exception as e:
        后台模式提示("cap_err", f"⚠️ 后台截图异常，这次退回普通截图：{e}")
        后台释放画布()
        return None


def 抓一帧(region=None):
    """统一截图入口：返回 PIL 图片（RGB），和 pyautogui.screenshot 完全一致。

    优先用 PrintWindow 向游戏窗口要"客户区"画面（这个操作不需要管理员权限）。
    以前 region=None 时一律走 pyautogui 全屏截图 —— 在 4K + 200% 缩放的机器上
    会截出 3840x2160（模板是 1920 尺度），于是所有模板都对不上，
    表现为"明明在大厅却说不在大厅""仓库只抓到 1 页"（实测踩过）。
    """
    if region is None and not _FORCE_FOREGROUND_SHOT[0]:
        try:
            hwnd = 缓存窗口句柄()
            if hwnd:
                arr = 后台截图(hwnd)
                if arr is not None:
                    # 有些机器（4K + 缩放）PrintWindow 会给 2 倍尺寸，而模板是 1920 尺度的，
                    # 不缩回来所有模板都对不上 → 按客户区尺寸缩一次。
                    try:
                        _win = 游戏窗口范围()
                        if _win is not None:
                            _cw, _ch = int(_win[2]), int(_win[3])
                            _H, _W = arr.shape[:2]
                            if _cw > 0 and _ch > 0 and (_W != _cw or _H != _ch):
                                import cv2 as _cv2
                                arr = _cv2.resize(arr, (_cw, _ch), interpolation=_cv2.INTER_AREA)
                                if not globals().get("_SIZE_FIX_WARNED"):
                                    globals()["_SIZE_FIX_WARNED"] = True
                                    print(f"🖼️ 截图尺寸 {_W}x{_H} → 按客户区缩放到 {_cw}x{_ch}（模板是 1920 尺度）")
                    except Exception:
                        pass
                    from PIL import Image as _PILImage
                    return _PILImage.fromarray(np.ascontiguousarray(arr[:, :, ::-1]))
        except Exception as e:
            后台模式提示("shot_err_full", f"⚠️ 客户区截图失败，这次退回普通截图：{e}")
    if region is not None and 后台模式开着吗() and not _FORCE_FOREGROUND_SHOT[0]:
        try:
            hwnd = 缓存窗口句柄()
            win = 游戏窗口范围() if hwnd else None
            if hwnd and win:
                arr = 后台截图(hwnd)
                if arr is not None:
                    H, W = arr.shape[:2]
                    cw, ch = int(region[2]), int(region[3])
                    if cw > 0 and ch > 0:
                        cx, cy = int(region[0] - win[0]), int(region[1] - win[1])
                        x0, y0 = max(0, cx), max(0, cy)
                        x1, y1 = min(W, cx + cw), min(H, cy + ch)
                        tile = np.zeros((ch, cw, 3), np.uint8)
                        if x1 > x0 and y1 > y0:
                            tile[y0 - cy : y0 - cy + (y1 - y0), x0 - cx : x0 - cx + (x1 - x0)] = (
                                arr[y0:y1, x0:x1]
                            )
                        from PIL import Image as _PILImage

                        return _PILImage.fromarray(np.ascontiguousarray(tile[:, :, ::-1]))
        except Exception as e:
            后台模式提示("shot_err", f"⚠️ 后台截图失败，这次退回普通截图：{e}")
    if region:
        # 前台模式是"截屏幕"，游戏被别人窗口盖住就会截到别人的画面 → 先把它提到最前
        if not 后台模式开着吗():
            try:
                _now = time.time()
                if _now - float(globals().get("_FG_RAISE_TS", 0.0)) > 2.0:
                    globals()["_FG_RAISE_TS"] = _now
                    _hwnd = 缓存窗口句柄()
                    if _hwnd:
                        窗口提到前面(_hwnd)
            except Exception:
                pass
        return pyautogui.screenshot(region=region)
    # 普通截图兜底：4K + 缩放机器上 pyautogui 给的是物理分辨率（比如 3840x2160），
    # 而模板和窗口坐标都是逻辑尺度（1920x1080）→ 这里按比例裁出客户区再缩回来。
    shot = pyautogui.screenshot()
    try:
        import ctypes as _ct
        win = 游戏窗口范围()
        _sw = int(_ct.windll.user32.GetSystemMetrics(0)) or shot.width
        if win and _sw > 0 and (shot.width != int(win[2]) or shot.height != int(win[3])):
            _scale = shot.width / float(_sw)
            _l, _t, _w, _h = (int(win[0] * _scale), int(win[1] * _scale),
                              int(win[2] * _scale), int(win[3] * _scale))
            from PIL import Image as _PILImg
            _resample = getattr(_PILImg, "LANCZOS", None) or getattr(_PILImg, "BILINEAR")
            _crop = shot.crop((_l, _t, _l + _w, _t + _h)).resize(
                (int(win[2]), int(win[3])), _resample)
            if not globals().get("_SIZE_FIX_WARNED"):
                globals()["_SIZE_FIX_WARNED"] = True
                print(f"🖼️ 整屏截图 {shot.width}x{shot.height} → 裁客户区并缩放到 "
                      f"{int(win[2])}x{int(win[3])}（模板是 1920 尺度）")
            return _crop
    except Exception as _e:
        if not globals().get("_SIZE_FIX_ERR"):
            globals()["_SIZE_FIX_ERR"] = True
            print(f"⚠️ 截图裁剪失败（按原图返回）：{_e}")
    return shot


@执行游戏动作
def 后台拖拽(x1, y1, x2, y2, steps=14, gap=0.02):
    """Release the held game button even if a drag is interrupted."""
    hwnd = 缓存窗口句柄()
    win = 游戏窗口范围()
    if not hwnd or win is None:
        return False
    if CURSOR_YIELD_USER and not 后台鼠标空闲():
        后台模式提示("cursor_busy", "⏸️ 你正在使用鼠标，暂停后台拖拽")
        return False
    left, top = win[:2]
    old = win32api.GetCursorPos() if CURSOR_RESTORE else None
    placed = None
    pressed = False
    try:
        后台激活(hwnd)
        if not 后台移鼠标(x1, y1, tries=1, wait_idle=False):
            return False
        placed = (x1, y1)
        if not 后台确保鼠标(*placed):
            return False
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON,
                             win32api.MAKELONG(x1 - left, y1 - top))
        pressed = True
        steps = max(2, int(steps))
        for index in range(1, steps + 1):
            if not running or not 后台确保鼠标(*placed):
                return False
            x = round(x1 + (x2 - x1) * index / steps)
            y = round(y1 + (y2 - y1) * index / steps)
            if not 后台移鼠标(x, y, tries=1, wait_idle=False, expected=placed):
                return False
            placed = (x, y)
            win32gui.PostMessage(hwnd, win32con.WM_MOUSEMOVE, win32con.MK_LBUTTON,
                                 win32api.MAKELONG(x - left, y - top))
            time.sleep(gap)
        return 后台确保鼠标(*placed)
    except Exception as exc:
        print(f"⚠️ 后台拖拽失败: {exc}")
        return False
    finally:
        if pressed:
            try:
                win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0,
                                     win32api.MAKELONG(placed[0] - left, placed[1] - top))
            except Exception as exc:
                print(f"⚠️ 释放后台拖拽失败: {exc}")
        if placed is not None:
            后台还鼠标(old, placed)


def 后台标记自己(seconds=0.15):
    """告诉"防吸鼠标"线程：接下来这点时间是我自己在挪光标，别管"""
    _BG_STATE["ignore_until"] = time.time() + seconds


def 后台移鼠标(x, y, tries=3, wait_idle=True, expected=None):
    """把真实鼠标挪到 (x,y) 并回读校验（游戏只认真实光标位置，挪不到就点不中）"""
    # 初次移动检查按键状态，拖拽中的每一段也检查真实输入和上一次位置。
    if not _鼠标动作仍有效() or (wait_idle and not 后台鼠标空闲()):
        后台模式提示("cursor_busy", "⏸️ 你正在使用鼠标，等待后重新识别游戏画面")
        return False
    try:
        # 按整个虚拟桌面裁坐标，不再裁到主屏 0..W/H。
        # 游戏放在左侧负坐标显示器、右侧副屏或超宽屏时都能正常移动鼠标。
        vx = win32api.GetSystemMetrics(win32con.SM_XVIRTUALSCREEN)
        vy = win32api.GetSystemMetrics(win32con.SM_YVIRTUALSCREEN)
        vw = win32api.GetSystemMetrics(win32con.SM_CXVIRTUALSCREEN)
        vh = win32api.GetSystemMetrics(win32con.SM_CYVIRTUALSCREEN)
        if vw <= 0 or vh <= 0:
            vx = vy = 0
            vw = win32api.GetSystemMetrics(win32con.SM_CXSCREEN)
            vh = win32api.GetSystemMetrics(win32con.SM_CYSCREEN)
        tx = max(int(vx), min(int(x), int(vx) + int(vw) - 1))
        ty = max(int(vy), min(int(y), int(vy) + int(vh) - 1))
    except Exception:
        tx, ty = int(x), int(y)
    for _i in range(max(1, tries)):
        if not _鼠标动作仍有效():
            return False
        try:
            if expected is not None and win32api.GetCursorPos() != expected:
                return False
            后台标记自己()
            _校准鼠标采样((tx, ty))
            win32api.SetCursorPos((tx, ty))
            time.sleep(0.01)
            cur = win32api.GetCursorPos()
            if abs(int(cur[0]) - tx) <= 2 and abs(int(cur[1]) - ty) <= 2:
                _BG_STATE["placed"] = (tx, ty)
                return True
        except Exception:
            pass
        time.sleep(0.05)
    return False


_USER_MOUSE_IDLE_SECONDS = 0.12
_USER_MOUSE_MOVE_PIXELS = 16
_USER_MOUSE_MOVE_WINDOW = 0.12
_USER_MOUSE_LAST = float("-inf")
_USER_MOUSE_MOVE_ANCHOR = None
_USER_MOUSE_PREV_POINT = None
_USER_MOUSE_OUTSIDE_HELD = set()
_USER_MOUSE_LEFT_DOWN = False
_USER_MOUSE_EPOCH = 0
_MOUSE_FLOW_EPOCH = 0
_MOUSE_VERIFIED = threading.local()
_USER_MOUSE_READY = threading.Event()
_USER_MOUSE_THREAD = None
_USER_MOUSE_LOCK = threading.Lock()


def _校准鼠标采样(point):
    global _USER_MOUSE_PREV_POINT, _USER_MOUSE_MOVE_ANCHOR
    _USER_MOUSE_PREV_POINT = tuple(point)
    _USER_MOUSE_MOVE_ANCHOR = None


def _记录用户鼠标(message, point, data, now):
    global _USER_MOUSE_LAST, _USER_MOUSE_LEFT_DOWN, _USER_MOUSE_MOVE_ANCHOR
    global _USER_MOUSE_EPOCH, _USER_MOUSE_PREV_POINT
    if message == win32con.WM_MOUSEMOVE:
        anchor = _USER_MOUSE_MOVE_ANCHOR
        if anchor is None or now - anchor[0] > _USER_MOUSE_MOVE_WINDOW:
            _USER_MOUSE_MOVE_ANCHOR = (now, _USER_MOUSE_PREV_POINT or point)
            anchor = _USER_MOUSE_MOVE_ANCHOR
        _USER_MOUSE_PREV_POINT = point
        distance = max(abs(point[0] - anchor[1][0]), abs(point[1] - anchor[1][1]))
        if distance >= _USER_MOUSE_MOVE_PIXELS or now - _USER_MOUSE_LAST < _USER_MOUSE_IDLE_SECONDS:
            _USER_MOUSE_LAST = now
            _USER_MOUSE_EPOCH += 1
        return
    buttons = {
        0x0201: (1, True), 0x0202: (1, False),
        0x0204: (2, True), 0x0205: (2, False),
        0x0207: (3, True), 0x0208: (3, False),
        0x020B: (3 + (data >> 16), True), 0x020C: (3 + (data >> 16), False),
    }
    if message not in buttons and message not in (0x020A, 0x020E):
        return
    key, down = buttons.get(message, (0, True))
    if key == 1:
        _USER_MOUSE_LEFT_DOWN = down
    if not down:
        if key in _USER_MOUSE_OUTSIDE_HELD:
            _USER_MOUSE_OUTSIDE_HELD.discard(key)
            _USER_MOUSE_LAST = now
        return
    # 游戏内手动点击也会改变画面，要作废旧坐标，但不启动窗口外的让行等待。
    _USER_MOUSE_EPOCH += 1
    try:
        target = win32gui.WindowFromPoint(point)
        inside_game = bool(_HWND_CACHE and target and (
            target == _HWND_CACHE or win32gui.IsChild(_HWND_CACHE, target)))
    except Exception:
        inside_game = False
    if not inside_game:
        if key:
            _USER_MOUSE_OUTSIDE_HELD.add(key)
        _USER_MOUSE_LAST = now


def _鼠标动作仍有效():
    if not CURSOR_YIELD_USER:
        return True
    expected = getattr(_MOUSE_VERIFIED, "epoch", _MOUSE_FLOW_EPOCH)
    return expected == _USER_MOUSE_EPOCH and not _近期有用户输入()


@contextmanager
def _已核对鼠标画面(epoch):
    previous = getattr(_MOUSE_VERIFIED, "epoch", None)
    _MOUSE_VERIFIED.epoch = epoch
    try:
        yield
    finally:
        if previous is None:
            del _MOUSE_VERIFIED.epoch
        else:
            _MOUSE_VERIFIED.epoch = previous


def _按新画面点击(x, y, epoch):
    if not CURSOR_YIELD_USER:
        return 安全点击(x, y)
    if epoch != _USER_MOUSE_EPOCH:
        _BG_STATE["click_outcome"] = "yielded"
        return False
    with _已核对鼠标画面(epoch):
        _BG_STATE["click_epoch"] = epoch
        return 安全点击(x, y)


def _等鼠标让行结束(check_bid_pause=False):
    """只等待当前鼠标动作；结束后由调用者重新截图。"""
    while running and CURSOR_YIELD_USER and _近期有用户输入():
        if check_bid_pause:
            status = 暂停时等着()
            if status in ("STOP", "SKIP"):
                return status
        轮询面板控件()
        time.sleep(0.025)
    return "READY" if running else "STOP"


def _用户鼠标消息循环():
    """只记录最近一次物理鼠标输入的时间，原样转发所有事件。"""
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    callback_type = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_int,
                                      wintypes.WPARAM, wintypes.LPARAM)

    class MouseEvent(ctypes.Structure):
        _fields_ = [("point", wintypes.POINT), ("data", wintypes.DWORD),
                    ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("extra", ctypes.c_size_t)]

    user32.SetWindowsHookExW.argtypes = (ctypes.c_int, callback_type, wintypes.HINSTANCE, wintypes.DWORD)
    user32.SetWindowsHookExW.restype = wintypes.HANDLE
    user32.CallNextHookEx.argtypes = (wintypes.HANDLE, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    user32.CallNextHookEx.restype = ctypes.c_ssize_t
    user32.UnhookWindowsHookEx.argtypes = (wintypes.HANDLE,)
    user32.UnhookWindowsHookEx.restype = wintypes.BOOL

    @callback_type
    def on_mouse(code, message, lparam):
        if code >= 0 and lparam:
            event = ctypes.cast(lparam, ctypes.POINTER(MouseEvent)).contents
            if not event.flags & 0x01:  # LLMHF_INJECTED
                try:
                    _记录用户鼠标(message, (event.point.x, event.point.y), event.data, time.monotonic())
                except Exception:
                    pass
        return user32.CallNextHookEx(None, code, message, lparam)

    hook = user32.SetWindowsHookExW(14, on_mouse, win32api.GetModuleHandle(None), 0)  # WH_MOUSE_LL
    if not hook:
        return
    try:
        _USER_MOUSE_READY.set()
        win32gui.PumpMessages()
    finally:
        _USER_MOUSE_READY.clear()
        user32.UnhookWindowsHookEx(hook)


def _启动鼠标输入监测():
    global _USER_MOUSE_THREAD
    if _USER_MOUSE_THREAD is None:
        with _USER_MOUSE_LOCK:
            if _USER_MOUSE_THREAD is None:
                try:
                    _校准鼠标采样(win32api.GetCursorPos())
                except Exception:
                    pass
                _USER_MOUSE_THREAD = threading.Thread(target=_用户鼠标消息循环,
                                                     daemon=True, name="鼠标输入监测")
                _USER_MOUSE_THREAD.start()


def _近期有用户输入():
    if not CURSOR_YIELD_USER:
        return False
    _启动鼠标输入监测()
    if not _USER_MOUSE_READY.is_set():
        # 会话级 GetLastInputInfo 会把脚本点击及键盘也算进来，改用光标位移兜底。
        try:
            point = tuple(win32api.GetCursorPos())
            if point != _USER_MOUSE_PREV_POINT:
                _记录用户鼠标(win32con.WM_MOUSEMOVE, point, 0, time.monotonic())
        except Exception:
            pass
    return bool(_USER_MOUSE_OUTSIDE_HELD) or time.monotonic() - _USER_MOUSE_LAST < _USER_MOUSE_IDLE_SECONDS


def 后台鼠标空闲():
    if not CURSOR_YIELD_USER:
        return True
    try:
        return (not _近期有用户输入()
                and not any(win32api.GetAsyncKeyState(key) & 0x8000 for key in (1, 2, 4, 5, 6)))
    except Exception:
        return False


def 后台还鼠标(old, placed=None):
    """把光标还回去——但**只在指针还老老实实停在我们放的位置时**。
    如果你自己动了鼠标（说明你正在用），就绝对不碰它、把控制权留给你，
    免得出现"脚本跟人抢鼠标"的手感。"""
    if old is None or not _鼠标动作仍有效() or not 后台鼠标空闲():
        return
    try:
        placed = placed or _BG_STATE.get("placed")
        cur = win32api.GetCursorPos()
        if placed is not None and (
            abs(int(cur[0]) - int(placed[0])) > 4 or abs(int(cur[1]) - int(placed[1])) > 4
        ):
            后台模式提示(
                "cursor_yours",
                "🖱️ 检测到你自己在动鼠标：本次不把指针拉回原位（你在用的时候脚本不会跟你抢）",
            )
            return
        if not _近期有用户输入():
            后台标记自己()
            _校准鼠标采样(old)
            win32api.SetCursorPos(old)
    except Exception:
        pass


def 后台激活(hwnd):
    """给游戏窗口发一条"你被激活了"的假消息（你桌面上真正的前台窗口不变、不会被抢）"""
    if int(BACKGROUND_ACTIVATE) != 1:
        return
    try:
        if win32gui.GetForegroundWindow() == hwnd:
            return
        win32gui.SendMessage(hwnd, win32con.WM_ACTIVATE, win32con.WA_ACTIVE, 0)
        _BG_STATE["activate_n"] += 1
    except Exception as e:
        后台模式提示(
            "act_err", f"⚠️ 后台假激活失败（游戏可能不认后台点击，请确认脚本是管理员运行）：{e}"
        )


@执行游戏动作
def 后台按键(vk, hwnd=None):
    """后台按一个键：往游戏窗口发 WM_KEYDOWN/WM_KEYUP（带扫描码），
    完全不动你的键盘；前台模式下才用真键盘。
    做法同 ok-nte / Noki 两个脚本（lParam 里必须带扫描码，否则游戏不认）。"""
    hwnd = hwnd or 缓存窗口句柄()
    if not hwnd or not win32gui.IsWindow(hwnd):
        return False
    try:
        后台激活(hwnd)
        scan = win32api.MapVirtualKey(int(vk), 0)
        down = (int(scan) << 16) | 1
        up = down | (1 << 30) | (1 << 31)
        win32gui.PostMessage(hwnd, win32con.WM_KEYDOWN, int(vk), down)
        time.sleep(0.05)
        win32gui.PostMessage(hwnd, win32con.WM_KEYUP, int(vk), up)
        return True
    except Exception as e:
        后台模式提示("key_err", f"⚠️ 后台按键失败，已退回真键盘：{e}")
        return False


def 后台确保鼠标(x, y, tol=4):
    """确认光标仍停在目标，发生争用时让行。"""
    if not _鼠标动作仍有效():
        return False
    try:
        cx, cy = win32api.GetCursorPos()
        return abs(cx - int(x)) <= tol and abs(cy - int(y)) <= tol
    except Exception:
        return False


def _松开前台鼠标():
    # 如果用户已经按住左键，交给用户自己的抬键事件来结束按下状态。
    if CURSOR_YIELD_USER and _USER_MOUSE_READY.is_set() and _USER_MOUSE_LEFT_DOWN:
        return
    try:
        win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
    except Exception as exc:
        print(f"⚠️ 释放前台鼠标失败：{exc}")


@执行游戏动作
def _前台点击(x, y, *, pre, hold, post, raise_game=False):
    _BG_STATE["click_outcome"] = "yielded"
    if not running or not 后台鼠标空闲():
        后台模式提示("cursor_busy", "⏸️ 你正在使用鼠标，已让行")
        return False
    pressed = False
    try:
        if raise_game and not 确保在游戏窗口():
            return False
        pyautogui.failSafeCheck()
        if not 后台移鼠标(x, y, tries=1):
            return False
        time.sleep(pre)
        if not running or not 后台确保鼠标(x, y):
            return False
        _BG_STATE["click_outcome"] = "uncertain"
        pyautogui.mouseDown(_pause=False)
        pressed = True
        time.sleep(hold)
        if running and 后台确保鼠标(x, y):
            _BG_STATE["click_outcome"] = "posted"
            return True
        return False
    except Exception as exc:
        print(f"⚠️ 前台点击失败：{exc}")
        return False
    finally:
        if pressed:
            _松开前台鼠标()
            if post > 0:
                time.sleep(post)


@执行游戏动作
def 前台拖拽(x1, y1, x2, y2, steps=12, gap=0.025):
    if not running or not 后台鼠标空闲() or not 确保在游戏窗口():
        return False
    pressed = False
    placed = (int(x1), int(y1))
    try:
        pyautogui.failSafeCheck()
        if not 后台移鼠标(*placed, tries=1) or not 后台确保鼠标(*placed):
            return False
        pyautogui.mouseDown(_pause=False)
        pressed = True
        for index in range(1, steps + 1):
            if not running or not 后台确保鼠标(*placed):
                return False
            x = round(x1 + (x2 - x1) * index / steps)
            y = round(y1 + (y2 - y1) * index / steps)
            if not 后台移鼠标(x, y, tries=1, wait_idle=False, expected=placed):
                return False
            placed = (x, y)
            time.sleep(gap)
        return 后台确保鼠标(*placed)
    except Exception as exc:
        print(f"⚠️ 前台拖拽失败：{exc}")
        return False
    finally:
        if pressed:
            _松开前台鼠标()


@执行游戏动作
def 前台滚轮(x, y, clicks):
    if not running or not 后台鼠标空闲() or not 确保在游戏窗口():
        return False
    try:
        pyautogui.failSafeCheck()
        if not 后台移鼠标(x, y, tries=1) or not 后台确保鼠标(x, y):
            return False
        win32api.mouse_event(win32con.MOUSEEVENTF_WHEEL, 0, 0, int(clicks) * 120, 0)
        return True
    except Exception as exc:
        print(f"⚠️ 前台滚轮失败：{exc}")
        return False


def 前台点一次(x, y, note=""):
    pre, hold, post, _ = 点击节奏()
    ok = _前台点击(x, y, pre=pre, hold=hold, post=post, raise_game=True)
    if ok and note:
        后台模式提示("click_fg_fallback", "ℹ️ " + note)
    return ok


@执行游戏动作
def 后台点击(x, y, hold=None, restore=None, wait_idle=True):
    """后台点击：假激活 → 挪真实光标 → 发按下/弹起消息 → 光标还原

    连续点击同样检查用户输入，空闲检查无需阻塞等待。
    """
    _BG_STATE["click_outcome"] = "unavailable"
    hwnd = 缓存窗口句柄()
    win = 游戏窗口范围()
    if not hwnd or win is None:
        return False
    if not (0 <= x - win[0] < win[2] and 0 <= y - win[1] < win[3]):
        return False
    hold = None if hold is None else float(hold)
    do_restore = int(CURSOR_RESTORE if restore is None else restore) == 1
    old = None
    ok = False
    placed = None
    if CURSOR_YIELD_USER and not 后台鼠标空闲():
        _BG_STATE["click_outcome"] = "yielded"
        后台模式提示("cursor_busy", "⏸️ 你正在使用鼠标，等待后重新识别游戏画面")
        return False
    try:
        if do_restore:
            old = win32api.GetCursorPos()
        后台激活(hwnd)
        if not 后台移鼠标(x, y, tries=1 if CURSOR_YIELD_USER else 3, wait_idle=False):
            _BG_STATE["click_outcome"] = "yielded"
            后台模式提示("mv_err", "⚠️ 后台点击：鼠标指针挪不过去（被别的程序锁住了？），这次跳过不点")
            return False
        placed = (x, y)
        _pre, _hold, _post, _glide = 点击节奏()
        if hold is None:
            hold = _hold
        time.sleep(float(_pre))
        # "优先保证脚本点击"：发消息前再对一次位置，
        #   防你刚好动了鼠标 → 这一下点到你的位置（等于白点）。
        if not 后台确保鼠标(x, y):
            _BG_STATE["click_outcome"] = "yielded"
            后台模式提示("mv_drift", "⚠️ 后台点击：发消息前光标被挪走了 → 这次跳过不点")
            return False
        lp = win32api.MAKELONG(int(x) - int(win[0]), int(y) - int(win[1]))
        _BG_STATE["click_outcome"] = "uncertain"
        win32gui.PostMessage(hwnd, win32con.WM_LBUTTONDOWN, win32con.MK_LBUTTON, lp)
        try:
            time.sleep(hold)
            drifted = not 后台确保鼠标(x, y)
        finally:
            win32gui.PostMessage(hwnd, win32con.WM_LBUTTONUP, 0, lp)
        if drifted:
            后台模式提示("cursor_busy", "⏸️ 点击时鼠标被移动，结果待确认")
            return False
        time.sleep(float(_post))
        ok = True
        _BG_STATE["click_outcome"] = "posted"
        _BG_STATE["click_n"] += 1
    except Exception as e:
        print(f"⚠️ 后台点击失败: {e}")
    finally:
        if placed is not None:
            后台还鼠标(old, placed)
    return ok


@执行游戏动作
def 后台滚轮(x, y, clicks):
    """后台滚轮（注意：WM_MOUSEWHEEL 的坐标要用屏幕坐标）"""
    hwnd = 缓存窗口句柄()
    if not hwnd:
        return False
    if CURSOR_YIELD_USER and not 后台鼠标空闲():
        return False
    placed = None
    old = win32api.GetCursorPos() if int(CURSOR_RESTORE) == 1 else None
    try:
        后台激活(hwnd)
        if not 后台移鼠标(x, y, tries=1, wait_idle=False):
            return False
        placed = (x, y)
        time.sleep(0.03)
        if not 后台确保鼠标(*placed):
            return False
        lp = win32api.MAKELONG(int(x), int(y))
        # 滚轮一个"格"的 delta 必须是 ±120；以前直接把 clicks 当 delta 传，
        # 等于只滚了 3/120 格 → 游戏根本没动（这就是藏品仓库翻不动页的原因）。
        _delta = int(round(float(clicks) * 120))
        win32gui.PostMessage(hwnd, win32con.WM_MOUSEWHEEL, win32api.MAKELONG(0, _delta), lp)
        time.sleep(0.05)
        return True
    except Exception as e:
        print(f"⚠️ 后台滚轮失败: {e}")
        return False
    finally:
        if placed is not None:
            后台还鼠标(old, placed)


@执行游戏动作
def 后台拖动(x1, y1, x2, y2, steps=12, gap=0.03):
    return 后台拖拽(x1, y1, x2, y2, steps=steps, gap=gap)


def 后台守护循环():
    """异环在后台会把鼠标指针【瞬间搬】到屏幕中心。
    这个线程只处理这一种情况：指针在两次采样之间（20ms）被瞬移进中心区。
    你自己把鼠标移过去、或者在中心区里动，它都不会碰（早期版本只要指针到中心
    就拉回去，等于跟你抢鼠标，这里已经改掉）。连续触发多次还会自动停手 30 秒。"""
    while not _BG_STATE["guard_stop"].is_set():
        try:
            if int(CURSOR_STEAL_GUARD) == 1 and time.time() >= _BG_STATE["guard_off_until"]:
                hwnd = 缓存窗口句柄()
                if (
                    hwnd
                    and win32gui.IsWindow(hwnd)
                    and not win32gui.IsIconic(hwnd)
                    and win32gui.GetForegroundWindow() != hwnd
                ):
                    win = 游戏窗口范围()
                    if win and win[2] > 0 and win[3] > 0:
                        cx = win[0] + win[2] / 2.0
                        cy = win[1] + win[3] / 2.0
                        lim = max(8.0, min(win[2], win[3]) * 0.015)
                        pos = win32api.GetCursorPos()
                        now = time.time()
                        prev = _BG_STATE.get("prev_sample")
                        jump = 0
                        if prev:
                            jump = max(abs(int(pos[0]) - prev[0]), abs(int(pos[1]) - prev[1]))
                        _BG_STATE["prev_sample"] = (int(pos[0]), int(pos[1]))
                        inside = abs(pos[0] - cx) <= lim and abs(pos[1] - cy) <= lim
                        if not inside:
                            _BG_STATE["last_pos"] = (int(pos[0]), int(pos[1]))
                            _BG_STATE["was_outside"] = True
                        else:
                            teleported = jump >= 150  # 20ms 内跳这么远 = 不是你手动的
                            cooled = (now - _BG_STATE["last_reset"]) >= 0.8
                            if (
                                _BG_STATE["was_outside"]
                                and _BG_STATE["last_pos"]
                                and teleported
                                and cooled
                                and now >= _BG_STATE["ignore_until"]
                                and 后台鼠标空闲()

                            ):
                                if not GAME_ACTION_LOCK.acquire(blocking=False):
                                    _BG_STATE["was_outside"] = False
                                    continue
                                try:
                                    if not 后台鼠标空闲() or win32api.GetCursorPos() != pos:
                                        _BG_STATE["was_outside"] = False
                                        continue
                                    _校准鼠标采样(_BG_STATE["last_pos"])
                                    win32api.SetCursorPos(tuple(_BG_STATE["last_pos"]))
                                finally:
                                    GAME_ACTION_LOCK.release()
                                _BG_STATE["last_reset"] = now
                                _BG_STATE["ignore_until"] = now + 0.2
                                _BG_STATE["prev_sample"] = tuple(_BG_STATE["last_pos"])
                                fires = [t for t in _BG_STATE["fires"] if now - t < 10][-5:]
                                fires.append(now)
                                _BG_STATE["fires"] = fires
                                if len(fires) >= 4:
                                    _BG_STATE["guard_off_until"] = now + 30
                                    _BG_STATE["fires"] = []
                                    后台模式提示(
                                        "guard_backoff",
                                        "🖱️ 「防吸鼠标」连续触发多次 → 自动停手 30 秒不再干预"
                                        "（你要是在用鼠标，它就不会跟你抢了）",
                                    )
                            else:
                                _BG_STATE["was_outside"] = False
        except Exception:
            pass
        try:
            _BG_STATE["guard_stop"].wait(max(0.005, float(BACKGROUND_GUARD_GAP)))
        except Exception:
            time.sleep(0.02)


def 后台守护启动():
    """启动"防吸鼠标"线程（后台模式才需要）"""
    if _BG_STATE["guard_thread"] and _BG_STATE["guard_thread"].is_alive():
        return
    _BG_STATE["guard_stop"] = threading.Event()
    _BG_STATE["guard_thread"] = threading.Thread(
        target=后台守护循环, daemon=True, name="后台防吸鼠标"
    )
    _BG_STATE["guard_thread"].start()


def 客户区转屏幕(x, y, window=None):
    """把 1920x1080 游戏客户区坐标换算成当前桌面的绝对坐标。

    `点在坐标` / `后台点击` 接收的是屏幕绝对坐标，而月卡标题、盲点和备用点
    都是按游戏客户区测量的。游戏窗口移动或换显示器后必须在点击当下重新换算，
    不能把客户区坐标直接当成桌面坐标使用。
    """
    try:
        win = 游戏窗口范围() if window is None else window
        if not win:
            return None
        left, top, width, height = [int(v) for v in win[:4]]
        cx, cy = int(x), int(y)
        if width <= 0 or height <= 0 or cx < 0 or cy < 0 or cx >= width or cy >= height:
            return None
        return (left + cx, top + cy)
    except Exception:
        return None


@执行游戏动作
def 点在坐标(x, y, force_real=False):
    """点一下屏幕坐标；前后台操作都受同一套鼠标让行检查。"""
    if 后台模式开着吗() and not force_real:
        return 后台点击(x, y)
    pre, hold, post, _ = 点击节奏()
    return _前台点击(x, y, pre=pre, hold=hold, post=post)


@执行游戏动作
def 安全点击(x, y, wait_idle=True, restore=None):
    global last_activity_ts
    if not running:
        return False
    if 后台模式开着吗():
        last_activity_ts = time.time()
        return 后台点击(x, y, restore=restore, wait_idle=wait_idle)
    _BG_STATE["click_outcome"] = "yielded"
    if CURSOR_YIELD_USER and (not 后台鼠标空闲() or not _鼠标动作仍有效()):
        后台模式提示("cursor_busy", "⏸️ 鼠标动作让行，等待重新识别游戏画面")
        return False
    # 前台模式是真鼠标点击：如果游戏被别人窗口盖着，点下去就点到别人窗口上了 → 先提到最前
    if not 后台模式开着吗():
        try:
            _now2 = time.time()
            if _now2 - float(globals().get("_FG_RAISE_TS2", 0.0)) > 1.0:
                globals()["_FG_RAISE_TS2"] = _now2
                _h2 = 缓存窗口句柄()
                if _h2:
                    窗口提到前面(_h2)
        except Exception:
            pass
    if ENSURE_FOREGROUND == 1 and not 确保在游戏窗口():
        if not globals().get("_FG_WARNED"):
            globals()["_FG_WARNED"] = True
            print("⚠️ 游戏窗口当前不在前台，暂停前台点击")
        return False
    last_activity_ts = time.time()
    pre, hold, post, _ = 点击节奏()
    return _前台点击(x, y, pre=pre, hold=hold, post=post)


_WIN_MISS_PRINT_TS = [0.0]


def 提醒窗口没了():
    try:
        now = time.time()
        if now - _WIN_MISS_PRINT_TS[0] < 300:
            return
        _WIN_MISS_PRINT_TS[0] = now
        print(
            f"❌ 找不到游戏窗口「{WINDOW_TITLE}」（游戏没开 / 被最小化 / 窗口标题变了）"
            f"—— 这条每 5 分钟最多提示一次"
        )
    except Exception:
        pass


def 游戏窗口范围():
    try:
        hwnd = 缓存窗口句柄()
        if hwnd is None:
            提醒窗口没了()
            记报错(
                "window_missing",
                f"找不到游戏窗口 '{WINDOW_TITLE}'" f"（游戏没开/被最小化/窗口标题变了）",
                shot=False,
                throttle=300,
            )
            return None
        if win32gui.IsIconic(hwnd):
            win32gui.ShowWindow(hwnd, 9)
            time.sleep(0.5)
            if 后台模式开着吗():
                后台模式提示(
                    "bg_min",
                    "⚠️ 后台模式下游戏窗口被最小化了 —— 最小化时系统不再给画面，"
                    "脚本看不见也点不了；已自动还原。请改用「被别的窗口盖住」代替最小化。",
                )
        rect = win32gui.GetClientRect(hwnd)
        left, top = win32gui.ClientToScreen(hwnd, (rect[0], rect[1]))
        right, bottom = win32gui.ClientToScreen(hwnd, (rect[2], rect[3]))
        return (left, top, right - left, bottom - top)
    except Exception as e:
        print(f"❌ 获取窗口失败: {e}")
        return None


def 估价区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    return (left + VALUE_LEFT, top + VALUE_TOP, VALUE_WIDTH, VALUE_HEIGHT)


def 回合区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    return (left + ROUND_LEFT, top + ROUND_TOP, ROUND_WIDTH, ROUND_HEIGHT)


def 资产区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    hall = (left + FUNDS_HALL_LEFT, top + FUNDS_HALL_TOP, FUNDS_HALL_WIDTH, FUNDS_HALL_HEIGHT)
    room = (left + FUNDS_LEFT, top + FUNDS_TOP, FUNDS_WIDTH, FUNDS_HEIGHT)
    try:
        # 大厅与拍卖房间的顶部资产栏横向位置不同；先按当前画面的布局选区域。
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            return hall
    except Exception:
        pass
    return room


def 出价区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    return (left + BID_REGION_LEFT, top + BID_REGION_TOP, BID_REGION_WIDTH, BID_REGION_HEIGHT)


def 天黑区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    dl, dt, dw, dh = DARK_VENUE_REGION
    return (left + dl, top + dt, dw, dh)


_dark_venue_cache = {"t": -999.0, "v": False}


def 是不是天黑(ttl=2.0):
    now = time.time()
    if now - _dark_venue_cache["t"] < ttl:
        return _dark_venue_cache["v"]
    value = False
    try:
        region = 天黑区域()
        if region is not None:
            value = bool(画面有吗(DARK_VENUE_IMAGE, timeout=0, region=region))
    except Exception:
        value = False
    _dark_venue_cache["t"] = now
    _dark_venue_cache["v"] = value
    return value


def 数量区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    return (
        left + COUNT_REGION_LEFT,
        top + COUNT_REGION_TOP,
        COUNT_REGION_WIDTH,
        COUNT_REGION_HEIGHT,
    )


def 拍卖状态区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    x, y, w, h = AUCTION_STATUS_REGION
    return (left + x, top + y, w, h)


def 倒计时区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    x, y, w, h = BID_TIMER_REGION
    return (left + x, top + y, w, h)


def 出价核对区域():
    window = 游戏窗口范围()
    if window is None:
        return None
    left, top, _, _ = window
    return (
        left + BID_AMOUNT_CHECK_LEFT,
        top + BID_AMOUNT_CHECK_TOP,
        BID_AMOUNT_CHECK_WIDTH,
        BID_AMOUNT_CHECK_HEIGHT,
    )


def 默认截图范围():
    if LIMIT_TO_GAME_WINDOW != 1:
        return None
    window = 游戏窗口范围()
    if window is None:
        return None
    return (window[0], window[1], window[2], window[3])


def 画面有吗(image_name, timeout=0, region=None, threshold=None):
    if threshold is None:
        threshold = THRESHOLD
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        return False
    start = time.time()
    while True:
        if not running:
            return False
        try:
            actual_region = region if region is not None else 默认截图范围()
            gray = 抓灰度图(actual_region)
            found, _, _ = 最佳模板匹配(gray, template_gray, threshold)
            if found:
                return True
        except Exception as e:
            print(f"⚠️ 检测 {image_name} 出错: {e}")
            return False
        if timeout <= 0:
            return False
        if 守住重连(f"检测 {image_name}"):
            start = time.time()
            continue
        if time.time() - start > timeout:
            return False
        time.sleep(0.5)


def 找到就点(
    image_name, step_desc, region=None, timeout=10, check_bid_pause=False, report_timeout=True,
    verify_after_yield=None
):
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        print(f"⏭️ 模板 {image_name} 不可用，跳过 [{step_desc}]")
        return False
    start_time = time.time()
    original_window = 游戏窗口范围() if region is not None and CURSOR_YIELD_USER else None
    original_epoch = _USER_MOUSE_EPOCH
    needs_recheck = CURSOR_YIELD_USER and _MOUSE_FLOW_EPOCH != original_epoch
    while True:
        轮询面板控件()
        if not running:
            return False
        if check_bid_pause:
            r = 暂停时等着()
            if r == "SKIP":
                return "SKIP"
            if r == "STOP":
                return False
        if CURSOR_YIELD_USER and (_近期有用户输入() or original_epoch != _USER_MOUSE_EPOCH):
            wait_started = time.monotonic()
            status = _等鼠标让行结束(check_bid_pause)
            if status != "READY":
                return status if status == "SKIP" else False
            start_time += time.monotonic() - wait_started
            original_epoch = _USER_MOUSE_EPOCH
            needs_recheck = True
        if 守住重连(f"寻找[{step_desc}]"):
            start_time = time.time()
            continue
        if timeout > 0 and time.time() - start_time > timeout:
            if not report_timeout:
                print(f"ℹ️ 没看到 [{step_desc}]（这一步是可选的，继续走后面的流程）")
                return False
            print(f"⏰ 寻找 [{step_desc}] 超时 ({timeout}秒)，放弃点击")
            RUNLOG_STATS["steps_failed"] += 1
            记报错(
                "step_timeout",
                f"找不到 [{step_desc}]，{timeout} 秒超时放弃",
                extra={
                    "step": step_desc,
                    "timeout": timeout,
                    "template": image_name,
                    "ocr": dict(RUNLOG_OCR),
                },
            )
            return False
        try:
            epoch = _USER_MOUSE_EPOCH
            actual_region = region if region is not None else 默认截图范围()
            gray = 抓灰度图(actual_region)
            found, center_x, center_y = 最佳模板匹配(gray, template_gray)
            if CURSOR_YIELD_USER and epoch != _USER_MOUSE_EPOCH:
                continue
            if CURSOR_YIELD_USER and epoch != original_epoch:
                needs_recheck = True
            if needs_recheck and original_window is not None and 游戏窗口范围() != original_window:
                print(f"♻️ 鼠标让行后游戏窗口位置变化，放弃 [{step_desc}] 的旧区域")
                return False
            if needs_recheck and not found:
                print(f"♻️ 鼠标让行后 [{step_desc}] 已不在当前画面，放弃旧操作")
                return False
            if found:
                if needs_recheck and verify_after_yield is not None:
                    if not verify_after_yield():
                        print(f"♻️ 鼠标让行后 [{step_desc}] 的回合或金额已不一致，放弃旧操作")
                        return False
                    fresh_region = region if region is not None else 默认截图范围()
                    if fresh_region != actual_region:
                        return False
                    found, center_x, center_y = 最佳模板匹配(抓灰度图(fresh_region), template_gray)
                    if not found or epoch != _USER_MOUSE_EPOCH:
                        return False
                _MATCH_FAIL_STREAK[0] = 0
                if _FORCE_FOREGROUND_SHOT[0]:
                    _FORCE_FOREGROUND_SHOT[0] = False
                    print("🖼️ 已经认得到模板了 → 退回后台截图（省资源、不怕遮挡）")
                if actual_region:
                    center_x += actual_region[0]
                    center_y += actual_region[1]
                print(f"✅ 发现 [{step_desc}]，点击坐标 ({center_x}, {center_y})")
                if _按新画面点击(center_x, center_y, epoch):
                    return True
                outcome = _BG_STATE.get("click_outcome")
                if outcome != "uncertain" and CURSOR_YIELD_USER and epoch != _USER_MOUSE_EPOCH:
                    outcome = "yielded"
                single_action = check_bid_pause or image_name in ("step4.png", "btn_confirm.png", "step3.png")
                if outcome == "uncertain" or (single_action and outcome != "yielded"):
                    return False
                if image_name.startswith("num_"):
                    return False
                if timeout == 0 or not 歇一下(0.15):
                    return False
                continue
            # 连续认不到很多次 → 临时改用前台截图再试（校准救不回来的情况）
            _MATCH_FAIL_STREAK[0] += 1
            if (not _FORCE_FOREGROUND_SHOT[0]
                    and _MATCH_FAIL_STREAK[0] >= 15
                    and 后台模式开着吗()):
                _FORCE_FOREGROUND_SHOT[0] = True
                print("🖼️ 连续 %d 次认不到模板 → 临时改用前台截图重试；认到后自动退回后台"
                      % _MATCH_FAIL_STREAK[0])
        except Exception as e:
            print(f"⚠️ 寻找 [{step_desc}] 时出错: {e}")
            记报错(
                "find_error",
                f"寻找 [{step_desc}] 时出错: {e}",
                exc=e,
                shot=False,
                throttle=30,
                extra={"step": step_desc, "template": image_name},
            )
        if timeout == 0:
            return False
        time.sleep(0.3)


def 限时找图并点(image_name, step_desc, timeout=3):
    start_time = time.time()
    while True:
        轮询面板控件()
        if not running:
            return False
        wait_started = time.monotonic()
        if _等鼠标让行结束() != "READY":
            return False
        start_time += time.monotonic() - wait_started
        if time.time() - start_time > timeout:
            print(f"⏰ 查找 [{step_desc}] 超时 ({timeout}秒)，跳过")
            try:
                pyautogui.screenshot(os.path.join(SCREENSHOT_DIR, "debug_timeout.png"))
            except Exception:
                pass
            RUNLOG_STATS["steps_failed"] += 1
            记回合事件(
                "step_timeout",
                human=f"⏰ 找不到 [{step_desc}]，{timeout} 秒超时跳过",
                step=step_desc,
                timeout=timeout,
            )
            存回合截图(f"超时_{step_desc}", 回合截图区域(), f"卡在这一步：{step_desc}")
            记报错(
                "step_timeout_skip",
                f"找不到 [{step_desc}]，{timeout} 秒超时跳过",
                extra={"step": step_desc, "timeout": timeout, "template": image_name},
            )
            return False
        try:
            epoch = _USER_MOUSE_EPOCH
            actual_region = 默认截图范围()
            template_gray = 读图片模板(image_name)
            if template_gray is None:
                return False
            gray = 抓灰度图(actual_region)
            found, center_x, center_y = 最佳模板匹配(gray, template_gray)
            if found:
                if actual_region:
                    center_x += actual_region[0]
                    center_y += actual_region[1]
                print(f"✅ 发现 [{step_desc}]，点击坐标 ({center_x}, {center_y})")
                if _按新画面点击(center_x, center_y, epoch):
                    return True
                if _BG_STATE.get("click_outcome") == "uncertain":
                    return False
        except Exception as e:
            pass
        time.sleep(0.3)


def 等图出现(image_name, step_desc="等待图片", timeout=60, heartbeat=10):
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        return False
    start_time = time.time()
    last_beat = start_time
    while True:
        轮询面板控件()
        if not running:
            return False
        try:
            actual_region = 默认截图范围()
            gray = 抓灰度图(actual_region)
            found, _, _ = 最佳模板匹配(gray, template_gray)
            if found:
                print(f"✅ [{step_desc}] 已出现")
                return True
        except Exception as e:
            pass
        if timeout > 0 and time.time() - start_time > timeout:
            print(f"⏰ [{step_desc}] 等待超时（{timeout} 秒），放弃")
            return False
        if heartbeat > 0 and time.time() - last_beat >= heartbeat:
            last_beat = time.time()
            print(f"⏳ 仍在等待 [{step_desc}] ... 已等待 {int(time.time() - start_time)} 秒")
        time.sleep(0.5)


def 歇一下(seconds):
    try:
        _total = max(0.0, float(seconds))
    except Exception:
        _total = 0.0
    # 用 0.1 秒切片轮询面板控件，但**余量也睡足**：
    # 以前 int(seconds * 10) 会把 0.18 当成 0.1、把 0.25 当成 0.2，
    # 参数里填的间隔根本落不下去。
    _left = _total
    while _left > 0.0005:
        轮询面板控件()
        if not running:
            return False
        if not CONTROL_AUTH.allows_current_thread():
            time.sleep(0.1)
            _left -= 0.1
            continue
        if 守住重连("等待中"):
            continue
        _slice = min(0.1, _left)
        time.sleep(_slice)
        _left -= _slice
    return True


CONTROL_FLAG_START = os.path.join(RUNLOG_DIR, "_面板_开始.flag")
CONTROL_FLAG_STOP = os.path.join(RUNLOG_DIR, "_面板_停止.flag")
_NEED_BRING_FRONT = [False]
_CURSOR_SETTING_NEXT_READ = 0.0


def 轮询面板控件():
    global running, CURSOR_YIELD_USER, _CURSOR_SETTING_NEXT_READ, _MOUSE_FLOW_EPOCH
    # 下面几行原先缺 global，赋值实际落在局部变量上，
    #   导致「重新开始挂机就把计数清零」一直没生效。
    global _MATCH_STEP4_FAIL_STREAK, _MATCH_STEP4_FAIL_LAST, _MATCH_STEP4_LOW_FUNDS_STREAK
    global _MATCH_STEP4_RESCUE_DONE
    now = time.monotonic()
    if now >= _CURSOR_SETTING_NEXT_READ:
        _CURSOR_SETTING_NEXT_READ = now + 0.25
        enabled = _热读参数("CURSOR_YIELD_USER") == 1
        if enabled != bool(CURSOR_YIELD_USER):
            _MOUSE_FLOW_EPOCH = _USER_MOUSE_EPOCH
            CURSOR_YIELD_USER = int(enabled)
            print(f"⚙️ 鼠标让行已{'开启' if enabled else '关闭'}")
    try:
        if os.path.exists(CONTROL_FLAG_STOP):
            try:
                os.remove(CONTROL_FLAG_STOP)
            except Exception:
                pass
            if running:
                print("🛑 收到面板的【停止】指令，正在停下…")
                写日志("🛑 收到面板的【停止】指令，正在停下")
                running = False
        if os.path.exists(CONTROL_FLAG_START):
            try:
                os.remove(CONTROL_FLAG_START)
            except Exception:
                pass
            if not running:
                print("▶️ 收到面板的【开始】指令，开始挂机")
                写日志("▶️ 收到面板的【开始】指令，开始挂机")
                running = True
                _MATCH_STEP4_FAIL_STREAK = 0
                _MATCH_STEP4_FAIL_LAST = 0.0
                _MATCH_STEP4_LOW_FUNDS_STREAK = 0
                _MATCH_STEP4_RESCUE_DONE = 0  # 面板重新开始挂机 = 自救次数重新算
                _NEED_BRING_FRONT[0] = True
                碰一下进度("面板开始挂机")
    except Exception:
        pass


def 读当前估价():
    """读取当前估价：模板直接读金额，OCR 提供上下文和兜底。"""
    global LAST_ESTIMATE
    if not running:
        return ""
    try:
        region = 估价区域()
        if region is None:
            return ""
    except Exception:
        return ""
    last = int(LAST_ESTIMATE or 0)
    last_raw = ""
    for attempt in range(1, ESTIMATE_READ_ATTEMPTS + 1):
        try:
            img_np = np.array(抓一帧(region=region))
        except Exception:
            img_np = None
        d_main, d_alt, t_main, t_alt = 读估价数字(img_np)
        last_raw = (t_main or t_alt or "").strip()
        RUNLOG_OCR["value_raw"] = last_raw
        RUNLOG_OCR["value_alt"] = (t_alt or "").strip()
        digits, source, template_decision = 按模板读数字(
            img_np, "estimate", [d_main, d_alt]
        )
        RUNLOG_OCR["value_template"] = 数字库概要(template_decision)
        RUNLOG_OCR["value_source"] = source
        if not digits:
            print(
                "⚠️ 估价模板和 OCR 都失败（原文 '%s'），重读（第 %d/%d 次）"
                % (last_raw, attempt, ESTIMATE_READ_ATTEMPTS)
            )
            if not 歇一下(0.35):
                return ""
            continue
        try:
            value = int(digits)
        except Exception:
            value = 0
        if value <= 1000:
            print(
                "⚠️ 估价读成 %s（太小），重读（第 %d/%d 次）"
                % (value, attempt, ESTIMATE_READ_ATTEMPTS)
            )
            if not 歇一下(0.35):
                return ""
            continue
        # 估价突然涨很多是正常情况（扫到高价值物品），不设上限。
        if last and value < last:
            _drop = (last - value) / float(last)
            if _drop > ESTIMATE_MAX_DROP_RATIO:
                # 跌太多（读丢一位是 -90%）→ 一定是读错
                print(
                    "⚠️ 估价读到 %s，比本局之前的 %s 低了 %.0f%%（估价只涨不跌，这么大跌幅=读错）"
                    "→ 重读（第 %d/%d 次）"
                    % (f"{value:,}", f"{last:,}", _drop * 100, attempt, ESTIMATE_READ_ATTEMPTS)
                )
                if not 歇一下(0.35):
                    return ""
                continue
            # 小跌（≤10%）：游戏用完仪器自己重算，实测会掉 1~2% → 照收（实测）
            print(
                "ℹ️ 估价从 %s 降到 %s（-%.1f%%，在容差内 → 当游戏自己重算，照收）"
                % (f"{last:,}", f"{value:,}", _drop * 100)
            )
        # 模板高置信：跳过第二遍确认（省一次抓图 + 一次识别，约 0.6~0.9 秒）
        try:
            _sc = float(getattr(template_decision, "min_score", 0) or 0)
            _mg = float(getattr(template_decision, "min_margin", 0) or 0)
        except Exception:
            _sc, _mg = 0.0, 0.0
        if (
            template_decision is not None
            and _sc >= float(ESTIMATE_SINGLE_PASS_SCORE)
            and _mg >= float(ESTIMATE_SINGLE_PASS_MARGIN)
        ):
            LAST_ESTIMATE = value
            print(
                f"💰 识别到当前估价: {value}（来源 {source}；原文 '{last_raw}'；"
                f"单遍高置信：最低分 {_sc:.3f} / 最小差 {_mg:.3f}）"
            )
            return str(value)
        # 第二遍确认（和出价金额一样：隔 0.12 秒再读，两次要一致）
        if not 歇一下(ESTIMATE_CONFIRM_GAP):
            return ""
        try:
            img2 = np.array(抓一帧(region=region))
        except Exception:
            img2 = None
        e_main, e_alt, _, _ = 读估价数字(img2)
        e_digits, e_source, e_template_decision = 按模板读数字(
            img2, "estimate", [e_main, e_alt]
        )
        e_val = 0
        try:
            e_val = int(e_digits or 0)
        except Exception:
            e_val = 0
        if e_val and e_val != value:
            print(
                "⚠️ 估价两次读数不一致（%s / %s），重读（第 %d/%d 次）"
                % (f"{value:,}", f"{e_val:,}", attempt, ESTIMATE_READ_ATTEMPTS)
            )
            if not 歇一下(0.35):
                return ""
            continue
        LAST_ESTIMATE = value
        print(
            f"💰 识别到当前估价: {value}（来源 {source}；原文 '{last_raw}'；"
            f"第二遍 {e_source}，两遍一致）"
        )
        return str(value)
    print(f"⚠️ 估价重读 {ESTIMATE_READ_ATTEMPTS} 遍仍不可靠（最后原文 '{last_raw}'）")
    try:
        存数字调试图(
            "debug_value.png",
            cv2.cvtColor(np.array(抓一帧(region=region)), cv2.COLOR_RGB2BGR),
        )
    except Exception:
        pass
    return ""


def 读估价数字(img_np):
    """把一块估价画面喂两个模型，返回 (中文数字, 英文数字, 中文原文, 英文原文)。

    **原图优先，二值化只当兜底**：
      10-19 06:06 那局，把估价那块切成纯黑白之后，中文模型只读出"当前估价："、数字全丢，
      而同一张截图喂原图，中英两个模型都读到 777,217 —— 二值化偶尔会把数字吃掉（大字、
      橙色数字、紧挨着标签那种画面）。所以顺序改成：先读原图；原图读不到数字，才读二值化的。
    """
    if img_np is None or getattr(img_np, "size", 0) == 0:
        return "", "", "", ""

    def _read(src):
        t_main = 拼识别文字(ocr.ocr(src, cls=True))
        t_alt = ""
        try:
            if amount_ocr_alt is not None:
                t_alt = 拼识别文字(amount_ocr_alt.ocr(src, cls=True))
        except Exception:
            t_alt = ""
        return (re.sub(r"[^\d]", "", t_main), re.sub(r"[^\d]", "", t_alt), t_main, t_alt)

    try:
        raw = _read(img_np)  # ① 原图（抓一帧 给的就是 RGB）
    except Exception as e:
        print(f"⚠️ 估价OCR(原图)异常: {e}")
        raw = ("", "", "", "")
    if raw[0] or raw[1]:
        return raw
    try:
        _g = img_np.max(axis=2)  # ② 兜底：切成纯黑白再读一遍
        _bw = np.where(_g > ESTIMATE_BIN_THRESHOLD, 255, 0).astype(np.uint8)
        return _read(np.dstack([_bw, _bw, _bw]))
    except Exception as e:
        print(f"⚠️ 估价OCR异常: {e}")
        return "", "", "", ""


def 小程序区识别(region, binary=False):
    """对小块游戏文字做一次轻量 OCR，返回按纵坐标排序的文本。"""
    if region is None:
        return []
    try:
        img = np.array(抓一帧(region=region))
        rgb = img
        if binary:
            gray = img.max(axis=2) if img.ndim == 3 else img
            bw = np.where(gray > BID_AMOUNT_BIN_THRESHOLD, 255, 0).astype(np.uint8)
            rgb = np.dstack([bw, bw, bw])
        result = ocr.ocr(rgb, cls=True)
        lines = []
        for line in result[0] or []:
            try:
                box = line[0]
                text = str(line[1][0] or "").strip()
            except Exception:
                continue
            if not text:
                continue
            ys = [float(p[1]) for p in box]
            lines.append((min(ys), text))
        lines.sort(key=lambda item: item[0])
        return lines
    except Exception as e:
        print("⚠️ 小区域 OCR 失败：%s" % e)
        return []


def 读拍卖状态文字():
    """读取房间底部的场地/模式栏，例如“标准对局”“紧迫危机”。"""
    region = 拍卖状态区域()
    # 新版部分场地的标题有颜色；先读原图，原图没有中文再二值化兜底。
    for binary in (False, True):
        lines = 小程序区识别(region, binary=binary)
        for _y, text in lines:
            if re.search(r"[\u3400-\u9fff]", text or ""):
                return text
        if lines:
            first = lines[0][1].strip()
            if first and first not in ("?", "？"):
                return first
    return ""


def 解析出价倒计时(text):
    match = re.search(r"(\d{1,2})\s*[:：]\s*(\d{2})", text)
    if not match:
        return None
    minutes, seconds = int(match.group(1)), int(match.group(2))
    if seconds >= 60:
        return None
    return minutes * 60 + seconds


def 读出价倒计时():
    """读取本回合当前倒计时，返回秒数；读不到返回 None。"""
    lines = 小程序区识别(倒计时区域(), binary=True)
    text = " ".join(t for _y, t in lines)
    return 解析出价倒计时(text)


def 判定拍卖阶段(status_text, seconds, was_urgent=False):
    """根据场地栏文字和初始倒计时识别紧迫危机。"""
    text_urgent = any(k in str(status_text or "") for k in URGENT_CRISIS_KEYWORDS)
    known_other_mode = any(
        k in str(status_text or "") for k in ("标准对局", "福利多多", "天黑了", "一手情报", "加倍")
    )
    timer_urgent = bool(
        seconds is not None
        and 0 < int(seconds) <= URGENT_CRISIS_MAX_SECONDS
        and not known_other_mode
    )
    urgent = bool(text_urgent or timer_urgent or (was_urgent and not status_text))
    source = "status-text" if text_urgent else ("timer" if timer_urgent else "")
    return urgent, source


def 刷新回合状态(round_num):
    """记录场地和倒计时，并识别新版本“紧迫危机”20 秒模式。"""
    rnd = int(round_num or 0)
    auction_no = int(RUNLOG_AUCTION_NO or 0)
    cached_round = int(_BID_WINDOW_STATE.get("round") or 0)
    cached_auction = int(_BID_WINDOW_STATE.get("auction_no") or 0)
    if (
        cached_auction == auction_no
        and cached_round == rnd
        and _BID_WINDOW_STATE.get("observed_at")
    ):
        return bool(_BID_WINDOW_STATE.get("urgent"))
    # 场地模式在本局内固定。首回合识别成功后，后续回合不再重复 OCR；
    # 紧迫危机仍要重读倒计时，用它决定是否跳过可选仪器。
    if cached_auction == auction_no and _BID_WINDOW_STATE.get("status_text"):
        if _BID_WINDOW_STATE.get("urgent"):
            seconds = 读出价倒计时()
            if seconds is None:
                seconds = URGENT_CRISIS_ASSUMED_SECONDS
        else:
            seconds = None
        _BID_WINDOW_STATE.update(
            round=rnd,
            seconds=seconds,
            observed_at=time.time(),
        )
        try:
            记回合事件(
                "auction_condition_cached",
                round=rnd,
                status_text=_BID_WINDOW_STATE.get("status_text"),
                timer_seconds=seconds,
                urgent=bool(_BID_WINDOW_STATE.get("urgent")),
                source="auction-cache",
            )
        except Exception:
            pass
        return bool(_BID_WINDOW_STATE.get("urgent"))
    started = time.time()
    status_text = 读拍卖状态文字()
    seconds = 读出价倒计时()
    was_urgent = bool(_BID_WINDOW_STATE.get("urgent"))
    urgent, source = 判定拍卖阶段(status_text, seconds, was_urgent)
    _BID_WINDOW_STATE.update(
        urgent=urgent,
        seconds=seconds,
        status_text=status_text,
        source=source,
        round=rnd,
        observed_at=time.time(),
        auction_no=auction_no,
    )
    human = (
        f"🏷️ 第{rnd}回合场地/模式：{status_text or '未识别'}"
        f"｜倒计时 {seconds if seconds is not None else '未识别'} 秒"
        f"｜紧迫危机 {'是' if urgent else '否'}"
    )
    print(human)
    try:
        记回合事件(
            "auction_condition",
            human=human,
            round=rnd,
            status_text=status_text,
            timer_seconds=seconds,
            urgent=urgent,
            source=source,
            ocr_ms=int((time.time() - started) * 1000),
        )
    except Exception:
        pass
    return urgent


def 快没时间了吗():
    return bool(_BID_WINDOW_STATE.get("urgent"))


def 急吗(urgent_flag=None):
    """这一步要不要按"紧迫危机"的节奏走。

    三路判断（任一成立就算）：
      ① 本回合开门时判定的场地是紧迫危机（urgent_flag，最可靠）
      ② 状态里 urgent=True
      ③ 读得到剩余秒数且 < 12 秒（15 秒场也吃得住）
    """
    try:
        if urgent_flag:
            return True
        if _BID_WINDOW_STATE.get("urgent"):
            return True
        r = 紧迫剩余秒数()
        # 紧迫局是 15/20 秒；普通局 40+ 秒。剩余 <16 秒一律按紧迫节奏走。
        if r is not None and r < 16.0:
            return True
    except Exception:
        pass
    return False


def 估剩余时间():
    seconds = _BID_WINDOW_STATE.get("seconds")
    if seconds is None:
        return None
    observed = float(_BID_WINDOW_STATE.get("observed_at") or 0.0)
    return max(0.0, float(seconds) - max(0.0, time.time() - observed))


def 紧迫剩余秒数():
    """紧迫局还剩几秒（读不到返回 None）。"""
    try:
        v = 估剩余时间()
    except Exception:
        return None
    return None if v is None else float(v)


def 本机很慢吗():
    """「慢机器省时模式」开关：开了就跳过"查举报/数品质"这类重动作。

    以前是"机器抓帧慢到门槛才跳"，快机器（k<阈值）开了开关也不跳，
    等于开关没用（实测踩过）。现在改成：开关=1 就直接跳过，开关=0 才照做。
    """
    try:
        return int(SLOW_PC_SKIP_HEAVY or 0) == 1
    except Exception:
        return False


def 测本机速度():
    """开机测一次"抓一帧"耗时，算出本机速度系数 k（1.0 = 参考机）。"""
    try:
        samples = []
        for _ in range(3):
            t0 = time.time()
            img = 抓一帧()
            if img is not None:
                samples.append((time.time() - t0) * 1000.0)
            time.sleep(0.05)
        if not samples:
            return 1.0
        ms = sum(samples) / len(samples)
        k = max(0.5, min(6.0, ms / 120.0))   # 参考机抓一帧约 120ms
        _SPEED_K[0] = round(k, 2)
        level = "快" if k <= 1.1 else ("标准" if k <= 1.8 else ("偏慢" if k <= 3.0 else "很慢"))
        print("⚙️ 本机速度：抓一帧 %.0fms → 系数 k=%.2f（%s）" % (ms, k, level))
        try:
            os.makedirs(os.path.dirname(MACHINE_SPEED_FILE), exist_ok=True)
            with open(MACHINE_SPEED_FILE, "w", encoding="utf-8") as fh:
                json.dump({"capture_ms": round(ms, 1), "k": round(k, 2),
                           "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S")},
                          fh, ensure_ascii=False, indent=2)
        except Exception:
            pass
        return k
    except Exception:
        return 1.0


def 本机出价耗时估计():
    """最近几注的实测出价耗时；还没有样本就按速度系数估 8 秒。"""
    try:
        if _BID_COST_SAMPLES[0] > 0 and _BID_COST_EMA[0] > 0:
            return float(_BID_COST_EMA[0])
        return 8.0 * float(_SPEED_K[0] or 1.0)
    except Exception:
        return 8.0


def 记一次出价耗时(seconds):
    try:
        v = max(0.5, float(seconds))
        if _BID_COST_SAMPLES[0] <= 0:
            _BID_COST_EMA[0] = v
        else:
            _BID_COST_EMA[0] = _BID_COST_EMA[0] * 0.7 + v * 0.3
        _BID_COST_SAMPLES[0] += 1
    except Exception:
        pass


def 时间紧吗():
    """剩余时间是否已经不够从容（用于跳过数仓/压缩等待）。"""
    if int(LOWSPEC_ENABLED or 0) != 1:
        return False
    R = 估剩余时间()
    if R is None:
        return False
    return R < 本机出价耗时估计() * float(LOWSPEC_TIGHT_RATIO)


def 仪器等待上限(默认秒):
    """时间紧的时候，别把剩余时间全耗在"等仪器生效"上。"""
    try:
        if not 时间紧吗():
            return float(默认秒)
        R = 估剩余时间()
        if R is None:
            return float(默认秒)
        budget = R - 本机出价耗时估计() - float(LOWSPEC_BID_RESERVE_SEC)
        return max(1.0, min(float(默认秒), budget))
    except Exception:
        return float(默认秒)


def 出价前守门(round_num):
    """时间真的不够时放弃这一注（留在局里等下一回合，不退出对局）。"""
    global NO_BID_REASON
    if int(LOWSPEC_ENABLED or 0) != 1:
        return True
    R = 估剩余时间()
    if R is None:
        return True
    need = 本机出价耗时估计() + float(LOWSPEC_BID_RESERVE_SEC)
    if R >= need:
        return True
    msg = ("⏳ 第%s回合只剩 %.1fs < 本机出价约需 %.1fs → 本回合放弃出价（等下一回合）"
           % (round_num, R, need))
    print(msg)
    NO_BID_REASON = "低配保护：剩余时间不够"
    try:
        记回合事件("bid_skipped_low_spec", human=msg, round=int(round_num),
                   remaining=round(R, 1), need=round(need, 1), speed_k=_SPEED_K[0])
    except Exception:
        pass
    return False


def 执行出价(round_num, bid_images, bid_display, estimate=None):
    """统一出价入口：顺手记一次本机出价耗时（给时间预算用）。"""
    t0 = time.time()
    try:
        if estimate is None:
            return 去出价(bid_images, bid_display, round_num=round_num)
        return 去出价(bid_images, bid_display, round_num=round_num, estimate=estimate)
    finally:
        try:
            记一次出价耗时(time.time() - t0)
        except Exception:
            pass


def 急了就别用仪器(round_num):
    """紧迫危机时是否跳过可选仪器。

    默认不跳（URGENT_SKIP_INSTRUMENT=0）：仪器是主要情报来源，
    宁可把"等生效"的时间压短，也要每回合都用上。
    """
    if not 急吗():
        return False
    if int(URGENT_SKIP_INSTRUMENT or 0) != 1:
        return False
    remaining = 估剩余时间()
    skip = remaining is None or remaining < URGENT_INSTRUMENT_MIN_REMAINING
    if skip:
        msg = (
            f"⚡ 紧迫危机：第{round_num}回合剩余"
            f"{'未知' if remaining is None else f'{remaining:.1f}'}秒，"
            f"跳过可选仪器，直接读取估价并出价"
        )
        print(msg)
        try:
            记回合事件(
                "urgent_skip_instrument",
                human=msg,
                round=int(round_num),
                remaining=round(remaining, 2) if remaining is not None else None,
                threshold=URGENT_INSTRUMENT_MIN_REMAINING,
            )
        except Exception:
            pass
    return skip


_ROUND_OCR_CACHE = {"key": None, "value": 0, "shown": None, "miss": 0}


def 拼识别文字(result):
    try:
        out = []
        for line in result[0] or []:
            try:
                out.append(str(line[1][0]))
            except Exception:
                continue
        return "".join(out)
    except Exception:
        return ""


def 回合帧键(img_np):
    try:
        small = cv2.resize(img_np, (24, 8), interpolation=cv2.INTER_AREA)
        return hash(small.tobytes())
    except Exception:
        return None


def 解析回合数(text):
    if not text:
        return 0
    t = str(text).strip()
    t = re.sub(r"[\uff10-\uff19]", lambda m: str(ord(m.group(0)) - ord("\uff10")), t)
    for a, b in (
        ("弟", "第"),
        ("笫", "第"),
        ("回台", "回合"),
        ("回会", "回合"),
        ("回合", "回合"),
        ("回盒", "回合"),
    ):
        t = t.replace(a, b)
    m = re.search(r"第\s*([1-6])\s*回合", t)
    if m:
        return int(m.group(1))
    if ROUND_LOOSE_FALLBACK == 1:
        m = re.search(r"(\d+)", t)
        return int(m.group(1)) if m else 0
    nums = re.findall(r"(?<!\d)([1-6])(?!\d)", t)
    if len(nums) == 1 and re.search(r"[回合]", t):
        return int(nums[0])
    return 0


def 核对回合数(img_np, expected_round):
    """Cross-check the round digit in its dedicated one-digit window.

    The full round strip contains Chinese text, so passing it to a one-digit
    template is invalid.  OCR has already parsed the structured
    ``竞拍第N回合`` text here.  If the tiny window is temporarily unavailable
    or unreadable, keep that context-validated result; only a clear visual
    read of a different digit rejects it.
    """
    try:
        h, w = img_np.shape[:2]
        if (
            ROUND_DIGIT_LEFT < 0
            or ROUND_DIGIT_TOP < 0
            or ROUND_DIGIT_RIGHT <= ROUND_DIGIT_LEFT
            or ROUND_DIGIT_BOTTOM <= ROUND_DIGIT_TOP
            or ROUND_DIGIT_RIGHT > w
            or ROUND_DIGIT_BOTTOM > h
        ):
            return True, "round digit crop unavailable; retained OCR result", None
        digit_image = img_np[
            ROUND_DIGIT_TOP:ROUND_DIGIT_BOTTOM,
            ROUND_DIGIT_LEFT:ROUND_DIGIT_RIGHT,
        ]
    except Exception as e:
        return True, f"round digit crop error: {e}; retained OCR result", None
    available, confirmed, decision = 确认数字候选(digit_image, [str(expected_round)])
    if not available:
        return True, "numeric templates unavailable; retained OCR result", decision
    if confirmed:
        return True, 数字库概要(decision), decision
    visual_digits = getattr(decision, "digits", "") if decision is not None else ""
    if visual_digits and visual_digits != str(expected_round):
        return (
            False,
            ("round digit mismatch: OCR=%s visual=%s" % (expected_round, visual_digits)),
            decision,
        )
    return True, ("round digit could not be independently scored; retained OCR result"), decision


def 读当前回合(force=False):
    if not running:
        return 0
    try:
        region = 回合区域()
        if region is None:
            return 0
        img_np = np.array(抓一帧(region=region))
        key = 回合帧键(img_np)
        if (not force) and key is not None and key == _ROUND_OCR_CACHE["key"]:
            return _ROUND_OCR_CACHE["value"]
        result = ocr.ocr(cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB), cls=True)
        full_text = 拼识别文字(result)
        RUNLOG_OCR["round_raw"] = full_text
        val = 解析回合数(full_text)
        if val:
            visual_ok, visual_reason, decision = 核对回合数(img_np, val)
            RUNLOG_OCR["round_template"] = 数字库概要(decision)
            if not visual_ok:
                print(
                    f"⚠️ 回合数字模板与 OCR 冲突（OCR '{full_text.strip()}'；"
                    f"{visual_reason}），先按 0 处理"
                )
                val = 0
        _ROUND_OCR_CACHE["key"] = key
        _ROUND_OCR_CACHE["value"] = val
        if val:
            if val != _ROUND_OCR_CACHE["shown"]:
                try:
                    reader = 数字识别器()
                    if reader is not None:
                        reader.clear_cache()
                except Exception:
                    pass
                print(f"📖 回合识别到: {full_text.strip() or val} → 第 {val} 回合")
                _ROUND_OCR_CACHE["shown"] = val
            _ROUND_OCR_CACHE["miss"] = 0
        else:
            _ROUND_OCR_CACHE["miss"] += 1
            if full_text.strip() and _ROUND_OCR_CACHE["miss"] <= 2:
                print(f"⚠️ 回合号识别异常（读到 '{full_text.strip()}'），先按 0 处理")
            存数字调试图(
                "debug_round.png",
                cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR),
            )
        return val
    except Exception:
        return 0


def 试估价模板(image):
    """Cheap template-only readiness/effect probe for the value region."""
    reader = 数字识别器()
    if reader is None or image is None or getattr(image, "size", 0) == 0:
        return 0, None
    try:
        min_digits, max_digits = 数字字段范围("estimate")
        decision = reader.recognize(
            image,
            min_digits=min_digits,
            max_digits=max_digits,
        )
        if not decision.ok:
            return 0, decision
        try:
            value = int(decision.digits)
        except Exception:
            value = 0
        return (value if value > 1000 else 0), decision
    except Exception:
        return 0, None


def 等估价出来(round_num):
    """Wait only until the new round's estimate is visibly stable.

    Returns the value, ``None`` on timeout/uncertainty, or ``"STOP"`` when
    the user pauses.  The caller falls back to the existing full retry path.
    """
    global LAST_ESTIMATE
    region = 估价区域()
    if region is None:
        return None
    # 场地模式决定等多久：一手情报的数字会逐件刷新，其余场地情报量固定、很快就稳。
    _status = str(_BID_WINDOW_STATE.get("status_text") or "")
    _intel = "一手情报" in _status
    _stable_window = float(ROUND_ESTIMATE_STABLE_WINDOW)
    _max_wait = float(ROUND_ESTIMATE_MAX_WAIT)
    # 紧迫危机每回合只有 20 秒：第 3 回合光等估价就要 16 秒，
    # 等数字稳定下来回合计时早跑完了。这里两头一起压：
    # 稳定窗口放短（情报该亮的已经亮了），并且绝不占用留给出价的那几秒。
    if 快没时间了吗():
        _stable_window = min(_stable_window, float(URGENT_ESTIMATE_STABLE_WINDOW))
        _max_wait = min(_max_wait, float(URGENT_ESTIMATE_MAX_WAIT))
        _remaining = 估剩余时间()
        if _remaining is not None:
            _max_wait = min(
                _max_wait, max(1.0, float(_remaining) - float(URGENT_BID_RESERVE_SECONDS))
            )
    elif int(round_num or 0) == 3:
        # 第 3 回合有角色技能，估价会跳变一段才停。
        # 以前只有「一手情报」场地才等长，别的场地技能放到一半、数字刚一停
        # 就被认下了，拿到的是半截估价。技能不看场地，这里也不该看。
        _stable_window = max(_stable_window, float(ROUND3_ESTIMATE_STABLE_WINDOW))
        _max_wait = max(_max_wait, float(ROUND3_ESTIMATE_MAX_WAIT))
    elif not _intel:
        # 常规局不用干等：数字一两秒就停住，9 秒纯属陪跑。
        _stable_window = min(_stable_window, float(FAST_ESTIMATE_STABLE_WINDOW))
        _max_wait = min(_max_wait, float(FAST_ESTIMATE_MAX_WAIT))
    started = time.time()
    deadline = started + max(float(ROUND_ESTIMATE_MIN_WAIT), _max_wait)
    if not 歇一下(ROUND_ESTIMATE_MIN_WAIT):
        return "STOP"
    last_digits = ""
    stable_since = 0.0
    old_estimate = int(LAST_ESTIMATE or 0)
    samples = []

    def _remember(value, digits, when):
        if not value:
            return
        if samples and samples[-1].get("value") == int(value):
            return
        samples.append(
            {
                "value": int(value),
                "digits": str(digits or ""),
                "t": round(when - started, 3),
            }
        )
        while len(samples) > 20:
            samples.pop(0)

    while time.time() < deadline:
        if not running:
            return "STOP"
        try:
            image = np.array(抓一帧(region=region))
        except Exception:
            image = None
        value, probe = 试估价模板(image)
        digits = str(probe.digits) if probe is not None and probe.ok else ""
        now = time.time()
        if value and digits:
            _remember(value, digits, now)
            _ready = False
            if digits != last_digits:
                last_digits = digits
                stable_since = now
                # 模板快读：隔 0.12 秒再截一张，两遍读出同一串数字就当稳定。
                # 以前这里只能死等 2.5 秒（第 3 回合 5.5 秒），两遍一致等价于"没在跳"，
                # 省下的两秒正好给紧迫局留出来。
                if not 歇一下(ESTIMATE_CONFIRM_GAP):
                    return "STOP"
                try:
                    _img2 = np.array(抓一帧(region=region))
                except Exception:
                    _img2 = None
                _v2, _p2 = 试估价模板(_img2)
                _d2 = str(_p2.digits) if _p2 is not None and _p2.ok else ""
                if _v2 and _d2 == digits:
                    if int(round_num or 0) == 3:
                        # 第 3 回合有角色技能：估价会先闪一个数、过一会儿再跳。
                        # 两遍只隔 0.5 秒，技能没放完也可能两次读到同一串，
                        # 这时候认下来就是半截估价。交给 _stable_window（5.5 秒）判。
                        _ready = now - stable_since >= _stable_window
                    else:
                        value = _v2
                        _ready = True
            else:
                _ready = now - stable_since >= _stable_window
            if _ready:
                current_round = 读当前回合(force=True)
                if current_round and current_round != int(round_num):
                    last_digits = ""
                    stable_since = 0.0
                    continue
                d_main, d_alt, t_main, t_alt = 读估价数字(image)
                final_digits, source, decision = 按模板读数字(
                    image, "estimate", [d_main, d_alt]
                )
                try:
                    final_value = int(final_digits or 0)
                except Exception:
                    final_value = 0
                if final_value and final_value == value:
                    if old_estimate and final_value < old_estimate:
                        drop = (old_estimate - final_value) / float(old_estimate)
                        if drop > ESTIMATE_MAX_DROP_RATIO:
                            print(
                                "⚠️ 估价就绪轮询读到异常下跌（%s → %s），继续等待"
                                % (f"{old_estimate:,}", f"{final_value:,}")
                            )
                            last_digits = ""
                            stable_since = 0.0
                            if not 歇一下(ROUND_ESTIMATE_POLL_INTERVAL):
                                return "STOP"
                            continue
                    LAST_ESTIMATE = final_value
                    RUNLOG_OCR["value_raw"] = (t_main or t_alt or "").strip()
                    RUNLOG_OCR["value_alt"] = (t_alt or "").strip()
                    RUNLOG_OCR["value_template"] = 数字库概要(decision)
                    RUNLOG_OCR["value_source"] = source
                    elapsed = time.time() - started
                    print(
                        f"✅ 第{round_num}回合估价已就绪: {final_value:,}"
                        f"（等待 {elapsed:.2f}s；来源 {source}）"
                    )
                    try:
                        记回合事件(
                            "estimate_ready",
                            human=f"🔎 第{round_num}回合估价稳定：{final_value:,}"
                            f"（{elapsed:.2f}s，{len(samples)} 个候选）",
                            round=round_num,
                            phase="round-entry",
                            final=final_value,
                            samples=samples,
                            elapsed_ms=int(elapsed * 1000),
                            stable_window=_stable_window,
                        )
                    except Exception:
                        pass
                    return str(final_value)
        if not 歇一下(ROUND_ESTIMATE_POLL_INTERVAL):
            return "STOP"
    print(f"ℹ️ 第{round_num}回合估价快速轮询 {_max_wait:.1f}s 未稳定，" f"回退完整识别")
    try:
        记回合事件(
            "estimate_ready_timeout",
            human=f"ℹ️ 第{round_num}回合入口估价 {_max_wait:.1f}s 未稳定，回退完整识别",
            round=round_num,
            phase="round-entry",
            samples=samples,
            elapsed_ms=int((time.time() - started) * 1000),
        )
    except Exception:
        pass
    return None


_FUNDS_CACHE = {"at": 0.0, "val": ""}


def 读当前资产():
    if not running:
        return ""
    try:
        _ttl = float(FUNDS_CACHE_SEC or 0)
    except Exception:
        _ttl = 0.0
    if _ttl > 0 and _FUNDS_CACHE["val"]:
        if time.time() - _FUNDS_CACHE["at"] < _ttl:
            return _FUNDS_CACHE["val"]
    window = 游戏窗口范围()
    if window is None:
        return ""
    left, top, _, _ = window
    room = (left + FUNDS_LEFT, top + FUNDS_TOP, FUNDS_WIDTH, FUNDS_HEIGHT)
    hall = (left + FUNDS_HALL_LEFT, top + FUNDS_HALL_TOP, FUNDS_HALL_WIDTH, FUNDS_HALL_HEIGHT)
    preferred = 资产区域() or room
    regions = [preferred, hall if preferred == room else room]
    last_raw = ""
    for attempt in range(3):
        saw_asset_label = False
        for region in regions:
            try:
                img_np = np.array(抓一帧(region=region))
                存数字调试图(
                    "debug_funds.png",
                    cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR),
                )
                result = ocr.ocr(cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB), cls=True)
                full_text = 拼识别文字(result)
                alt_text = ""
                try:
                    if amount_ocr_alt is not None:
                        alt_text = 拼识别文字(
                            amount_ocr_alt.ocr(
                                cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB),
                                cls=True,
                            )
                        )
                except Exception:
                    alt_text = ""
                last_raw = full_text or alt_text
                label_text = re.sub(r"\s+", "", "%s%s" % (full_text, alt_text))
                if "我的资产" not in label_text:
                    # 大厅顶部的「低保金」等按钮也会落在旧余额区域里；没有标签就不认。
                    continue
                saw_asset_label = True
                main_digits = re.sub(r"\D", "", full_text)
                alt_digits = re.sub(r"\D", "", alt_text)
                RUNLOG_OCR["funds_raw"] = last_raw
                RUNLOG_OCR["funds_alt"] = alt_text
                digits, source, decision = 按模板读数字(
                    img_np, "funds", [main_digits, alt_digits]
                )
                RUNLOG_OCR["funds_template"] = 数字库概要(decision)
                RUNLOG_OCR["funds_source"] = source
                if digits:
                    print(
                        f"💰 识别到我的资金: {digits}"
                        f"（来源 {source}；OCR '{last_raw}'；{数字库概要(decision)}）"
                    )
                    _FUNDS_CACHE["at"] = time.time()
                    _FUNDS_CACHE["val"] = digits
                    return digits
            except Exception as e:
                print(f"⚠️ 资金识别异常（第 {attempt + 1}/3 次）：{e}")
        if not saw_asset_label:
            print("⚠️ 资金区域没有识别到『我的资产』标签，本次读数作废（不用于停机判断）")
        else:
            print("⚠️ 资金模板和 OCR 未得到可确认读数，重读（第 %d/3 次）" % (attempt + 1))
        if not 歇一下(0.25):
            return ""
    print(f"⚠️ 资金连续 3 次未通过模板确认（最后原文 '{last_raw}'）")
    return ""


def 只读实际价值():
    if not running:
        return 0
    window = 游戏窗口范围()
    if window is None:
        return 0
    left, top, _, _ = window
    region = (
        left + ACTUAL_VALUE_LEFT,
        top + ACTUAL_VALUE_TOP,
        ACTUAL_VALUE_WIDTH,
        ACTUAL_VALUE_HEIGHT,
    )
    value, _, decision = 读金额并核对(region, "实际价值")
    if value > 0:
        print(f"📊 实际价值数值: {value:,}（{数字库概要(decision)}）")
    return max(0, value)


def 抓出价金额图():
    """只抓「出价金额」那一小块，存进 LAST_BID_AMOUNT_IMAGE 给模板判定用。

    不走 OCR —— 模板判定只要几十毫秒，出价校验的快路径全靠这个。
    """
    global LAST_BID_AMOUNT_IMAGE
    LAST_BID_AMOUNT_IMAGE = None
    if not running:
        return None
    try:
        region = 出价核对区域()
        if region is None:
            return None
        screenshot = 抓一帧(region=region)
        img_np = np.array(screenshot)
        LAST_BID_AMOUNT_IMAGE = img_np.copy()
        return img_np
    except Exception as e:
        print(f"⚠️ 抓出价金额小图失败: {e}")
        return None


def 只读出价金额():
    if not running:
        return ""
    global LAST_AMOUNT_ALT, LAST_BID_AMOUNT_IMAGE, LAST_BID_TEMPLATE_DECISION
    LAST_AMOUNT_ALT = ""
    LAST_BID_TEMPLATE_DECISION = None
    try:
        img_np = 抓出价金额图()
        if img_np is None:
            return ""
        # 喂给 OCR 之前先二值化成「纯黑底 + 纯白字」：
        # 这块里背景亮度只有 2~5、白字是 255，切一刀最干净（顺带把左边按钮的灰边也切没）。
        _gray = img_np.max(axis=2)  # 取最亮通道，白字最亮
        _bw = np.where(_gray > BID_AMOUNT_BIN_THRESHOLD, 255, 0).astype(np.uint8)
        _bw3 = np.dstack([_bw, _bw, _bw])  # 三通道纯黑白，两个模型都喂它
        if int(str(BID_AMOUNT_DEBUG_SAVE).strip() or 0) == 1:
            存数字调试图(
                "debug_bid_amount.png",
                cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR),
            )
            存数字调试图("debug_bid_amount_bin.png", _bw3)
        result = ocr.ocr(_bw3, cls=True)
        # 该框内有上下两行文字：
        #   上面大字 = 你输入的完整数字（520,521）
        #   下面小字 = 游戏自己算的缩写（520.52K）
        # 以前把两行直接首尾相接 → 读成 "520,521520.52K"，只能靠"包含"判定兜住。
        # 现在只取【字最大、且含数字】的那一行（就是输入框那行），小字那行直接丢掉。
        main_line, main_h = 挑金额那一行(result)
        main_text = 去掉单位尾巴(main_line)
        alt_text = ""
        alt_line = ""
        try:
            if amount_ocr_alt is not None:
                res2 = amount_ocr_alt.ocr(_bw3, cls=True)
                alt_line, _alt_h = 挑金额那一行(res2)
                alt_text = 去掉单位尾巴(alt_line)
        except Exception:
            alt_text = ""
        LAST_AMOUNT_ALT = alt_text
        print(
            f"📖 出价金额OCR识别到: {main_text}（只取大字那行 / 框高 {main_h:.0f}px）"
            + (f"（备用模型：{alt_text}）" if alt_text and alt_text != main_text else "")
        )
        RUNLOG_OCR["bid_amount_raw"] = main_text
        RUNLOG_OCR["bid_amount_alt"] = alt_text
        clean_text = re.sub(r"[^\d]", "", main_text)
        if not clean_text:
            clean_text = re.sub(r"[^\d]", "", alt_text)
        return clean_text
    except Exception as e:
        print(f"⚠️ 出价金额OCR异常: {e}")
        return ""


def 截图里有这个模板吗(screenshot_bgr, image_name, threshold=None):
    template_gray = 读图片模板(image_name)
    if template_gray is None:
        return 0.0
    try:
        screenshot_gray = cv2.cvtColor(screenshot_bgr, cv2.COLOR_BGR2GRAY)
        if (
            screenshot_gray.shape[0] < template_gray.shape[0]
            or screenshot_gray.shape[1] < template_gray.shape[1]
        ):
            return 0.0
        res = cv2.matchTemplate(screenshot_gray, template_gray, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(res)
        return max_val
    except Exception as e:
        print(f"⚠️ 模板匹配 {image_name} 出错: {e}")
        return 0.0


def 读数量区域():
    if not running:
        return -1
    try:
        region = 数量区域()
        if region is None:
            return -1
        screenshot = 抓一帧(region=region)
        img_np = np.array(screenshot)
        img_bgr = cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)
        cv2.imwrite(os.path.join(SCREENSHOT_DIR, "debug_count.png"), img_bgr)

        val_1 = 截图里有这个模板吗(img_bgr, COUNT_1_IMAGE)
        val_0 = 截图里有这个模板吗(img_bgr, COUNT_0_IMAGE)

        print(f"📊 剩余数量模板匹配: count_1={val_1:.3f}, count_0={val_0:.3f}")

        if val_1 >= THRESHOLD and val_1 >= val_0:
            print("📊 剩余数量为 1（模板匹配）")
            return 1
        if val_0 >= THRESHOLD and val_0 > val_1:
            print("📊 剩余数量为 0（模板匹配）")
            return 0

        print("ℹ️ 模板匹配未达阈值，回退 OCR 识别...")
        img_rgb = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
        result = ocr.ocr(img_rgb, cls=True)
        full_text = ""
        if result and result[0]:
            for line in result[0]:
                full_text += line[1][0]
        print(f"📖 剩余数量OCR识别到: {full_text}")
        clean_text = re.sub(r"[^\d]", "", full_text)
        if clean_text:
            num = int(clean_text)
            if num == 0:
                print("📊 剩余数量为 0（OCR）")
                return 0
            elif num == 1:
                print("📊 剩余数量为 1（OCR）")
                return 1
            else:
                print(f"⚠️ 剩余数量识别到其他值: {num}，视为失败")
                return -1
        return -1
    except Exception as e:
        print(f"⚠️ 剩余数量识别异常: {e}")
        return -1


def 重试读回合(attempts=6, gap=0.8):
    for i in range(max(1, attempts)):
        if not running:
            return 0
        r = 读当前回合(force=True)
        if r != 0:
            return r
        time.sleep(gap)
    return 0


def 高价确认区域():
    return (HIGH_BID_OFFSET_X - 100, HIGH_BID_OFFSET_Y - 48, 200, 96)


def 高价确认框可见(timeout=0, window=None):
    win = window if window is not None else 游戏窗口范围()
    if win is None:
        return False
    x, y, w, h = 高价确认区域()
    return 画面有吗("step_confirm_high_bid.png", timeout=timeout,
                  region=(win[0] + x, win[1] + y, w, h), threshold=0.84)


def 确认高价出价(verify_timeout=1.0, submitted_epoch=None):
    if submitted_epoch is None:
        return False
    if _等鼠标让行结束(check_bid_pause=True) != "READY":
        return False
    epoch = _USER_MOUSE_EPOCH
    if CURSOR_YIELD_USER and submitted_epoch != epoch:
        return False  # 已无法把弹窗与之前提交的金额对应起来。
    window = 游戏窗口范围()
    if window is None or not 高价确认框可见(verify_timeout, window) or 游戏窗口范围() != window:
        return False
    left, top, _, _ = window
    clicked = _按新画面点击(left + HIGH_BID_OFFSET_X, top + HIGH_BID_OFFSET_Y, epoch)
    if not clicked:
        return False
    print("✅ 已点击异常高价确认按钮")
    return True


def 点红点():
    window = 游戏窗口范围()
    if window is None:
        return False
    left, top, _, _ = window
    安全点击(left + RED_DOT_OFFSET_X, top + RED_DOT_OFFSET_Y)
    return True


def 等下一回合(current_round):
    print(f"⏳ 等待进入下一回合（当前是第 {current_round} 回合）...")
    t_wait = time.time()
    try:
        记回合事件(
            "round_wait_start",
            human=f"⏳ 等待第{current_round + 1}回合（当前第{current_round}回合）",
            current_round=int(current_round),
            next_round=int(current_round) + 1,
            urgent=快没时间了吗(),
        )
    except Exception:
        pass
    _min_wait = MIN_WAIT_AFTER_BID_URGENT if 快没时间了吗() else MIN_WAIT_AFTER_BID
    if not 歇一下(_min_wait):
        return -2
    start_time = time.time()
    _slow_shot_done = False
    unknown_high_bid_logged = False
    while time.time() - start_time < MAX_WAIT_FOR_NEXT_ROUND:
        轮询面板控件()
        if not running:
            return -2
        if 守住重连(f"等第{current_round + 1}回合"):
            start_time = time.time()
            continue
        if not _slow_shot_done and time.time() - start_time > 30:
            _slow_shot_done = True
            try:
                存回合截图(
                    f"等待第{current_round + 1}回合_超过30秒",
                    回合截图区域(),
                    "等下一回合等太久的现场",
                )
                记报错(
                    "wait_next_round_slow",
                    f"等第 {current_round + 1} 回合已经超过 30 秒（上限 {MAX_WAIT_FOR_NEXT_ROUND} 秒），"
                    f"接近超时了",
                    level="警告",
                    shot=False,
                    extra={"current_round": current_round, "ocr": dict(RUNLOG_OCR)},
                )
            except Exception:
                pass
        if 画面有吗("step_skip.png", timeout=0):
            print("⚠️ 检测到跳过动画，说明进入了结算界面")
            标记已结算("wait_next_round", t_wait)
            return -1
        if 画面有吗("step_sell.png", timeout=0):
            print("⚠️ 检测到一键出售按钮，说明进入了结算界面（我拍到）")
            标记已结算("wait_next_round", t_wait)
            return -1
        if not unknown_high_bid_logged and 高价确认框可见():
            unknown_high_bid_logged = True
            _BG_STATE["unverified_high_bid"] = True
            print("⚠️ 高价弹窗无法关联本轮已核对的出价，等待你处理弹窗或回合变化")
        new_round = 读当前回合()
        if new_round > current_round:
            print(f"✅ 检测到进入下一回合: 第 {new_round} 回合")
            标记已结算("wait_next_round", t_wait)
            碰一下进度(f"进入第 {new_round} 回合")
            try:
                记回合事件(
                    "round_detected",
                    human=f"✅ 检测到第{new_round}回合（上一回合等待 {time.time() - t_wait:.2f}s）",
                    round=int(new_round),
                    elapsed_ms=int((time.time() - t_wait) * 1000),
                    previous_round=int(current_round),
                )
            except Exception:
                pass
            return new_round
        elif new_round == 0:
            _miss = _ROUND_OCR_CACHE.get("miss", 0)
            if _miss == 3:
                print("ℹ️ 回合横幅暂时看不到（过渡动画），继续等待…")
        if not 歇一下(NEXT_ROUND_POLL_INTERVAL):
            return -2
    print(f"⏰ 等待下一回合超时（{MAX_WAIT_FOR_NEXT_ROUND}秒），尝试继续执行...")
    标记已结算("wait_next_round_timeout", t_wait)
    try:
        记回合事件(
            "round_wait_timeout",
            human=f"⚠️ 等待第{current_round + 1}回合超时（{MAX_WAIT_FOR_NEXT_ROUND}秒）",
            previous_round=int(current_round),
            timeout=MAX_WAIT_FOR_NEXT_ROUND,
            elapsed_ms=int((time.time() - t_wait) * 1000),
        )
    except Exception:
        pass
    retry_round = 重试读回合()
    if retry_round > current_round:
        return retry_round
    # 超时后仍停在当前回合时，绝不能把“当前回合号”交给主循环当成结算。
    # -3 表示结果不确定，由主循环先验证画面，再决定接结算还是断点续接。
    return -3


def 等完确认结算(previous_round):
    """超时后确认是否真的进入结算；拍卖房间/出价面板一律视为未结算。"""
    state = rc.Screen.UNKNOWN
    for attempt in range(3):
        if not running:
            return False, state
        state = 认流程页()
        if state == rc.Screen.REWARD_TIP:
            关卖出提示()
            if not 歇一下(0.5):
                return False, state
            continue
        if state == rc.Screen.SETTLEMENT:
            return True, state
        if state in (rc.Screen.AUCTION_ROOM, rc.Screen.BID_PANEL, rc.Screen.HALL):
            return False, state
        if attempt < 2 and not 歇一下(0.6):
            return False, state
    print(
        f"⚠️ 等第{int(previous_round) + 1}回合超时后仍无法确认结算画面"
        f"（最后识别：{state}）→ 交给画面恢复"
    )
    return False, state


def 买并使用重试():
    if 找到就点(BUY_AND_USE_IMAGE, "购买并使用", timeout=10):
        return True
    print(f"📍 [状态] 未找到购买并使用，等待 {RETRY_WAIT} 秒后重试...")
    if not 歇一下(RETRY_WAIT):
        return False
    return 找到就点(BUY_AND_USE_IMAGE, "购买并使用", timeout=10)


def 确认购买重试():
    if 找到就点(CONFIRM_BUY_IMAGE, "确认购买", timeout=10):
        return True
    print(f"📍 [状态] 未找到确认购买，等待 {RETRY_WAIT} 秒后重试...")
    if not 歇一下(RETRY_WAIT):
        return False
    return 找到就点(CONFIRM_BUY_IMAGE, "确认购买", timeout=10)


def 数字一样吗(expect, actual, max_edit=1):
    norm = {
        "O": "0",
        "o": "0",
        "D": "0",
        "Q": "0",
        "l": "1",
        "I": "1",
        "i": "1",
        "|": "1",
        "S": "5",
        "s": "5",
        "B": "8",
        "Z": "2",
        "z": "2",
        "g": "9",
    }

    def clean(s):
        s = "".join(norm.get(ch, ch) for ch in (s or ""))
        return re.sub(r"\D", "", s)

    a, b = clean(expect), clean(actual)
    if not a or not b:
        return False
    if a == b:
        return True
    # 位数不一样就不算"读错一位"：以前允许 ±1 位（插入/删除），
    # 结果"520521 被读成 5205210"这种多一位的也会放行。位数不同基本就是真的不一样了，
    # 直接失败、清空重打（重打一遍只要 1~2 秒，比放一个错金额进确认划算）。
    if len(a) != len(b):
        return False
    dp = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        prev, dp[0] = dp[0], i
        for j, cb in enumerate(b, 1):
            cur = dp[j]
            dp[j] = min(dp[j] + 1, dp[j - 1] + 1, prev + (0 if ca == cb else 1))
            prev = cur
    return dp[-1] <= max_edit


# 把 OCR 结果里"输入框那一行"挑出来
# 缩写尾巴：整数部分最多 3 位（游戏显示成 520.52K / 599K / 1.2M 这种），
# 用它把"大字数字"和"小字缩写"之间的边界找出来（OCR 把两行粘一起时用得上）
_AMOUNT_UNIT_TAIL = re.compile(r"(\d{1,3}(?:[.,]\d{1,2})?)\s*[KkMm万亿]\s*$")


def 挑金额那一行(result):
    """从 OCR 结果里挑出【输入框那一行】：字最大、并且含数字的那行。

    为什么：金额校验框里其实有上下两行字 —— 上面大字是你输入的完整数字（520,521），
    下面小字是游戏自己按同一个值算的缩写（520.52K / 599K）。以前把两行首尾相接，
    读出来是「520,521520.52K」，只能靠"包含"判定兜住（而那会把真错的数也放过去）。
    这里按识别框的高度取最高的那行（大字那行），小字那行直接丢掉。
    返回 (文本, 框高)；挑不到返回 ("", 0)。
    """
    best, best_h = "", 0.0
    try:
        for line in result[0] or []:
            try:
                box = line[0]
                txt = str(line[1][0] or "")
            except Exception:
                continue
            if not re.search(r"\d", txt):
                continue
            try:
                ys = [float(p[1]) for p in box]
                h = max(ys) - min(ys)
            except Exception:
                h = 0.0
            if h > best_h:
                best, best_h = txt, h
    except Exception:
        pass
    return best, best_h


def 去掉单位尾巴(t):
    """万一 OCR 把上下两行粘成【一个】框（少见），把带单位的缩写尾巴（520.52K）去掉。

    输入框那行永远是纯数字、不会带 K/M/万/亿，所以去掉尾巴是安全的；
    去掉后前面还必须剩数字，否则原样返回（不乱动）。
    """
    t = str(t or "").strip()
    m = _AMOUNT_UNIT_TAIL.search(t)
    if not m:
        return t
    head = t[: m.start()].strip()
    return head if re.search(r"\d", head) else t


def 出价金额候选(actual_raw):
    out = []
    digits = re.sub(r"[^\d]", "", actual_raw or "")
    if digits:
        out.append(int(digits))
    for m in re.finditer(r"(\d+(?:[.,]\d+)?)\s*([KkMm万亿]?)", (actual_raw or "")):
        try:
            v = float(m.group(1).replace(",", ""))
        except Exception:
            continue
        v *= {"K": 1e3, "k": 1e3, "M": 1e6, "m": 1e6, "万": 1e4, "亿": 1e8}.get(m.group(2), 1)
        if v > 0:
            out.append(int(v))
    return out


def 出价金额对得上(expected_int, actual_raw):
    digits = re.sub(r"[^\d]", "", actual_raw or "")
    if not digits:
        return False
    if int(digits) == int(expected_int):
        return True
    if 数字一样吗(str(expected_int), actual_raw):
        return True
    # 原来这里还有一条"无条件包含"：读到的数字串里含期望数字就算过。
    # 它是为了兜"上下两行粘一起"那个毛病（5,205,210 里含 520521 也能过），
    # 现在改成"只取大字那行 + 粘一起时砍掉单位尾巴"，这条就用不着了 —— 撤掉。
    # 撤掉之后：纯数字多一位/少一位都会判失败（宁可重打一遍，也不放错值进确认）。
    ratio = globals().get("READ_TOLERANCE", 0)
    try:
        ratio = float(ratio)
    except Exception:
        ratio = 0.0
    if ratio > 0 and expected_int > 0:
        lo = expected_int * (1.0 - ratio)
        hi = expected_int * (1.0 + ratio)
        for v in 出价金额候选(actual_raw):
            if lo <= v <= hi:
                return True
    return False


def 出价金额任一匹配(expected_int, *raws):
    for raw in raws:
        if raw and 出价金额对得上(expected_int, raw):
            return True
    return False


def 核对并修出价金额(digit_images, expected_str):
    if not running:
        return "STOP"
    # 大肥鱼：校验开关关掉时直接放行（打完数字就点确认），省 0.7~1.5 秒/回合。
    # 代码整段保留，参数改回 1 立刻恢复。
    try:
        if int(str(BID_AMOUNT_VERIFY_ENABLED).strip() or 1) != 1:
            return True
    except Exception:
        pass
    expected_int = int(re.sub(r"[^\d]", "", expected_str) or 0)
    if expected_int <= 0:
        print(f"❌ 预期出价金额无法解析: {expected_str}")
        return False

    def _ok(actual_raw):
        image = globals().get("LAST_BID_AMOUNT_IMAGE")
        if image is None:
            return False
        available, accepted, decision = 数字模板判定(
            image, expected_value=expected_int
        )
        globals()["LAST_BID_TEMPLATE_DECISION"] = decision
        RUNLOG_OCR["bid_amount_template"] = 数字库概要(decision)
        # The visual template is authoritative when available: it reads what
        # is actually painted in the input box.  OCR supplies diagnostics and
        # the legacy fallback, but a known OCR confusion must not reject a
        # correctly displayed amount.
        if available:
            return bool(accepted)
        return 出价金额任一匹配(expected_int, actual_raw, globals().get("LAST_AMOUNT_ALT"))

    def _template_pass():
        """只做「抓图 + 数字模板判定」，不碰 OCR。

        返回 True=对得上 / False=对不上 / None=模板不可用（那就得走 OCR）。
        这是出价校验的快路径：两次加起来约 0.2~0.3 秒，而一次 OCR 就要 0.7~0.9 秒。
        """
        if 抓出价金额图() is None:
            return None
        image = globals().get("LAST_BID_AMOUNT_IMAGE")
        if image is None:
            return None
        available, accepted, decision = 数字模板判定(
            image, expected_value=expected_int
        )
        globals()["LAST_BID_TEMPLATE_DECISION"] = decision
        RUNLOG_OCR["bid_amount_template"] = 数字库概要(decision)
        if not available:
            return None
        return bool(accepted)

    window = 游戏窗口范围()
    if window is None:
        print("❌ 无法获取窗口位置，无法校验金额")
        return False
    left, top, _, _ = window
    bid_region = 出价区域()

    for attempt in range(BID_AMOUNT_RETRY_MAX):
        if not running:
            return "STOP"

        # ── 快路：数字模板优先，命中就直接放行（不再跑两次 OCR）──────────
        if int(str(BID_VERIFY_TEMPLATE_FIRST).strip() or 0) == 1:
            _tpl = _template_pass()
            if _tpl is True:
                # 高置信：一遍就够（省一次抓图 + 一次模板判定）
                _dec = globals().get("LAST_BID_TEMPLATE_DECISION")
                try:
                    _score = float(getattr(_dec, "min_score", 0) or 0)
                    _margin = float(getattr(_dec, "min_margin", 0) or 0)
                except Exception:
                    _score, _margin = 0.0, 0.0
                try:
                    _need_score = float(BID_VERIFY_SINGLE_PASS_SCORE)
                    _need_margin = float(BID_VERIFY_SINGLE_PASS_MARGIN)
                except Exception:
                    _need_score, _need_margin = 0.99, 0.10
                if _score >= _need_score and _margin >= _need_margin:
                    print(
                        f"✅ 出价金额校验通过（预期 {expected_int:,}，单遍高置信："
                        f"最低分 {_score:.3f} / 最小差 {_margin:.3f}）"
                    )
                    return True
                if not 歇一下(BID_AMOUNT_CONFIRM_GAP):
                    return "STOP" if not running else False
                _tpl2 = _template_pass()
                if _tpl2 is True:
                    print(
                        f"✅ 出价金额校验通过（预期 {expected_int:,}，两遍模板一致；"
                        f"{数字库概要(globals().get('LAST_BID_TEMPLATE_DECISION'))}）"
                    )
                    return True
                if _tpl2 is None:
                    print("ℹ️ 模板第二遍不可用 → 转 OCR 复核")
                else:
                    print("⚠️ 模板第一遍过、第二遍没过（读数不稳定）→ 转 OCR 复核")

        actual_raw = 只读出价金额()
        actual_int = int(re.sub(r"[^\d]", "", actual_raw or "") or 0)
        print(
            f"📊 出价金额校验 第 {attempt + 1}/{BID_AMOUNT_RETRY_MAX} 次："
            f"预期 {expected_int:,}，读到 {actual_int:,}"
        )
        if not _ok(actual_raw):
            for _ in range(3):
                if not 歇一下(0.15):
                    return "STOP" if not running else False
                actual_raw = 只读出价金额()
                actual_int = int(re.sub(r"[^\d]", "", actual_raw or "") or 0)
                if _ok(actual_raw):
                    break
        if _ok(actual_raw):
            # 先别急着通过：隔 0.12 秒再读一遍，两遍都一致才算"读数稳定"。
            # （防止某一帧画面/一次闪读恰好读成了期望值，实际输入框里却不是这个数）
            if not 歇一下(BID_AMOUNT_CONFIRM_GAP):
                return "STOP" if not running else False
            raw2 = 只读出价金额()
            if _ok(raw2):
                _second = int(re.sub(r"[^\d]", "", raw2 or "") or 0)
                print(
                    f"✅ 出价金额校验通过（预期 {expected_int:,} / 读到 {actual_int:,}，"
                    f"第二遍 {_second:,} 也一致；"
                    f"{数字库概要(globals().get('LAST_BID_TEMPLATE_DECISION'))}）"
                )
                return True
            _second = int(re.sub(r"[^\d]", "", raw2 or "") or 0)
            print(
                f"⚠️ 第一遍读到 {actual_int:,}（判过），但第二遍读到 {_second:,} "
                f"→ 判为读数不稳定，清空重打一遍"
            )
            actual_raw = raw2
            actual_int = _second
        else:
            print(f"⚠️ 出价金额不一致：预期 {expected_int:,}，读到 {actual_int:,}")
            if globals().get("LAST_BID_TEMPLATE_DECISION") is not None:
                print("   " + 数字库概要(globals().get("LAST_BID_TEMPLATE_DECISION")))
        if attempt >= BID_AMOUNT_RETRY_MAX - 1:
            break
        print(f"🖱️ 点击清空按钮 ({CLEAR_BID_X}, {CLEAR_BID_Y})")
        if not 安全点击(left + CLEAR_BID_X, top + CLEAR_BID_Y):
            return False
        if not 歇一下(0.5):
            return "STOP" if not running else False
        for img in digit_images:
            if not running:
                return "STOP"
            if bid_region is not None and not 画面有吗(
                BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region
            ):
                print("⚠️ 出价面板已消失，无法重新输入")
                return False
            if not 找到就点(img, f"数字键 {img}", region=bid_region, timeout=2):
                print(f"⚠️ 重新输入数字 {img} 失败")
                return "SKIP"
            if not 歇一下(0.1):
                return "STOP" if not running else False

    if not running:
        return "STOP"
    print(f"⚠️ 出价金额校验失败，已达到最大重试次数 {BID_AMOUNT_RETRY_MAX}")
    记报错(
        "bid_verify_fail",
        f"出价金额校验失败（预期 {expected_int:,}，读到 {actual_int:,}），已重试 "
        f"{BID_AMOUNT_RETRY_MAX} 次仍不一致，放弃本局出价",
        extra={
            "expected": expected_int,
            "actual": actual_int,
            "raw": actual_raw,
            "tolerance": globals().get("READ_TOLERANCE"),
            "ocr": dict(RUNLOG_OCR),
        },
    )
    return False


def 走仪器流程():
    print("\n📍 [状态] 进入仪器组合页面流程...")

    if (画面有吗("step2.png", timeout=3.0)
            or 画面有吗("step2.png", timeout=1.5)):
        _补全成功 = False
        for _try in (1, 2):
            if not 找到就点("step2.png", "一键补全", timeout=3, report_timeout=False):
                break
            if not 歇一下(1.2):
                break
            # 验证：补全成功后，【一键补全】按钮本身会消失（变成【使用】/【开始匹配】）。
            # 注意别用"读剩余数量"当判据 —— 那个区域这时经常读不到，会造成误判。
            if not 画面有吗("step2.png", timeout=0.6):
                _补全成功 = True
                break
            if 画面有吗("step7.png", timeout=0.3) or 画面有吗("step3.png", timeout=0.3):
                _补全成功 = True
                break
            print(f"   ⚠️ 点了【一键补全】但按钮还在（第 {_try} 次）→ 再点一次")
        if _补全成功:
            print("📍 [状态] 一键补全成功（已验证），走完整匹配流程")
            try:
                _INSTRUMENTS_CONSUMED[0] = False
            except Exception:
                pass
            return "MATCH_FULL"
        print("⚠️ 【一键补全】点了没反应 → 关掉仪器页回大厅，这次不开匹配（避免空手进局）")
        关仪器页(quiet=True)
        return False
    print("ℹ️ 页面没有【一键补全】（仪器槽已填好时它不出现），继续走后面的流程")

    if 画面有吗("step3.png", timeout=0) and not _INSTRUMENTS_CONSUMED[0]:
        print("📍 [状态] 没找到一键补全，但页面上有【开始匹配】→ 直接开始匹配")
        记回合事件(
            "instrument_direct_match", human="📌 没有一键补全，页面已有【开始匹配】→ 直接开始匹配"
        )
        return "MATCH_DIRECT"

    if _INSTRUMENTS_CONSUMED[0]:
        print("📦 [状态] 本局消耗过仪器 → 不走『直接匹配』捷径，先到仪器组页面补全/购买")
    win = 游戏窗口范围()
    if win is None:
        print("❌ 无法获取窗口位置，返回主循环")
        return False
    left, top, _, _ = win
    print(f"📍 [状态] 未找到一键补全，点击 (452, 865) 拉到底部")
    if not 安全点击(left + FALLBACK_CLICK_X, top + FALLBACK_CLICK_Y):
        return False
    if not 歇一下(0.5):
        return False

    if not 画面有吗(SUPER_INSTRUMENT_INTRO_IMAGE, timeout=10):
        print("⚠️ 未找到超级品鉴仪器组介绍，返回主循环")
        return False
    if not 歇一下(FALLBACK_INTRO_WAIT):
        return False
    找到就点(SUPER_INSTRUMENT_INTRO_IMAGE, "超级品鉴仪器组介绍", timeout=5)
    if not 歇一下(1):
        return False

    count = 读数量区域()
    if count not in (0, 1):
        print(f"ℹ️ 剩余数量没读准（{count}）→ 再读一次")
        if not 歇一下(0.6):
            return False
        count = 读数量区域()
    if count is not None and isinstance(count, int) and count >= 2:
        # 以前没有这个分支：剩余数量 2 组以上时永远走到 last else → 返回失败 → 卡在仪器页
        print(f"✅ 剩余数量 {count} 组，够用 → 不补货，直接开始匹配")
        try:
            _INSTRUMENTS_CONSUMED[0] = False
        except Exception:
            pass
        关仪器页(quiet=True)
        if not 歇一下(0.5):
            return False
        return "MATCH_DIRECT"
    if count == 1:
        print("📍 [状态] 剩余数量为 1，点击【使用】启用超级品鉴仪器组")
        if not 找到就点("step7.png", "使用仪器", timeout=10, report_timeout=False):
            # 兜底：模板没认到【使用】，但页面上通常还有【购买并使用】那颗按钮
            print("⚠️ 没认到【使用】按钮 → 试着点【购买并使用】兜底")
            if 找到就点(BUY_AND_USE_IMAGE, "购买并使用（兜底）", timeout=3, report_timeout=False):
                if not 歇一下(1.0):
                    return False
                if not 确认购买重试():
                    print("⚠️ 兜底购买没确认成功，返回主循环")
                    return False
                if not 歇一下(1.0):
                    return False
                return "RETRY"
            print("⚠️ 剩余数量为 1，但没有找到【使用】按钮，返回主循环重试")
            return False
        try:
            _INSTRUMENTS_CONSUMED[0] = False   # 仪器组已启用，下一局不会再被当成"消耗过"
        except Exception:
            pass
        关仪器页(quiet=True)                    # 页面不关会挡住大厅/step1 的识别
        if not 歇一下(1):
            return False

        if 画面有吗("step1.png", timeout=5):
            print("📍 [状态] 使用仪器后检测到 step1，准备走匹配流程")
            return "MATCH_SKIP"
        print(f"📍 [状态] 使用仪器后未检测到 step1，等待 {RETRY_WAIT} 秒后重试...")
        if not 歇一下(RETRY_WAIT):
            return False
        if 画面有吗("step1.png", timeout=5):
            print("📍 [状态] 使用仪器后重试检测到 step1，准备走匹配流程")
            return "MATCH_SKIP"
        print("⚠️ 使用仪器后仍未检测到 step1，返回主循环")
        return False

    elif count == 0:
        print("📍 [状态] 剩余数量为 0，开始购买流程")
        if not 买并使用重试():
            print("⚠️ 未找到购买并使用，购买流程失败")
            return False
        if not 歇一下(1):
            return False

        if not 确认购买重试():
            print("⚠️ 未找到确认购买，购买流程失败")
            return False
        if not 歇一下(1):
            return False

        print("📍 [状态] 购买完成，关掉仪器页再回主循环")
        try:
            _INSTRUMENTS_CONSUMED[0] = False
        except Exception:
            pass
        关仪器页(quiet=True)
        if not 歇一下(0.6):
            return False
        return "RETRY"

    else:
        print(f"⚠️ 剩余数量识别失败（读到 {count}）→ 关掉仪器页，返回主循环重试")
        关仪器页(quiet=True)
        return False


def 进场后恢复():
    print(
        f"📍 [状态] 等待 Enter 图标出现（最长 {LOGIN_MAX_WAIT} 秒，阈值 {ENTER_ICON_THRESHOLD}）..."
    )
    start_time = time.time()
    found_enter = False

    while time.time() - start_time < LOGIN_MAX_WAIT:
        if not running:
            return
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            print("✅ 已经进入大厅，无需恢复")
            return
        if 画面有吗(LOGIN_PAGE_IMAGE, timeout=0, threshold=LOGIN_PAGE_THRESHOLD):
            print("ℹ️ 现在停在登录页 → 交回主循环点登录按钮")
            _LOGIN_LOOP_COUNT[0] += 1
            if _LOGIN_LOOP_COUNT[0] <= 5:
                碰一下进度("检测到登录页")
            else:
                print(
                    f"⚠️ 登录页已经连续 {_LOGIN_LOOP_COUNT[0]} 次没进去 → "
                    f"不再刷新卡死计时，让自救重开游戏"
                )
                # 原来只是"等着看门狗来救"，可看门狗依赖两个面板配置
                # （卡死自救开关 + 游戏快捷方式）。实测另一台电脑因为没生效，登录页卡了
                # 1.8 小时没人管。这里到第 10 次就自己重开一次，并写一条带截图的报错。
                if _LOGIN_LOOP_COUNT[0] == 10:
                    try:
                        记报错(
                            "login_loop_stuck",
                            f"登录页连续 {_LOGIN_LOOP_COUNT[0]} 次进不去，" f"尝试自动重开游戏",
                            shot=True,
                        )
                    except Exception:
                        pass
                    if int(RESTART_ON_STUCK or 0) == 1:
                        print("🚨 连续进不去登录页 → 不等看门狗，直接自救一轮")
                        _LOGIN_LOOP_COUNT[0] = 0
                        现在就重启("登录页连续 10 次进不去")
                    else:
                        print(
                            "⚠️ 『卡死自动重启』开关是关的 → 只能继续重试；"
                            "建议打开（控制面板 ② 参数 → 流程重启 · 卡死自救）"
                        )
                        try:
                            异步报警()  # 响一下，提醒你回来看看
                        except Exception:
                            pass
                elif _LOGIN_LOOP_COUNT[0] >= 60 and int(RESTART_ON_STUCK or 0) != 1:
                    # 自救关着、又卡了半小时：与其无声无息挂一整天，不如停下来让人看见
                    print(
                        "⛔ 登录页连续 60 次进不去、自救又是关的 → 停下载机（不关游戏），"
                        "请人工看一眼再点『开始挂机』"
                    )
                    try:
                        记报错(
                            "login_loop_stop",
                            "登录页连续进不去且卡死自救关闭，已主动停机",
                            shot=True,
                        )
                    except Exception:
                        pass
                    try:
                        异步报警()
                    except Exception:
                        pass
                    暂停脚本()
                    return
            return
        if 画面有吗(ENTER_ICON_IMAGE, timeout=0, threshold=ENTER_ICON_THRESHOLD):
            print("✅ 识别到 Enter 图标")
            碰一下进度("识别到 Enter 图标")
            found_enter = True
            break
        if time.time() - start_time > ENTER_WAIT_CHUNK:
            print(
                f"ℹ️ 等了 {ENTER_WAIT_CHUNK} 秒还没看到 Enter 图标 → 先交回主循环重新判断"
                f"（可能是登录页 / 还在加载）"
            )
            return
        time.sleep(1)

    if not found_enter:
        print("⚠️ 未识别到 Enter 图标，恢复失败")
        return

    print(f"⏳ 等待 {AFTER_ENTER_WAIT} 秒后再按 M 键...")
    if not 歇一下(AFTER_ENTER_WAIT):
        return

    hwnd = 取窗口句柄()
    # 如果"都市闲趣"列表已经开着（玩家进门时就停在这个界面），再按 M 会把它关掉
    _urban_already = False
    try:
        _urban_already = bool(画面有吗(URBAN_LEISURE_IMAGE, timeout=0.3))
    except Exception:
        _urban_already = False
    if _urban_already:
        print("✅ 都市闲趣已经在画面上 → 跳过按 M，直接往下点")
    # 后台模式不抢前台（用户可能正在别的窗口打字）
    if hwnd and not 后台模式开着吗() and not _urban_already:
        try:
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.3)
        except Exception as e:
            print(f"⚠️ 拉起窗口失败: {e}")

    # 后台模式下不能再按真键盘：真按键会打到用户当前那个窗口里
    # （比如正在打字的浏览器）。改成往游戏窗口发按键消息，用户完全无感。
    _m_by_msg = False
    if not _urban_already:
        if 后台模式开着吗():
            print("⌨️ 按 M 键（后台模式：往游戏窗口发消息，不碰你的键盘）")
            _m_by_msg = 后台按键(0x4D, hwnd)
            if not _m_by_msg:
                print("   ↳ 发消息失败 → 退回真键盘（会短暂抢一下前台）")
        if not _m_by_msg:
            print("⌨️ 按下 M 键")
            with GAME_ACTION_LOCK:
                win32api.keybd_event(0x4D, 0, 0, 0)
                time.sleep(0.05)
                win32api.keybd_event(0x4D, 0, win32con.KEYEVENTF_KEYUP, 0)

    print(f"⏳ 等待都市闲趣出现（最长 {URBAN_LEISURE_MAX_WAIT} 秒）...")
    urban_start = time.time()
    urban_found = bool(_urban_already)
    while time.time() - urban_start < URBAN_LEISURE_MAX_WAIT:
        if not running:
            return
        if 画面有吗(URBAN_LEISURE_IMAGE, timeout=0):
            urban_found = True
            break
        time.sleep(0.5)

    if not urban_found and _m_by_msg:
        # 后台消息没被游戏接受（有些版本会忽略发过去的按键）→ 老老实实用真键盘再试一次
        print("⚠️ 后台发的 M 键没反应 → 改用真键盘再按一次（会短暂把游戏拉到前台）")
        try:
            if hwnd:
                win32gui.SetForegroundWindow(hwnd)
                time.sleep(0.3)
        except Exception:
            pass
        with GAME_ACTION_LOCK:
            win32api.keybd_event(0x4D, 0, 0, 0)
            time.sleep(0.05)
            win32api.keybd_event(0x4D, 0, win32con.KEYEVENTF_KEYUP, 0)
        urban_start = time.time()
        while time.time() - urban_start < URBAN_LEISURE_MAX_WAIT:
            if not running:
                return
            if 画面有吗(URBAN_LEISURE_IMAGE, timeout=0):
                urban_found = True
                break
            time.sleep(0.5)

    if not urban_found:
        print("⚠️ 未找到都市闲趣，恢复失败")
        return

    print(f"✅ 已确认都市闲趣出现，等待 {AFTER_URBAN_WAIT} 秒后点击固定坐标")
    碰一下进度("恢复：都市闲趣")
    if not 歇一下(AFTER_URBAN_WAIT):
        return

    window = 游戏窗口范围()
    if window is None:
        return
    left, top, _, _ = window

    print(f"🖱️ 点击坐标 ({AFTER_M_CLICK_X1}, {AFTER_M_CLICK_Y1})")
    安全点击(left + AFTER_M_CLICK_X1, top + AFTER_M_CLICK_Y1)
    if not 歇一下(1):
        return

    print(f"🖱️ 点击坐标 ({AFTER_M_CLICK_X2}, {AFTER_M_CLICK_Y2})")
    安全点击(left + AFTER_M_CLICK_X2, top + AFTER_M_CLICK_Y2)
    if not 歇一下(1):
        return

    print("🔍 正在寻找即刻落锤按钮...")
    if not 找到就点(INSTANT_HAMMER_IMAGE, "即刻落锤", timeout=10):
        print("⚠️ 未找到即刻落锤，恢复失败")
        return
    碰一下进度("恢复：已点即刻落槌")
    if not 歇一下(2):
        return

    print(f"⏳ 等待进入竞拍大厅（最长 {AUCTION_HALL_WAIT} 秒）...")
    hall_start = time.time()
    hall_entered = False
    while time.time() - hall_start < AUCTION_HALL_WAIT:
        if not running:
            return
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            hall_entered = True
            break
        time.sleep(1)

    if hall_entered:
        print("✅ 成功进入竞拍大厅，恢复完成！")
        _LOGIN_LOOP_COUNT[0] = 0
        碰一下进度("恢复进入大厅")
    else:
        print("⚠️ 未检测到拍卖大厅特征，可能还未加载完成")


def 从都市闲趣进大厅():
    """当前停在「都市闲趣」列表时，直接点进去 → 即刻落锤 → 等大厅。

    为什么单独拿一段：以前只有"从标题/主世界 Enter"那条路，
    玩家如果手动开在都市闲趣列表上，脚本会一直等 Enter 图标，永远进不去。
    """
    win = 游戏窗口范围()
    if win is None:
        return False
    left, top, _, _ = win
    print("🎪 检测到「都市闲趣」→ 直接点进去（不再等 Enter）")
    安全点击(left + AFTER_M_CLICK_X1, top + AFTER_M_CLICK_Y1)
    if not 歇一下(1):
        return False
    安全点击(left + AFTER_M_CLICK_X2, top + AFTER_M_CLICK_Y2)
    if not 歇一下(1):
        return False
    print("🔍 正在寻找即刻落锤按钮...")
    if not 找到就点(INSTANT_HAMMER_IMAGE, "即刻落锤", timeout=10):
        print("⚠️ 未找到即刻落锤（列表可能没滚到底）")
        return False
    if not 歇一下(2):
        return False
    print(f"⏳ 等待进入竞拍大厅（最长 {AUCTION_HALL_WAIT} 秒）...")
    t0 = time.time()
    while time.time() - t0 < AUCTION_HALL_WAIT:
        if not running:
            return False
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            print("✅ 已进入竞拍大厅")
            碰一下进度("从都市闲趣进入大厅")
            return True
        time.sleep(1)
    return False


def 从登录页救回来():
    if LOGIN_RECOVER_ENABLED != 1:
        return
    print("\n🚨 [恢复] 检测到登录页面，点击登录按钮...")
    window = 游戏窗口范围()
    if window is None:
        return
    left, top, _, _ = window
    print(f"🖱️ 点击登录按钮 ({LOGIN_BTN_X}, {LOGIN_BTN_Y})")
    安全点击(left + LOGIN_BTN_X, top + LOGIN_BTN_Y)
    进场后恢复()


def 从游戏内救回来():
    if LOGIN_RECOVER_ENABLED != 1:
        return
    print("\n🚨 [恢复] 当前在游戏内中间界面，直接从检测 Enter 开始...")
    进场后恢复()


# ============================================================================
# 画面驱动的断点续接 / 卡死恢复
# 目标：不再要求必须从“拍卖大厅 → step1”这一条固定路线开始。
# 每轮先识别当前画面，能续接就直接续接；只有连续多次都认不出来时，
# 才在明确允许的恢复入口发送一次 ESC，再重新识别画面。
# ============================================================================
AUTO_SCREEN_RECOVERY_ENABLED = 1
STUCK_ESC_RECOVERY_ENABLED = 1
STUCK_ESC_COOLDOWN_SECONDS = 30
_FLOW_RECOVERY_STATE = {"unknown_since": 0.0, "last_esc": 0.0}

FLOW_CLIENT_REGION_SETTLEMENT = (1150, 780, 770, 300)
FLOW_CLIENT_REGION_ROOM_LEFT = (250, 820, 650, 260)
FLOW_CLIENT_REGION_ROOM_RIGHT = (1150, 820, 770, 260)
FLOW_CLIENT_REGION_BID_PANEL = (900, 840, 1020, 240)


def 流程灰度图(gray, image_name, box=None, threshold=None):
    """在已经转好的灰度帧里匹配模板。

    原来每次匹配都把整帧 BGR 再转一遍灰度（一帧要转十几次），
    这里改成整帧只转一次，匹配结果和 截图里有这个模板吗 完全一致。
    """
    tpl = 读图片模板(image_name)
    if tpl is None:
        return False
    try:
        target = gray
        if box is not None:
            x, y, w, h = [int(v) for v in box]
            if y < 0 or x < 0 or y + h > target.shape[0] or x + w > target.shape[1]:
                return False
            target = target[y : y + h, x : x + w]
        if target.shape[0] < tpl.shape[0] or target.shape[1] < tpl.shape[1]:
            return False
        res = cv2.matchTemplate(target, tpl, cv2.TM_CCOEFF_NORMED)
        _, max_val, _, _ = cv2.minMaxLoc(res)
        return max_val >= (THRESHOLD if threshold is None else threshold)
    except Exception:
        return False


_FLOW_RESULT_CACHE = {"fp": None, "t": 0.0, "screen": None}
FLOW_RESULT_CACHE_SECONDS = 0.4  # 只缓存这么短的时间，过了就重新认
FLOW_RESULT_CACHE_TOL = 3  # 缩略图灰度最大差，超过就当画面变了


def 流程指纹(gray):
    try:
        return cv2.resize(gray, (64, 36), interpolation=cv2.INTER_AREA)
    except Exception:
        return None


def 指纹像不像(a, b):
    try:
        if a is None or b is None or a.shape != b.shape:
            return False
        return int(np.max(cv2.absdiff(a, b))) <= FLOW_RESULT_CACHE_TOL
    except Exception:
        return False


def 从灰度认流程(gray):
    """纯匹配：按优先级认流程画面。"""
    if 流程灰度图(gray, SELL_CLOSE_TIP_IMAGE, threshold=0.82):
        return rc.Screen.REWARD_TIP
    if 流程灰度图(gray, DAILY_CARD_IMAGE, threshold=0.82):
        return rc.Screen.MONTHLY_CARD
    if 流程灰度图(gray, LOGIN_PAGE_IMAGE, threshold=LOGIN_PAGE_THRESHOLD):
        return rc.Screen.LOGIN
    if 流程灰度图(gray, AUCTION_HALL_IMAGE):
        return rc.Screen.HALL
    if (
        流程灰度图(gray, "step_skip.png", FLOW_CLIENT_REGION_SETTLEMENT, 0.80)
        or 流程灰度图(gray, "step_sell.png", FLOW_CLIENT_REGION_SETTLEMENT, 0.82)
        or 流程灰度图(gray, "step_exit.png", FLOW_CLIENT_REGION_SETTLEMENT, 0.86)
    ):
        return rc.Screen.SETTLEMENT
    if 流程灰度图(gray, BID_DIGIT_CHECK_IMAGE, FLOW_CLIENT_REGION_BID_PANEL, 0.82):
        return rc.Screen.BID_PANEL
    if 流程灰度图(gray, "step5.png", FLOW_CLIENT_REGION_ROOM_LEFT, 0.84) or 流程灰度图(
        gray, "btn_bid.png", FLOW_CLIENT_REGION_ROOM_RIGHT, 0.84
    ):
        return rc.Screen.AUCTION_ROOM
    if 流程灰度图(gray, "step_confirm_exit.png", None, 0.84):
        return rc.Screen.EXIT_CONFIRM
    if 流程灰度图(gray, "step_confirm_high_bid.png", 高价确认区域(), 0.84):
        return rc.Screen.HIGH_BID_CONFIRM
    if 流程灰度图(gray, "step4.png", (650, 650, 700, 400), 0.84):
        return rc.Screen.ENTRY_CONFIRM
    # 放在具体按钮/面板之后：已知流程优先，避免普通界面里的 Enter 字样误抢分类。
    # Enter 画面不一定同时带有大厅/登录页特征；识别后必须交给进入主世界恢复流程。
    if 流程灰度图(gray, ENTER_ICON_IMAGE, threshold=ENTER_ICON_THRESHOLD):
        return rc.Screen.TITLE_ENTER
    return rc.Screen.UNKNOWN


def 从图认流程页(img_bgr):
    """纯函数：给一帧 BGR 画面，返回最可能的流程位置。

    这一步只做模板定位，不做点击。会先把不同 DPI/窗口缩放统一到 1920x1080，
    这是通用缩放兼容，不依赖某一张演示截图的尺寸。
    """
    try:
        if img_bgr is None or getattr(img_bgr, "size", 0) == 0:
            return rc.Screen.UNKNOWN
        img = img_bgr
        if img.shape[1] != RESOLUTION_EXPECT_W or img.shape[0] != RESOLUTION_EXPECT_H:
            img = cv2.resize(
                img,
                (RESOLUTION_EXPECT_W, RESOLUTION_EXPECT_H),
                interpolation=(
                    cv2.INTER_AREA if img.shape[1] > RESOLUTION_EXPECT_W else cv2.INTER_CUBIC
                ),
            )
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        # 同一帧画面（缩略图几乎没差）直接复用上一次的结论：
        # 省掉十几轮模板匹配。画面一动就在 0.4 秒内自动失效。
        fp = 流程指纹(gray)
        now = time.time()
        cache = _FLOW_RESULT_CACHE
        if (
            cache["screen"] is not None
            and now - cache["t"] <= FLOW_RESULT_CACHE_SECONDS
            and 指纹像不像(cache["fp"], fp)
        ):
            return cache["screen"]
        screen = 从灰度认流程(gray)
        cache.update(fp=fp, t=now, screen=screen)
        return screen
    except Exception as e:
        print("⚠️ 画面流程识别异常: %s" % e)
    return rc.Screen.UNKNOWN


def 认流程页():
    """截当前游戏客户区一帧并识别流程位置。"""
    try:
        win = 游戏窗口范围()
        if win is None:
            return rc.Screen.UNKNOWN
        shot = 抓一帧(region=win)
        img_bgr = np.ascontiguousarray(np.array(shot)[:, :, ::-1])
        return 从图认流程页(img_bgr)
    except Exception as e:
        print("⚠️ 截取流程画面失败: %s" % e)
        return rc.Screen.UNKNOWN


def 重置未知流程():
    _FLOW_RECOVERY_STATE["unknown_since"] = 0.0


def 标记未知流程():
    now = time.time()
    if not _FLOW_RECOVERY_STATE["unknown_since"]:
        _FLOW_RECOVERY_STATE["unknown_since"] = now
    return now - _FLOW_RECOVERY_STATE["unknown_since"]


@执行游戏动作
def 游戏里按ESC(where="卡死恢复"):
    """只在明确恢复入口发送一次 ESC；正常对局/流程B仍然绝不按键盘 ESC。"""
    if not running:
        return False
    print("⎋ [画面恢复] %s：发送一次 ESC，然后用新画面重新判断流程。" % where)
    try:
        if 后台模式开着吗():
            ok = 后台按键(0x1B)
            if not ok:
                return False
        else:
            if not 确保在游戏窗口():
                print("⚠️ [画面恢复] 无法确认游戏在前台，取消发送 ESC（避免按到别的窗口）")
                return False
            win32api.keybd_event(0x1B, 0, 0, 0)
            time.sleep(0.06)
            win32api.keybd_event(0x1B, 0, win32con.KEYEVENTF_KEYUP, 0)
        time.sleep(0.8)
        # 【重要】发送 ESC 只是“尝试恢复”，不是流程进展。
        # 这里绝不能 碰一下进度，否则 ESC + 30 秒冷却会不断重置卡死自救计时，
        # 让看门狗永远等不到 STUCK_MINUTES，实际把自救架空。
        记回合事件("screen_escape_recover", human="⎋ 卡死恢复发送 ESC 后重新识别画面", where=where)
        return True
    except Exception as e:
        print("⚠️ [画面恢复] 发送 ESC 失败: %s" % e)
        return False


def 路由拍卖回合(where="断点续接"):
    """当前画面在拍卖房间时，读取当前回合并从该回合续接。"""
    round_num = 重试读回合(attempts=3, gap=0.5)
    if round_num <= 0:
        print("⚠️ [%s] 看到拍卖房间，但回合号暂时读不到，稍后重试。" % where)
        return False
    global in_auction
    if in_auction:
        print("ℹ️ [%s] 已在拍卖状态，等待当前调用返回后再续接。" % where)
        return False
    关仪器页(quiet=True)
    in_auction = True
    try:
        print(
            "♻️ [%s] 检测到第 %d 回合，直接从当前画面续接；"
            "失败/退出后不会按固定路线从头再来。" % (where, round_num)
        )
        try:
            写日志("♻️ [断点续接] 从第 %d 回合当前画面继续" % round_num)
        except Exception:
            pass
        跑一局拍卖(resume_round=round_num, resumed=True)
    finally:
        in_auction = False
        print("📍 [状态] 断点续接流程结束，in_auction 已重置为 False")
    return True


def 路由当前流程页(where="主循环", allow_escape=True):
    """识别当前画面，并且只执行控制策略给出的一个动作。

    所有“画面 -> 动作”判断集中在 runtime_control.plan_flow_action()。本函数
    只负责取得证据和执行动作，不再用散落的 if/continue 自己决定优先级。
    """
    if AUTO_SCREEN_RECOVERY_ENABLED != 1:
        return False

    # 先看是不是停在「都市闲趣」列表上（开局/手动导航常见）——直接进去
    try:
        if 画面有吗(URBAN_LEISURE_IMAGE, timeout=0):
            if 从都市闲趣进大厅():
                return True
    except Exception:
        pass

    state = 认流程页()
    if state == rc.Screen.AUCTION_ROOM:
        if 路由拍卖回合(where):
            return True
        # 房间识别到了但回合号读不到，降级为未知画面走有界 ESC 恢复。
        state = rc.Screen.UNKNOWN

    unknown_sec = 0.0
    if state == rc.Screen.UNKNOWN:
        unknown_sec = 标记未知流程()
        print("🧭 [画面恢复] 当前画面暂未匹配到已知步骤（已持续 %.1f 秒）" % unknown_sec)

    now = time.time()
    esc_ready = now - float(_FLOW_RECOVERY_STATE["last_esc"] or 0) >= STUCK_ESC_COOLDOWN_SECONDS
    decision = rc.plan_flow_action(
        state,
        unknown_seconds=unknown_sec,
        allow_escape=bool(allow_escape and STUCK_ESC_RECOVERY_ENABLED == 1),
        esc_ready=esc_ready,
        auction_finished=bool(_AUCTION_FINISHED[0]),
    )

    if decision.action == rc.Action.WAIT:
        return False

    if decision.action == rc.Action.ESC:
        _FLOW_RECOVERY_STATE["last_esc"] = now
        if not 游戏里按ESC(where):
            return False
        # ESC 后只负责找一个“已知画面”，具体处理仍由同一动作表完成。
        for _ in range(3):
            state = 认流程页()
            if rc.is_known_screen(state) and state != rc.Screen.UNKNOWN:
                重置未知流程()
                decision = rc.plan_flow_action(
                    state,
                    auction_finished=bool(_AUCTION_FINISHED[0]),
                )
                break
            if not 歇一下(0.6):
                return False
        else:
            print("⚠️ [画面恢复] ESC 后仍未识别到可续接步骤，稍后再试")
            return False

    重置未知流程()
    action = decision.action

    if action == rc.Action.DISMISS_REWARD:
        print("🎁 [画面恢复] 检测到『获得物品 / 点击空白区域关闭』，先点掉遮挡层")
        关卖出提示()
    elif action == rc.Action.DISMISS_MONTHLY:
        print("🗓️ [画面恢复] 检测到月卡/领奖弹窗，先执行弹窗清理")
        守住日常弹窗(where)
    elif action == rc.Action.RECOVER_LOGIN:
        print("🔐 [画面恢复] 检测到登录页，执行登录恢复")
        从登录页救回来()
    elif action == rc.Action.RECOVER_TITLE_ENTER:
        print("⌨️ [画面恢复] 检测到标题画面/主世界的 Enter 图标，执行进入主世界并前往拍卖大厅")
        从游戏内救回来()
    elif action == rc.Action.RUN_SETTLEMENT:
        print("🏁 [画面恢复] 检测到结算画面，直接接回结算流程")
        走结算()
    elif action == rc.Action.RETRY_SETTLEMENT_EXIT:
        _SETTLEMENT_EXIT_FAILS[0] += 1
        print(
            "🏁 [画面恢复] 本局已经结算记账，当前只继续退出结算页"
            "（第 %d 次）" % _SETTLEMENT_EXIT_FAILS[0]
        )
        clicked = 限时找图并点("step_exit.png", "结算后退出", timeout=3)
        if clicked and 歇一下(1.0) and 认流程页() != rc.Screen.SETTLEMENT:
            return True
        if _SETTLEMENT_EXIT_FAILS[0] >= 3:
            _SETTLEMENT_EXIT_FAILS[0] = 0
            print("⚠️ [画面恢复] 连续 3 次点不到结算退出，发送 ESC 重新定位画面")
            游戏里按ESC(where)
        return False
    elif action == rc.Action.CLOSE_BID_AND_RESUME:
        print("🎛️ [画面恢复] 检测到出价面板，先关闭面板，再从当前回合续接")
        closed = 关出价面板(quiet=False)
        if closed and 歇一下(0.25):
            return 路由拍卖回合(where)
    elif action == rc.Action.RESUME_AUCTION:
        return 路由拍卖回合(where)
    elif action == rc.Action.HALL_READY:
        return True
    elif action == rc.Action.CONFIRM_EXIT:
        print("🚪 [画面恢复] 检测到退出确认框，点击确认回大厅")
        找到就点("step_confirm_exit.png", "画面恢复：确认退出", timeout=3)
    elif action == rc.Action.CONFIRM_HIGH_BID:
        if not _BG_STATE.get("unverified_high_bid"):
            print("⚠️ [画面恢复] 高价弹窗无法核对来源，等待你处理弹窗")
            _BG_STATE["unverified_high_bid"] = True
        return False
    elif action == rc.Action.CANCEL_ENTRY:
        print("🚪 [画面恢复] 检测到入场费确认框，点【取消】回大厅后重新开始正常开局")
        找到就点(STEP_CANCEL_IMAGE, "画面恢复：取消入场费确认", timeout=3)
    else:
        print("⚠️ [画面恢复] 控制表缺少处理器：%s（%s）" % (action, decision.reason))
        return False
    return True


RESTART_LOCK = threading.Lock()
LAST_PROGRESS_TS = time.time()
_LAST_PROGRESS_WHY = "启动"
_RESTART_HISTORY = []
_GAME_EXE_CACHE = {"path": None}
_STUCK_WARN_TS = [0.0]
_STUCK_WATCH_LOG = [0.0]
_LOGIN_LOOP_COUNT = [0]
_STUCK_MIN_WARNED = [False]
# 认不到大厅时"先把该点的点掉"的连续次数（防止游戏反复弹同一个框时无限点：
# 最多连续处理 3 轮，之后老老实实走原来的恢复/自救路，免得重复花钱）。
_READY_CLEANUP_STREAK = [0]
_READY_CLEANUP_MAX = 3
# 大厅里"既找不到 step1、也没有【开始匹配】"的连续次数：
# 到上限先自救一轮，救不回来才停下载机 —— 防止"进仪器组页面转一圈又回来"的死循环。
_STEP1_MISS_STREAK = [0]
STEP1_MISS_LIMIT = 3
_NET_LAST_CHECK = [0.0]
_NET_HOLD = [False]
_NET_IN_GUARD = [False]


def 重启准备好了():
    p = (LAUNCH_LINK or "").strip().strip('"')
    if not p:
        return False, "没填【游戏启动快捷方式】"
    p = os.path.normpath(p)
    if not os.path.exists(p):
        return False, f"快捷方式路径不存在（{p}）"
    return True, p


def 碰一下进度(why=""):
    global LAST_PROGRESS_TS, _LAST_PROGRESS_WHY
    LAST_PROGRESS_TS = time.time()
    if why:
        _LAST_PROGRESS_WHY = why


def 是不是掉线重连(timeout=0):
    try:
        return 画面有吗(
            NET_RECONNECT_IMAGE, timeout=timeout, threshold=NET_RECONNECT_THRESHOLD
        )
    except Exception as e:
        print(f"⚠️ 网络画面检测出错: {e}")
        return False


def 守住重连(where=""):
    if WAIT_ON_RECONNECT != 1:
        return False
    if _NET_IN_GUARD[0]:
        return False
    now = time.time()
    if now - _NET_LAST_CHECK[0] < NET_RECONNECT_CHECK_INTERVAL:
        return False
    _NET_LAST_CHECK[0] = now
    if not 是不是掉线重连():
        return False

    _wait_limit = max(int(_NET_WAIT_FLOOR_SEC), int(RECONNECT_WAIT_MIN) * 60)
    _where = f"（{where}）" if where else ""
    print(
        f"\n🌐 检测到「网络不稳定，尝试重新连接中」{_where}，原地等它恢复"
        f"（最多 {int(RECONNECT_WAIT_MIN)} 分钟；这期间不会关游戏、不会乱点）"
    )
    写日志("🌐 检测到网络掉线画面，原地等它恢复")
    t0 = time.time()
    _NET_IN_GUARD[0] = True
    _NET_HOLD[0] = True
    try:
        while True:
            time.sleep(2)
            轮询面板控件()
            if not running:
                return True
            if not 是不是掉线重连():
                _secs = time.time() - t0
                print(f"✅ 网络已恢复（等了 {_secs:.0f} 秒），继续流程")
                写日志(f"✅ 网络已恢复（等了 {_secs:.0f} 秒），继续流程")
                碰一下进度("网络已恢复")
                记回合事件(
                    "net_reconnect",
                    human=f"🌐 掉线等待 {_secs:.0f} 秒后恢复",
                    seconds=round(_secs, 1),
                    where=where,
                )
                return True
            if time.time() - t0 >= _wait_limit:
                _msg = (
                    f"⚠️ 掉线画面已经持续 {int((time.time() - t0) / 60)} 分钟还没恢复"
                    f"（上限 {int(RECONNECT_WAIT_MIN)} 分钟）→ 交回主流程，"
                    f"接下来由『卡死自救』按设定处理"
                )
                print(_msg)
                写日志(_msg)
                记报错(
                    "net_reconnect_timeout",
                    _msg,
                    level="警告",
                    shot=False,
                    throttle=300,
                    extra={"seconds": round(time.time() - t0, 1), "where": where},
                )
                记回合事件(
                    "net_reconnect_timeout",
                    human=_msg,
                    seconds=round(time.time() - t0, 1),
                    where=where,
                )
                return False
    finally:
        _NET_IN_GUARD[0] = False
        _NET_HOLD[0] = False


def 游戏程序文件():
    return os.path.join(RUNLOG_DIR, "_游戏进程.txt")


def 游戏窗口列表():
    out = []

    def _cb(hwnd, _):
        t = (win32gui.GetWindowText(hwnd) or "").strip()
        if not t or 是不是自己窗口(t) or WINDOW_TITLE not in t:
            return
        try:
            r = win32gui.GetClientRect(hwnd)
            w, h = int(r[2]), int(r[3])
        except Exception:
            return
        if t == WINDOW_TITLE or (t.startswith(WINDOW_TITLE) and w >= 1280 and h >= 720):
            out.append((hwnd, t, w, h))

    try:
        win32gui.EnumWindows(_cb, None)
    except Exception:
        pass
    return out


_NEVER_KILL = (
    "python.exe",
    "pythonw.exe",
    "explorer.exe",
    "cmd.exe",
    "conhost.exe",
    "powershell.exe",
    "pwsh.exe",
    "taskkill.exe",
)


def 能安全结束吗(exe_path, pid):
    name = os.path.basename(str(exe_path or "")).lower()
    if name in _NEVER_KILL:
        print(f"   ⚠️ 跳过 pid={pid}：{name} 不在该关的名单里")
        return False
    try:
        if exe_path and os.path.abspath(exe_path).lower().startswith(SCRIPT_DIR.lower()):
            print(f"   ⚠️ 跳过 pid={pid}：这个进程在脚本自己的目录里")
            return False
    except Exception:
        pass
    return True


def 记住游戏程序():
    try:
        wins = 游戏窗口列表()
        if not wins:
            return None
        import psutil

        wins.sort(key=lambda x: x[2] * x[3], reverse=True)
        hwnd = wins[0][0]
        _, pid = win32process.GetWindowThreadProcessId(hwnd)
        exe = psutil.Process(pid).exe()
        if exe and 能安全结束吗(exe, pid):
            _GAME_EXE_CACHE["path"] = exe
            with open(游戏程序文件(), "w", encoding="utf-8") as fh:
                fh.write(exe)
            return exe
        return None
    except Exception:
        return None


def 读游戏程序():
    if _GAME_EXE_CACHE.get("path"):
        return _GAME_EXE_CACHE["path"]
    try:
        p = 游戏程序文件()
        if os.path.exists(p):
            with open(p, encoding="utf-8") as fh:
                _GAME_EXE_CACHE["path"] = fh.read().strip() or None
    except Exception:
        pass
    return _GAME_EXE_CACHE.get("path")


def 结束游戏进程():
    if not running:
        print("⏹️ 脚本已停止 → 不关游戏")
        return 0
    pids = {}
    for hwnd, t, _w, _h in 游戏窗口列表():
        try:
            _, pid = win32process.GetWindowThreadProcessId(hwnd)
            if pid:
                pids[pid] = t
        except Exception:
            pass

    exe = 读游戏程序()
    try:
        import psutil

        if exe and 能安全结束吗(exe, "cached"):
            for proc in psutil.process_iter(["pid", "exe"]):
                try:
                    if (proc.info.get("exe") or "").lower() == exe.lower():
                        pids[proc.info["pid"]] = exe
                except Exception:
                    continue
    except Exception:
        psutil = None

    killed = 0
    for pid in list(pids):
        try:
            if not running:
                print("⏹️ 脚本已停止 → 停止关闭剩下的游戏进程")
                break
            if psutil is not None:
                _exe_now = ""
                try:
                    _exe_now = psutil.Process(pid).exe()
                except Exception:
                    _exe_now = ""
                if not 能安全结束吗(_exe_now, pid):
                    continue
            if psutil is not None:
                proc = psutil.Process(pid)
                for child in proc.children(recursive=True):
                    try:
                        child.terminate()
                    except Exception:
                        pass
                proc.terminate()
                try:
                    proc.wait(timeout=KILL_GAME_WAIT)
                except Exception:
                    proc.kill()
            else:
                os.system("taskkill /F /T /PID %d >nul 2>nul" % int(pid))
            killed += 1
            print(f"   🛑 已关闭游戏进程 pid={pid}")
        except Exception:
            continue
    return killed


@执行游戏动作
def 原始点击(x, y, desc=""):
    ok = _前台点击(x, y, pre=0.10, hold=0.06, post=0.10)
    if ok:
        print(f"🖱️ 点击【{desc}】坐标 ({x}, {y})")
    return ok


def 找启动按钮(threshold=None):
    tpl = 读图片模板(LAUNCHER_START_IMAGE)
    if tpl is None:
        return None
    if threshold is None:
        threshold = LAUNCHER_BUTTON_THRESHOLD
    try:
        gray = 抓灰度图(None)
    except Exception:
        return None
    best_score, best = 0.0, None
    for s in (1.0, 0.95, 1.05, 0.9, 1.1, 0.85, 1.15, 0.8, 1.2, 0.75, 1.25, 1.3, 1.4, 1.5):
        tt = cv2.resize(
            tpl, None, fx=s, fy=s, interpolation=cv2.INTER_AREA if s < 1 else cv2.INTER_CUBIC
        )
        h, w = tt.shape[:2]
        if h >= gray.shape[0] or w >= gray.shape[1]:
            continue
        res = cv2.matchTemplate(gray, tt, cv2.TM_CCOEFF_NORMED)
        _, mx, _, loc = cv2.minMaxLoc(res)
        if mx > best_score:
            best_score = mx
            best = (loc[0] + w // 2, loc[1] + h // 2, round(s, 2))
    if best and best_score >= threshold:
        return best[0], best[1], best_score, best[2]
    return None


def 等游戏窗口(timeout):
    start = time.time()
    while time.time() - start < timeout:
        if not running:
            return None
        win = 游戏窗口范围()
        if win and abs(win[2] - 1920) <= 60 and abs(win[3] - 1080) <= 60:
            记住游戏程序()
            return win
        time.sleep(2)
    return None


def 聚焦那个窗口(x, y):
    try:
        hwnd = win32gui.WindowFromPoint((int(x), int(y)))
        if not hwnd:
            return False
        root = win32gui.GetAncestor(hwnd, win32con.GA_ROOT)
        if root and win32gui.IsWindow(root):
            窗口提到前面(root)
            time.sleep(0.4)
            return True
    except Exception:
        pass
    return False


def 用一次重启额度():
    global running
    now = time.time()
    while _RESTART_HISTORY and now - _RESTART_HISTORY[0] > 3600:
        _RESTART_HISTORY.pop(0)
    if len(_RESTART_HISTORY) >= max(1, int(RESTART_HOURLY_CAP)):
        msg = (
            f"⛔ 一小时内已经自动重启 {len(_RESTART_HISTORY)} 次（上限 {RESTART_HOURLY_CAP}），"
            f"先停下载机，请人工看一眼游戏"
        )
        print("🚨 " + msg)
        写日志("🚨 " + msg)
        记报错("restart_limit", msg, shot=False)
        记回合事件("restart_limit", human=msg, restarts=len(_RESTART_HISTORY))
        # 这类情况意味着脚本即将停止、需要人工确认，因此同时响一次警报，
        # 免得你不在电脑前、只留一条日志没人注意。
        try:
            异步报警()
        except Exception:
            pass
        running = False
        return False
    _RESTART_HISTORY.append(now)
    return True


def 快捷方式指向(path):
    try:
        if str(path).lower().endswith(".lnk"):
            import win32com.client

            target = win32com.client.Dispatch("WScript.Shell").CreateShortcut(path).TargetPath
            return target or path
    except Exception:
        pass
    return path


def 快照窗口():
    out = set()
    _bad = (
        "textinputhost.exe",
        "explorer.exe",
        "applicationframehost.exe",
        "searchhost.exe",
        "startmenuexperiencehost.exe",
        "shellexperiencehost.exe",
        "sihost.exe",
        "dwm.exe",
    )

    def _cb(hwnd, _):
        try:
            if not win32gui.IsWindowVisible(hwnd):
                return
            if 是不是自己窗口(win32gui.GetWindowText(hwnd) or ""):
                return
            try:
                import psutil

                _, _pid = win32process.GetWindowThreadProcessId(hwnd)
                if psutil.Process(_pid).name().lower() in _bad:
                    return
            except Exception:
                pass
            r = win32gui.GetClientRect(hwnd)
            if int(r[2]) < 400 or int(r[3]) < 300:
                return
            out.add(hwnd)
        except Exception:
            pass

    try:
        win32gui.EnumWindows(_cb, None)
    except Exception:
        pass
    return out


def 那个进程的窗口(pid):
    out = []

    def _cb(hwnd, _):
        try:
            _, p = win32process.GetWindowThreadProcessId(hwnd)
            if p != pid or not win32gui.IsWindowVisible(hwnd):
                return
            r = win32gui.GetClientRect(hwnd)
            if int(r[2]) >= 400 and int(r[3]) >= 300:
                out.append(hwnd)
        except Exception:
            pass

    try:
        win32gui.EnumWindows(_cb, None)
    except Exception:
        pass
    return out


def 聚焦启动器窗口(before=None, launcher_dir=None, quiet=True):
    dir_cands = []
    if launcher_dir:
        try:
            import psutil

            for proc in psutil.process_iter(["pid", "exe"]):
                exe = proc.info.get("exe") or ""
                if exe and os.path.dirname(exe).lower() == str(launcher_dir).lower():
                    for h in 那个进程的窗口(proc.info["pid"]):
                        try:
                            # 只跳过真正的游戏窗口；启动器标题是「异环启动器」，
                            # 用包含判断会把它一起跳过，结果它从来抢不到前台，
                            # 点【开始游戏】就容易点到别的窗口上。
                            if (win32gui.GetWindowText(h) or "").strip() == WINDOW_TITLE:
                                continue
                        except Exception:
                            pass
                        dir_cands.append(h)
        except Exception:
            pass
    new_cands = []
    if before:
        try:
            new_cands = [h for h in 快照窗口() if h not in before]
        except Exception:
            pass
    cands = dir_cands or new_cands
    best, area = None, -1
    for h in set(cands):
        try:
            r = win32gui.GetClientRect(h)
            a = int(r[2]) * int(r[3])
        except Exception:
            continue
        if a > area:
            best, area = h, a
    if not best:
        return None
    try:
        title = win32gui.GetWindowText(best) or ""
    except Exception:
        title = ""
    ok = 窗口提到前面(best)
    if not quiet:
        print(
            f"🪟 把启动器窗口抓到最前台：{title!r} → "
            f"{'成功' if ok else '没成功（被系统前台锁挡住，会再试）'}"
        )
    return best


def 等启动按钮(before=None, launcher_dir=None):
    gap = max(1, int(LAUNCHER_WAIT_SEC))
    tries = int(LAUNCHER_TRIES)
    unlimited = tries <= 0
    print(
        f"⏳ 先等 {gap} 秒让启动器界面渲染完，再找【开始游戏】"
        f"（{'一直等到按钮出现' if unlimited else '最多 %d 次' % tries}）..."
    )
    if not 歇一下(gap):
        return False
    attempt = 0
    t_start = time.time()
    last_log = 0.0
    last_shot = 0.0
    while True:
        attempt += 1
        if not running:
            return False
        聚焦启动器窗口(before, launcher_dir, quiet=True)
        hit = 找启动按钮()
        if hit:
            x, y, score, s = hit
            print(
                f"✅ 找到【开始游戏】（第 {attempt} 次尝试｜"
                f"匹配度 {score:.2f}，缩放 {s}）→ 点击"
            )
            聚焦那个窗口(x, y)
            原始点击(x, y, "开始游戏")
            return True
        if (not unlimited) and attempt >= tries:
            msg = f"⛔ 连续 {tries} 次都没找到【开始游戏】按钮 → 判定卡住，关掉重来一轮"
            print(msg)
            写日志("⛔ " + msg)
            记报错("restart_launcher_timeout", msg, shot=False)
            记回合事件("restart_launcher_timeout", human=msg, tries=tries)
            try:
                存回合截图("auto_restart_launcher_timeout", None, "没找到开始游戏按钮")
            except Exception:
                pass
            return False
        if time.time() - last_log > 60:
            last_log = time.time()
            mins = (time.time() - t_start) / 60.0
            # 带上前台窗口标题：一眼能看出是卡在启动器、还是启动器压根没起来
            try:
                import win32gui as _wg

                _fg = (_wg.GetWindowText(_wg.GetForegroundWindow()) or "").strip()
            except Exception:
                _fg = ""
            _fg = _fg or "（无标题/桌面）"
            print(
                f"   …还没看到【开始游戏】（第 {attempt} 次尝试，已等 {mins:.1f} 分钟；"
                f"当前前台：{_fg}）"
            )
            if mins >= 1:
                写日志(f"⏳ [自救] 还在等【开始游戏】按钮（已 {mins:.1f} 分钟，前台：{_fg}）")
            # 卡了 5 分钟以上，每 5 分钟留一张现场图，事后能看清启动器停在哪
            if mins >= 5 and time.time() - last_shot > 300:
                last_shot = time.time()
                try:
                    存回合截图("wait_start_button", None, f"等开始游戏按钮 {mins:.0f} 分钟")
                except Exception:
                    pass
        if not 歇一下(gap):
            return False


def 等标题画面(minutes):
    timeout = max(1, int(minutes)) * 60
    start = time.time()
    last_log = 0.0
    last_focus = time.time()
    print(f"⏳ 等标题画面出现（Enter 图标 / 登录页 / 大厅，上限 {int(minutes)} 分钟）...")
    while time.time() - start < timeout:
        if not running:
            return False, "脚本被停止"
        try:
            win = 游戏窗口范围()
            if win:
                if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
                    return True, "已经在拍卖大厅"
                if 画面有吗(LOGIN_PAGE_IMAGE, timeout=0, threshold=LOGIN_PAGE_THRESHOLD):
                    return True, "已到登录页（资源校验已过）"
                if 画面有吗(ENTER_ICON_IMAGE, timeout=0, threshold=ENTER_ICON_THRESHOLD):
                    return True, "标题画面的 Enter 图标"
        except Exception:
            pass
        if time.time() - last_focus > 30:
            last_focus = time.time()
            try:
                _gh = 缓存窗口句柄()
                if _gh:
                    窗口提到前面(_gh)
            except Exception:
                pass
        if time.time() - last_log > 60:
            last_log = time.time()
            print(
                f"   …还在资源校验/加载中（已等 {(time.time() - start) / 60:.1f} 分钟，"
                f"上限 {int(minutes)} 分钟）"
            )
        if not 歇一下(TITLE_SCREEN_CHECK_GAP):
            return False, "脚本被停止"
    return False, f"等了 {int(minutes)} 分钟还没出现标题画面"


def 真正去重启(reason):
    global LAST_PROGRESS_TS, running
    if not RESTART_LOCK.acquire(blocking=False):
        return False
    try:
        _ok_path, _path_info = 重启准备好了()
        if not _ok_path:
            msg = (
                f"⚠️ {_path_info}，没法自动重启（请到控制面板 →② 参数 → 流程重启 · 卡死自救 里填）"
            )
            print(msg)
            记报错("restart_not_ready", msg, shot=False, extra={"path": LAUNCH_LINK})
            return False
        shortcut = _path_info

        print(f"\n🚨🚨🚨 [自救] {reason} → 开始重启游戏")
        写日志(f"🚨 [自救] {reason} → 关游戏重开")
        记回合事件("auto_restart", human=f"🚨 [自救] {reason} → 关游戏重开", reason=reason)
        try:
            存回合截图("auto_restart_before", None, "自救前的现场")
        except Exception:
            pass
        LAST_PROGRESS_TS = time.time()

        attempt = 0
        while True:
            attempt += 1
            if not running:
                print("⏹️ 已经手动停止 → 取消自救（游戏保持原样，你可以直接接管）")
                写日志("⏹️ [自救] 手动停止，取消自救（不关游戏）")
                return False
            if not 用一次重启额度():
                return False
            LAST_PROGRESS_TS = time.time()
            print(f"\n🔁 第 {attempt} 轮：关游戏 → 重开 → 等标题画面")

            n = 结束游戏进程()
            print(f"🛑 已关闭游戏进程 {n} 个")
            if not 歇一下(3):
                return False

            print(f"🚀 启动游戏启动器：{shortcut}")
            try:
                _before = 快照窗口()
            except Exception:
                _before = set()
            try:
                _ldir = os.path.dirname(快捷方式指向(shortcut))
            except Exception:
                _ldir = ""
            try:
                os.startfile(shortcut)
            except Exception as e:
                msg = f"启动失败：{e}"
                print("⚠️ " + msg)
                记报错("restart_launch_fail", msg, extra={"path": shortcut})
                return False

            print("🪟 等启动器窗口出现，并把它抓到最前台...")
            for _ in range(40):
                _h = 聚焦启动器窗口(_before, _ldir, quiet=True)
                if _h:
                    try:
                        _t = win32gui.GetWindowText(_h) or "(无标题)"
                    except Exception:
                        _t = "(未知)"
                    print(f"   ✅ 启动器窗口已抓到最前台：{_t!r}")
                    break
                if not 歇一下(1):
                    return False
            else:
                print("   ⚠️ 没认出刚弹出的启动器窗口，继续按『整屏找按钮』的方式等")

            if not 等启动按钮(_before, _ldir):
                if not running:
                    print("⏹️ 已经手动停止 → 取消自救（不关游戏）")
                    return False
                print("🔁 判定卡住 → 回到开头重来一轮")
                continue

            print(f"⏳ 等游戏窗口出现（最长 {GAME_BOOT_WAIT_MAX} 秒）...")
            win = 等游戏窗口(GAME_BOOT_WAIT_MAX)
            if not win:
                if not running:
                    print("⏹️ 已经手动停止 → 取消自救（不关游戏）")
                    return False
                msg = (
                    f"⛔ 点了【开始游戏】后 {GAME_BOOT_WAIT_MAX} 秒内没等到游戏窗口 → 关掉重来一轮"
                )
                print(msg)
                写日志("⛔ " + msg)
                记报错("restart_game_timeout", msg)
                记回合事件("restart_game_timeout", human=msg)
                continue
            print(f"✅ 游戏窗口已出现（{win[2]}x{win[3]}），继续等标题画面")

            ok, why = 等标题画面(TITLE_WAIT_MINUTES)
            if ok:
                print(f"✅ 标题画面已出现（{why}），交回主流程继续")
                写日志(f"✅ [自救] 第 {attempt} 轮成功：{why}，交回主流程")
                记回合事件(
                    "auto_restart_done", human=f"✅ [自救] 游戏重启完成（{why}）", attempt=attempt
                )
                _NEED_BRING_FRONT[0] = True
                碰一下进度("自救完成")
                return True
            if not running:
                print("⏹️ 已经手动停止 → 取消自救（游戏保持原样，你可以直接接管）")
                写日志("⏹️ [自救] 手动停止，取消自救（不关游戏）")
                return False
            msg = f"⛔ 第 {attempt} 轮：{why} → 把游戏关掉，重来一轮"
            print(msg)
            写日志("⛔ " + msg)
            记报错("restart_title_timeout", msg)
            记回合事件("restart_title_timeout", human=msg, attempt=attempt)
            try:
                存回合截图(f"auto_restart_title_timeout_{attempt}", None, "没等到标题画面")
            except Exception:
                pass
    except Exception as e:
        print(f"⚠️ 自救流程异常: {e}")
        记报错("restart_crash", f"自救流程异常: {e}", exc=e)
        return False
    finally:
        RESTART_LOCK.release()


def 现在就重启(reason):
    with CONTROL_AUTH.operation(rc.Mode.RECOVERY, "auto-restart"):
        return 真正去重启(reason)


# ======================================================================
# 闪退秒级自救（移植自 v1 的 window.is_alive() / process_running 检测）
#   爱音原本只有「5 分钟没进展 → 自救」；游戏闪退后主循环只是空转，
#   最坏要等满 STUCK_MINUTES 才救。这里补一个 0.5 秒轮询的存活看门狗：
#   窗口 + 进程都没了 → 立刻调现成的【现在就重启】，仍受额度/锁/暂停约束。
# ======================================================================
_WINDOW_LOST_STATE = {"seen": False, "miss": 0, "warn_ts": 0.0}


def 游戏进程还在吗():
    """游戏主程序还活着吗。True/False/None（判不了，比如拿不到 exe 路径）。"""
    try:
        exe = (读游戏程序() or "").strip()
    except Exception:
        exe = ""
    if not exe:
        return None
    try:
        import psutil
    except Exception:
        return None
    try:
        for proc in psutil.process_iter(["exe"]):
            try:
                if (proc.info.get("exe") or "").lower() == exe.lower():
                    return True
            except Exception:
                continue
    except Exception:
        return None
    return False


def 窗口消失监控线程():
    """游戏窗口/进程没了 → 立刻自救，不必等满 STUCK_MINUTES 分钟。

    刻意保守，宁可漏救也不误救：
      · 从没见过游戏窗口（还没开局/还没拉起游戏）→ 不动；
      · 暂停中、结算等大厅、月卡值守、掉线等待、正在自救 → 不动；
      · 连续 WINDOW_LOST_CONFIRM_HITS 次（约 1.5 秒）都看不到窗口才算；
      · 进程还活着（只是窗口被藏/标题变了）→ 不动，交给 5 分钟卡死自救。
    """
    while True:
        try:
            time.sleep(float(WINDOW_LOST_POLL_SEC))
            if int(str(WINDOW_LOST_WATCH).strip() or 0) != 1:
                continue
            if not running or 等用户操作():
                _WINDOW_LOST_STATE["miss"] = 0
                continue
            if RESTART_LOCK.locked() or _NET_HOLD[0]:
                _WINDOW_LOST_STATE["miss"] = 0
                continue
            if 游戏窗口列表():
                _WINDOW_LOST_STATE["seen"] = True
                _WINDOW_LOST_STATE["miss"] = 0
                continue
            if not _WINDOW_LOST_STATE["seen"]:
                continue
            _WINDOW_LOST_STATE["miss"] += 1
            if _WINDOW_LOST_STATE["miss"] < int(WINDOW_LOST_CONFIRM_HITS):
                continue
            _WINDOW_LOST_STATE["miss"] = 0
            _proc = 游戏进程还在吗()
            if _proc is True:
                continue
            _msg = (
                "🚨 游戏窗口消失（进程也退出）→ 立即自救重启"
                if _proc is False
                else "🚨 游戏窗口消失（进程状态未知）→ 立即自救重启"
            )
            print(_msg)
            try:
                写日志(_msg)
            except Exception:
                pass
            try:
                记报错("window_lost", _msg, level="严重", shot=False)
            except Exception:
                pass
            if not 重启准备好了()[0]:
                _now = time.time()
                if _now - _WINDOW_LOST_STATE["warn_ts"] > 600:
                    _WINDOW_LOST_STATE["warn_ts"] = _now
                    _tip = "⚠️ 游戏没了但没配『启动游戏快捷方式』，没法自动重启（参数→流程重启·卡死自救里填）"
                    print(_tip)
                    try:
                        写日志(_tip)
                    except Exception:
                        pass
                time.sleep(10)
                continue
            现在就重启("游戏窗口/进程消失")
            time.sleep(10)   # 自救期间别反复触发；真正去重启 内部还有锁和额度
        except Exception as e:
            try:
                print(f"⚠️ 窗口监控线程异常: {e}")
            except Exception:
                pass
            time.sleep(1.0)


def 重启线程():
    global LAST_PROGRESS_TS
    while True:
        try:
            time.sleep(5)
            if not running:
                continue
            if 等用户操作() or (CURSOR_YIELD_USER and _近期有用户输入()):
                LAST_PROGRESS_TS = time.time()  # 暂停/等用户时不算卡死，倒计时清零
                continue
            if RESTART_ON_STUCK != 1:
                continue
            if RESTART_LOCK.locked():
                continue
            if _NET_HOLD[0]:
                continue
            _mins = int(STUCK_MINUTES)
            if _mins < 2:
                if not _STUCK_MIN_WARNED[0]:
                    _STUCK_MIN_WARNED[0] = True
                    _w = (
                        f"⚠️ 『多久没进展算卡死』填的是 {_mins} 分钟，太短（一局平均 2 分多钟），"
                        f"本次按 2 分钟算；建议改成 5"
                    )
                    print(_w)
                    写日志(_w)
                _mins = 2
            limit = max(1, _mins) * 60
            idle = time.time() - LAST_PROGRESS_TS
            # 卡死倒计时每分钟留一条痕迹：万一下次它该救却没救，日志里能直接看出
            # 是"等用户操作/自救锁/网络等待"哪一关把看门狗挡住了。
            if idle >= 60 and time.time() - _STUCK_WATCH_LOG[0] >= 60:
                _STUCK_WATCH_LOG[0] = time.time()
                try:
                    写日志(
                        f"🔎 [看门狗] 已 {idle / 60:.1f} 分钟没进展（阈值 {_mins} 分钟）"
                        f"｜等用户={等用户操作()}｜锁={RESTART_LOCK.locked()}"
                        f"｜网络等待={_NET_HOLD[0]}｜running={running}"
                    )
                except Exception:
                    pass
            if idle < limit:
                continue
            _ok, _info = 重启准备好了()
            if not _ok:
                if time.time() - _STUCK_WARN_TS[0] > 600:
                    _STUCK_WARN_TS[0] = time.time()
                    _msg = (
                        f"⏰ 已经 {idle / 60:.1f} 分钟没有任何进展，但{_info}，没法自动重启"
                        f"（控制面板 →② 参数 → 流程重启 · 卡死自救 里填）"
                    )
                    print("⚠️ " + _msg)
                    写日志("⚠️ " + _msg)
                    记报错("restart_not_ready", _msg, level="警告", shot=False)
                continue
            print(
                f"⏰ 已经 {idle / 60:.1f} 分钟没有任何进展（阈值 {STUCK_MINUTES} 分钟）→ 触发自救"
            )
            现在就重启(f"卡住超过 {int(STUCK_MINUTES)} 分钟没进展")
        except Exception as e:
            print(f"⚠️ 自救线程异常: {e}")
            time.sleep(5)


def 等出价面板(bid_region, timeout=None):
    """Poll for the bid panel and return as soon as it is visible."""
    try:
        limit = float(BID_PANEL_READY_TIMEOUT if timeout is None else timeout)
    except Exception:
        limit = 1.8
    started = time.time()
    while time.time() - started <= limit:
        if not running:
            return None
        r = 暂停时等着()
        if r in ("SKIP", "STOP"):
            return r
        if 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region):
            return time.time() - started
        if not 歇一下(0.08):
            return "STOP" if not running else None
    return None


def 关出价面板(quiet=True):
    """Close an already-open bid panel by its verified top-right X button."""
    bid_region = 出价区域()
    if bid_region is None or not 画面有吗(
        BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region
    ):
        return False
    window = 游戏窗口范围()
    if window is None:
        return False
    left, top, _, _ = window
    安全点击(left + BID_PANEL_CLOSE_X, top + BID_PANEL_CLOSE_Y)
    if not 歇一下(0.2):
        return False
    closed = not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region)
    if not quiet:
        print("🚪 已关闭出价面板" if closed else "⚠️ 出价面板关闭后仍在")
    return closed


def 定出价键位(bid_region, tokens):
    """Locate every requested key (digit / "0000" / "00") in one screenshot.

    The numeric keypad does not move, so one screen capture is enough to build
    a coordinate map and avoid repeated full-region template searches.
    """
    if bid_region is None:
        return {}
    wanted = []
    for tok in tokens:
        tok = str(tok)
        if tok and tok not in wanted:
            wanted.append(tok)
    if not wanted:
        return {}
    try:
        gray = 抓灰度图(bid_region)
    except Exception:
        return {}
    left, top = int(bid_region[0]), int(bid_region[1])
    positions = {}
    used = set()
    for tok in wanted:
        template = 读图片模板("num_%s.png" % tok)
        if template is None:
            return {}
        found, center_x, center_y = 最佳模板匹配(gray, template)
        if not found:
            return {}
        screen_pos = (left + center_x, top + center_y)
        if screen_pos in used:
            return {}
        used.add(screen_pos)
        positions[tok] = screen_pos
    return positions


def 按键位输数字(tokens, bid_region, positions):
    """Click pre-located keys (digit / "0000" / "00"), then re-check the panel once."""
    # 普通局按键之间慢一点（BID_DIGIT_CLICK_GAP），紧迫危机保持 0.04
    _gap = BID_DIGIT_CLICK_GAP_URGENT if 快没时间了吗() else BID_DIGIT_CLICK_GAP
    _keys = [str(t) for t in tokens]
    _last_idx = len(_keys) - 1
    # 每个键都检查真实鼠标输入，光标仅在最后一下尝试还原。
    _old_cursor = None
    try:
        if int(CURSOR_RESTORE or 0) == 1:
            import win32api as _w32
            _old_cursor = _w32.GetCursorPos()
    except Exception:
        _old_cursor = None
    placed = None
    try:
        for idx, key in enumerate(_keys):
            if not running:
                return "STOP"
            result = 暂停时等着()
            if result in ("SKIP", "STOP"):
                return result
            if key not in positions:
                return False
            if placed and CURSOR_YIELD_USER and not 后台确保鼠标(*placed):
                return False
            if not 安全点击(*positions[key], wait_idle=(idx == 0), restore=0):
                return False
            placed = positions[key]
            if not 歇一下(_gap):
                return "STOP" if not running else False
    finally:
        if placed is not None:
            后台还鼠标(_old_cursor, placed)
    if not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region):
        return False
    return True


def 着急时输数字(tokens, bid_region):
    """Static-coordinate fallback for the urgent 20-second mode.

    这里只有数字键的写死坐标，所以把 "0000"/"00" 这类成组 token 摊回逐位数字。
    """
    window = 游戏窗口范围()
    if window is None:
        return False
    left, top, _, _ = window
    positions = {tok: (left + x, top + y) for tok, (x, y) in BID_KEY_POSITIONS.items()}
    digits = []
    for tok in tokens:
        key = str(tok)
        match = re.search(r"num_(\d+)\.png", key)
        if match:
            key = match.group(1)
        digits.extend(list(key))
    return 按键位输数字(digits, bid_region, positions)


# ======================================================================
# 举报面板：看三个对手是不是都跑了
# 实测：点右上角【举报】会开出玩家列表，三行头像右下角的黑圆里是等级；
# 谁离开这局，等级就变成 0。所以第 3、5 回合顺手看一眼，三个都是 0
# 就说明没人会跟价了，出一块钱直接拿下。
# 坐标是 1920x1080 游戏画面里量的（按窗口大小等比缩放）。
# ======================================================================
OPPONENTS_GONE_CHECK = 1
OPPONENTS_GONE_ROUNDS = (2, 3, 4, 5)
OPPONENTS_GONE_PRICE = 1
OPPONENTS_GONE_LV_CENTERS = ((194, 293), (196, 460), (198, 627))
OPPONENTS_GONE_LV_SIZE = (36, 40)


class _后台举报:
    """后台线程查举报面板：开始 → 等结果（带超时）。

    为什么要后台：慢机器上"点举报→读等级→关面板"要 2~4 秒，而用道具后
    本来就要停 3.3 秒等估价 —— 把这两件事叠起来，等于白赚 2~4 秒。
    """

    def __init__(self):
        self.box = {"done": False, "v": None}
        self.th = None

    def 开始(self):
        import threading

        def _run():
            try:
                self.box["v"] = 对手跑光了吗()
            except Exception:
                self.box["v"] = None
            finally:
                self.box["done"] = True

        self.th = threading.Thread(target=_run, daemon=True)
        self.th.start()
        return self

    def 取结果(self, timeout=2.0):
        """等最多 timeout 秒；没等到就收拾现场（关面板）再返回 None。"""
        if self.th is None:
            return None
        try:
            self.th.join(float(timeout))
        except Exception:
            pass
        if not self.box["done"]:
            # 后台还没收工：可能面板正开着，主线程接下来读价/出价会被它挡住
            print("⚠️ 查举报还没跑完（等超时）→ 按 ESC 收拾现场，先保证出价")
            try:
                游戏里按ESC("查举报超时")
            except Exception:
                pass
            try:
                self.th.join(1.0)
            except Exception:
                pass
            return None
        return self.box["v"]


def 读玩家列表等级(frame, width, height):
    if frame is None:
        return [None, None, None]
    pixels = np.asarray(frame)
    sx, sy = width / 1920.0, height / 1080.0
    cw, ch = OPPONENTS_GONE_LV_SIZE
    levels = []
    for cx, cy in OPPONENTS_GONE_LV_CENTERS:
        x, y = round(cx * sx), round(cy * sy)
        half_w, half_h = max(1, round(cw * sx / 2)), max(1, round(ch * sy / 2))
        crop = pixels[y-half_h:y+half_h, x-half_w:x+half_w]
        try:
            digits, _, _ = 按模板读数字(crop, "opp_lv")
            level = int(digits) if digits and digits.isdigit() and len(digits) <= 3 else None
            if level in (None, 0):
                pad_x, pad_y = max(1, round(18 * sx)), max(1, round(24 * sy))
                wider = pixels[y-half_h-pad_y:y+half_h+pad_y, x-half_w-pad_x:x+half_w+pad_x]
                digits, _, decision = 按模板读数字(wider, "opp_lv")
                score, margin = 数字权威阈值()
                if 高置信数字(digits, decision, score, margin) and digits.isdigit() and len(digits) <= 3:
                    level = int(digits) or level
        except Exception:
            level = None
        levels.append(level)
    return levels


def 对手跑光了吗():
    """看一眼举报面板。True=三个都跑了 / False=还有人在 / None=没看成。

    注意：整个过程（点举报 → 读等级 → 关面板）都在 GAME_ACTION_LOCK 里跑。
    以前后台线程和主线程会互相插进对方的点击之间 ——
    比如主线程正在开仪器列表，后台线程却把举报面板打开，
    两边各自点对方的按钮，最后面板关不掉、卡在举报页。
    """
    with GAME_ACTION_LOCK:
        return _对手跑光了吗_内()


def _对手跑光了吗_内():
    """真正的检查逻辑（由 对手跑光了吗 在锁里调用）。"""
    if int(OPPONENTS_GONE_CHECK or 0) != 1:
        return None
    if 快没时间了吗():
        # 紧迫危机只有十几秒，点举报再关面板要两三秒，这趟不去
        print("⚡ 紧迫危机：这次不查举报面板")
        return None
    if 本机很慢吗():
        # 慢机器上"点举报→读等级→关面板"实测要 4 秒（快的机器 1~2 秒），
        # 为了省这一块钱把出价窗口耗掉不值当。
        print("🐢 本机较慢（抓帧系数≥%.1f）→ 跳过查举报面板，直接出价"
              % float(SLOW_PC_K_THRESHOLD))
        return None
    if not running:
        return None
    win = 游戏窗口范围()
    if win is None:
        return None
    left, top, ww, hh = win
    if ww <= 0 or hh <= 0:
        return None
    # 区域沿用原来的右上一整条（窄框会认不到举报图标 → 超时）。
    # 误点到「我的资产」的风险改由下面的"面板校验 + ESC 退出"兜住。
    region = (left + int(ww * 0.62), top, int(ww * 0.38), int(hh * 0.13))
    _t_open0 = time.time()
    if not 找到就点("btn_report.png", "举报（看对手跑没跑）", region=region, timeout=1.2):
        print("ℹ️ 没找到举报按钮，这次不看了")
        return None
    _t_clicked = time.time()
    lv = []
    _panel_ok = False
    _t_check = 0.0
    _t_read = 0.0
    _wait_panel = 0.0
    try:
        # 原来死等 0.7 秒；改成每 0.1 秒看一眼面板出来没，出来就立刻读
        _w0 = time.time()
        _panel_ready = False
        while time.time() - _w0 < 1.2:
            try:
                if 画面有吗("btn_playlist_close.png", timeout=0.1):
                    _panel_ready = True
                    break
            except Exception:
                break
            time.sleep(0.05)
        _wait_panel = time.time() - _w0
        # 确认真的开了举报面板（认关闭按钮）；没开 = 点到别处了（最典型是右边的「我的资产」）
        try:
            _panel_ok = bool(画面有吗("btn_playlist_close.png", timeout=0.4))
        except Exception:
            _panel_ok = True
        if not _panel_ok:
            print("⚠️ 点了举报但面板没出现 → 可能点到旁边的「我的资产」，按 ESC 退出，这次不看了")
            try:
                游戏里按ESC("举报没开出来")
            except Exception:
                pass
            return None
        _t_check = time.time()
        if not _panel_ready:
            print("⚠️ 举报面板 1.2 秒内没出来 → 按 ESC 退出，这次不看了")
            try:
                游戏里按ESC("举报面板没出来")
            except Exception:
                pass
            return None
        lv = 读玩家列表等级(抓一帧(region=win), ww, hh)
        _t_read = time.time()
        print(f"👀 举报面板三个对手等级: {lv}")
        try:
            print("⏱️ 举报面板：找按钮+点击 %.2fs｜等面板 %.2fs｜校验 %.2fs｜读3个等级 %.2fs"
                  % (_t_clicked - _t_open0, _wait_panel,
                     _t_check - (_t_clicked + _wait_panel), _t_read - _t_check))
        except Exception:
            pass
        try:
            记回合事件("opponents_levels", human=f"👀 对手等级 {lv}", levels=lv)
        except Exception:
            pass
    finally:
        # 面板一定要关掉，不然挡住出价按钮
        _t_close0 = time.time()
        try:
            if not 找到就点("btn_playlist_close.png", "关举报面板", timeout=1.5):
                # 兜底不再点固定坐标 —— 那个位置可能落在「我的资产」上，一点就卡死。
                print("⚠️ 举报面板没关掉 → 按 ESC 关（不点坐标，避免误点旁边的按钮）")
                try:
                    游戏里按ESC("关举报面板")
                except Exception:
                    pass
                time.sleep(0.35)
                try:
                    if 画面有吗("btn_playlist_close.png", timeout=0.3):
                        print("⚠️ 举报面板还在 → 再按一次 ESC")
                        游戏里按ESC("举报面板仍在")
                        time.sleep(0.3)
                except Exception:
                    pass
        except Exception:
            pass
        try:
            print("⏱️ 举报面板总计 %.2fs（关闭 %.2fs）"
                  % (time.time() - _t_open0, time.time() - _t_close0))
        except Exception:
            pass
    if len(lv) == 3 and all(v == 0 for v in lv):
        return True
    return False


def 回合出价显示匹配(expected, text):
    from decimal import Decimal

    match = re.fullmatch(r"([0-9][0-9,，]*(?:\.[0-9]+)?)([KMB万亿]?)",
                         str(text).strip().upper().replace(" ", ""))
    if expected <= 0 or not match:
        return False
    digits, suffix = match.groups()
    value = Decimal(digits.replace(",", "").replace("，", ""))
    if not suffix:
        return value == expected
    factor = {"K": 1000, "M": 1000000, "B": 1000000000, "万": 10000, "亿": 100000000}[suffix]
    resolution = Decimal(factor).scaleb(value.as_tuple().exponent)
    # 游戏缩写会舍入或截断。只接受显示精度内的差值。
    return abs(value * factor - expected) < resolution


def 出价输入金额一致(expected, actual):
    """确认按钮前只接受完整的整数金额，允许千位分隔符。"""
    amount = re.sub(r"[,，'’‘\s]", "", str(actual or ""))
    return bool(expected > 0 and re.fullmatch(r"[0-9]+", amount) and int(amount) == expected)


def 出价确认已生效(round_num, value, bid_region, timeout=2.0):
    expected = 解析金额(value)
    deadline = time.monotonic() + timeout
    while running and time.monotonic() < deadline:
        if not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region):
            win = 游戏窗口范围()
            if win and 读当前回合(force=True) == round_num and not 画面有吗("btn_bid.png", timeout=0):
                left, top, width, height = win
                box = (left + int(width * .83), top + int(height * .88),
                       int(width * .14), int(height * .09))
                text = 识别区域文字(box, retry=1).strip().upper().replace(" ", "")
                if 回合出价显示匹配(expected, text):
                    return True
        if not 歇一下(0.12):
            break
    return False


def 恢复中断的出价输入(round_num, digits, bid_region, expected_amount):
    status = _等鼠标让行结束(check_bid_pause=True)
    if status != "READY":
        return status
    epoch = _USER_MOUSE_EPOCH
    if 出价区域() != bid_region:
        return False
    if 读当前回合(force=True) != round_num or not 画面有吗(
        BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region
    ):
        return False
    win = 游戏窗口范围()
    if not win:
        return False
    left, top, _, _ = win
    current = 只读出价金额()
    remaining = 估剩余时间()
    if (出价输入金额一致(expected_amount, current)
            and (not CURSOR_YIELD_USER or epoch == _USER_MOUSE_EPOCH)
            and (remaining is None or remaining > 1)
            and 出价区域() == bid_region
            and 读当前回合(force=True) == round_num
            and 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region)):
        print("♻️ 中断后已核对本回合输入金额，继续确认")
        return True
    if (remaining is None or remaining < max(6.0, len(digits) * .45 + 3)
            or 读当前回合(force=True) != round_num
            or not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region)):
        return False
    print(f"⏸️ 数字输入中断，当前面板读数：{current or '未读到'}，准备清空重输")
    if not _按新画面点击(left + CLEAR_BID_X, top + CLEAR_BID_Y, epoch):
        return False
    if not 歇一下(0.2) or 读当前回合(force=True) != round_num:
        return False
    tokens = [re.sub(r"num_(\d+)\.png", r"\1", img) for img in digits]
    positions = 定出价键位(bid_region, tokens)
    if not positions or (CURSOR_YIELD_USER and epoch != _USER_MOUSE_EPOCH):
        return False
    with _已核对鼠标画面(epoch):
        return 按键位输数字(tokens, bid_region, positions)


def 去出价(digit_images, bid_amount_str, round_num=None, estimate=None):
    global bid_interrupt_state, running
    with bid_state_lock:
        bid_interrupt_state = 0

    flow_started = time.time()
    expected_amount = 解析金额(bid_amount_str)
    print(f"💰 执行出价: {bid_amount_str}")
    try:
        记回合事件(
            "bid_flow_start",
            human=f"💳 开始出价 {bid_amount_str}",
            round=round_num,
            estimate=estimate,
            amount=bid_amount_str,
            urgent=快没时间了吗(),
            timer_remaining=估剩余时间(),
        )
    except Exception:
        pass

    # 紧迫危机只剩 20 秒：找按钮别死等，但 2 秒对"按钮淡入 + 模板匹配"太紧
    # （实测有局就是 2 秒没认出来直接放弃出价），给到 3 秒。
    # 常规 / 情报局给 4 秒就够 —— 5 秒纯浪费，真没出来 4 秒也等不到了。
    _btn_timeout = 2.5 if 快没时间了吗() else 4
    def 仍是计划出价回合():
        remaining = 估剩余时间()
        return (round_num is not None and 读当前回合(force=True) == round_num
                and remaining is not None and remaining > 1)

    r = 找到就点("btn_bid.png", "出价按钮", timeout=_btn_timeout, check_bid_pause=True,
                verify_after_yield=仍是计划出价回合)
    if r == "SKIP":
        return "SKIP"
    if not r:
        if not running:
            return "STOP"
        # 实测有 2 局是"仪器列表还开着"挡住了出价按钮 ——
        # 先把仪器列表关掉再找一次（只在失败时走这里，多花不到 3 秒）。
        if 关仪器页(quiet=False):
            r = 找到就点(
                "btn_bid.png", "出价按钮", timeout=3, check_bid_pause=True,
                verify_after_yield=仍是计划出价回合
            )
            if r == "SKIP":
                return "SKIP"
        if not r:
            return "STOP" if not running else False

    bid_region = 出价区域()
    if bid_region is None:
        print("❌ 无法获取出价面板区域")
        return False

    # 等面板出现：常规给 3 秒；紧迫局给 2.5 秒（不够还有下面那次宽限兜底）
    _panel_waited = 等出价面板(
        bid_region, timeout=(2.5 if 快没时间了吗() else None)
    )
    if _panel_waited == "SKIP":
        return "SKIP"
    if _panel_waited == "STOP":
        return "STOP"

    if _panel_waited is None:
        # 实测面板有时在点击后展开 3 秒以上，首次 1.8 秒超时并不代表失败。
        # 普通局再给一段动画宽限；紧迫危机仍保持短宽限，避免吃掉 20 秒窗口。
        _grace_timeout = 1.0 if 快没时间了吗() else BID_PANEL_ANIMATION_GRACE_TIMEOUT
        print(f"ℹ️ 出价面板暂未出现 → 继续等待动画展开（宽限 {_grace_timeout:.1f} 秒）")
        _panel_waited = 等出价面板(bid_region, timeout=_grace_timeout)
        if _panel_waited == "SKIP":
            return "SKIP"
        if _panel_waited == "STOP":
            return "STOP"
        if _panel_waited is not None:
            try:
                记回合事件(
                    "bid_panel_animation_grace",
                    human=f"ℹ️ 出价面板展开较慢，宽限等待 {_grace_timeout:.1f} 秒后已就绪",
                    round=round_num,
                    estimate=estimate,
                    grace_seconds=_grace_timeout,
                )
            except Exception:
                pass

    if _panel_waited is None:
        # 面板没出来的最常见原因：仪器列表还开着挡在出价面板前面
        # （实测 16:55 那局就是这个）→ 关掉它再点一次【出价】，别直接放弃这一局。
        print("ℹ️ 出价面板没出来 → 先关掉可能挡着的仪器列表，再点一次【出价】")
        _closed = False
        try:
            _closed = bool(关仪器页(quiet=False))
        except Exception:
            _closed = False
        if _closed:
            if not 歇一下(0.5):
                return "STOP" if not running else False
            r2 = 找到就点(
                "btn_bid.png", "出价按钮(清掉仪器列表后重试)", timeout=4, check_bid_pause=True
            )
            if r2 == "SKIP":
                return "SKIP"
            _panel_waited = 等出价面板(bid_region)
            if _panel_waited == "SKIP":
                return "SKIP"
            if _panel_waited == "STOP":
                return "STOP"
        if not running:
            return "STOP"
        if _panel_waited is None:
            print("⚠️ 出价面板未出现，中止出价")
            记回合事件("bid_fail", human="❌ 出价面板未出现，中止出价", stage="panel_missing")
            存回合截图("bid_panel_missing", 回合截图区域(), "出价面板没出现")
            记报错(
                "bid_panel_missing",
                "按了出价按钮但出价面板没出现，中止出价",
                extra={"ocr": dict(RUNLOG_OCR)},
            )
            return False

    if not 快没时间了吗():
        存回合截图("bid_panel", 回合截图区域(), "出价面板已开（左侧含对手出价历史）")
    panel_ready_at = time.time()
    _panel_ready_ms = int((_panel_waited or 0.0) * 1000)

    _map_started = time.time()
    # 成组键：先把金额拆成 token（"0000" / "00" / 数字），拆不出来就退回逐位。
    _tokens = []
    try:
        _tokens = 金额转按键序列(bid_amount_str) or []
    except Exception as e:
        print(f"ℹ️ 成组键拆分失败，改走逐位：{e}")
        _tokens = []
    try:
        key_positions = 定出价键位(bid_region, _tokens) if _tokens else {}
    except Exception as e:
        print(f"ℹ️ 数字键一次定位失败，改走逐键识别：{e}")
        key_positions = {}
    _keymap_ms = int((time.time() - _map_started) * 1000)
    mapped_digits = bool(key_positions) and all(
        str(tok) in key_positions for tok in _tokens
    )

    if mapped_digits:
        r = 按键位输数字(_tokens, bid_region, key_positions)
        if r == "SKIP":
            return "SKIP"
        if r == "STOP":
            return "STOP"
        if not r:
            r = 恢复中断的出价输入(round_num, digit_images, bid_region, expected_amount)
            if r is not True:
                return r if r in ("STOP", "SKIP") else "WAIT_ROUND"
    elif 快没时间了吗():
        r = 着急时输数字(digit_images, bid_region)
        if r == "SKIP":
            return "SKIP"
        if r == "STOP":
            return "STOP"
        if not r:
            r = 恢复中断的出价输入(round_num, digit_images, bid_region, expected_amount)
            if r is not True:
                return r if r in ("STOP", "SKIP") else "WAIT_ROUND"
        key_positions = BID_KEY_POSITIONS
    else:
        for img in digit_images:
            if not running:
                return "STOP"

            r = 暂停时等着()
            if r == "SKIP":
                return "SKIP"
            if r == "STOP":
                return "STOP"

            if not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region):
                if not running:
                    return "STOP"
                print(f"⚠️ 出价面板已消失，无法输入 [{img}]，中止出价")
                记报错(
                    "bid_panel_gone",
                    f"出价面板中途消失（正在输入 [{img}]），中止出价",
                    extra={"digit": img, "ocr": dict(RUNLOG_OCR)},
                )
                return False

            r = 暂停时等着()
            if r == "SKIP":
                return "SKIP"
            if r == "STOP":
                return "STOP"

            r = 找到就点(
                img, f"数字键 {img}", region=bid_region, timeout=2, check_bid_pause=True
            )
            if r == "SKIP":
                return "SKIP"
            if not r:
                if not running:
                    return "STOP"
                print(f"⚠️ 寻找数字键 [{img}] 超时，面板可能已消失，中止出价")
                记报错(
                    "bid_digit_timeout",
                    f"找不到数字键 [{img}]，中止出价",
                    extra={"digit": img, "ocr": dict(RUNLOG_OCR)},
                )
                r = 恢复中断的出价输入(round_num, digit_images, bid_region)
                if r is not True:
                    return r if r in ("STOP", "SKIP") else "SKIP"
                break

            if not 歇一下(
                BID_DIGIT_CLICK_GAP_URGENT if 快没时间了吗() else BID_DIGIT_CLICK_GAP
            ):
                return "STOP" if not running else False

    r = 暂停时等着()
    if r == "SKIP":
        return "SKIP"
    if r == "STOP":
        return "STOP"

    digits_done_at = time.time()
    _verify_result = 核对并修出价金额(digit_images, bid_amount_str)
    if _verify_result == "STOP":
        print("⏹️ 用户在出价金额校验期间暂停 → 结束当前出价，不记为金额错误")
        return "STOP"
    if not _verify_result:
        print("⚠️ 出价金额校验最终失败，中止出价")
        记回合事件(
            "bid_fail",
            human=f"❌ 出价金额校验失败（目标 {bid_amount_str}，"
            f"实际读到 '{RUNLOG_OCR.get('bid_amount_raw','')}'）",
            stage="amount_verify",
            expected=bid_amount_str,
            ocr=dict(RUNLOG_OCR),
        )
        存回合截图("bid_amount_mismatch", 回合截图区域(), "金额校验失败")
        记报错(
            "bid_amount_mismatch",
            f"出价金额最终校验失败（目标 {bid_amount_str}，"
            f"读到 '{RUNLOG_OCR.get('bid_amount_raw','')}'）",
            extra={"expected": bid_amount_str, "ocr": dict(RUNLOG_OCR)},
        )
        return False

    verified_at = time.time()
    # 大肥鱼：这里原来会「存一张截图 + 歇 0.8 秒」再点确认，实测多出 1 秒左右的空档。
    # 用户要求输完价格立刻确认，所以整段去掉（截图只是排查用，确认按钮本来就会自己复核）。

    r = 暂停时等着()
    if r == "SKIP":
        return "SKIP"
    if r == "STOP":
        return "STOP"

    if not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region):
        if not running:
            return "STOP"
        print("⚠️ 出价面板已消失，无法确认，中止出价")
        return False

    r = 暂停时等着()
    if r == "SKIP":
        return "SKIP"
    if r == "STOP":
        return "STOP"

    # 在同一确认流程里检查游戏是否显示本回合的出价，避免把点击当提交。
    with bid_commit_lock:
        def 仍是计划出价金额():
            amount = 只读出价金额()
            remaining = 估剩余时间()
            return (出价输入金额一致(expected_amount, amount)
                    and round_num is not None and 读当前回合(force=True) == round_num
                    and (remaining is None or remaining > 1)
                    and 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0, region=bid_region))

        confirm_epoch = _USER_MOUSE_EPOCH
        _BG_STATE["click_outcome"] = "unavailable"
        _BG_STATE.pop("click_epoch", None)
        r = 找到就点("btn_confirm.png", "确认出价", timeout=3, check_bid_pause=True,
                    verify_after_yield=仍是计划出价金额)
        if r == "SKIP":
            return "SKIP"
        if not r and not running:
            return "STOP"
        if not r and _BG_STATE.get("click_outcome") != "uncertain":
            print("⚠️ 确认出价未发出，等待回合变化")
            return "WAIT_ROUND"
        submitted_epoch = _BG_STATE.get("click_epoch", confirm_epoch)
        _after_confirm = (
            BID_AFTER_CONFIRM_WAIT_URGENT if 快没时间了吗() else BID_AFTER_CONFIRM_WAIT
        )
        if not 歇一下(_after_confirm):
            return "STOP" if not running else False
        # 高价弹窗只有 ≥ HIGH_BID_CHECK_MIN_AMOUNT 才可能出现：小额局只做一次
        # 单帧探测（timeout=0，约 20ms），不在这里干等一秒。
        try:
            _amt_int = int(re.sub(r"[^\d]", "", str(bid_amount_str)) or 0)
        except Exception:
            _amt_int = 0
        _high_bid_armed = _amt_int >= int(HIGH_BID_CHECK_MIN_AMOUNT)
        _high_bid_wait = max(float(HIGH_BID_VERIFY_WAIT), float(_after_confirm))
        if 高价确认框可见(_high_bid_wait if _high_bid_armed else 0):
            if not r or not 确认高价出价(verify_timeout=0, submitted_epoch=submitted_epoch):
                _BG_STATE["unverified_high_bid"] = True
                if CURSOR_YIELD_USER and (
                    _USER_MOUSE_EPOCH != confirm_epoch or not _鼠标动作仍有效()
                    or _BG_STATE.get("click_outcome") in ("yielded", "uncertain")
                ):
                    print("♻️ 高价确认期间发生鼠标接管，停止本轮确认，等待新画面")
                    return "WAIT_ROUND"
                记回合事件("bid_unconfirmed", human="⚠️ 高价确认结果不明，等待处理或回合变化",
                           round=round_num, price_raw=bid_amount_str)
                return "WAIT_ROUND"
        if not 出价确认已生效(round_num, bid_amount_str, bid_region):
            记回合事件("bid_unconfirmed", human="⚠️ 出价提交结果不明，等待回合变化",
                       round=round_num, price_raw=bid_amount_str)
            return "WAIT_ROUND"
        submitted_at = time.time()
        记回合事件(
            "bid_submitted",
            human=f"✅ 已提交出价 {bid_amount_str}",
            round=round_num,
            estimate=estimate,
            price_raw=bid_amount_str,
            urgent=快没时间了吗(),
            timer_remaining=估剩余时间(),
            open_ms=int((panel_ready_at - flow_started) * 1000),
            digit_ms=int((digits_done_at - panel_ready_at) * 1000),
            verify_ms=int((verified_at - digits_done_at) * 1000),
            confirm_ms=int((submitted_at - verified_at) * 1000),
            total_ms=int((submitted_at - flow_started) * 1000),
            fast_digits=bool(mapped_digits),
            panel_wait_ms=_panel_ready_ms,
            keymap_ms=_keymap_ms,
        )
    return True


def 金额转键位图(value_str):
    image_list = []
    for char in value_str:
        if char.isdigit():
            image_list.append(f"num_{char}.png")
        else:
            print(f"⚠️ 发现非数字字符: {char}，已忽略")
    try:
        amount_str = f"{int(value_str):,}"
    except ValueError:
        amount_str = value_str
    return image_list, amount_str


def 金额转按键序列(value_str):
    """金额 → 键盘按键序列（token 列表）。

    移植自 v1 的 keypad_zero_group：连续 4 个 0 用一次「0000」键点掉。
    「00」只有在 素材\\num_00.png 存在时才用（默认没有这张模板，留个后门）。
    关掉 BID_ZERO_GROUP 就退回「一位一个 token」的旧行为。
    """
    s = re.sub(r"[^\d]", "", str(value_str or ""))
    if not s:
        return []
    try:
        use_group = int(str(BID_ZERO_GROUP).strip() or 0) == 1
    except Exception:
        use_group = False
    if not use_group:
        return list(s)
    try:
        has_00 = os.path.isfile(素材路径("num_00.png"))
    except Exception:
        has_00 = False
    tokens = []
    i = 0
    while i < len(s):
        if s[i] == "0":
            if s[i:i + 4] == "0000":
                tokens.append("0000")
                i += 4
                continue
            if has_00 and s[i:i + 2] == "00":
                tokens.append("00")
                i += 2
                continue
        tokens.append(s[i])
        i += 1
    return tokens


def 档位预设价(value):
    # 分支必须和 查档位() 一一对应、同序：那边有 GATE_280 这一档，这边以前漏了，
    # 结果估价 512万~898万 的仓被 查档位 判成 "280"（首价 2,721,000），
    # 这里却返回 321 档的 2,199,999 —— 首轮少出 52 万，后几轮还拿 280 的倍率。
    if value > GATE_22668:
        return str(TIER_22668_OPEN)
    if value > GATE_666:
        return str(TIER_666_OPEN)
    elif value > GATE_1680:
        return str(TIER_620_OPEN)
    elif value > GATE_588:
        return str(TIER_588_OPEN)
    elif value > GATE_898:
        return str(TIER_420_OPEN)
    elif value > GATE_280:
        return str(TIER_280_OPEN)
    elif value > GATE_321:
        return str(TIER_321_OPEN)
    elif value > GATE_233:
        return str(TIER_233_OPEN)
    elif value > GATE_179:
        return str(LOW_TIER_OPEN)
    elif value > GATE_1100:
        return str(TIER_1100_OPEN)
    else:
        return str(TIER_1100_OPEN)


TIER_MULTIPLIER_KEYS = {
    "22668": (
        "TIER_22668_R2_MULT",
        "TIER_22668_R3_MULT",
        "TIER_22668_R4_MULT",
        "TIER_22668_R5_MULT",
    ),
    "1100": (
        "TIER_1100_R2_MULT",
        "TIER_1100_R3_MULT",
        "TIER_1100_R4_MULT",
        "TIER_1100_R5_MULT",
    ),
    "low": (
        "LOW_TIER_R2_MULT",
        "LOW_TIER_R3_MULT",
        "LOW_TIER_R4_MULT",
        "LOW_TIER_R5_MULT",
    ),
    "280": (
        "TIER_280_R2_MULT",
        "TIER_280_R3_MULT",
        "TIER_280_R4_MULT",
        "TIER_280_R5_MULT",
    ),
    "420": (
        "TIER_420_R2_MULT",
        "TIER_420_R3_MULT",
        "TIER_420_R4_MULT",
        "TIER_420_R5_MULT",
    ),
    "588": (
        "TIER_588_R2_MULT",
        "TIER_588_R3_MULT",
        "TIER_588_R4_MULT",
        "TIER_588_R5_MULT",
    ),
    "620": (
        "TIER_620_R2_MULT",
        "TIER_620_R3_MULT",
        "TIER_620_R4_MULT",
        "TIER_620_R5_MULT",
    ),
    "666": (
        "TIER_666_R2_MULT",
        "TIER_666_R3_MULT",
        "TIER_666_R4_MULT",
        "TIER_666_R5_MULT",
    ),
    "233": (
        "TIER_233_R2_MULT",
        "TIER_233_R3_MULT",
        "TIER_233_R4_MULT",
        "TIER_233_R5_MULT",
    ),
    "321": (
        "TIER_321_R2_MULT",
        "TIER_321_R3_MULT",
        "TIER_321_R4_MULT",
        "TIER_321_R5_MULT",
    ),
}


def 档位价贴整(price):
    try:
        price = int(price)
    except Exception:
        return price
    if price <= 0:
        return price
    try:
        cand = int(向下贴整(price))
    except Exception:
        cand = price
    if 0 < cand <= price and cand >= price * 0.9:
        return cand
    return int(price) // 10000 * 10000


def 查档位(value):
    value = int(value)
    if value > GATE_22668:
        return "22668", int(TIER_22668_OPEN)
    if value > GATE_666:
        return "666", int(TIER_666_OPEN)
    if value > GATE_1680:
        return "620", int(TIER_620_OPEN)
    if value > GATE_588:
        return "588", int(TIER_588_OPEN)
    if value > GATE_898:
        return "420", int(TIER_420_OPEN)
    if value > GATE_280:
        return "280", int(TIER_280_OPEN)
    if value > GATE_321:
        return "321", int(TIER_321_OPEN)
    return None, int(value)


def _int_param(name, default=0):
    try:
        v = globals().get(name, default)
        s = str(v).strip()
        if not s:
            return 0
        return int(float(s))
    except Exception:
        return int(default)


def 普通倍率价(value):
    """按估价区间算价：估价 × (rate/100)。没命中任何一段返回 None。

    七段是显式区间（上界/下界都在参数里）；倍率是百分比整数：130 = 估价×1.3。
    某段区间或倍率没填（0）就跳过那一段。
    """
    try:
        v = int(value or 0)
    except Exception:
        return None
    if v <= 0:
        return None
    segs = [
        (0, _int_param("NORMAL_MULT_1_HI"), _int_param("NORMAL_MULT_1_RATE"), "第1段"),
        (_int_param("NORMAL_MULT_2_LO"), _int_param("NORMAL_MULT_2_HI"),
         _int_param("NORMAL_MULT_2_RATE"), "第2段"),
        (_int_param("NORMAL_MULT_3_LO"), _int_param("NORMAL_MULT_3_HI"),
         _int_param("NORMAL_MULT_3_RATE"), "第3段"),
        (_int_param("NORMAL_MULT_4_LO"), _int_param("NORMAL_MULT_4_HI"),
         _int_param("NORMAL_MULT_4_RATE"), "第4段"),
        (_int_param("NORMAL_MULT_5_LO"), _int_param("NORMAL_MULT_5_HI"),
         _int_param("NORMAL_MULT_5_RATE"), "第5段"),
        (_int_param("NORMAL_MULT_6_LO"), _int_param("NORMAL_MULT_6_HI"),
         _int_param("NORMAL_MULT_6_RATE"), "第6段"),
        (_int_param("NORMAL_MULT_7_LO"), None, _int_param("NORMAL_MULT_7_RATE"), "第7段"),
    ]
    for lo, hi, rate, tag in segs:
        if hi is not None and hi <= 0:
            continue                       # 这一段没设上限 → 不启用
        if lo > 0 and hi is not None and hi <= lo:
            continue
        if rate <= 0:
            continue
        if v > lo and (hi is None or v <= hi):
            # 倍率是"百分比整数"：130 = ×1.3（100 = 原价）
            mult = rate / 100.0
            price = int(v * mult)
            print(f"💰 普通倍率：估价 {v:,} 落在{tag}（{rate} ≙ ×{mult:.2f}）→ {price:,}")
            return price
    return None


def _档位首轮价(tier):
    return _int_param({
        "1100": "TIER_1100_OPEN", "low": "LOW_TIER_OPEN", "233": "TIER_233_OPEN",
        "321": "TIER_321_OPEN", "280": "TIER_280_OPEN", "420": "TIER_420_OPEN",
        "588": "TIER_588_OPEN", "620": "TIER_620_OPEN", "666": "TIER_666_OPEN",
        "22668": "TIER_22668_OPEN",
    }.get(tier, ""), 0)


def _首轮链价(tier, step):
    """首轮价 → ×R2 → ×R3 → ×R4 → ×R5，依次相乘（每步贴整）。

    step=0 → 首轮价本身；1 → ×R2；2 → ×R3；3 → ×R4；4 → ×R5。
    """
    price = int(_档位首轮价(tier) or 0)
    if price <= 0:
        return 0
    keys = TIER_MULTIPLIER_KEYS.get(tier) or TIER_MULTIPLIER_KEYS.get("low")
    if not keys:
        return price
    for k in range(max(0, min(int(step), 4))):
        try:
            mult = float(globals().get(keys[k], "") or 0)
        except Exception:
            mult = 0.0
        if mult <= 0:
            break
        price = int(档位价贴整(int(price * mult)))
    return int(price)


def 档位倍率按发现回合(tier, round_num):
    """按"发现这件之后的第几个回合"取倍率：发现当回合=首轮价，下一回合=R2，再下=R3…"""
    first = TIER_FIRST_ROUND.get(tier)
    if first is None:
        return None
    step = int(round_num) - int(first)
    if step <= 0:
        return None             # 本回合=首轮价
    keys = TIER_MULTIPLIER_KEYS.get(tier) or TIER_MULTIPLIER_KEYS.get("low")
    if not keys:
        return None
    idx = min(step - 1, 3)      # step1→R2, 2→R3, 3→R4, 4→R5（之后一直用 R5）
    raw = globals().get(keys[idx], "")
    try:
        return float(raw) if str(raw).strip() else None
    except Exception:
        return None


def 目标藏品价(name, round_num, value):
    """识别到的目标藏品 → 该档位的首轮价 / 相对回合倍率价。"""
    tier = None
    for k, v in ITEM_BY_TIER.items():
        if v == name:
            tier = k
            break
    if not tier:
        return None
    TIER_FIRST_ROUND.setdefault(tier, int(round_num))
    first = TIER_FIRST_ROUND.get(tier)
    if int(round_num) <= int(first):
        price = _档位首轮价(tier)
        print(f"🎯 目标藏品「{name}」首见（第{round_num}回合）→ 出首轮价 {price:,}")
        return int(price) if price > 0 else None
    mult = 档位倍率按发现回合(tier, round_num)
    if mult is None:
        price = _档位首轮价(tier)
        return int(price) if price > 0 else None
    _step = int(round_num) - int(first)
    price = _首轮链价(tier, _step)
    print(f"🎯 目标藏品「{name}」第{round_num - first + 1}次跟价 → "
          f"首轮价链式×{_step}档 = {price:,}")
    return int(price)


def _规范藏品名(name):
    """统一藏品名的写法：储存/存储、空格、全角空格等差异。"""
    t = str(name or "").strip()
    for a, b in (("储存", "存储"), (" ", ""), ("\u3000", ""), ("·", ""), ("・", "")):
        t = t.replace(a, b)
    return t


def 藏品同名(a, b):
    """两个藏品名是不是同一件（先归一，再允许 85% 相似）。"""
    x, y = _规范藏品名(a), _规范藏品名(b)
    if not x or not y:
        return False
    if x == y:
        return True
    try:
        from difflib import SequenceMatcher

        return SequenceMatcher(None, x, y).ratio() >= 0.85
    except Exception:
        return False


def 识别到的目标藏品(round_num):
    """从本回合的仓库视觉结果里，挑出价值最高的那件"目标藏品"（10 档里的）。"""
    try:
        scan = _WAREHOUSE_VISION_ROUNDS.get(int(round_num)) or {}
        items = scan.get("items") or []
    except Exception:
        return None
    found = []
    for it in items:
        nm = str(it.get("item") or "").strip()
        if not nm:
            continue
        for _tier, _want in (ITEM_BY_TIER or {}).items():
            if 藏品同名(nm, _want):
                if _want not in found:
                    found.append(_want)      # 统一成档位表里的标准名
                break
    if not found:
        return None
    price_of = {}
    for tier_key, nm in ITEM_BY_TIER.items():
        price_of[nm] = _档位首轮价(tier_key)
    return max(found, key=lambda n: price_of.get(n, 0))


def 档位回合倍率(tier, round_num):
    keys = TIER_MULTIPLIER_KEYS.get(tier) or TIER_MULTIPLIER_KEYS.get("low")
    if not keys:
        return None
    idx = {2: 0, 3: 1, 4: 2}.get(int(round_num), 3)
    raw = globals().get(keys[idx], "")
    if raw is None or (isinstance(raw, str) and not raw.strip()):
        return None
    try:
        return float(raw)
    except Exception:
        return None


def 档位出价(value, round_num, tier, first_price):
    prev = 0
    try:
        prev = int(MY_BIDS.get(int(round_num) - 1) or 0)
    except Exception:
        prev = 0
    try:
        est = int(value)
    except Exception:
        est = 0
    # 用户定的：发现当回合=首轮价，之后按"发现后第几个回合"取 R2→R5（不再按绝对回合）
    mult = 档位倍率按发现回合(tier, round_num)
    if est <= 0:
        base = prev or int(first_price)
        if mult is None:
            return int(base)
        return 档位价贴整(int(base * mult))
    if mult is None:
        price = int(prev or first_price)
    else:
        try:
            _first_rnd = int(TIER_FIRST_ROUND.get(tier) or round_num)
        except Exception:
            _first_rnd = int(round_num)
        _step = int(round_num) - _first_rnd
        price = _首轮链价(tier, _step) or int(prev or first_price)
    if TIER_CAP_BY_PRICE == 1:
        if price > est:
            price = 档位价贴整(est)
        if prev > 0 and price < prev:
            price = prev
    return int(price)


def 解析简写金额(text):
    if not text:
        return None
    t = str(text).strip().replace(",", "").replace("，", "").replace(" ", "")
    if not t:
        return None
    mult = 1
    if t[-1] in "Kk":
        mult, t = 1000, t[:-1]
    elif t[-1] in "Mm":
        mult, t = 1000000, t[:-1]
    elif t[-1] in "Ww" or t.endswith("万"):
        mult, t = 10000, t[:-1]
    try:
        value = int(float(t) * mult)
    except Exception:
        return None
    return value if value >= 0 else None


def 过滤可疑出价(opponents, raw=None):
    if OPPONENT_OUTLIER_FILTER != 1:
        vals = [v for v in opponents if v]
        if len(vals) >= 2:
            top, second = sorted(vals, reverse=True)[:2]
            if top >= 3000000 and second > 0 and top >= second * 5:
                print(
                    f"ℹ️ 有对手出价 {top:,} 明显高于其他人（第二高 {second:,}），"
                    f"按'他可能发现了高价值物品'处理，保留不丢"
                )
                记回合事件(
                    "opponent_bid_outlier",
                    human=f"ℹ️ 对手出价 {top:,} 远高于其他人（第二高 {second:,}）——"
                    f"未丢弃（可能是他真的发现了高价值物品）",
                    value=top,
                    others_max=second,
                    kept=True,
                    raw=raw,
                )
        return opponents
    if len([v for v in opponents if v is not None]) < 2:
        return opponents
    kept = []
    for i, v in enumerate(opponents):
        rest = [x for j, x in enumerate(opponents) if j != i and x is not None]
        rest_max = max(rest) if rest else 0
        if v is not None and v >= 3000000 and rest_max > 0 and v >= rest_max * 5:
            print(f"⚠️ 对手出价 {v:,} 明显异常（其他对手最高 {rest_max:,}），判定为 OCR 误读，忽略")
            记回合事件(
                "opponent_bid_outlier",
                human=f"⚠️ 忽略异常对手出价 {v:,}（其他最高 {rest_max:,}，疑似 OCR 误读）",
                value=v,
                others_max=rest_max,
                raw=raw,
            )
            continue
        kept.append(v)
    return kept


def 认我那一行(grid, slot):
    my = MY_BIDS.get(int(slot))
    if my:
        tol = max(int(PANEL_ROW_MATCH_MIN), int(my * PANEL_ROW_MATCH_TOL))
        hit = [r for r in sorted(grid) if abs(grid[r] - my) <= tol]
        if hit:
            return hit[0], True
    if MY_PANEL_ROW is not None and MY_PANEL_ROW in grid:
        return MY_PANEL_ROW, False
    return (sorted(grid)[0] if grid else None), False


def 面板格子范围(slot):
    slot_x = PANEL_SLOT_X[min(max(int(slot), 1), len(PANEL_SLOT_X)) - 1] - PANEL_LEFT
    rects = []
    for row, row_y in enumerate(PANEL_ROW_Y):
        cy = row_y - PANEL_TOP
        rects.append(
            (
                row,
                slot_x - PANEL_CELL_W,
                cy - PANEL_CELL_H,
                slot_x + PANEL_CELL_W,
                cy + PANEL_CELL_H,
            )
        )
    return rects


def 从图读出价(img, slot):
    global LAST_REFINED_ROWS, LAST_PANEL_DARK, LAST_PANEL_RANKS
    got = {}
    raw = []
    refined_rows = set()
    rects = 面板格子范围(slot)
    # 天黑场地只显示名次、不显示金额 —— 这里必须只看「是不是天黑」，
    # 绝不能再看 NIGHT_USE_TIER。那个开关只决定「天黑时用不用档位价」，
    # 不决定「要不要把名次当成金额」。
    # 以前两者绑在一起：开关一关 dark=False，名次 1/2/3/4 就被当成出价读进来
    # （PANEL_BID_MIN=1 拦不住），对手最高=4 → 4×1.2=4 → 抬到最低出价，
    # 又被对手溢价闸压到 5 → 最后出价 5 块，金红再加 5 万 → 出 50,005。
    dark = False
    try:
        dark = 是不是天黑()
    except Exception:
        dark = False
    if dark:
        ranks = {}
        for row, x0, y0, x1, y1 in rects:
            rk = 从框里读排名(金额框在哪(img, row, slot))
            if rk is not None:
                ranks[row] = rk
        LAST_PANEL_DARK = True
        LAST_PANEL_RANKS = dict(ranks)
        LAST_REFINED_ROWS = set()
        txt = "，".join("第%d位=名次%d" % (r + 1, ranks[r]) for r in sorted(ranks))
        raw.append("🌑 天黑·只记名次：" + (txt if txt else "（名次没读到）"))
        return {}, raw
    LAST_PANEL_DARK = False
    LAST_PANEL_RANKS = {}
    for row, x0, y0, x1, y1 in rects:
        if x0 < 0 or y0 < 0:
            continue
        money, text, refined = 识别出价格(img, x0, y0, x1, y1, row, slot)
        if money is not None and (money == 0 or PANEL_BID_MIN <= money <= PANEL_BID_MAX):
            got[row] = money
            if refined:
                refined_rows.add(row)
            raw.append(f"第{row + 1}位={text}" + ("*" if refined else ""))
    LAST_REFINED_ROWS = set(refined_rows)
    return got, raw


def 金额框在哪(img, row, slot):
    try:
        cx = PANEL_SLOT_X[min(max(int(slot), 1), len(PANEL_SLOT_X)) - 1] - PANEL_LEFT
        cy = PANEL_ROW_Y[row] - PANEL_TOP
        bx0, bx1 = cx + int(PANEL_VALUE_BOX_DX0), cx + int(PANEL_VALUE_BOX_DX1)
        by0, by1 = cy + int(PANEL_VALUE_BOX_DY0), cy + int(PANEL_VALUE_BOX_DY1)
        if bx0 >= 0 and by0 >= 0 and bx1 <= img.shape[1] and by1 <= img.shape[0]:
            return img[by0:by1, bx0:bx1]
    except Exception:
        pass
    return None


def 从框里读排名(crop):
    lib = 取数字库()
    if not lib or crop is None or getattr(crop, "size", 0) == 0:
        return None
    try:
        g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    except Exception:
        return None
    mask = (g > 150).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, 8)
    h, w = mask.shape[:2]
    cand = []
    for i in range(1, n):
        bx, by, bw, bh, area = st[i]
        if area < 5 or bw >= w * 0.7 or bh >= h * 0.7:
            continue
        cand.append((bx, by, bw, bh))
    if len(cand) != 1:
        return None
    bx, by, bw, bh = cand[0]
    glyph = mask[by : by + bh, bx : bx + bw]
    typ = cv2.resize(glyph * 255, (16, 22), interpolation=cv2.INTER_AREA)
    typ = (typ > 127).astype(np.uint8)
    best, bestscore = None, -1.0
    for ch in ("1", "2", "3", "4"):
        for t in lib.get(ch, []):
            s = float((typ == t).mean())
            if s > bestscore:
                best, bestscore = ch, s
    return int(best) if (best is not None and bestscore >= 0.55) else None


_PANEL_MONEY_RE = re.compile(r"^\d+(?:\.\d+)?[KkMmWw万]?$")


def 识别置信度(res):
    parts, confs = [], []
    try:
        for line in res or []:
            if not line:
                continue
            for item in line:
                if item and len(item) >= 2 and isinstance(item[1], (list, tuple)):
                    t = str(item[1][0] or "")
                    c = float(item[1][1])
                    if t:
                        parts.append(t)
                        confs.append(c)
    except Exception:
        pass
    return "".join(parts), (min(confs) if confs else 0.0)


def 金额文字靠谱吗(text):
    t = str(text or "").strip().replace(" ", "").replace("\u00a0", "").replace("，", ",")
    if not t:
        return False
    if "," in t:
        return bool(re.match(r"^\d{1,3}(,\d{3})+$", t))
    return bool(_PANEL_MONEY_RE.match(t))


_DIGIT_LIB = None


def 取数字库():
    global _DIGIT_LIB
    if _DIGIT_LIB is not None:
        return _DIGIT_LIB
    _DIGIT_LIB = {}
    try:
        import base64 as _b64
        import sys as _sys

        _here = os.path.dirname(os.path.abspath(__file__))
        if _here not in _sys.path:
            _sys.path.insert(0, _here)
        import paimai_digits as _dm

        gw, gh = int(_dm.GLYPH_W), int(_dm.GLYPH_H)
        for ch, arr in _dm.DIGIT_TEMPLATES.items():
            lst = []
            for s in arr:
                raw = _b64.b64decode(s)
                bits = np.unpackbits(np.frombuffer(raw, dtype=np.uint8))[: gw * gh]
                lst.append(bits.reshape(gh, gw).astype(np.uint8))
            _DIGIT_LIB[ch] = lst
    except Exception:
        _DIGIT_LIB = {}
    return _DIGIT_LIB


def 切字符(crop, th=200, gw=16, gh=22):
    g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    mask = (g > th).astype(np.uint8)
    h, w = mask.shape[:2]
    n, lab, st, _ = cv2.connectedComponentsWithStats(mask, 8)
    out = []
    for i in range(1, n):
        bx, by, bw, bh, area = st[i]
        if area < 3:
            continue
        if bw >= w * 0.8 or bh >= h * 0.8:
            continue
        is_char = (9 <= bh <= 20) and (3 <= bw <= 12) and (area >= 15)
        if is_char:
            glyph = mask[by : by + bh, bx : bx + bw]
            typ = cv2.resize(glyph * 255, (gw, gh), interpolation=cv2.INTER_AREA)
            out.append(
                (int(bx), (typ > 127).astype(np.uint8), int(bh), int(by), int(area), int(bw))
            )
        else:
            out.append((int(bx), None, int(bh), int(by), int(area), int(bw)))
    out.sort(key=lambda z: z[0])
    return out


def 按模板读格子(crop):
    lib = 取数字库()
    if not lib:
        return None, "", 0.0
    gw, gh = 16, 22
    try:
        import paimai_digits as _dm

        gw, gh = int(_dm.GLYPH_W), int(_dm.GLYPH_H)
    except Exception:
        pass
    blobs = 切字符(crop, 200, gw, gh)
    if not blobs:
        return None, "", 0.0
    chars = [b for b in blobs if b[1] is not None]
    if not chars:
        return None, "", 0.0
    top = min(b[3] for b in chars)
    bottom = max(b[3] + b[2] for b in chars)
    band = max(1, bottom - top)
    char_left = min(b[0] for b in chars)
    char_right = max(b[0] + b[5] for b in chars)
    dots = [
        b
        for b in blobs
        if b[1] is None
        and b[5] <= 7
        and b[4] >= 3
        and (b[3] + b[2]) >= top + band * 0.5
        and char_left <= (b[0] + b[5] // 2) <= char_right
    ]
    dot_x = None
    if dots:
        dots.sort(key=lambda b: -b[4])
        dot_x = dots[0][0]
    seq, worst = [], 1.0
    for b in blobs:
        if b[1] is None:
            if dot_x is not None and b[0] == dot_x:
                seq.append(".")
            continue
        best, bestscore = "?", -1.0
        for ch, tmpls in lib.items():
            for t in tmpls:
                score = float((b[1] == t).mean())
                if score > bestscore:
                    best, bestscore = ch, score
        seq.append(best)
        worst = min(worst, bestscore)
    text = "".join(seq)
    if "?" in text or not 金额文字靠谱吗(text):
        return None, text, worst
    money = 解析简写金额(text)
    if money is None or not (money == 0 or PANEL_BID_MIN <= money <= PANEL_BID_MAX):
        return None, text, worst
    return money, text, worst


def 格子识别候选(crop, limit_scale=PANEL_OCR_SCALE):
    out = []
    try:
        g = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    except Exception:
        return out
    views = [cv2.resize(crop, None, fx=limit_scale, fy=limit_scale, interpolation=cv2.INTER_CUBIC)]
    inv = cv2.cvtColor(cv2.bitwise_not(g), cv2.COLOR_GRAY2BGR)
    views.append(cv2.resize(inv, None, fx=5, fy=5, interpolation=cv2.INTER_CUBIC))
    for th in (110, 135):
        b = cv2.cvtColor(cv2.threshold(g, th, 255, cv2.THRESH_BINARY)[1], cv2.COLOR_GRAY2BGR)
        views.append(cv2.resize(b, None, fx=5, fy=5, interpolation=cv2.INTER_CUBIC))
    engines = [ocr]
    try:
        if amount_ocr_alt is not None:
            engines.append(amount_ocr_alt)
    except Exception:
        pass
    for v in views:
        rgb = cv2.cvtColor(v, cv2.COLOR_BGR2RGB)
        for eng in engines:
            try:
                text, conf = 识别置信度(eng.ocr(rgb, cls=True))
            except Exception:
                continue
            if not text or not 金额文字靠谱吗(text):
                continue
            money = 解析简写金额(text)
            if money is None:
                continue
            if not (money == 0 or PANEL_BID_MIN <= money <= PANEL_BID_MAX):
                continue
            out.append((money, text, conf))
    return out


def 多数表决金额(cands):
    if not cands:
        return None, "", 0, 0
    by = {}
    for money, text, conf in cands:
        by.setdefault(money, []).append((text, conf))
    best = max(by, key=lambda k: (len(by[k]), max(c for _, c in by[k])))
    text = max(by[best], key=lambda tc: tc[1])[0]
    return best, text, len(by[best]), len(cands)


def 识别出价格(img, x0, y0, x1, y1, row, slot):
    plain = None
    cands = []
    box = None
    try:
        cx = PANEL_SLOT_X[min(max(int(slot), 1), len(PANEL_SLOT_X)) - 1] - PANEL_LEFT
        cy = PANEL_ROW_Y[row] - PANEL_TOP
        bx0, bx1 = cx + int(PANEL_VALUE_BOX_DX0), cx + int(PANEL_VALUE_BOX_DX1)
        by0, by1 = cy + int(PANEL_VALUE_BOX_DY0), cy + int(PANEL_VALUE_BOX_DY1)
        if bx0 >= 0 and by0 >= 0 and bx1 <= img.shape[1] and by1 <= img.shape[0]:
            box = img[by0:by1, bx0:bx1]
    except Exception:
        box = None
    if box is not None and box.size:
        try:
            t_money, t_text, t_score = 按模板读格子(box)
            if t_money is not None:
                return t_money, t_text + ("?" if t_score < 0.60 else ""), False
        except Exception:
            pass
    if box is not None and box.size:
        cands += 格子识别候选(box)
        try:
            big = cv2.resize(
                box, None, fx=PANEL_OCR_SCALE, fy=PANEL_OCR_SCALE, interpolation=cv2.INTER_CUBIC
            )
            t, c = 识别置信度(ocr.ocr(cv2.cvtColor(big, cv2.COLOR_BGR2RGB), cls=True))
            if t and 金额文字靠谱吗(t):
                m_ = 解析简写金额(t)
                if m_ is not None and (m_ == 0 or PANEL_BID_MIN <= m_ <= PANEL_BID_MAX):
                    plain = (m_, t, c)
        except Exception:
            pass
    if not cands:
        try:
            if x0 >= 0 and y0 >= 0 and x1 <= img.shape[1] and y1 <= img.shape[0]:
                crop = img[y0:y1, x0:x1]
                if crop.size:
                    cands += 格子识别候选(crop)
        except Exception:
            pass
    money, text, votes, total = 多数表决金额(cands)
    if money is None:
        return None, "", False
    refined = not (plain is not None and plain[0] == money)
    if total > 1 and votes * 3 < total * 2:
        text = "%s?" % text
    return money, text, refined


def 识别金额框(img, row, slot):
    cx = PANEL_SLOT_X[min(max(int(slot), 1), len(PANEL_SLOT_X)) - 1]
    cy = PANEL_ROW_Y[row]
    try:
        y0 = cy + int(PANEL_VALUE_BOX_DY0) - PANEL_TOP
        y1 = cy + int(PANEL_VALUE_BOX_DY1) - PANEL_TOP
        x0 = cx + int(PANEL_VALUE_BOX_DX0) - PANEL_LEFT
        x1 = cx + int(PANEL_VALUE_BOX_DX1) - PANEL_LEFT
        if y0 < 0 or x0 < 0 or y1 > img.shape[0] or x1 > img.shape[1]:
            return None, ""
        crop = img[y0:y1, x0:x1]
        if crop.size == 0:
            return None, ""
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        inv = cv2.cvtColor(cv2.bitwise_not(gray), cv2.COLOR_GRAY2BGR)
        inv = cv2.copyMakeBorder(inv, 14, 14, 14, 14, cv2.BORDER_CONSTANT, value=(255, 255, 255))
        big = cv2.resize(inv, None, fx=5, fy=5, interpolation=cv2.INTER_CUBIC)
        text = 拼识别文字(ocr.ocr(cv2.cvtColor(big, cv2.COLOR_BGR2RGB), cls=True))
        money = 解析简写金额(text)
        return money, text
    except Exception:
        return None, ""


def 读出价面板(round_num):
    if READ_RIVAL_BIDS != 1 or not running:
        return None, []
    window = 游戏窗口范围()
    if window is None:
        return None, []
    slot = min(max(int(round_num), 1), len(PANEL_SLOT_X))
    try:
        left, top = window[0], window[1]
        shot = 抓一帧(
            region=(
                left + PANEL_LEFT,
                top + PANEL_TOP,
                PANEL_RIGHT - PANEL_LEFT,
                PANEL_BOTTOM - PANEL_TOP,
            )
        )
        img = np.array(shot)
    except Exception as e:
        print(f"⚠️ 读取玩家列表失败: {e}")
        return None, []

    global LAST_OPPONENT_RAW
    global MY_PANEL_ROW, LAST_PANEL_GRID, LAST_PANEL_MY_ROW, LAST_REFINED_ROWS
    grid, raw = 从图读出价(img, slot)

    my_row, sure = 认我那一行(grid, slot)
    if my_row is not None and sure:
        MY_PANEL_ROW = my_row
    LAST_PANEL_GRID = dict(grid)
    LAST_PANEL_MY_ROW = my_row
    mine = grid.get(my_row) if my_row is not None else None
    opponents = [v for r, v in sorted(grid.items()) if r != my_row]
    LAST_OPPONENT_RAW = list(raw)
    if my_row is not None and my_row != 0:
        print(
            f"ℹ️ 玩家列表里我在第 {my_row + 1} 行（列表按名次排序，不是固定第 1 行）"
            f"{'' if sure else '（本次是兜底判断）'}"
        )
    opponents = 过滤可疑出价(opponents, raw)
    print(
        f"👥 第{round_num}回合各家出价：{raw if raw else '（未读到，可能是本回合还没人出价）'}"
        + (f"  → 采用 {opponents}" if opponents else "")
    )
    return mine, opponents


# 出价尾数一律尽量落在 …9999 上（往下贴 / 往上贴各一个）：
# · 撤掉以前"避开 6/9"的那套（has_bad_digits / LUCKY_TAILS）——
# 实测数字键 6 与 9 的模板相似度只有 0.33，点键不会混；金额和估价读数也都换成了
# 二值化 + 中英双模型 + 两遍确认，不需要再靠"不出 69"兜底。
# · 例：1,350,000 → 1,349,999 ｜ 816,833 → 809,999 ｜ 往上贴：1,200,000 → 1,209,999。
NICE_TAIL = 9999


def 向上贴整(price, rng=None):
    """往上贴到最近的 …9999（例：1,200,000 → 1,209,999）。"""
    try:
        price = int(price)
    except Exception:
        return price
    if price <= 0:
        return price
    v = price // 10000 * 10000 + NICE_TAIL
    if v < price:
        v += 10000
    return v


def 向下贴整(price):
    """往下贴到最近的 …9999（例：1,350,000 → 1,349,999 ｜ 816,833 → 809,999）。"""
    try:
        price = int(price)
    except Exception:
        return price
    if price <= 0:
        return price
    v = price // 10000 * 10000 + NICE_TAIL
    if v > price:
        v -= 10000
    return v if v > 0 else price


ROUND_K = (2.0, 1.6, 1.3, 1.1, 1.0, 1.0)

SECOND_PRIOR = (0.40, 0.52, 0.66, 0.80, 0.92, 1.00)


@dataclass
class StrategyConfig:

    cap_ratio: float = 1.00
    hard_cap_ratio: float = 1.0
    margin_ratio: float = 0.03
    second_growth: float = 1.06
    max_second_growth: float = 1.40
    prior_scale: float = 1.0
    early_round_wait: bool = False
    skip_when_over_cap: bool = False
    blind_aggressiveness: float = 0.5
    jitter: float = 0.02
    min_price: int = 1000
    value_confidence: float = 1.0


@dataclass
class BidContext:

    round_index: int
    estimate: int
    my_funds: int
    value_uplift: float = 1.0
    second_history: list[int] = field(default_factory=list)
    opponent_bids: list[int] = field(default_factory=list)
    my_last_bid: int = 0
    my_last_rank: int = 0
    blind: bool = False


@dataclass
class BidDecision:
    price: int
    cap: int
    predicted_second: int
    reason: str


def 预测第二高(ctx: BidContext, cfg: StrategyConfig) -> int:
    candidates: list[float] = []

    if ctx.opponent_bids:
        sorted_bids = sorted(ctx.opponent_bids, reverse=True)
        if len(sorted_bids) >= 2:
            candidates.append(sorted_bids[1])
        candidates.append(sorted_bids[0] * 0.85)

    if ctx.second_history:
        last_second = ctx.second_history[-1]
        growth = cfg.second_growth
        if len(ctx.second_history) >= 2 and ctx.second_history[-2] > 0:
            observed = last_second / ctx.second_history[-2]
            growth = min(max(observed, 1.0), cfg.max_second_growth)
        candidates.append(last_second * growth)

    prior = (
        ctx.estimate * SECOND_PRIOR[min(ctx.round_index, len(SECOND_PRIOR) - 1)] * cfg.prior_scale
    )
    candidates.append(prior)

    return max(int(max(candidates)), cfg.min_price)


def 算上限(ctx: BidContext, cfg: StrategyConfig) -> int:
    uplift = max(1.0, float(ctx.value_uplift))
    value_line = ctx.estimate * uplift * cfg.cap_ratio * cfg.value_confidence
    hard_line = ctx.estimate * cfg.hard_cap_ratio
    cap = int(min(value_line, hard_line))
    return max(int(min(cap, ctx.my_funds)), 0)


def 规则引擎出价(
    ctx: BidContext, cfg: StrategyConfig | None = None, rng: random.Random | None = None
) -> BidDecision:
    cfg = cfg or StrategyConfig()
    rng = rng or random
    cap = 算上限(ctx, cfg)

    if cap < cfg.min_price:
        return BidDecision(0, cap, 0, f"上限 {cap} 太低，放弃本回合（保住本金）")

    k = ROUND_K[min(ctx.round_index, len(ROUND_K) - 1)]
    predicted = 预测第二高(ctx, cfg)

    if ctx.blind:
        base = max(ctx.my_last_bid, predicted)
        thr = int(base * (1.0 + (cfg.second_growth - 1.0) * cfg.blind_aggressiveness))
    else:
        thr = int(predicted * k)

    target = int(thr + max(1, thr * cfg.margin_ratio))
    if target > cap and cfg.skip_when_over_cap:
        return BidDecision(
            0,
            cap,
            predicted,
            f"第{ctx.round_index + 1}回合：要赢需出 {target:,} 超过上限 {cap:,}，"
            f"本轮观望（保住本金，等倍数降低）",
        )
    target = min(target, cap)

    if cfg.early_round_wait and ctx.round_index < 3 and k >= 1.3:
        if target > cap * 0.55:
            soft = max(int(min(cap * 0.35, predicted * 0.9)), cfg.min_price)
            reason = (
                f"第{ctx.round_index + 1}回合倍数 {k}x：门槛 {target} 超过上限的 55%，"
                f"主动压价到 {soft} 观望（上限 {cap}）"
            )
            return BidDecision(扰一下(soft, cfg, rng), cap, predicted, reason)

    reason = (
        f"第{ctx.round_index + 1}回合：预测第二高 {predicted}，需 {k}x -> 门槛 {target}，"
        f"上限 {cap}（估价 {ctx.estimate}，估值系数 {ctx.value_uplift:.2f}）"
    )
    return BidDecision(扰一下(target, cfg, rng), cap, predicted, reason)


def 扰一下(price: int, cfg: StrategyConfig, rng) -> int:
    if cfg.jitter <= 0 or price <= 0:
        return int(price)
    return max(cfg.min_price, int(price + price * cfg.jitter * rng.random()))


_BidCfg = StrategyConfig
_BidCtx = BidContext
_decide_bid = 规则引擎出价
_ROUND_K = ROUND_K
BID_AVAILABLE = True


def 更新对手记忆(round_num):
    if 快没时间了吗():
        print("⚡ 紧迫危机：跳过读对手出价（按你的要求）")
        return
    global LAST_OPPONENT_BIDS, OPPONENT_MAX_SEEN, PREV_ROUND_OPP_MAX, PANEL_READ_FAIL_STREAK
    global PANEL_BIDS
    if READ_RIVAL_BIDS != 1 or round_num <= 1:
        return
    _record_only = globals().get("BID_MODE", "opponent") == "preset"
    mine, opps = 读出价面板(round_num - 1)
    try:
        if LAST_PANEL_DARK:
            _use_tier = False
            try:
                _use_tier = int(NIGHT_USE_TIER or 0) == 1
            except Exception:
                _use_tier = False
            _dark_msg = (
                "🌑 天黑局：只看得到名次 → 本回合按档位价出价"
                if _use_tier
                else "🌑 天黑局：只看得到名次（档位价开关是关的）→ 本回合按估价出价"
            )
            print(_dark_msg)
            try:
                PANEL_BIDS[int(round_num) - 1] = {
                    "rows": {},
                    "mine_row": (int(LAST_PANEL_MY_ROW) if LAST_PANEL_MY_ROW is not None else None),
                    "mine": (int(mine) if mine else None),
                    "opponents": [],
                    "raw": list(LAST_OPPONENT_RAW),
                    "refined_rows": [],
                    "dark": True,
                    "ranks": {int(k): int(v) for k, v in LAST_PANEL_RANKS.items()},
                }
            except Exception:
                pass
            try:
                记回合事件(
                    "dark_venue",
                    human=(
                        f"🌑 第 {RUNLOG_AUCTION_NO} 局：天黑局（只看得到名次），"
                        + ("本回合按档位价出价" if _use_tier else "档位价已关 → 本回合按估价出价")
                    ),
                    round=round_num - 1,
                    ranks=dict(LAST_PANEL_RANKS),
                    use_tier=_use_tier,
                )
            except Exception:
                pass
            PANEL_READ_FAIL_STREAK = 0
            return
    except Exception:
        pass
    try:
        记回合事件(
            "panel_read",
            round=round_num - 1,
            ok=bool(opps),
            n=len(opps),
            raw=list(LAST_OPPONENT_RAW),
            mine=mine,
            human=(
                f"📋 第{round_num - 1}回合玩家列表：读到 {len(opps)} 家对手出价"
                f"{'（' + ', '.join(格式化出价(v) for v in opps) + '）' if opps else '（空！跟价只能用兜底价）'}"
            ),
        )
    except Exception:
        pass
    if not opps:
        PANEL_READ_FAIL_STREAK += 1
        if _record_only:
            if PANEL_READ_FAIL_STREAK == 30:
                msg = (
                    "⚠️ 连续 30 个回合没读到对手出价（档位模式：只影响记录，不影响出价）。"
                    "请检查：游戏是不是 1080p 窗口化、左侧玩家列表有没有被挡住"
                )
                print(msg)
                记报错(
                    "panel_read_fail",
                    msg,
                    shot=False,
                    extra={"streak": PANEL_READ_FAIL_STREAK, "raw": list(LAST_OPPONENT_RAW)},
                )
            return
        if PANEL_READ_FAIL_STREAK in (5, 15, 30):
            msg = (
                f"⚠️ 连续 {PANEL_READ_FAIL_STREAK} 个回合读不到对手出价 → 跟价策略只能出兜底价。"
                f"请检查：游戏是不是 1080p 窗口化、左侧玩家列表有没有被挡住"
            )
            print(msg)
            try:
                记回合事件("panel_read_fail", human=msg, streak=PANEL_READ_FAIL_STREAK)
            except Exception:
                pass
            记报错(
                "panel_read_fail",
                msg,
                extra={"streak": PANEL_READ_FAIL_STREAK, "raw": list(LAST_OPPONENT_RAW)},
            )
        return
    PANEL_READ_FAIL_STREAK = 0
    try:
        PANEL_BIDS[int(round_num) - 1] = {
            "rows": {int(k): int(v) for k, v in LAST_PANEL_GRID.items()},
            "mine_row": (int(LAST_PANEL_MY_ROW) if LAST_PANEL_MY_ROW is not None else None),
            "mine": (int(mine) if mine else None),
            "opponents": [int(v) for v in opps],
            "raw": list(LAST_OPPONENT_RAW),
            "refined_rows": sorted(int(r) for r in LAST_REFINED_ROWS),
        }
    except Exception:
        pass
    if _record_only:
        try:
            记回合事件(
                "opponent_bids",
                human=(
                    f"👥 第{round_num - 1}回合各家出价 "
                    f"{[格式化出价(v) for v in opps]}"
                    f"（档位模式：只记录，不参与出价；我 "
                    f"{格式化出价(mine) if mine is not None else '未读到'}）"
                ),
                round=round_num - 1,
                opponents=opps,
                mine=mine,
                raw=list(LAST_OPPONENT_RAW),
                record_only=True,
            )
        except Exception:
            pass
        return
    LAST_OPPONENT_BIDS = list(opps)
    OPPONENT_MAX_SEEN = max([OPPONENT_MAX_SEEN] + list(opps))
    PREV_ROUND_OPP_MAX = max(opps)
    ordered = sorted(opps, reverse=True)
    second = ordered[1] if len(ordered) >= 2 else ordered[0]
    SECOND_HISTORY.append(second)
    记回合事件(
        "opponent_bids",
        human=(
            f"👥 第{round_num - 1}回合各家出价 {[格式化出价(v) for v in opps]}，"
            f"第二名 {格式化出价(second)}（我 "
            f"{格式化出价(mine) if mine is not None else '未读到'}）"
        ),
        round=round_num - 1,
        opponents=opps,
        second=second,
        mine=mine,
        raw=list(LAST_OPPONENT_RAW),
    )


class _SimpleDecision:

    def __init__(self, price, cap, predicted, reason):
        self.price = price
        self.cap = cap
        self.predicted_second = predicted
        self.reason = reason


def 预测下一轮第二():
    if not SECOND_HISTORY:
        return 0
    last = SECOND_HISTORY[-1]
    if len(SECOND_HISTORY) >= 2 and SECOND_HISTORY[-2] > 0:
        growth = SECOND_HISTORY[-1] / SECOND_HISTORY[-2]
        growth = min(max(growth, 1.0), 1.5)
    else:
        growth = 1.15
    return int(last * growth)


def 超估价额度(value, round_num):
    # 跟价模式的"出价上限"：默认就是估价本身（额度 0 → 与旧行为逐字节一致）。
    # 额度 > 0 且 round_num >= OVER_PRICE_FROM_R 时放宽成 估价+额度；
    # 再往上还有 HARD_CAP_MULT 那道总闸统一压，这里不用重复夹。
    base = int(value) if value else 0
    if base <= 0:
        return base
    try:
        allow = int(globals().get("OVER_PRICE_ROOM", 0) or 0)
        from_round = int(globals().get("OVER_PRICE_FROM_R", 3) or 0)
    except Exception:
        return base
    if allow <= 0 or round_num < from_round:
        return base
    limit = base + allow
    return int(max(limit, base))


_CATALOG_MEDIAN = {}
_CATALOG_BLOCK_CACHE = {}


def 图鉴中位数():
    """图鉴里各档藏品的中位价。读一次就缓存，图鉴不会变。"""
    global _CATALOG_MEDIAN
    if _CATALOG_MEDIAN:
        return _CATALOG_MEDIAN
    try:
        bucket = {}
        for p, q, _n in CATALOG_ITEMS:
            bucket.setdefault(str(q), []).append(int(p))
        med = {}
        for q, v in bucket.items():
            v.sort()
            med[q] = int(v[len(v) // 2])
        _CATALOG_MEDIAN = med
    except Exception:
        _CATALOG_MEDIAN = {}
    return _CATALOG_MEDIAN


def 数这一局的仓(force=False):
    """数这一局的仓。默认同一局只数一次（滚屏截图挺慢的）。

    force=True：忽略缓存重新数一遍（第 3 回合要再数一次时用）。
    """
    try:
        no = int(globals().get("RUNLOG_AUCTION_NO", 0) or 0)
    except Exception:
        no = 0
    if not force and no and no in _CATALOG_BLOCK_CACHE:
        return _CATALOG_BLOCK_CACHE[no]
    # 紧迫危机只有 20 秒：滚屏数仓要滚 4 次、认 3 屏（实测 8~10 秒），
    # 数完回合计时已经走完，后面连出价按钮都点不到。
    if 快没时间了吗():
        print("⚡ 紧迫危机：跳过数仓（滚屏太慢，先保证出价）")
        try:
            记回合事件("urgent_skip_count", human="⚡ 紧迫危机跳过数仓")
        except Exception:
            pass
        return {}
    try:
        q = 数整仓品质块()
    except Exception:
        q = {}
    if no:
        _CATALOG_BLOCK_CACHE.clear()
        _CATALOG_BLOCK_CACHE[no] = q
    记下仓里格子(q, no)
    return q


def 记下仓里格子(q, no=0):
    """把这一局各档几块写到 记录\\仓计数.json，面板「总览」页读它显示。"""
    if not isinstance(q, dict) or not q:
        return
    try:
        单价表 = 图鉴中位数() or {}
    except Exception:
        单价表 = {}
    各行 = []
    for 名字, 个数 in q.items():
        try:
            列表 = int(个数 or 0)
        except Exception:
            列表 = 0
        if 列表 <= 0:
            continue
        try:
            单价 = int(单价表.get(str(名字), 0))
        except Exception:
            单价 = 0
        各行.append(
            {"品质": str(名字), "格数": 列表, "单价": 单价, "小计": 单价 * 列表}
        )
    总估值 = sum(行["小计"] for 行 in 各行)
    数据 = {
        "时间": time.strftime("%Y-%m-%d %H:%M:%S"),
        "局号": int(no or 0),
        "各档": 各行,
        "总格数": sum(行["格数"] for 行 in 各行),
        "总估值": 总估值,
    }
    try:
        路径 = os.path.join(RUNLOG_DIR, "仓计数.json")
        with open(路径, "w", encoding="utf-8", newline="\n") as 文件:
            json.dump(数据, 文件, ensure_ascii=False, indent=2)
            文件.write("\n")
    except Exception:
        pass


def 求稳上限(value, round_num):
    """求稳模式下这一回合的封顶价：第 3~4 回合 估价×1.2，第 5 回合起 估价×1.3。

    前两回合不受这个上限管（返回估价本身，调用方也不会用）。
    """
    try:
        base = int(value or 0)
    except Exception:
        return 0
    if base <= 0:
        return 0
    try:
        rn = int(round_num or 0)
        if rn < 3:
            return base
        mult = float(SAFE_CAP_RATIO_LATE if rn >= 5 else SAFE_CAP_RATIO)
        if mult <= 0:
            return base
        return max(base, int(base * mult))
    except Exception:
        return base


def 求稳模式压价(price, value, round_num):
    """求稳模式：把出价压到本回合的封顶价以内。

    第 3~4 回合最多估价的 1.2 倍，第 5 回合起 1.3 倍；
    前两回合原样返回（开局保底价该出还得出）；拿仓模式也原样返回。
    """
    try:
        price = int(price or 0)
    except Exception:
        return price
    if SAFE_MODE != 1:
        return price
    try:
        if int(round_num or 0) < 3 or not value:
            return price
        cap = 求稳上限(value, round_num)
        return min(price, cap) if cap > 0 else price
    except Exception:
        return price


def _出价自检(price, value, cap, round_num):
    """出价落日志前自检：只记录「明显违反约束」的情况，绝不改价。

    三道闸（cap 夹 → 保底补价 → 硬顶）散在几百行里，顺序一旦错位，
    出价就会悄悄越过上限。以前只能靠人翻代码才发现；记下来之后，
    一行统计就能知道有多少局越界、越了多少。

    注意 cap 的语义：它是「这一轮被合法放宽之后的上限」（超估价额度会把它
    抬到 估价+额度），不是最初那个 估价×比例。所以「超cap」报出来的是
    「连放宽后都超了」，比最初的口径更严重。
    """
    problems = []
    try:
        p = int(price or 0)
        v = int(value or 0)
        c = int(cap or 0)
        r = int(round_num or 0)
        if p <= 0 or v <= 0:
            return problems
        if c > 0 and p > c:
            problems.append("超cap:出价%d>上限%d(%.2fx)" % (p, c, p / float(c)))
        if HARD_CAP_MULT > 0 and r >= 3:
            hard = int(v * float(HARD_CAP_MULT))
            if hard > 0 and p > hard:
                problems.append(
                    "超硬顶:出价%d>估价%d×%g=%d(%.2fx)"
                    % (p, v, HARD_CAP_MULT, hard, p / float(hard))
                )
    except Exception:
        pass
    return problems


def 智能出价(value, round_num):
    global NO_BID_REASON
    NO_BID_REASON = ""
    _mode = globals().get("BID_MODE", "opponent")
    # 求稳模式只管第 3 回合以后；前两回合跟拿仓模式一模一样
    # 图鉴模式一开，求稳自动让位（两个都按自己算，叠加只会互相打架）
    _safe = SAFE_MODE == 1 and round_num >= 3
    _floor_bid = 当前保底价()
    # 仓库视觉（认整仓里的具体藏品）：三层开关全开才让它改估价 ——
    # 打开总开关 + 关掉影子模式 + 打开风险开关。默认三层都关着，老行为一点不变。
    try:
        if (
            int(WAREHOUSE_VISION_ENABLED or 0) == 1
            and int(WAREHOUSE_VISION_SHADOW_MODE or 0) != 1
            and int(WAREHOUSE_VISION_RISK_ENABLED or 0) == 1
        ):
            _vision_value = 仓库视觉策略估值(value, round_num)
            if _vision_value and int(_vision_value) != int(value):
                print(
                    f"🧠 仓库视觉把估价从 {int(value):,} 调到 {int(_vision_value):,}"
                )
                value = _vision_value
    except Exception:
        pass
    # 闸门 / 退出线里"压不住对手"比的是【对手上一轮】的出价 ——
    # 不再拿"本局见过的对手最高价"：对手早期乱抬一手、后面降下来了，不该一直按那口价算。
    # 只有"上一轮没读到对手价"时才退回本局最高价（漏读时不至于误放行）。
    if PREV_ROUND_OPP_MAX > 0:
        _opp_ref, _opp_which = PREV_ROUND_OPP_MAX, "上轮最高"
    elif OPPONENT_MAX_SEEN > 0:
        _opp_ref, _opp_which = OPPONENT_MAX_SEEN, "本局最高（上轮没读到）"
    else:
        _opp_ref, _opp_which = 0, "本局最高"
    _info_ok = _opp_ref > 0 and value > _opp_ref
    # 第 3 回合起：**信息差优先，退出线只兜底**。
    #   规则：估价 > 对手上一轮出价 × 门槛（默认 1.0）→ 就算有信息差 → **不退出**，
    #   照常走下面的跟价（对手上轮价 × 回合倍数，必要时夹到估价/额度）。
    #   以前是"退出线先判、而且它内部只认『估价 > 对手上轮价』（等于门槛写死 1.0）"，
    #   所以门槛调成 0.8 时，估价 80 万 / 对手 90 万这种明明命中信息差的局，
    #   照样被退出线（99.9999 万）踢掉 —— 现在不会了。
    _gap_hit = False
    if (
        round_num >= 3
        and BAIL_IF_OUTBID == 1
        and INFO_ADVANTAGE_RATIO > 0
        and _opp_ref > 0
        and _mode != "highvalue"
        and (CHASE_TO_END != 1 or _safe)
    ):
        _gap = value / float(_opp_ref)
        if _gap < INFO_ADVANTAGE_RATIO:
            msg = (
                f"🚪 第{round_num}回合：信息差只有 {_gap:.2f}×（估价 {value:,} / 对手{_opp_which} "
                f"{_opp_ref:,}，门槛 {INFO_ADVANTAGE_RATIO}×），没便宜可赚，退出本局"
            )
            NO_BID_REASON = (
                f"第{round_num}回合信息差只有 {_gap:.2f}×（估价 {value:,} / "
                f"对手{_opp_which} {_opp_ref:,}，门槛 {INFO_ADVANTAGE_RATIO}×）"
            )
            print(msg)
            记回合事件(
                "exit_small_gap",
                human=msg,
                round=round_num,
                estimate=value,
                opponent_max=OPPONENT_MAX_SEEN,
                opponent_ref=_opp_ref,
                gap=round(_gap, 3),
            )
            存回合截图(
                f"round{round_num}_exit_small_gap", 回合截图区域(), "信息差太小，退出本局"
            )
            return None
        _gap_hit = True
        print(
            f"ℹ️ 第{round_num}回合信息差 {_gap:.2f}×（估价 {value:,} / 对手{_opp_which} {_opp_ref:,}"
            f"，门槛 {INFO_ADVANTAGE_RATIO}×）→ 有信息差：不退出，照常按倍数跟价"
            + ("（不再看退出线）" if value < EXIT_BELOW_PRICE else "")
        )

    # 退出线：只有"信息差没命中"（闸门关着 / 门槛为 0 / 读不到对手上轮价 / 高价值模式）时才看。
    if (
        round_num >= 3
        and EXIT_BELOW_PRICE > 0
        and value < EXIT_BELOW_PRICE
        and (CHASE_TO_END != 1 or _safe)
        and not _info_ok
        and not _gap_hit
    ):
        msg = (
            f"🚪 第{round_num}回合估价 {value:,} 低于 {EXIT_BELOW_PRICE:,}"
            f"（无信息低价值仓），退出本局"
        )
        NO_BID_REASON = (
            f"第{round_num}回合估价 {value:,} 低于退出线 "
            f"{EXIT_BELOW_PRICE:,}（无信息的低价值仓）"
        )
        print(msg)
        记回合事件(
            "exit_low_value",
            human=msg,
            round=round_num,
            estimate=value,
            opponent_max=OPPONENT_MAX_SEEN,
            ocr=dict(RUNLOG_OCR),
        )
        存回合截图(f"round{round_num}_exit_low_value", 回合截图区域(), "估价不够，退出本局")
        return None

    if (
        MIN_PRICE_GATE > 0
        and value < MIN_PRICE_GATE
        and (CHASE_TO_END != 1 or _safe)
    ):
        print(f"💰 智能出价：估价 {value:,} 低于门槛 {MIN_PRICE_GATE:,}，放弃本局")
        NO_BID_REASON = f"估价 {value:,} 低于最低估价门槛 {MIN_PRICE_GATE:,}"
        return None
    notes = []
    cap = int(value * BID_CAP_RATIO) if value else 0
    _dark = NIGHT_USE_TIER == 1 and 是不是天黑()
    _keep_price = _dark
    if _dark:
        _tier = 老档位价(value, round_num)
        if _tier is None and CHASE_TO_END == 1 and value > 0:
            _dk_tier, _dk_first = 查档位(value)
            _dk_price = int(档位出价(value, round_num, _dk_tier, _dk_first))
            price = int(_dk_price)
            cap = 0
            notes.append(
                f"🌑 天黑 + 拍到底：估价 {value:,} 在档位表里本要退出 → "
                f"按『估价×倍率』继续出 {price:,}"
            )
            decision = _SimpleDecision(price, 0, 0, "天黑 + 拍到底（不退出）")
        elif _tier is None:
            msg = (
                f"🚪 天黑场地效果 + 第{round_num}回合估价 {value:,} 在档位表里不值得出手，退出本局"
            )
            NO_BID_REASON = (
                f"天黑场地效果 + 第{round_num}回合估价 {value:,} " f"在档位表里没有对应出价"
            )
            print(msg)
            记回合事件(
                "exit_low_value",
                human=msg,
                round=round_num,
                estimate=value,
                opponent_max=OPPONENT_MAX_SEEN,
                dark=1,
                ocr=dict(RUNLOG_OCR),
            )
            存回合截图(
                f"round{round_num}_exit_low_value", 回合截图区域(), "天黑+估价不够，退出本局"
            )
            return None
        else:
            price = int(_tier)
            if NIGHT_CAP_BY_PRICE and value and price > int(value):
                notes.append(f"档位价 {price:,} 被估价 {value:,} 夹住")
                price = int(value)
            cap = 0
            notes.append(f"🌑 天黑（只显示排名，看不到金额）→ 按估价用档位价出 {price:,}")
            decision = _SimpleDecision(price, 0, 0, "天黑：按估价用档位价")
    elif _mode in ("opponent", "highvalue"):
        global high_first_round
        _high = value > BIG_LOT_GATE
        if _high and high_first_round is None:
            high_first_round = round_num
        cap = int(value) if value else 0
        _keep_price = True
        if _high:
            _preset = int(档位预设价(value))
            _noticed = (
                OPPONENT_MAX_SEEN > 0 and OPPONENT_MAX_SEEN > value * BIG_LOT_RIVAL_RATIO
            )
            _tier_code, _tier_first = 查档位(value)
            try:
                TIER_FIRST_ROUND.setdefault(_tier_code, round_num)
            except Exception:
                pass
            if _noticed and round_num > 1:
                price = int(档位出价(value, round_num, _tier_code, _tier_first))
                notes.append(
                    f"高价值仓 · 第{round_num}回合：对手也发现了"
                    f"（对手最高 {OPPONENT_MAX_SEEN:,} > 估价×{BIG_LOT_RIVAL_RATIO}）"
                    f"→ 按该档第{round_num}回合倍率出价 {price:,}"
                )
            else:
                price = _preset
                if round_num == 1:
                    notes.append(
                        f"高价值仓 · 第1回合：估价 {value:,} > {BIG_LOT_GATE:,}"
                        f"（出现高价值物品）→ 出该档第一轮预设价 {price:,}"
                    )
                else:
                    notes.append(
                        f"高价值仓 · 第{round_num}回合：对手没发现"
                        f"（对手最高 {OPPONENT_MAX_SEEN:,} ≤ 估价×{BIG_LOT_RIVAL_RATIO}）"
                        f"→ 只出该档第一轮预设价 {price:,}"
                    )
            decision = _SimpleDecision(price, 0, OPPONENT_MAX_SEEN, "高价值仓（合并模式）")
        else:
            _prev = PREV_ROUND_OPP_MAX or OPPONENT_MAX_SEEN
            price = 0
            _opponent_priority = round_num >= 2 and _prev > 0
            if _opponent_priority:
                if round_num == 2:
                    price = int(_prev * R2_RIVAL_MULT)
                    notes.append(
                        f"第2回合：优先按对手第1回合最高 {_prev:,} × "
                        f"{R2_RIVAL_MULT} → {price:,}，用估价 {value:,} 封顶"
                    )
                elif round_num == 3:
                    _need = _prev * ROUND3_GAP_RATIO
                    # 求稳模式允许出到估价的 1.2 倍，门槛跟着放宽：
                    # 对手没超过「我能出的上限」，就还有得抢，不算没便宜可赚。
                    if _safe:
                        _need = _prev / float(SAFE_CAP_RATIO or 1.0)
                    # 信息差一旦命中，第 3 回合这道老门槛也不再拦。
                    if value <= _need and (CHASE_TO_END != 1 or _safe) and not _gap_hit:
                        msg = (
                            f"🚪 第3回合：估价 {value:,} 没压住对手第2回合最高 {_prev:,}"
                            f"（门槛 ×{ROUND3_GAP_RATIO}），没便宜可赚，退出本局"
                        )
                        print(msg)
                        记回合事件(
                            "exit_small_gap",
                            human=msg,
                            round=round_num,
                            estimate=value,
                            opponent_max=_prev,
                            gap=round(value / float(_prev or 1), 3),
                        )
                        存回合截图(
                            f"round{round_num}_exit_small_gap",
                            回合截图区域(),
                            "没到第3回合门槛，退出",
                        )
                        return None
                    price = int(_prev * R3_RIVAL_MULT)
                    _g = (
                        "估价压得住对手"
                        if value > _need
                        else ("信息差命中（不看这道门槛）" if _gap_hit else "拍到底（本应退出）")
                    )
                    notes.append(
                        f"第3回合：{_g}（估价 {value:,} / 对手第2回合最高 {_prev:,} × {ROUND3_GAP_RATIO}）"
                        f"，出手 {_prev:,} × {R3_RIVAL_MULT} → {price:,}"
                    )
                elif round_num == 4:
                    price = int(_prev * R4_RIVAL_MULT)
                    notes.append(
                        f"第4回合：优先按对手第3回合最高 {_prev:,} × "
                        f"{R4_RIVAL_MULT} → {price:,}"
                    )
                else:
                    price = int(_prev * R5_RIVAL_MULT)
                    notes.append(
                        f"第{round_num}回合：优先按对手上一轮最高 {_prev:,} × "
                        f"{R5_RIVAL_MULT} → {price:,}"
                    )
            else:
                if round_num == 1:
                    if value <= _floor_bid:
                        price = int(_floor_bid)
                        notes.append(f"第1回合：估价 {value:,} ≤ 保底 → 出保底 {price:,}")
                    elif GATE_179 < value < GATE_233:
                        price = int(LOW_TIER_OPEN)
                        notes.append(
                            f"第1回合：{GATE_179:,} < 估价 {value:,} < "
                            f"{GATE_233:,} → 低价卡价档统一出 {price:,}"
                        )
                    else:
                        _full = 向下贴整(int(value))
                        if ROUND12_HALF_ENABLED == 1 and ROUND12_FIRST_HALF_RATIO > 0:
                            _half = max(
                                向下贴整(int(value * float(ROUND12_FIRST_HALF_RATIO))),
                                int(_floor_bid),
                            )
                            if _half < _full:
                                price = _half
                                notes.append(
                                    f"第1回合：估价 {value:,} → 先只出 {ROUND12_FIRST_HALF_RATIO} 倍"
                                    f" {price:,}（先探一手，不亮底牌）"
                                )
                            else:
                                price = _full
                                notes.append(f"第1回合：估价 {value:,} → 按估价向下贴规整数字 {price:,}")
                        else:
                            price = _full
                            notes.append(f"第1回合：估价 {value:,} → 按估价向下贴规整数字 {price:,}")
                elif GATE_179 < value < GATE_233:
                    price = int(档位出价(value, round_num, "low", LOW_TIER_OPEN))
                    notes.append(
                        f"第{round_num}回合：没读到对手出价 → "
                        f"按低价档第{round_num}回合倍率兜底 {price:,}"
                    )
                else:
                    _full = 向下贴整(int(value))
                    if ROUND12_HALF_ENABLED == 1 and ROUND12_FIRST_HALF_RATIO > 0:
                        _half = max(
                            向下贴整(int(value * float(ROUND12_FIRST_HALF_RATIO))),
                            int(_floor_bid),
                        )
                        if _half < _full:
                            price = _half
                            notes.append(
                                f"第{round_num}回合：没读到对手出价 → 先只出 "
                                f"{ROUND12_FIRST_HALF_RATIO} 倍 {price:,}（不亮底牌）"
                            )
                        else:
                            price = _full
                            notes.append(
                                f"第{round_num}回合：没读到对手出价 → 按估价向下贴规整数字 {price:,}"
                            )
                    else:
                        price = _full
                        notes.append(
                            f"第{round_num}回合：没读到对手出价 → 按估价向下贴规整数字 {price:,}"
                        )
            if not (round_num == 1 and GATE_179 < value < GATE_233):
                price = 向下贴整(price)
            _limit = (
                求稳上限(value, round_num)
                if _safe
                else 超估价额度(value, round_num)
            )
            if value and price > int(value) and _limit > int(value):
                if _limit > cap:
                    cap = _limit
                if price > _limit:
                    price = 向下贴整(_limit)
                    notes.append(
                        f"超估价 → 夹至额度上限 {price:,}"
                        f"（估价 {value:,} + {_limit - int(value):,}，第{round_num}回合起可用）"
                    )
                else:
                    notes.append(
                        f"📈 超估价额度生效：出价 {price:,} 高于估价 {value:,}"
                        f"（额度上限 {_limit:,}）"
                    )
            elif value and price > int(value):
                price = 向下贴整(int(value))
                notes.append(f"超过估价 → 夹回 {price:,}")
            if round_num <= 2 and price < _floor_bid:
                notes.append(f"低于前两回合保底 → 补到 {int(_floor_bid):,}（撑到第 3 回合）")
                price = int(_floor_bid)
            try:
                _funds = int(读当前资产() or 0)
            except Exception:
                _funds = 0
            if _funds > 0:
                # 这个是「资金安全线」，别和上面的求稳开关 _safe 混用一个名字
                _funds_line = int(_funds * (1.0 - R1_FUNDS_KEEP))
                if price > _funds_line:
                    price = 向下贴整(_funds_line)
                    notes.append(f"资产 {_funds:,} 只够出 {_funds_line:,} → 按资产封顶")
            decision = _SimpleDecision(price, cap, OPPONENT_MAX_SEEN, "跟价（合并模式）")

    elif _mode == "preset":
        preset = 老档位价(value, round_num)
        if preset is None:
            if CHASE_TO_END == 1 and value > 0:
                _tier, _first = 查档位(value)
                preset = str(int(档位出价(value, round_num, _tier, _first)))
                notes.append(
                    f"拍到底：估价 {value:,} 在档位表里本要退出，"
                    f"按『估价×倍率』继续出 {int(preset):,}"
                )
            else:
                print(f"🚪 第{round_num}回合估价 {value:,} 在预设档位里不值得出手，退出本局")
                NO_BID_REASON = (
                    f"第{round_num}回合估价 {value:,} 在预设档位表里没有对应出价"
                    f"（退出线 {EXIT_BELOW_PRICE:,}）"
                )
                return None
        price = int(preset)
        if not notes:
            notes.append("预设档位")
        cap = 0
        decision = _SimpleDecision(price, 0, 0, "预设档位价（不跟随对手节奏）")
    else:
        cfg = _BidCfg(
            cap_ratio=BID_CAP_RATIO,
            hard_cap_ratio=BID_CAP_RATIO,
            margin_ratio=BID_MARGIN,
            early_round_wait=False,
        )
        ctx = _BidCtx(
            round_index=max(0, round_num - 1),
            estimate=value,
            my_funds=10**12,
            opponent_bids=list(LAST_OPPONENT_BIDS),
            second_history=list(SECOND_HISTORY),
        )
        decision = _decide_bid(ctx, cfg)
        price = int(decision.price or 0)

    if cap > 0 and price > cap:
        notes.append(f"上限 {cap:,}")
        price = cap

    if _mode == "rule" and not _dark and round_num >= 3 and PREMIUM_RATIO > 0:
        premium = int(value * PREMIUM_RATIO)
        if price < premium:
            notes.append(f"溢价至 {premium:,}（{PREMIUM_RATIO}x 估价）")
        price = max(price, premium)
        if cap > 0 and price > cap:
            notes.append(f"被上限 {cap:,} 夹住")
            price = cap

    if TIDY_BID == 1 and price > 0 and _mode != "preset" and not _keep_price:
        price = 向上贴整(price)
        if cap > 0 and price > cap:
            price = cap

    if (
        round_num <= 2
        and _floor_bid > 0
        and (not _dark or DARK_VENUE_USE_FLOOR_BID == 1)
        and price < _floor_bid
    ):
        floor = _floor_bid
        if FLOOR_CAP_BY_PRICE and value > 0:
            capped = max(int(value), FLOOR_MIN)
            if capped < floor:
                floor = (
                    向上贴整(capped)
                    if (TIDY_BID == 1 and _mode != "preset")
                    else capped
                )
                notes.append(f"保底 {_floor_bid:,} 被估价夹到 {floor:,}（不为小仓多花钱）")
            else:
                notes.append(f"保底 {_floor_bid:,}（估价 {value:,} 已在保底之上）")
        else:
            notes.append(
                f"保底 {_floor_bid:,}" + ("（天黑同样执行）" if _dark else "（不受上限约束）")
            )
        price = floor

    # 最低出价保险：算出来的价太低时抬到这个数（只抬不压，不突破上限）
    if MIN_BID_AMOUNT > 0 and price > 0 and _mode != "preset" and price < int(MIN_BID_AMOUNT):
        _min_bid = int(MIN_BID_AMOUNT)
        if cap > 0 and _min_bid > cap:
            _min_bid = cap
        if _min_bid > price:
            notes.append(f"抬到最低出价 {_min_bid:,}")
            price = _min_bid

    # 求稳模式：第 3 回合起把出价压回估价（前两回合不动）
    if _safe:
        _clamped = 求稳模式压价(price, value, round_num)
        if _clamped != price:
            notes.append(f"求稳模式：{price:,} 压到上限 {_clamped:,}")
            price = _clamped
            decision = _SimpleDecision(
                price, cap, decision.predicted_second, "求稳模式：不超估价"
            )

    _no_exit_target = 0
    if CHASE_TO_END == 1 and not _safe:
        _no_exit_target = 保底链要求(round_num)
        if 防亏守卫该停吗(round_num, value, _floor_bid, _no_exit_target, _opp_ref):
            _gmsg = (
                f"🛑 第{round_num}回合不退出保底刹车：保底链要求 {_no_exit_target:,}，"
                f"策略估值只有 {value:,}，对手参考 {_opp_ref:,} → 没人抢还往上抬只会亏，本局收手"
            )
            print(_gmsg)
            NO_BID_REASON = _gmsg
            try:
                记回合事件(
                    "no_exit_loss_guard",
                    human=_gmsg,
                    round=round_num,
                    value=int(value),
                    floor_bid=int(_floor_bid),
                    target=int(_no_exit_target),
                    opponent_ref=int(_opp_ref),
                )
            except Exception:
                pass
            return None
        # 不退出模式下要不要「绝不降价」：
        #   1（默认，跟以前一样）= 每回合至少按 CHASE_STEP_RATIO 递增，绝不回落
        #   0 = 允许按智能估价回落，只有完全算不出价时才拿保底链兜底
        _no_down = int(globals().get("NO_EXIT_NO_DOWNGRADE", 1) or 0) == 1
        if _no_down and (price < _no_exit_target or price <= 0):
            if price > 0:
                notes.append(
                    f"不退出模式：上轮保底链要求至少 {_no_exit_target:,}，"
                    f"不降价（原算价 {price:,}）"
                )
            else:
                notes.append(f"不退出模式：无其他有效价，按保底链出 {_no_exit_target:,}")
            price = _no_exit_target
            decision = _SimpleDecision(
                price,
                cap,
                decision.predicted_second,
                "不退出模式：保底价逐回合递增",
            )
        elif price <= 0:
            # 关掉「不降价」时，只有真算不出价才拿保底链兜底
            notes.append(f"不退出模式：无其他有效价，按保底链出 {_no_exit_target:,}")
            price = _no_exit_target
            decision = _SimpleDecision(
                price, cap, decision.predicted_second, "不退出模式：保底链兜底"
            )
        if price > 0:
            regular_price = 保底价贴整(price)
            if regular_price != price:
                notes.append(f"不退出模式：出价按千位数向上贴整 {price:,} → {regular_price:,}")
                price = regular_price

    # 超估价硬顶：最后一道闸，不管哪条路径算出来的价都压住（图鉴模式自己有 CAP）
    if (
        HARD_CAP_MULT > 0
        and round_num >= 3
        and value
        and value > 0
        and price > 0
       
    ):
        _hard = int(int(value) * float(HARD_CAP_MULT))
        if _hard > 0 and price > _hard:
            notes.append(
                f"超估价硬顶：{price:,} 超过估价 {HARD_CAP_MULT:g} 倍 {_hard:,} → 压回"
            )
            price = _hard

    # 对手溢价闸：读到对手出价时，别为了赢多花四成
    if (
        RIVAL_PREMIUM_CAP > 0
        and round_num >= 3
        and price > 0
       
        and int(value or 0) <= int(BIG_LOT_GATE)
    ):
        _rmax = int(globals().get("PREV_ROUND_OPP_MAX", 0) or 0)
        if _rmax <= 0:
            _rmax = int(globals().get("OPPONENT_MAX_SEEN", 0) or 0)
        if _rmax > 0:
            _rp = int(_rmax * float(RIVAL_PREMIUM_CAP))
            if _rp > 0 and price > _rp:
                notes.append(
                    f"对手溢价闸：{price:,} 比对手最高 {_rmax:,} 多出"
                    f" {price / float(_rmax):.2f} 倍 → 压到 {_rp:,}"
                )
                price = _rp

    if price <= 0:
        NO_BID_REASON = f"第{round_num}回合算不出合适的出价（{decision.reason}）"
        print(f"💰 智能出价：{decision.reason}")
        记回合事件(
            "bid_decision",
            human=f"第{round_num}回合 估价 {value:,} → 放弃（{decision.reason}）",
            round=round_num,
            estimate=value,
            price=0,
            cap=decision.cap,
            predicted=decision.predicted_second,
            k=_ROUND_K[min(round_num - 1, 5)],
            reason=decision.reason,
            floor_bid=_floor_bid,
        )
        return None

    print(
        f"💰 智能出价：{decision.reason} -> 出价 {price:,}（{'；'.join(notes)}）"
        if notes
        else f"💰 智能出价：{decision.reason} -> 出价 {price:,}"
    )
    _kp = _ROUND_K[min(round_num - 1, 5)]
    _audit = _出价自检(price, value, cap, round_num)
    记回合事件(
        "bid_decision",
        human=(
            f"第{round_num}回合 估价 {value:,} → 出价 {price:,}"
            f"（引擎算 {decision.price:,}，上限 {cap:,}，规则 {_kp}×，"
            f"预测第二 {decision.predicted_second:,}"
            + (f"；{'；'.join(notes)}" if notes else "")
            + "）"
        ),
        round=round_num,
        estimate=value,
        price=price,
        cap=cap,
        predicted=decision.predicted_second,
        k=_kp,
        engine_price=decision.price,
        adjusts=notes,
        audit=_audit,
        price_over_estimate=round(price / value, 4) if value else 0,
        reason=decision.reason,
        floor_bid=_floor_bid,
        opponent_ref=_opp_ref,
        opponent_which=_opp_which,
        no_exit=bool(CHASE_TO_END == 1),
        no_exit_target=_no_exit_target,
        no_exit_ramp_step=float(CHASE_STEP_RATIO or 1.05),
        urgent=快没时间了吗(),
        ocr=dict(RUNLOG_OCR),
    )
    _RUNLOG_BID_DECISIONS[int(round_num)] = {
        "engine_price": decision.price,
        "adjusts": notes,
        "cap": cap,
        "predicted_second": decision.predicted_second,
        "k": _kp,
    }
    return str(price)


def 老档位价(value, round_num):
    global high_first_round, low_first_round
    floor_bid = 当前保底价()

    if round_num in (1, 2):
        if value <= floor_bid:
            return str(int(floor_bid))
        if value <= GATE_179:
            return str(向下贴整(value))
    elif value <= EXIT_BELOW_PRICE:
        return None

    tier, first = 查档位(value)
    if tier is None:
        # 去掉守望者/永恒之心/乐园巧克力三档后，<321 万没档位 → 直接按估价出，
        # 别掉进下面"无档位却套用 low 档倍率"的坑（TIER_FIRST_ROUND 用 None 当键会串到 low）。
        return str(int(value))
    if tier == "low" and low_first_round is None:
        low_first_round = round_num
    elif tier in ("233", "321", "280", "420", "588", "620", "666") and high_first_round is None:
        high_first_round = round_num

    _is_first_appear = (round_num == 1) or (tier not in TIER_FIRST_ROUND)
    try:
        TIER_FIRST_ROUND.setdefault(tier, round_num)
    except Exception:
        pass
    if _is_first_appear:
        return str(int(first))
    return str(int(档位出价(value, round_num, tier, first)))


_SPECIAL_FIRST_ROUND = {}      # 按档位记"首轮价出现在第几回合"（不同档分别首见，各算各的 R2..R5）
# 出价规则专用的"上回合估价"。
# 注意：不能用 _PREV_EST_FOR_VISION —— 那个在调用 取出价金额 之前就已经被改成"本回合估价"了，
#      导致涨幅永远算成 0，第1回合的大红判定永远不触发（实测 2027 万还按普通倍率出 2534 万）。
_PREV_EST_FOR_BID = [0]


def _特殊藏品出价(round_num, est, vision_name=None):
    """特殊藏品出价：首见 = 该档首轮价；之后 = 首见到本回合的 R2..R5 倍率。"""
    tier = None
    if vision_name:
        try:
            for _k, _v in ITEM_BY_TIER.items():
                if 藏品同名(_v, vision_name):
                    tier = _k
                    break
        except Exception:
            tier = None
    if not tier:
        try:
            tier, _first = 查档位(int(est))
        except Exception:
            tier = None
    if not tier:
        return None
    _rnd = int(round_num)
    _first_rnd = int(_SPECIAL_FIRST_ROUND.get(tier, 0) or 0)
    if _first_rnd <= 0:
        _first_rnd = _rnd
        _SPECIAL_FIRST_ROUND[tier] = _rnd
    if _rnd <= _first_rnd:
        price = _档位首轮价(tier)
        print(f"🎁 特殊藏品（{'视觉识别：' + str(vision_name) if vision_name else '涨幅判定'}）"
              f"→ 第{_rnd}回合出首轮价 {int(price or 0):,}")
        return int(price) if price else None
    # 倍率按"首轮价出现在第几回合"往后数：step1 → R2、2 → R3、3 → R4、4 → R5
    _keys = TIER_MULTIPLIER_KEYS.get(tier) or TIER_MULTIPLIER_KEYS.get("low")
    _step = _rnd - _first_rnd
    _mult = None
    if _keys and 1 <= _step <= 4:
        try:
            _mult = float(globals().get(_keys[_step - 1], "") or 0)
        except Exception:
            _mult = None
    if not _mult or _mult <= 0:
        price = _档位首轮价(tier)
        print(f"🎁 特殊藏品 → 第{_rnd}回合没有倍数配置，退回首轮价 {int(price or 0):,}")
        return int(price) if price else None
    price = _首轮链价(tier, _step)
    print(f"🎁 特殊藏品（首轮价在第{_first_rnd}回合）→ 第{_rnd}回合 "
          f"首轮价链式 ×{_step}档 = {price:,}")
    return int(price)


def 取出价金额(value_str, round_num):
    global NO_BID_REASON
    _RUNLOG_BID_DECISIONS.pop(int(round_num), None)
    # 撞果盘打到"福利多多"局时：每一回合都固定出 BONUS_KEEP_BID（默认 520）占位，
    # 不走策略（不加价、不退出）—— 要求"福利多多一直出 520"。
    if _GP_BONUS_MODE[0]:
        try:
            _amt = int(float(str(BONUS_KEEP_BID).strip() or 0))
        except Exception:
            _amt = 520
        if _amt > 0:
            print("💠 [撞果盘] 福利多多局：这一回合仍按固定价出 %s（占位，不跟价）" % f"{_amt:,}")
            return str(_amt)
    value = 金额转整数(value_str, None)
    if value is None:
        return None
    # 紧迫危机跳过仪器时：直接沿用上轮出价/保底价，不再走后面的算价
    try:
        if _URGENT_REUSE_BID[0]:
            _ub = int(_URGENT_REUSE_BID[0])
            _URGENT_REUSE_BID[0] = 0
            NO_BID_REASON = f"紧迫危机：跳过仪器 → 沿用上轮出价/保底价 {_ub:,}"
            print("💰 " + NO_BID_REASON)
            return str(_ub)
    except Exception:
        pass
    # 优先级：目标藏品 > 智能出价(若开) > 退出线 > 档位价(够到档位时) > 普通倍率 > 档位价(兜底)
    _SPECIAL_BID_ACTIVE[0] = False
    try:
        _sp = 识别到的目标藏品(round_num)
        if _sp:
            _sp_price = 目标藏品价(_sp, round_num, value)
            if _sp_price:
                _SPECIAL_BID_ACTIVE[0] = True
                return str(int(_sp_price))
    except Exception as _esp:
        print(f"⚠️ 目标藏品出价计算失败（退回常规规则）: {_esp}")
    if BID_AUTO_PRICE == 1 and BID_AVAILABLE:
        return 智能出价(value, round_num)
    # 退出线：第3回合起，估价低于这个数就不出价、退出本局。
    # 必须在"普通倍率/档位价"之前判，否则用户填了普通倍率会把退出线绕过去。
    try:
        # 一路追到底（CHASE_TO_END=1）时，第 3 回合估价再低也不退 → 跳过退出线。
        # 以前这里没看这个开关，只有"智能出价"那条路看了，导致智能出价一关，
        # 开了"一路追到底"照样被退出线踢出去（实测踩过）。
        if (int(round_num) >= 3
                and int(EXIT_BELOW_PRICE or 0) > 0
                and int(value) < int(EXIT_BELOW_PRICE)
                and int(CHASE_TO_END or 0) != 1):
            NO_BID_REASON = (f"第{round_num}回合估价 {int(value):,} < 退出线 "
                             f"{int(EXIT_BELOW_PRICE):,} → 收手退出本局")
            print("🚪 " + NO_BID_REASON)
            try:
                记回合事件("exit_below_price", human="🚪 " + NO_BID_REASON,
                           round=int(round_num), estimate=int(value))
            except Exception:
                pass
            return None
    except Exception as _eexit:
        print(f"⚠️ 退出线判断失败（继续按原规则）: {_eexit}")
    # ==========================================================================
    # 出价优先级（用户 2026-11-20 定稿，禁止改顺序）
    #   R1: 特殊藏品(视觉识别 / 涨幅) → 首轮价
    #       否则 底价>估价 ? 档位价 ＞ 普通倍率 : 普通倍率 ＞ 档位价
    #   R2: 特殊藏品(涨幅≥110万 / 已知R1出过首轮价 → R2倍率)
    #       否则 底价>估价 ? 档位价 ＞ 普通倍率 : 普通倍率 ＞ 档位价
    #   R3: 特殊藏品(涨幅 / 已知R1→R3 / 已知R2→R2)           否则 只走普通倍率
    #   R4: 特殊藏品(已知R1→R4 / R2→R3 / R3→R2) ＞ 涨幅→首轮价  否则 只走普通倍率
    #   R5: 特殊藏品(已知R1→R5 / R2→R4 / R3→R3 / R4→R2) ＞ 涨幅→首轮价  否则 只走普通倍率
    # ==========================================================================
    _rnd = int(round_num)
    try:
        _floor = int(当前保底价() or 0)
    except Exception:
        _floor = 0
    _est = int(value)

    def _算普通倍率():
        _np = 普通倍率价(_est)
        if not _np:
            return None
        print(f"📈 普通倍率价 {int(_np):,}（估价 {_est:,}，第{_rnd}回合）")
        return int(_np)

    def _算档位():
        _r = 老档位价(_est, _rnd)
        if _r is None:
            return None
        try:
            _th = 查档位(_est)[0]
        except Exception:
            _th = None
        print(f"🎯 走「{_th}」档价 {int(_r):,}"
              f"（底价 {_floor:,} {'>' if _floor > _est else '≤'} 估价 {_est:,}）")
        return int(_r)

    # ---- 特殊藏品（视觉 / 涨幅）----
    _special = None
    try:
        _vision_now = 识别到的目标藏品(_rnd)
    except Exception:
        _vision_now = None
    try:
        _prev_est = int(_PREV_EST_FOR_BID[0] or 0)
    except Exception:
        _prev_est = 0
    try:
        _PREV_EST_FOR_BID[0] = int(_est)
    except Exception:
        pass
    # "估价识别到特殊藏品"：本回合估价 − 上回合估价 ≥ 1,100,000。
    # 第1回合没有上回合（_prev_est=0）→ 不判涨幅，避免把所有高估价都当成特殊藏品。
    _surge = (_est - _prev_est) >= int(VISION_SURGE_STEP)
    # 当前估价/视觉对应哪一档，再查这一档的首见回合（不同档各自首见、各自 R2..R5）
    _rnd_tier = None
    if _vision_now:
        try:
            for _tk, _tv in ITEM_BY_TIER.items():
                if 藏品同名(_tv, _vision_now):
                    _rnd_tier = _tk
                    break
        except Exception:
            _rnd_tier = None
    if not _rnd_tier:
        try:
            _rnd_tier = 查档位(int(_est))[0]
        except Exception:
            _rnd_tier = None
    _prev_first = int(_SPECIAL_FIRST_ROUND.get(_rnd_tier, 0) or 0)

    if _rnd == 1:
        # 用户规则（没有视觉版）：估价识别 ≥ 上回合估价 + 1,100,000 → 特殊藏品首轮价。
        # 第1回合没有上回合，按 0 起算 = 估价 ≥ 110 万就算。
        if _vision_now or _surge:
            _special = _特殊藏品出价(_rnd, _est, _vision_now)
    elif _rnd == 2:
        if _surge or _vision_now or _prev_first == 1:
            _special = _特殊藏品出价(_rnd, _est, _vision_now)
    elif _rnd == 3:
        if _surge or _vision_now or _prev_first in (1, 2):
            _special = _特殊藏品出价(_rnd, _est, _vision_now)
    elif _rnd in (4, 5):
        if _prev_first and _prev_first < _rnd:
            _special = _特殊藏品出价(_rnd, _est, _vision_now)
        elif _surge or _vision_now:
            _special = _特殊藏品出价(_rnd, _est, _vision_now)

    if _special:
        _SPECIAL_BID_ACTIVE[0] = True
        return str(int(_special))

    # ---- 普通情况 ----
    if _rnd <= 2:
        if _floor > 0 and _floor > _est:
            print(f"🎯 底价 {_floor:,} > 估价 {_est:,} → 底价/档位价 优先")
            _a = _算档位()
            if _a:
                if _est > 0 and _a == _floor:
                    记回合事件(
                        "floor_bid_applied",
                        human=f"🎯 第{_rnd}回合保底价 {_a:,}（当前估价 {_est:,}，{_a / _est:.2f} 倍）",
                        round=_rnd, estimate=_est, floor_bid=_a, ratio=round(_a / _est, 4),
                    )
                return str(int(_a))
            _b = _算普通倍率()
            if _b:
                return str(int(_b))
            return str(int(_floor))
        _b = _算普通倍率()
        if _b:
            return str(int(_b))
        _a = _算档位()
        if _a:
            return str(int(_a))
    else:
        _b = _算普通倍率()
        if _b:
            return str(int(_b))
        _a = _算档位()
        if _a:
            return str(int(_a))

    _r = 老档位价(_est, _rnd)
    if _r is None and not NO_BID_REASON:
        NO_BID_REASON = f"第{_rnd}回合估价 {_est:,} 没有算出价（档位表/普通倍率都没配）"
    return _r


def 出价失败也留房(round_num, stage="出价"):
    """撞果盘命中后的保底规则：出价相关失败也不执行流程B。

    福利多多 + 名字符合条件后，这局的唯一目标是留在房间。金额校验失败、
    出价面板短暂异常等只跳过本回合出价，等下一回合继续；普通对局仍按原逻辑退出。
    """
    if not _GP_BONUS_MODE[0]:
        return False
    msg = (
        f"🛡️ [撞果盘] 第{round_num}回合{stage}失败，但本局已符合条件 → "
        f"不执行流程B、不退出对局；本回合跳过出价，继续等下一回合"
    )
    print(msg)
    try:
        写日志(msg)
        记回合事件("guo_pan_keep_bid_fail", human=msg, round=round_num, stage=stage)
    except Exception:
        pass
    return True


# 拍到高价值仓时，除了正常那几张，要不要再滚到底存一张「整个仓」的长图。
# 会多花 5~10 秒（一屏一停等画面稳定），结算界面有 100 秒倒计时，来得及。
LONG_SHOT_ENABLED = 1


def 存整仓长图(save_path, max_pages=8):
    """把当前仓库滚到底，拼成一张长图存下来。返回保存路径，失败返回空串。

    结算界面右下那块仓库就是同一个组件，滚动条坐标完全一致
    （x=1887、滑块 226~445、轨道到 761），所以滚仓和拼接直接复用仓库页面那套。

    最多滚 8 屏（一屏约 15 行，够 120 行了），防止某一屏滑块没动就死循环。
    """
    try:
        pages = []
        thumbs = []
        整仓滚到顶()
        for _p in range(max_pages):
            if not running:
                break
            page = 稳定整仓图()
            if page is None:
                break
            pages.append(page)
            rng = 整仓滚动范围()
            thumbs.append(float(rng[0]) if rng else 0.0)
            if 整仓到底了吗():
                break
            ok, _how = 整仓滚一屏(down=True)
            if not ok:
                break
        if not pages:
            return ""
        canvas, used = 竖向拼接(pages, thumbs)
        if canvas is None or used <= 0:
            return ""
        folder = os.path.dirname(save_path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        canvas.save(save_path)
        print(
            f"📜 整仓长图已保存：{os.path.basename(save_path)}"
            f"（{used} 屏，{canvas.width}×{canvas.height}）"
        )
        return save_path
    except Exception as e:
        print(f"⚠️ 整仓长图失败：{e}")
        return ""


def _不重名路径(folder, base, ext=".PNG"):
    """同一分钟拍到两个同名藏品时别互相覆盖：撞名就加 _2 / _3。

    文件名只用「时：分」，不放日期 —— 日期已经在目录名上了，
    再写一遍又长又重复（以前叫 夜光杯_20261114_180512.PNG）。
    """
    path = os.path.join(folder, base + ext)
    if not os.path.exists(path):
        return path
    for n in range(2, 1000):
        path = os.path.join(folder, "%s_%d%s" % (base, n, ext))
        if not os.path.exists(path):
            return path
    return os.path.join(folder, "%s_%s%s" % (base, datetime.now().strftime("%S"), ext))


def _截图认物品名(img=None):
    """在结算画面上 OCR，找「图鉴/档位里已知的物品名」。找不到返回 None。

    为什么不用金额档位命名：家用电影机、超级存储盘这些档位的金额区间会互相压住，
    5,241,000 这种金额既可能落在"超级存储盘"档，也可能是加价买到的"家用电影机" ——
    光看金额只能猜。画面上的物品名才是确定的。
    """
    try:
        import numpy as _np
        import cv2 as _cv
        shot = img if img is not None else 抓一帧()
        if shot is None:
            return None
        arr = _np.array(shot.convert("RGB"))[:, :, ::-1]
        res = ocr.ocr(arr, cls=True)
        texts = []
        for line in ((res[0] if res else None) or []):
            try:
                texts.append(str(line[1][0] or ""))
            except Exception:
                continue
        blob = "".join(texts)
        names = []
        try:
            names += [str(n) for n, _p in CATALOG_ITEMS if n]
        except Exception:
            pass
        names += list(ITEM_BY_TIER.values())
        # 屏幕上可能同时出现多个物品名（结算仓里还有别的藏品）。
        # 只有"只命中一个名字"时才敢用它命名，否则宁可退回金额分档，
        # 免得把仓里的永恒之心当成刚买到的那件。
        hits = []
        for name in sorted(set(names), key=len, reverse=True):
            if name and name in blob:
                hits.append(name)
        uniq = []
        for h in hits:
            if not any(h != u and h in u for u in hits):   # 去掉被更长名字包含的
                if h not in uniq:
                    uniq.append(h)
        return uniq[0] if len(uniq) == 1 else None
    except Exception:
        return None


def 存高价值截图(actual_value, mine=True):
    """结算截图存档。

    文件名只用「时间 + 谁拍到」，**不再带物品名**。
    原因：靠金额推档位会把加价买到的货算到隔壁档（比如家用电影机被写成 u盘），
    靠仓库识别又只能说明"仓里有它"，都不是"这局拍到的是哪件"。
    宁可让使用者自己看截图确认，也不要写一个错的名字。
    """
    if BIG_LOT_SHOT != 1:
        return
    is_low = not (actual_value > SCREENSHOT_TIER1_THRESHOLD)
    if is_low:
        # 没够到高价值线：只截【我拍到的】，别人拍走的不存（不然一天几百张）
        if LOW_VALUE_SCREENSHOT_ENABLED != 1 or not mine:
            return

    if not is_low:
        # 记录时附上图鉴名次作参照（纯计算，不额外截屏/识别）
        try:
            _rk, _nm, _mp = 图鉴品级(actual_value)
            if _nm:
                print(
                    f"📖 图鉴对比：实际价值 {actual_value:,} 够到图鉴第 {_rk} 名「{_nm}」（{_mp:,}）"
                )
            elif CATALOG_ITEMS:
                print(
                    f"📖 图鉴对比：实际价值 {actual_value:,} 没够上图鉴末位 {CATALOG_ITEMS[-1][0]:,}"
                )
        except Exception:
            pass

    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        # 文件名：时间 + 谁拍的（冒号用全角，Windows 认）
        _hhmm = datetime.now().strftime("%H：%M")
        _who = "我拍到" if mine else "他人拍走"
        # 全屏截图：以前只截游戏窗口，结算界面边上那圈信息会被切掉
        img = 抓一帧()
        if mine:
            try:
                if is_low:
                    p1 = _不重名路径(低价值截图目录(), f"{_hhmm}（{_who}）")
                    img.save(p1)
                    清最新的(LOW_VALUE_SHOT_ROOT, LOW_VALUE_SHOT_KEEP, recursive=True)
                    清到容量(LOW_VALUE_SHOT_ROOT, LOW_VALUE_SHOT_MAX_MB)
                else:
                    p1 = _不重名路径(高价值截图目录(), f"{_hhmm}（{_who}）")
                    img.save(p1)
                    print(f"📸 高价值截图已保存：{p1}")
                    清最新的(HIGH_VALUE_SHOT_ROOT, 300, recursive=True)
            except Exception as e:
                print(f"⚠️ 保存面板用高价值截图失败: {e}")
        if not is_low:
            try:
                p2 = os.path.join(
                    高价值分析目录(), f"a{RUNLOG_AUCTION_NO}_{timestamp}.PNG"
                )
                img.save(p2)
                print(f"📸 高价值截图已保存（分析用，永久保留）: {p2}")
            except Exception as e:
                print(f"⚠️ 保存分析用高价值截图失败: {e}")

        # 我拍到的大仓，再滚到底拼一张「整个仓」的长图
        if mine and not is_low and int(LONG_SHOT_ENABLED or 0) == 1:
            try:
                _base = _不重名路径(
                    高价值截图目录(), f"{_hhmm}（{_who}）整仓"
                )
                存整仓长图(_base)
            except Exception as e:
                print(f"⚠️ 整仓长图失败: {e}")
    except Exception as e:
        print(f"⚠️ 保存高价值成交截图失败: {e}")


def 查资产并停():
    global running
    if FUNDS_CHECK_ENABLED != 1:
        return False
    funds_str = 读当前资产()
    if not funds_str:
        print("⚠️ 资金识别失败，跳过本次检查")
        return False
    try:
        funds = int(funds_str)
    except ValueError:
        return False
    print(f"💰 当前资金: {funds:,}")
    if funds < STOP_BELOW_FUNDS:
        print(f"\n🚨🚨🚨 资金 {funds:,} 低于阈值 {STOP_BELOW_FUNDS:,}，脚本停止运行！ 🚨🚨🚨")
        记回合事件(
            "funds_stop",
            human=f"⛔ 资金不足停止：{funds:,} < {STOP_BELOW_FUNDS:,}",
            funds=funds,
            threshold=STOP_BELOW_FUNDS,
        )
        running = False
        return True
    return False


def 屏幕找东西(image_name, timeout=0):
    """在游戏窗口里找模板，返回 (找到?, 屏幕中心x, 屏幕中心y)。"""
    tpl = 读图片模板(image_name)
    if tpl is None:
        return False, 0, 0
    t0 = time.time()
    while True:
        if not running:
            return False, 0, 0
        try:
            region = 默认截图范围()
            gray = 抓灰度图(region)
            found, cx, cy = 最佳模板匹配(gray, tpl, THRESHOLD)
        except Exception as e:
            print(f"⚠️ 找 {image_name} 出错: {e}")
            return False, 0, 0
        if found:
            ox = region[0] if region else 0
            oy = region[1] if region else 0
            return True, ox + cx, oy + cy
        if timeout <= 0 or time.time() - t0 > timeout:
            return False, 0, 0
        time.sleep(0.4)


def 日常卡点位(title_pos=None, alt=False):
    """纯函数（自检能直接测）：月卡弹窗点哪里。
    默认点底部那行「点击领取今日奖励」（就是这行字，实测能领）；
    alt=True 时返回备用点的游戏客户区坐标，调用方必须再用
    客户区转屏幕() 换算成桌面绝对坐标。
    注意：只有"认到弹窗"（title_pos 有值）才会返回点位，认不到就返回 None（不点）。"""
    if not title_pos:
        return None
    if int(alt):
        return (int(DAILY_BACKUP_X), int(DAILY_BACKUP_Y))
    return (int(title_pos[0]), int(title_pos[1]) + int(DAILY_CARD_HINT_DY))


def 日常奖励点位(tip_pos=None, alt=False):
    """纯函数：奖励详情（「获得物品」）点哪里。
    默认点底部那行「点击空白区域关闭」；alt=True 时点备用坐标。"""
    if not tip_pos:
        return None
    if int(alt):
        return (int(DAILY_BACKUP_X), int(DAILY_BACKUP_Y))
    return (int(tip_pos[0]), int(tip_pos[1]))


def 日常卡坐标(attempt=0, wait=0):
    """在屏幕上找月卡弹窗该点的位置；返回 (x, y) 或 None（弹窗不在）。"""
    ok, x, y = 屏幕找东西(DAILY_CARD_IMAGE, timeout=wait)
    if ok:
        if int(attempt) % 2 == 1:
            pos = 客户区转屏幕(DAILY_BACKUP_X, DAILY_BACKUP_Y)
            if pos is not None:
                print(
                    "ℹ️ 月卡备用点：客户区 (%d, %d) → 屏幕 (%d, %d)"
                    % (int(DAILY_BACKUP_X), int(DAILY_BACKUP_Y), pos[0], pos[1])
                )
            return pos
        return 日常卡点位((x, y), alt=False)
    return None


def 日常奖励坐标(attempt=0, wait=0):
    """在屏幕上找奖励详情该点的位置；返回 (x, y) 或 None（弹窗不在）。"""
    ok, x, y = 屏幕找东西(DAILY_REWARD_TIP_IMAGE, timeout=wait)
    if ok:
        if int(attempt) % 2 == 1:
            pos = 客户区转屏幕(DAILY_BACKUP_X, DAILY_BACKUP_Y)
            if pos is not None:
                print(
                    "ℹ️ 奖励详情备用点：客户区 (%d, %d) → 屏幕 (%d, %d)"
                    % (int(DAILY_BACKUP_X), int(DAILY_BACKUP_Y), pos[0], pos[1])
                )
            return pos
        return 日常奖励点位((x, y), alt=False)
    return None


def 日常关掉(what, image, pos_func, times, wait_first=0, real=False, quiet=False):
    """点掉一个弹窗：每轮先确认模板还在不在、再找地方点。
    pos_func(第几次尝试, 首次搜索等待秒数) -> 该点哪里。返回 (点了几次, 还在吗)。
    real=True 时这一步强制用真鼠标点（后台模式点不掉时的兜底）。
    quiet=True 时不打印"没看到"（轮询等待时避免刷屏）。"""
    clicked = 0
    for i in range(max(1, int(times))):
        if i > 0 and not 画面有吗(image, timeout=0):
            return clicked, False
        pos = pos_func(i, wait_first if i == 0 else 0)
        if pos is None:
            if i == 0 and not quiet:
                print(f"ℹ️ 没看到【{what}】（模板没匹配上）→ 不点")
            return clicked, 画面有吗(image, timeout=0)
        print(f"🖱️ 【{what}】第 {i + 1}/{times} 次点击 ({pos[0]}, {pos[1]})")
        try:
            点在坐标(pos[0], pos[1], force_real=real)
            clicked += 1
        except Exception as e:
            print(f"⚠️ 【{what}】点击异常: {e}")
        if i < times - 1:
            time.sleep(DAILY_CLICK_INTERVAL)
    return clicked, 画面有吗(image, timeout=0)


def 日常窗口结束(now=None):
    """今天盯月卡弹窗的收工时间（默认 05:05:00）。"""
    t = now or datetime.now()
    return t.replace(
        hour=int(DAILY_CLICK_END_HOUR),
        minute=int(DAILY_CLICK_END_MINUTE),
        second=int(DAILY_CLICK_END_SECOND),
        microsecond=0,
    )


def 日常下一秒(interval, started=None):
    """睡到下一个节拍（每秒醒一次，暂停/停机能及时退出）。
    started = 这一拍开始的时间戳：把"点一下 + 看画面"花掉的时间扣掉，保证真的是每 interval 秒点一次。"""
    _spent = (time.time() - started) if started else 0.0
    _wait = max(1.0, float(interval) - max(0.0, _spent))
    t0 = time.time()
    while running and time.time() - t0 < _wait:
        time.sleep(1)


def 日常清一轮(times=1, real=False, quiet=False):
    """一个节拍：认月卡弹窗 → 点设定位置 → 立刻确认点掉没有；顺手把领奖后的「奖励详情」也点掉。
    返回 (月卡点了几下, 奖励详情点了几下, 画面上还有没有弹窗)。
    注意：认不到就**不点**（点位是"认到弹窗"才返回的），所以每 10 秒来一次也不会乱点。"""
    n_card, card_still = 日常关掉(
        "月卡弹窗",
        DAILY_CARD_IMAGE,
        日常卡坐标,
        max(1, int(times)),
        real=real,
        quiet=quiet,
    )
    if n_card or card_still:
        # 点完月卡紧接着会弹「获得物品」奖励详情 —— 给它几秒冒出来的时间再点掉
        n_rew, rew_still = 日常关掉(
            "奖励详情",
            DAILY_REWARD_TIP_IMAGE,
            日常奖励坐标,
            max(1, int(times)),
            wait_first=int(DAILY_REWARD_APPEAR_WAIT),
            real=real,
            quiet=quiet,
        )
    else:
        # 月卡没认到，但万一屏幕上只剩领奖弹窗（比如脚本刚重启过）也得点掉
        n_rew = 0
        rew_still = 画面有吗(DAILY_REWARD_TIP_IMAGE, timeout=0)
    return n_card, n_rew, bool(card_still or rew_still)


def 日常激活并清():
    """盯到 05:05 还没点掉时走这里：激活一下游戏窗口 → 用新画面重新识别。

    为什么要"激活"：后台抓图在游戏窗口长时间没人碰的时候会一直读到**旧帧** ——
    弹窗明明盖在屏幕上，脚本"看不见"（10-15、10-16 两次实测都是这个原因：
    04:50 起守候的那十几分钟一次都没点过游戏，等它 05:07:31 恢复操作时，
    弹窗才出现在新画面里，检查窗口已经过掉了）。激活（拉前台）会逼游戏重新渲染，
    这时候再认就一定认得到；游戏反正就在前台，点掉这一步用真鼠标。
    返回 (月卡点了几下, 奖励详情点了几下, 是否确认画面已经干净)。"""
    prev_fg = None
    try:
        prev_fg = win32gui.GetForegroundWindow()
    except Exception:
        prev_fg = None
    activated = False
    try:
        activated = bool(窗口提到前面(缓存窗口句柄()))
    except Exception as e:
        print("   （激活游戏窗口失败：%s）" % e)
    if activated:
        print("   🖥 已把游戏窗口拉到最前（这样抓到的是新画面，不是旧帧）")
    else:
        print("   ⚠️ 没能把游戏窗口拉到最前 → 直接再用一遍识别")
    n_card = n_rew = 0
    still = False
    try:
        time.sleep(0.8)
        _deadline = time.time() + max(10, int(DAILY_CLICK_ACTIVATE_WAIT))
        _pass = 0
        while running and time.time() < _deadline:
            _pass += 1
            _c, _r, still = 日常清一轮(DAILY_CLICK_TIMES, real=True, quiet=(_pass > 2))
            n_card += _c
            n_rew += _r
            if not still:
                break
            time.sleep(max(2, int(DAILY_CLICK_ACTIVATE_INTERVAL)))
    finally:
        # 前台还给用户：后台模式的意义就是不抢你的窗口
        try:
            if (
                activated
                and prev_fg
                and win32gui.IsWindow(prev_fg)
                and prev_fg != 缓存窗口句柄()
            ):
                win32gui.SetForegroundWindow(prev_fg)
        except Exception:
            pass
    return n_card, n_rew, (not still)


def 日常盲点(round_no=0):
    """盲点一下"设定位置"（DAILY_BLIND_X/Y = 卡片底部「点击领取今日奖励」）。

    完全不看识别结果：这段时间已经退出对局、专门守着月卡，这个位置不会点到别的按钮；
    而且就算后台抓到的是旧帧、模板认不到弹窗，**游戏照样收得到这一下点击**（输入和画面是两回事）。
    """
    try:
        pos = 客户区转屏幕(DAILY_BLIND_X, DAILY_BLIND_Y)
        if pos is None:
            print("   ⚠️ 盲点跳过：游戏窗口不存在、已最小化或客户区尺寸异常")
            return False
        点在坐标(int(pos[0]), int(pos[1]))
        print(
            "   🖱️ 第 %d 拍：盲点客户区 (%d, %d) → 屏幕 (%d, %d)"
            % (int(round_no), int(DAILY_BLIND_X), int(DAILY_BLIND_Y), int(pos[0]), int(pos[1]))
        )
        return True
    except Exception as e:
        print("   ⚠️ 盲点客户区 (%d, %d) 异常：%s" % (int(DAILY_BLIND_X), int(DAILY_BLIND_Y), e))
        return False


def 日常盲点秒(round_no=0, quiet=False):
    """一个节拍：盲点设定位置（不看认没认到弹窗）→ 等一小下 → 看画面还在不在。

    返回 (盲点次数, 识别补点次数, 奖励详情点击次数, 画面里还有没有弹窗, 这一拍有没有"认到过弹窗")。

    · 正在拍卖（in_auction）时这一拍跳过不点 —— 对局里这个位置会点到别的东西。
    · 盲点之后的那次抓图基本就是新画面了（点一下就把游戏唤醒了），所以"点掉没有"照样判得准。
    · 月卡弹窗还在 → 下一拍再点；月卡弹窗没了 → 多半刚领到奖：等「获得物品」详情冒出来、
      认到了就点掉它那行字。看到这个领奖弹窗就等于"确实领到了"，也是早点收工去开局的凭据。
    """
    if in_auction:
        # 局内也点"明确认出来的"月卡：
        #   盲点照样禁止（对局里那个位置会点到出价界面），但如果月卡模板真的匹配到了
        #   （0.85+），说明它就是盖在画面上的弹窗 —— 这时候点它是安全的；
        #   不点的话它会把出价面板/退出确认框一起挡住，整局乃至整晚卡死
        #   （10-18 别人那台就是"出价面板没出现 + 退出确认框没出现"，空了 3 小时）。
        if 画面有吗(DAILY_CARD_IMAGE, timeout=0):
            print("   🃏 正在拍卖中，但认到了月卡弹窗 → 点掉它（这一拍不盲点别的位置）")
            _n_in = 0
            try:
                _ok, _tx, _ty = 屏幕找东西(DAILY_CARD_IMAGE, timeout=0)
                if _ok:
                    if int(round_no) % 2 == 1:
                        _pos = 客户区转屏幕(DAILY_BACKUP_X, DAILY_BACKUP_Y)
                    else:
                        _pos = 日常卡点位((_tx, _ty), alt=False)
                    if _pos is not None:
                        点在坐标(int(_pos[0]), int(_pos[1]))
                        _n_in = 1
            except Exception as e:
                print("   ⚠️ 局内点月卡异常：%s" % e)
            time.sleep(max(0.2, float(DAILY_BLIND_SETTLE)))
            if 画面有吗(DAILY_CARD_IMAGE, timeout=0):
                return _n_in, 0, 0, True, True  # 还在 → 下一拍再点
            if 画面有吗(DAILY_REWARD_TIP_IMAGE, timeout=int(DAILY_REWARD_APPEAR_WAIT)):
                _n_r, rew_still = 日常关掉(
                    "奖励详情",
                    DAILY_REWARD_TIP_IMAGE,
                    日常奖励坐标,
                    max(1, int(DAILY_CLICK_TICK_CLICKS)),
                    quiet=quiet,
                )
                return _n_in, 0, _n_r, bool(rew_still), True
            return _n_in, 0, 0, False, True
        print("   ⏸ 正在拍卖中 → 这一拍不盲点（对局里这个位置会点到别的东西，等这局打完再点）")
        return 0, 0, 0, True, False
    _blind = 1 if 日常盲点(round_no) else 0
    time.sleep(max(0.2, float(DAILY_BLIND_SETTLE)))
    if 画面有吗(DAILY_CARD_IMAGE, timeout=0):
        return _blind, 0, 0, True, True  # 月卡弹窗还在（或刚弹出来）→ 下一拍再点
    # 月卡弹窗不在 → 等「获得物品」奖励详情冒出来（最多 DAILY_REWARD_APPEAR_WAIT 秒）
    if not 画面有吗(DAILY_REWARD_TIP_IMAGE, timeout=int(DAILY_REWARD_APPEAR_WAIT)):
        return _blind, 0, 0, False, False  # 两个都不在 → 画面干净
    _n, rew_still = 日常关掉(
        "奖励详情",
        DAILY_REWARD_TIP_IMAGE,
        日常奖励坐标,
        max(1, int(DAILY_CLICK_TICK_CLICKS)),
        quiet=quiet,
    )
    return _blind, 0, _n, bool(rew_still), True


def 日常点一次实现():
    global in_auction
    if DAILY_CLICK_REQUIRE_RUNNING == 1 and not running:
        print("⏰ [每日点击] 脚本当前未运行，跳过本次定时点击")
        return
    if in_auction:
        print(
            f"\n⏰ [每日点击] 检测到正在拍卖中，先等 {DAILY_CLICK_BIDDING_WAIT} 秒（避开出价阶段），"
            f"最长等待 {DAILY_CLICK_WAIT_MAX} 秒..."
        )
        wait_start = time.time()
        while (
            in_auction
            and time.time() - wait_start < DAILY_CLICK_WAIT_MAX
            and (time.time() - wait_start) < DAILY_CLICK_BIDDING_WAIT
        ):
            time.sleep(1)
        if in_auction:
            print(f"⏰ [每日点击] 等待拍卖超时（{DAILY_CLICK_WAIT_MAX}秒），强制执行一次点击")
        else:
            print(f"⏰ [每日点击] 拍卖已结束，开始执行点击")

    idle_start = time.time()
    while (
        running
        and (time.time() - last_activity_ts) < 2
        and time.time() - idle_start < DAILY_CLICK_WAIT_MAX
    ):
        time.sleep(1)

    window = 游戏窗口范围()
    if window is None:
        print("❌ 每日定时点击：无法获取窗口位置，跳过本次")
        return
    _eh, _em = int(DAILY_CLICK_END_HOUR), int(DAILY_CLICK_END_MINUTE)
    _tick = max(2, int(DAILY_CLICK_POLL_INTERVAL))
    _times = max(1, int(DAILY_CLICK_TICK_CLICKS))
    print(
        f"\n⏰ 到达每日定时点击时间（月卡弹窗）：每 {_tick} 秒盲点一次设定位置（客户区）"
        f"({int(DAILY_BLIND_X)}, {int(DAILY_BLIND_Y)})「点击领取今日奖励」"
        f"（不看识别结果），点完立刻看还在不在；盯到 {_eh:02d}:{_em:02d}:00"
    )
    # 04:59:00 起、每 10 秒一个节拍，盯到 05:05:00：
    #   ① 每拍直接盲点设定位置（不管认没认到弹窗）——这段时间已经退出对局守着月卡，不会点到别的东西；
    #   ② 点完立刻看画面：月卡弹窗还在就下一拍再点，冒出了「获得物品」领奖弹窗就点掉它；
    #   ③ 盯到 05:05 还没确认点掉 → 激活一下游戏窗口，用新画面重新识别，还在就点掉，然后继续游戏。
    # 为什么盲点是关键：后台抓图在游戏长时间没人碰时会一直读到旧帧、模板认不到弹窗，但点击照样送得进去 ——
    # 10-15/10-16 就是"认不到 → 没点 → 弹窗还盖在屏幕上"卡住的。
    n_blind = n_card = n_rew = 0
    _seen = False
    _still = True
    _now0 = datetime.now()
    _start = _now0.replace(
        hour=int(DAILY_CLICK_HOUR),
        minute=int(DAILY_CLICK_MINUTE),
        second=int(DAILY_CLICK_SECOND),
        microsecond=0,
    )
    _end = 日常窗口结束(_now0)
    # 只有在"今天的 04:59:00–05:05:00"里才按节拍盲点。窗口外（比如白天开局前 守住日常弹窗
    # 顺手调过来的那次）不盲点、只按识别结果点一下就走，免得把主流程按在这儿等到 05:05。
    _in_window = _start <= _now0 < _end
    _round = 0
    while running:
        _round += 1
        _tick_t0 = time.time()  # 这一拍开始的时间（下一拍按它对齐，保证真是每 10 秒点一次）
        if _in_window:
            _b, _c, _r, _still, _saw = 日常盲点秒(_round, quiet=(_round > 1))
        else:
            _b = 0
            _c, _r, _still = 日常清一轮(_times, quiet=(_round > 1))
            _saw = bool(_still or _c or _r)
        n_blind += _b
        n_card += _c
        n_rew += _r
        if _saw:
            _seen = True
        if _seen and not _still:
            break  # 认到过弹窗（或看到领奖弹窗）而画面已经干净 → 收工，正常继续流程
        if (not _in_window) or datetime.now() >= _end:
            break  # 盯到 05:05 收工 → 交给下面的"激活游戏再认一次"
        if _round == 1 and not _seen:
            print(
                f"   ℹ️ 第 1 拍点完了：没认到弹窗（也可能抓到的是旧画面）→"
                f" 继续每 {_tick} 秒盲点一下再看…"
            )
        日常下一秒(_tick, _tick_t0)

    if _seen and not _still:
        if running and int(DAILY_CLICK_AFTER_WAIT) > 0:
            歇一下(int(DAILY_CLICK_AFTER_WAIT))
        print(
            "✅ 每日定时点击：月卡弹窗已点掉（盲点 %d 次、识别补点 %d 次、奖励详情 %d 次）"
            "→ 正常继续流程" % (n_blind, n_card, n_rew)
        )
        return

    # 盯到 05:05 还没确认点掉 → 激活一下游戏，用新画面重新识别，还在就点掉，然后继续游戏
    print(
        "ℹ️ 盯到 %02d:%02d 还没确认点掉月卡弹窗（盲点已经发了 %d 次；也可能抓到的一直是旧画面）"
        "→ 激活一下游戏窗口，重新识别弹窗" % (_eh, _em, n_blind)
    )
    _c, _r, _clean = 日常激活并清()
    n_card += _c
    n_rew += _r
    if _c or _r:
        _seen = True
    if not _clean:
        print(
            "⚠️ 还有弹窗没点掉（盲点 %d 次、识别补点 %d 次、奖励详情 %d 次）→ 记一条报错，"
            "下次我按截图调位置" % (n_blind, n_card, n_rew)
        )
        try:
            记报错(
                "daily_card_stuck",
                "每日定时点击后还有弹窗没点掉（盲点 %d 次、识别补点 %d 次、奖励详情 %d 次）"
                % (n_blind, n_card, n_rew),
                shot=True,
                extra={
                    "seen": bool(_seen),
                    "clean": False,
                    "clicked": [n_blind, n_card, n_rew],
                    "x": DAILY_CLICK_X,
                    "y": DAILY_CLICK_Y,
                },
            )
        except Exception:
            pass
    elif _seen:
        print(
            "✅ 每日定时点击：激活游戏后认到并点掉了月卡弹窗（盲点 %d 次、识别补点 %d 次、"
            "奖励详情 %d 次）→ 正常继续流程" % (n_blind, n_card, n_rew)
        )
    else:
        # 没认到就是没认到，别写"画面已清干净"（那是假成功，10-15 另一台电脑就是这么被误导的）
        print(
            "ℹ️ 月卡弹窗这段没认到（盲点已经发了 %d 次；激活游戏后用新画面又确认了一遍："
            "画面上没有弹窗）→ 按没有处理，正常继续流程" % n_blind
        )


def 日常点一次():
    with CONTROL_AUTH.operation(rc.Mode.DAILY, "daily-card"):
        return 日常点一次实现()


def 初始化下次点击():
    global daily_click_next_time
    if DAILY_CLICK_ENABLED != 1:
        return
    now = datetime.now()
    today_target = now.replace(
        hour=DAILY_CLICK_HOUR, minute=DAILY_CLICK_MINUTE, second=DAILY_CLICK_SECOND, microsecond=0
    )
    if now < today_target:
        daily_click_next_time = today_target
    else:
        daily_click_next_time = today_target + timedelta(days=1)
    print(f"⏰ 每日定时点击：下次触发时间 = {daily_click_next_time.strftime('%Y-%m-%d %H:%M:%S')}")


def 检查日常点击():
    global daily_click_next_time
    if DAILY_CLICK_ENABLED != 1:
        return
    if daily_click_next_time is None:
        return
    now = datetime.now()
    if now >= daily_click_next_time:
        if _NET_HOLD[0]:
            print("⏰ [每日点击] 正在等网络恢复，先不点（网络回来立刻补上）")
            return
        try:
            日常点一次()
        except Exception as _e:
            # 点击流程万一抛异常，也必须把"今天处理过了"落下来：
            # 否则 今天点过日常了() 永远 False → 之后每次开局都守着 30 分钟，
            # 而且那属于"等用户"状态（看门狗不会自救）→ 脚本等于静默永久停摆。
            # 宁可算作已处理：弹窗还有的话，开局前的 守住日常弹窗 会兜住。
            print(f"⚠️ [每日点击] 执行出错（本次按已处理，明天再来）：{_e}")
            try:
                记报错("daily_click_exc", f"每日定时点击异常：{_e}", shot=True)
            except Exception:
                pass
        finally:
            daily_click_next_time = daily_click_next_time + timedelta(days=1)
            print(
                f"⏰ 每日定时点击：下次触发时间 = "
                f"{daily_click_next_time.strftime('%Y-%m-%d %H:%M:%S')}"
            )


def 日常点击线程():
    while True:
        try:
            检查日常点击()
        except Exception as e:
            print(f"⚠️ 每日定时点击线程异常: {e}")
        time.sleep(DAILY_CLICK_CHECK_INTERVAL)


def 记一回合(round_num, value_str, bid_amount_str=None):
    current_rounds.append(
        {"round": round_num, "value": value_str if value_str else "识别失败", "bid": bid_amount_str}
    )
    try:
        _mine = 解析金额(bid_amount_str or "")
        if _mine and _mine > 0:
            round_no = int(round_num)
            entry = _RUNLOG_BID_DECISIONS.pop(round_no, {})
            entry.update(round=round_no, estimate=解析金额(value_str), bid=int(_mine))
            RUNLOG_ROUNDS.append(entry)
            MY_BIDS[round_no] = int(_mine)
            if CHASE_TO_END == 1:
                _NO_EXIT_LAST_BID[0] = int(_mine)
    except Exception:
        pass
    try:
        记回合事件(
            "round_completed",
            human=f"✅ 第{round_num}回合完成：估价 {value_str}，出价 {bid_amount_str}",
            round=int(round_num),
            estimate=value_str,
            bid=bid_amount_str,
            no_exit=bool(CHASE_TO_END == 1),
            no_exit_last=int(_NO_EXIT_LAST_BID[0] or 0),
            urgent=快没时间了吗(),
        )
    except Exception:
        pass


def 面板出价文字(round_no, panel_bids=None):
    try:
        src = PANEL_BIDS if panel_bids is None else panel_bids
        info = src.get(int(round_no)) or src.get(str(round_no))
        if not info:
            return ""
        if info.get("dark"):
            ranks = info.get("ranks") or {}
            parts = []
            for row in range(4):
                if row in ranks:
                    parts.append("第%d位 名次%d" % (row + 1, ranks[row]))
                else:
                    parts.append("第%d位 未读到" % (row + 1))
            return "第%d回合（天黑·只有名次）：%s" % (int(round_no), " ｜ ".join(parts))
        rows = {int(k): int(v) for k, v in (info.get("rows") or {}).items()}
        mine_row = info.get("mine_row")
        mine_row = int(mine_row) if mine_row is not None else None
        parts = []
        for row in range(4):
            tag = "（我）" if (mine_row is not None and row == mine_row) else ""
            if row in rows:
                val = 格式化出价(rows[row])
                if row in (info.get("refined_rows") or ()):
                    val += "*"
            elif PANEL_EMPTY_AS_GIVEUP == 1:
                val = "0（放弃）*"
            else:
                val = "未读到（可能0/放弃）"
            parts.append("第%d位 %s%s" % (row + 1, val, tag))
        return "第%d回合各家出价：%s" % (int(round_no), " ｜ ".join(parts))
    except Exception:
        return ""


def 格式化出价(v):
    try:
        v = int(v)
    except Exception:
        return str(v)
    return "0（放弃）" if v == 0 else format(v, ",")


# 每 SUMMARY_EVERY_N 局打一行，白天挂机也能看到这一段跑得怎么样
SUMMARY_EVERY_N = 50
_RECENT_RESULTS = []


def 碰一批汇总(res, net_profit, final_price, actual_value):
    """攒够一批就打一行小结（res: won/lost/quit）。"""
    global _RECENT_RESULTS
    _RECENT_RESULTS.append(
        (str(res), int(net_profit or 0), int(final_price or 0), int(actual_value or 0))
    )
    if len(_RECENT_RESULTS) < SUMMARY_EVERY_N:
        return
    rows = _RECENT_RESULTS
    _RECENT_RESULTS = []
    n = len(rows)
    won = [r for r in rows if r[0] == "won"]
    lost = [r for r in rows if r[0] == "lost"]
    quit_ = [r for r in rows if r[0] == "quit"]
    total = sum(r[1] for r in rows)
    roi = [r[2] / r[3] for r in won if r[3] > 0 and r[2] > 0]
    avg_roi = (sum(roi) / len(roi)) if roi else 0.0
    avg_price = int(sum(r[2] for r in won) / len(won)) if won else 0
    msg = (
        f"📊 近 {n} 局：拍到 {len(won)}（均价 {avg_price:,}，"
        f"成交/价值 {avg_roi:.3f}）｜被拍走 {len(lost)}｜退出 {len(quit_)}"
        f"｜净赚 {total:+,}"
    )
    print(msg)
    try:
        写日志(msg)
    except Exception:
        pass


# 跨天时自动给前一天写一份日结（依赖同目录的 日报.py）
_LAST_REPORT_DAY = datetime.now().strftime("%Y-%m-%d")


def 可能写日报():
    """跨天时自动给前一天写一份日结（每局调一次，只比对日期，几乎不花钱）"""
    global _LAST_REPORT_DAY
    today = datetime.now().strftime("%Y-%m-%d")
    if today == _LAST_REPORT_DAY:
        return
    prev = _LAST_REPORT_DAY
    _LAST_REPORT_DAY = today
    try:
        import importlib

        rpt = importlib.import_module("日报")
        ok, out_path = rpt.write_report(prev, verbose=False)
        if ok:
            print(f"📊 跨天日结已生成：{out_path}")
        else:
            print(f"📊 跨天日结：{prev} 没有记录可写")
    except Exception as _e:
        print(f"⚠️ 日结生成失败：{_e}")


def 关拍卖(
    status, player_name="", final_price=0, actual_value=0, profit=0, note="", sell_clicked=False
):
    global auction_count, current_rounds, AUCTION_COST, AUCTION_COST_ITEMS, AUCTION_COST_KEYS
    if _AUCTION_FINISHED[0]:
        print("ℹ️ 本局已经记过账，忽略重复的 关拍卖 调用")
        return
    _AUCTION_FINISHED[0] = True
    auction_count += 1
    可能写日报()
    碰一下进度("本局结束")
    cost = int(AUCTION_COST or 0)
    cost_items = list(AUCTION_COST_ITEMS)
    cost_text = " + ".join(cost_items) if cost_items else "（未记录到任何扣费）"
    if status == "normal":
        _res = "won"
    elif note and note.startswith("他人拍走"):
        _res = "lost"
    else:
        _res = "quit"
    _res_text = {"won": "我拍到", "lost": "他人拍走", "quit": "中途退出"}[_res]
    if _res == "won":
        my_profit = int(profit or 0)
    else:
        my_profit = 输家补偿(profit, actual_value, final_price)
    net_profit = my_profit - cost
    # 每 50 局打一行，白天挂机也能看到进展
    try:
        碰一批汇总(_res, net_profit, final_price, actual_value)
    except Exception:
        pass
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    record_file = 拍卖记录路径()
    try:
        os.makedirs(os.path.dirname(record_file), exist_ok=True)
    except Exception:
        pass
    with open(record_file, "a", encoding="utf-8") as f:
        f.write(f"\n{'='*50}\n")
        f.write(f"第 {auction_count} 场  时间: {timestamp}\n")
        f.write(f"结果: {_res_text}\n")
        if player_name:
            f.write(f"玩家名称: {player_name}\n")
        for r in current_rounds:
            line = f"第{r['round']}回合估价: {r['value']}"
            if r["bid"]:
                line += f"  |  出价: {r['bid']}"
            f.write(line + "\n")
            _pb = 面板出价文字(r["round"])
            if _pb:
                f.write("    " + _pb + "\n")
        try:
            _extra = [
                int(k)
                for k in PANEL_BIDS.keys()
                if int(k) not in [int(x["round"]) for x in current_rounds]
            ]
            for _r in sorted(_extra):
                _pb = 面板出价文字(_r)
                if _pb:
                    f.write("    " + _pb + "（我没出价）\n")
        except Exception:
            pass
        f.write(f"本局成本: {cost:,}  （{cost_text}）\n")
        if status == "normal":
            f.write(f"最终成交价: {final_price:,}\n")
            f.write(f"实际价值: {actual_value:,}\n")
            f.write(f"收益: {profit:+,}\n")
            if note:
                f.write(f"备注: {note}\n")
        else:
            if final_price > 0:
                f.write(f"最终成交价: {final_price:,}\n")
            if actual_value > 0:
                f.write(f"实际价值: {actual_value:,}\n")
            if profit != 0:
                f.write(f"收益: {profit:+,}\n")
            f.write(f"备注: {note}\n")
        f.write(f"净收益: {net_profit:+,}  （我的收入 {my_profit:+,} − 成本 {cost:,}）\n")
        if sell_clicked:
            f.write("一键出售确认点击\n")
        f.write(f"{'='*50}\n")
    print(f"💾 第 {auction_count} 场记录已保存到 {record_file}")
    current_rounds = []

    _est_max = 0
    try:
        for _v in RUNLOG_SEEN_PRICES:
            _est_max = max(_est_max, int(_v))
    except Exception:
        pass
    for _r in RUNLOG_ROUNDS:
        try:
            _est_max = max(_est_max, int(_r.get("estimate", 0)))
        except Exception:
            pass
    RUNLOG_STATS["auctions"] += 1
    if _res == "won":
        RUNLOG_STATS["won"] += 1
        if my_profit < 0:
            RUNLOG_STATS["losing_bets"] += 1
    elif _res == "lost":
        RUNLOG_STATS["lost"] += 1
    else:
        RUNLOG_STATS["quit"] += 1
    try:
        RUNLOG_STATS["profit"] += my_profit
        RUNLOG_STATS["cost"] = RUNLOG_STATS.get("cost", 0) + cost
        RUNLOG_STATS["net_profit"] = RUNLOG_STATS.get("net_profit", 0) + net_profit
    except Exception:
        pass
    记回合事件(
        "auction_end",
        human=(
            f"🏁 第 {RUNLOG_AUCTION_NO} 局结束：{_res_text}"
            f"｜回合数 {len(RUNLOG_ROUNDS)}｜最高估价 {_est_max:,}"
            f"｜成交价 {final_price:,}｜实际价值 {actual_value:,}｜收益 {profit:+,}"
            + (f"｜我的收益 {my_profit:+,}" if _res != "won" else "")
            + f"｜成本 {cost:,}｜净收益 {net_profit:+,}"
            + (f"｜备注 {note}" if note else "")
        ),
        result=_res,
        status=status,
        sell_clicked=sell_clicked,
        rounds=RUNLOG_ROUNDS,
        rounds_played=len(RUNLOG_ROUNDS),
        max_estimate=_est_max,
        final_price=final_price,
        actual_value=actual_value,
        profit=profit,
        my_profit=my_profit,
        winner_profit=profit,
        cost=cost,
        cost_items=cost_items,
        net_profit=net_profit,
        player_name=player_name,
        note=note,
        panel_bids={str(k): v for k, v in PANEL_BIDS.items()},
        ocr=dict(RUNLOG_OCR),
        stats=dict(RUNLOG_STATS),
    )
    RUNLOG_ROUNDS.clear()
    AUCTION_COST = 0
    AUCTION_COST_ITEMS = []
    AUCTION_COST_KEYS = set()


def 走流程B():
    if not running:
        return
    try:
        if 画面有吗(LOGIN_PAGE_IMAGE, timeout=0):
            print("⏭️ 现在是游戏启动页/登录页（不在拍卖里），跳过流程B退出")
            退出流程成功()  # 不在拍卖里 = 退出这条路本来就不用走
            return
    except Exception:
        pass
    print("🙅 执行流程B退出")
    关仪器页()
    t = time.time()
    ok_esc = 找到就点("step_esc.png", "左上角ESC退出", timeout=5)
    if not ok_esc:
        print("↩️ 没找到 ESC 按钮，先关掉可能挡着的弹窗再试一次")
        for img in ("step_monthly_card.png", "step_close_tip.png"):
            找到就点(img, f"关闭弹窗 {img}", timeout=1, report_timeout=False)
        if not 歇一下(0.6):
            return
        ok_esc = 找到就点("step_esc.png", "左上角ESC退出", timeout=3, report_timeout=False)
    if not ok_esc:
        记报错(
            "exit_esc_missing",
            "找不到 [左上角ESC退出]，跳过退出点击（已停用键盘 ESC 兜底，避免误关游戏）",
            throttle=30,
        )
        print("⚠️ 没找到退出按钮，跳过退出（不按 ESC、不乱点），交给主循环")
        # 连续撞到上限会触发自救或停机，避免主循环以 21 秒一轮空转
        退出流程失败("流程B退出（找不到 ESC 按钮）")
        return
    if not 歇一下(1):
        return
    ok_cfm = 找到就点("step_confirm_exit.png", "弹窗确认退出", timeout=5)
    if not ok_cfm:
        print("↩️ 没看到确认弹窗，再等一次")
        if not 歇一下(0.6):
            return
        ok_cfm = 找到就点(
            "step_confirm_exit.png", "弹窗确认退出", timeout=3, report_timeout=False
        )
    if not 歇一下(1):
        return
    if not ok_cfm:
        记报错(
            "exit_flow_fail",
            "流程B退出：点了退出按钮但没看到确认框（保持原地，交给主循环处理）",
            extra={"esc": True, "confirm": False},
        )
        标记已结算("exit_flow_B", t)
        # 同上：ESC 点了没反应 + 确认框不出来，就是那种会连撞几小时的情形
        退出流程失败("流程B退出（没看到确认框）")
        return

    back_to_hall = 等回大厅(context="退出对局后")
    标记已结算("exit_flow_B", t)
    if back_to_hall:
        print("🚀 流程B结束，已确认回到大厅")
        退出流程成功()  # 退出这条路是通的 → 连撞计数清零
    else:
        print(
            f"⚠️ 退出对局后 {SETTLEMENT_HALL_WAIT} 秒内未确认拍卖大厅；"
            f"不主动进入画面恢复，交回主循环重新识别"
        )


def 看收益颜色(img_bgr):
    try:
        hsv = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2HSV)
        mask_red = cv2.inRange(hsv, np.array([0, 80, 80]), np.array([10, 255, 255])) + cv2.inRange(
            hsv, np.array([160, 80, 80]), np.array([179, 255, 255])
        )
        mask_green = cv2.inRange(hsv, np.array([40, 80, 80]), np.array([85, 255, 255]))
        red_p, green_p = cv2.countNonZero(mask_red), cv2.countNonZero(mask_green)
        if red_p > green_p and red_p > 50:
            return -1
        elif green_p > red_p and green_p > 50:
            return 1
    except Exception:
        pass
    return 0


def 识别区域文字(region, retry=3):
    for i in range(max(1, retry)):
        try:
            img_np = np.array(抓一帧(region=region))
            result = ocr.ocr(cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB), cls=True)
            if result and result[0]:
                return "".join([line[1][0] for line in result[0]])
        except Exception as e:
            print(f"  ⚠️ OCR 异常（第 {i + 1}/{retry} 次）: {e}")
        if not 歇一下(0.3):
            break
    return ""


def 识别找字并点(needles, region=None, step_desc="按文字点击", retry=2):
    """在指定区域 OCR 找一行字并点击该行中心。

    用于模板偶发不匹配、但文字内容明确的弹窗。默认扫游戏客户区。
    返回 True = 找到了文字并成功发出点击。
    """
    needles = [re.sub(r"\s+", "", str(x)) for x in (needles or []) if str(x).strip()]
    if not needles:
        return False
    for _ in range(max(1, int(retry))):
        try:
            actual_region = region if region is not None else 游戏窗口范围()
            if actual_region is None:
                return False
            shot = 抓一帧(region=actual_region)
            img_np = np.array(shot)
            result = ocr.ocr(cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB), cls=True)
            for line in (result[0] if result else None) or []:
                try:
                    text = str(line[1][0] or "")
                    compact = re.sub(r"\s+", "", text)
                    if not compact:
                        continue
                    if not any(
                        needle in compact or (len(compact) >= 6 and compact in needle)
                        for needle in needles
                    ):
                        continue
                    box = line[0]
                    xs = [float(p[0]) for p in box]
                    ys = [float(p[1]) for p in box]
                    sx = int(actual_region[0] + (min(xs) + max(xs)) / 2.0)
                    sy = int(actual_region[1] + (min(ys) + max(ys)) / 2.0)
                    print(
                        "🖱️ %s：OCR 找到『%s』，点击 (%d, %d)" % (step_desc, text.strip(), sx, sy)
                    )
                    安全点击(sx, sy)
                    return True
                except Exception:
                    continue
        except Exception as e:
            print("⚠️ %s：OCR 定位失败: %s" % (step_desc, e))
        if not 歇一下(0.35):
            break
    return False


def 卖出提示区域():
    win = 游戏窗口范围()
    if win is None:
        return None
    left, top, width, height = win
    return (
        int(left + width * 0.20),
        int(top + height * 0.82),
        int(width * 0.60),
        int(height * 0.16),
    )


def 解析金额(text, default=0):
    return 金额转整数(text, default)


# 金额解析统一入口。
# 实测：PaddleOCR 偶尔把千位逗号读成撇号（"实际价值829'986"），老写法只认半角/全角逗号，
# 一到撇号就断 → 金额被截成 829（真值 829,986），还连锁把成交价也算错（11 天 3 局）。
# 这里：先取"第一个数字串"，再把各种千位分隔符（, ， ' ’ ‘ · .）全去掉。
_MONEY_RE = re.compile(r"[-－一]?\d[\d,，.'’‘·]*")
_MONEY_NEG = ("-", "－", "一")


def 金额转整数(text, default=None):
    """把 OCR 读到的金额文字转成整数；读不到数字就返回 default。"""
    try:
        m = _MONEY_RE.search(str(text or ""))
        if not m:
            return default
        s = m.group(0)
        digits = "".join(ch for ch in s if ch.isdigit())
        if not digits:
            return default
        return -int(digits) if s[0] in _MONEY_NEG else int(digits)
    except Exception:
        return default


def 收益正常吗(actual, final, profit):
    """收益（赢家的：实际价值 - 成交价）读得合不合理。

    数学上 |收益| 不可能超过 实际价值/成交价 里大的那个（留 5% 余量）。
    实测有人机器上收益读成 -230,720,000（真值几十万）—— 这一条就能拦住。
    """
    try:
        cap = max(abs(int(actual or 0)), abs(int(final or 0)))
        if cap <= 0:
            return False
        return abs(int(profit or 0)) <= cap * 1.05 + 1
    except Exception:
        return False


def 输家补偿(profit, actual_value=0, final_price=0):
    """输掉的局：游戏按"对手亏损的 10%"返还（脚本按公式记，不是从画面上读的）。

    必须加合理性闸门 —— 收益读数一坏，这里会把它放大成 10 倍的假收入
    （实测有人机器上读成 -230,720,000 → 记录里凭空多了 +2,307 万"我的收入"）。
    赢家的亏损不可能超过他付的成交价，超过就是读数坏了，按 0 记。
    """
    try:
        p = int(profit or 0)
        if p >= 0:
            return 0
        cap = max(abs(int(actual_value or 0)), abs(int(final_price or 0)))
        if cap <= 0:
            return 0
        if abs(p) > cap * 1.05 + 1:
            print(f"⚠️ 收益读数不合理（{p:+,}，超过 实际价值/成交价 {cap:,}）→ 不记返还，按 0 处理")
            return 0
        return int(-p * 0.1)
    except Exception:
        return 0


def 实际价值正常吗(actual, profit, final_price=0):
    """实际价值是不是"被读残"了：收益的绝对值远大于实际价值时（比如实际价值读成 998、收益 -440,134）。

    这种情况绝不能拿实际价值去反推成交价（越改越错）。
    """
    try:
        actual = int(actual or 0)
        profit = int(profit or 0)
        final_price = int(final_price or 0)
        if final_price > 0:
            # 正常结算应满足：实际价值 + 收益 = 成交价。
            expected_actual = final_price + profit
            tolerance = max(50000, int(max(abs(actual), abs(expected_actual)) * 0.10))
            return abs(actual - expected_actual) <= tolerance
        # 亏损局的收益 = 实际价值 - 成交价，绝对值可能大于实际价值，
        # 但不可能大于两者中较大的那个。只拿实际价值比较会把手动高价拍中的真实亏损误报。
        return abs(profit) <= max(50000, 2 * abs(actual))
    except Exception:
        return True


def 读金额并核对(region, field_name, retries=3, *, force_ocr=False):
    """Read one settlement amount with template-first arbitration."""
    field_key = {
        "最终成交价": "final_price",
        "实际价值": "actual_value",
        "收益": "profit",
    }.get(field_name, "final_price")
    last_text = ""
    last_decision = None
    for attempt in range(max(1, int(retries))):
        try:
            img_np = np.array(抓一帧(region=region))
            color_sign = 看收益颜色(cv2.cvtColor(img_np, cv2.COLOR_RGB2BGR)) if field_key == "profit" else 0
            if not force_ocr:
                digits, _, decision = 按模板读数字(img_np, field_key)
                score, margin = 数字权威阈值()
                if 高置信数字(digits, decision, score, margin):
                    value = 金额转整数(digits, 0)
                    if field_key != "profit" and value > 0:
                        return value, "", decision
                    if field_key == "profit":
                        if color_sign or value == 0:
                            return color_sign * value, "", decision
            img_rgb = cv2.cvtColor(img_np, cv2.COLOR_BGR2RGB)
            main_text = 拼识别文字(ocr.ocr(img_rgb, cls=True))
            alt_text = ""
            try:
                if amount_ocr_alt is not None:
                    alt_text = 拼识别文字(amount_ocr_alt.ocr(img_rgb, cls=True))
            except Exception:
                alt_text = ""
            last_text = main_text or alt_text
            main_digits = re.sub(r"\D", "", main_text)
            alt_digits = re.sub(r"\D", "", alt_text)
            digits, source, decision = 按模板读数字(
                img_np, field_key, [main_digits, alt_digits]
            )
            last_decision = decision
            if not digits:
                print(
                    "  ⚠️ %s模板和 OCR 都失败（OCR %s / %s；%s），重读（第 %d/%d 次）"
                    % (
                        field_name,
                        main_digits or "-",
                        alt_digits or "-",
                        数字库概要(decision),
                        attempt + 1,
                        retries,
                    )
                )
                if not 歇一下(0.25):
                    return 0, last_text, last_decision
                continue
            value = 金额转整数(digits, 0)
            sign = color_sign or (-1 if 金额转整数(main_text or alt_text, 0) < 0 else 1)
            if value or field_key == "profit":
                print(f"    {field_name}来源：{source}")
                return sign * abs(value), main_text or alt_text, decision
        except Exception as e:
            print(f"  ⚠️ {field_name}识别异常（第 {attempt + 1}/{retries} 次）：{e}")
        if not 歇一下(0.25):
            break
    return 0, last_text, last_decision


def 识别结算数据(actual_value_hint=0):
    print("📊 正在识别结算数据...")
    if not 歇一下(0.8):
        return "", 0, 0, 0, ["流程被中断"]
    window = 游戏窗口范围()
    if window is None:
        return "", 0, 0, 0, ["找不到游戏窗口"]
    left, top, _, _ = window
    failed = []

    region_name = (left + NAME_LEFT, top + NAME_TOP, NAME_WIDTH, NAME_HEIGHT)
    player_name = 识别区域文字(region_name).strip()
    if not player_name:
        failed.append("玩家名称")
    print(f"  📋 玩家名称: {player_name}")

    region1 = (
        left + FINAL_PRICE_LEFT,
        top + FINAL_PRICE_TOP,
        FINAL_PRICE_WIDTH,
        FINAL_PRICE_HEIGHT,
    )
    final_price, final_raw, final_decision = 读金额并核对(region1, "最终成交价")
    if final_price <= 0:
        failed.append("最终成交价")
    print(f"  📋 最终成交价: {final_price:,}（{数字库概要(final_decision)}）")

    region2 = (
        left + ACTUAL_VALUE_LEFT,
        top + ACTUAL_VALUE_TOP,
        ACTUAL_VALUE_WIDTH,
        ACTUAL_VALUE_HEIGHT,
    )
    actual_value = int(actual_value_hint or 0)
    actual_decision = None
    if actual_value <= 0:
        actual_value, _, actual_decision = 读金额并核对(region2, "实际价值")
    if actual_value <= 0:
        failed.append("实际价值")
    actual_source = "沿用结算稳定时的读数" if actual_value_hint else 数字库概要(actual_decision)
    print(f"  📋 实际价值: {actual_value:,}（{actual_source}）")

    region3 = (left + PROFIT_LEFT, top + PROFIT_TOP, PROFIT_WIDTH, PROFIT_HEIGHT)
    profit, _, profit_decision = 读金额并核对(region3, "收益")
    if min(final_price, actual_value) > 0 and abs(actual_value - final_price - profit) > 1:
        print("  🔁 结算金额与收益不一致 → 用 OCR 重新核对三个金额")
        checked_price, _, _ = 读金额并核对(region1, "最终成交价", retries=1, force_ocr=True)
        checked_value, _, _ = 读金额并核对(region2, "实际价值", retries=1, force_ocr=True)
        checked_profit, _, _ = 读金额并核对(region3, "收益", retries=1, force_ocr=True)
        final_price = checked_price if checked_price > 0 else final_price
        actual_value = checked_value if checked_value > 0 else actual_value
        if checked_profit or actual_value == final_price:
            profit = checked_profit
    print(f"  📋 收益: {profit:+,}（{数字库概要(profit_decision)}）")

    # 先给"收益"做常识校验：赢家的收益 = 实际价值 - 成交价，绝对值不可能超过
    # 两者里大的那个。实测有人机器上收益读成 -230,720,000（真值只有几十万），旧逻辑拿它把
    # 成交价改成 2.3 亿、还按 10% 记出 +2,307 万的假收入。这里一律按 实际-成交价 拉回来。
    if profit != 0 and not 收益正常吗(actual_value, final_price, profit):
        if actual_value > 0 and final_price > 0:
            print(
                f"  ⚠️ 收益读数不可信（读到 {profit:+,}；实际价值 {actual_value:,} / "
                f"成交价 {final_price:,}）→ 按 实际-成交价 重算为 {actual_value - final_price:+,}"
            )
            profit = actual_value - final_price
        else:
            print(f"  ⚠️ 收益读数不可信（读到 {profit:+,}）且两个金额不齐 → 收益按 0 记")
            profit = 0
        if "收益" not in failed:
            failed.append("收益")

    if final_price > 0 and actual_value > 0 and profit != 0:
        computed = actual_value - profit
        # 先判断"实际价值"自己可不可信：收益的绝对值远大于实际价值时，
        # 多半是实际价值被读残了（老写法遇到撇号会截成三位数）→ 绝不能拿它去改成交价（越改越错）。
        if not 实际价值正常吗(actual_value, profit, final_price):
            print(
                f"  ⚠️ 实际价值 OCR 可疑（读到 {actual_value:,}，但收益 {profit:+,}）→ "
                f"保留直接读到的成交价 {final_price:,}，不改；记录里会标注"
            )
            if "实际价值" not in failed:
                failed.append("实际价值")
        elif computed > 0 and abs(computed - final_price) > max(2000, int(computed * 0.01)):
            print(
                f"  ⚠️ 成交价 OCR 可疑（读到 {final_price:,}，但 实际价值-收益 = {computed:,}），按后者修正"
            )
            final_price = computed

    if final_price <= 0 and actual_value <= 0 and running:
        print("  ⚠️ 结算数据全为 0，等待 2 秒后重读一次（动画可能还没滚完）")
        if 歇一下(2):
            price2, _, _ = 读金额并核对(region1, "最终成交价")
            value2, _, _ = 读金额并核对(region2, "实际价值")
            if price2 > 0 or value2 > 0:
                final_price = price2 or final_price
                actual_value = value2 or actual_value
                if final_price > 0 and actual_value > 0:
                    profit = actual_value - final_price
                print(
                    f"  🔁 重读结果：成交价 {final_price:,} / 实际价值 {actual_value:,}"
                    f" / 收益 {profit:+,}"
                )
                if final_price > 0:
                    failed.remove("最终成交价")
                if actual_value > 0:
                    failed.remove("实际价值")

    if failed:
        print(
            f"  ⚠️ 以下数据重试后仍识别失败: {', '.join(failed)}（会在记录里标注，不再静默写成 0）"
        )
    return player_name, final_price, actual_value, profit, failed


def 关卖出提示():
    if SELL_CLOSE_TIP_ENABLED != 1:
        return
    if not running:
        return
    print(
        f"🔍 等待 {SELL_CLOSE_TIP_WAIT} 秒后轮询一键出售成功提示"
        f"（最多等 {SELL_CLOSE_TIP_DETECT_TIMEOUT} 秒）..."
    )
    if not 歇一下(SELL_CLOSE_TIP_WAIT):
        return
    if not 多尺度看图有没有(
        SELL_CLOSE_TIP_IMAGE, timeout=SELL_CLOSE_TIP_DETECT_TIMEOUT
    ):
        print("ℹ️ 模板未命中，改用底部文字『点击空白区域关闭』复核一次")
        if not 识别找字并点(
            ("点击空白区域关闭", "点击空白处关闭"),
            卖出提示区域(),
            "关闭出售奖励提示（OCR兜底）",
            retry=2,
        ):
            print("ℹ️ 等待窗口内未检测到一键出售成功提示，可能不需要关闭或已自动关闭")
            return
        if not 歇一下(0.8):
            return
        if not 多尺度看图有没有(SELL_CLOSE_TIP_IMAGE, timeout=0.6):
            print("✅ OCR 兜底已关闭出售成功提示")
            return
    for _attempt in range(3):
        print(f"✅ 检测到『获得物品 / 点击空白区域关闭』提示（第 {_attempt + 1}/3 次）")
        多尺度找图并点(SELL_CLOSE_TIP_IMAGE, "关闭出售提示", timeout=3)
        if not 歇一下(0.8):
            return
        if not 多尺度看图有没有(SELL_CLOSE_TIP_IMAGE, timeout=0.6):
            print("✅ 出售成功提示已关闭")
            return
    if 识别找字并点(
        ("点击空白区域关闭", "点击空白处关闭"),
        卖出提示区域(),
        "关闭出售奖励提示（最终 OCR 兜底）",
        retry=2,
    ):
        if 歇一下(0.8) and not 多尺度看图有没有(
            SELL_CLOSE_TIP_IMAGE, timeout=0.6
        ):
            print("✅ 最终 OCR 兜底已关闭出售成功提示")
            return
    print("⚠️ 出售成功提示点按后仍未消失，交给主循环的画面恢复流程继续处理")


def 标记已结算(step, t0, extra=None):
    try:
        ms = int((time.time() - t0) * 1000)
        记回合事件(
            "settle_step",
            human=f"⏱️ 结算流程[{step}] 用时 {ms / 1000:.1f}s",
            step=step,
            ms=ms,
            extra=extra,
        )
        if step in ("wait_next_round", "wait_next_round_timeout"):
            _limit = SETTLE_SLOW_WARN_MS * 2
        elif step in ("total", "exit_flow_B"):
            _limit = SETTLE_SLOW_WARN_MS * 3
        else:
            _limit = SETTLE_SLOW_WARN_MS
        if ms >= _limit:
            记报错(
                "settle_slow",
                f"结算流程[{step}] 用了 {ms / 1000:.1f} 秒（超过 "
                f"{_limit / 1000:.0f} 秒），可能卡在结算界面",
                level="警告",
                extra={"step": step, "ms": ms, "extra": extra},
            )
    except Exception:
        pass
    return time.time()


def 等结算稳定(timeout=12, interval=0.4):
    """读一次实际价值就算数（大肥鱼：不再"连读两遍一致"，那要读 3 次太磨叽）。

    读不到（0）才重试；最多重试到自己放弃为止。
    """
    deadline = time.time() + timeout
    last = None
    while time.time() < deadline:
        if not running:
            return None
        value = 只读实际价值()
        if value:
            print(f"✅ 实际价值：{value:,}（单次读取）")
            return value
        last = value or last
        if not 歇一下(interval):
            return None
    print(f"⚠️ 实际价值 {timeout} 秒内没读到，用最后一次读数 {last}")
    return last


def 等回大厅(timeout=None, context="结算后"):
    """After an auction-ending action, wait only for the auction hall.

    Do not invoke the generic screen-recovery path from here. During this
    bounded wait the watchdog is told this is an expected wait; afterwards its
    normal progress/restart timing is restored. If the hall does not appear,
    return to the main loop so it can inspect the current screen with the
    normal state router.
    """
    try:
        wait_seconds = float(SETTLEMENT_HALL_WAIT if timeout is None else timeout)
    except Exception:
        wait_seconds = 20.0
    deadline = time.time() + max(0.0, wait_seconds)
    print(f"⏳ 等待{context}回到拍卖大厅（最长 {wait_seconds:.0f} 秒）...")
    _SETTLEMENT_HALL_WAIT[0] = True
    碰一下进度(f"{context}等待拍卖大厅")
    try:
        while time.time() < deadline:
            if not running:
                return False
            try:
                if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
                    return True
            except Exception:
                pass
            try:
                守住重连("等结算后回到大厅")
            except Exception:
                pass
            碰一下进度(f"{context}等待拍卖大厅")
            if not 歇一下(SETTLEMENT_HALL_POLL_INTERVAL):
                return False
        return False
    finally:
        _SETTLEMENT_HALL_WAIT[0] = False
        碰一下进度(f"{context}大厅等待结束")


def 走结算():
    global _LAST_TARGET_HITS
    t_all = time.time()
    _won_this_auction = False
    _LAST_TARGET_HITS = []
    print("✅ 进入结算流程...")
    if not running:
        return
    if not 歇一下(0.5):
        return

    for attempt in range(2):
        if not 画面有吗("step_skip.png", timeout=1):
            if attempt == 0:
                print("ℹ️ 没找到跳过动画按钮（可能动画已结束或已在结算界面）")
            break
        找到就点("step_skip.png", "跳过动画", timeout=2)
        if not 歇一下(0.6):
            return
        if not 画面有吗("step_skip.png", timeout=0.25):
            break
        print(f"⚠️ 跳过动画按钮还在，再点一次（第 {attempt + 2} 次）")
    t = 标记已结算("skip_anim", t_all)

    stable_actual_value = 等结算稳定()
    t = 标记已结算("wait_stable", t)

    存回合截图("settlement", 回合截图区域(), "结算界面（出现一键出售=我拍到）")

    if 画面有吗("step_sell.png", timeout=2):
        print("✅ 检测到一键出售按钮，自己拍到，执行正常结算流程")
        actual_value_pre = stable_actual_value or 只读实际价值()
        存高价值截图(actual_value_pre)

        max_value = 0
        for r in current_rounds:
            if r["value"] and r["value"] != "识别失败":
                try:
                    v = int(r["value"].replace(",", "").replace("，", ""))
                    if v > max_value:
                        max_value = v
                except Exception:
                    pass

        print(f"📊 本场历史最高估价: {max_value:,}")

        skip_red_dot = False
        _hits = []
        # ---- 判据：结算页右上角【当前估价】 vs 用户填的阈值 ----
        #   <  阈值 → 勾红圈，全卖
        #   >= 阈值 → 不勾红圈（红货留着），回大厅后进仓库：保留勾选的，其余出售
        _settle_val = 0
        try:
            _sv_raw = 快读当前估价()
            if _sv_raw:
                _settle_val = int(_sv_raw)
        except Exception:
            _settle_val = 0
        if _settle_val <= 0:
            _settle_val = int(actual_value_pre or 0)
            print(f"⚠️ 结算页当前估价没读到 → 用实际价值 {_settle_val:,} 当判据")
        else:
            print(f"📊 结算页当前估价：{_settle_val:,}")
        _thr = _热读参数("CLEAN_SELL_ALL_BELOW", 0)
        if _thr > 0 and 0 < _settle_val < _thr:
            print(f"🔴 当前估价 {_settle_val:,} < {_thr:,} → 勾红圈，全部出售")
            skip_red_dot = False
            _CLEAN_AFTER_AUCTION[0] = False
        else:
            if _thr > 0:
                _skip_sell_now = _热读参数("CLEAN_SKIP_SELL", 0) == 1
                if _skip_sell_now:
                    print(f"⏭️ 当前估价 {_settle_val:,} ≥ {_thr:,} → 不勾红圈；"
                          f"🛑「不进入仓库出售藏品」已打开 → 回大厅后**不进仓库清仓**")
                else:
                    print(f"⏭️ 当前估价 {_settle_val:,} ≥ {_thr:,} → 不勾红圈（红货留着），"
                          f"回大厅后进仓库清仓")
                skip_red_dot = True
                _CLEAN_AFTER_AUCTION[0] = True
            else:
                print("🔴 没有设置阈值（CLEAN_SELL_ALL_BELOW=0）→ 按老做法勾红圈全部出售")
                skip_red_dot = False
                _CLEAN_AFTER_AUCTION[0] = False

        if skip_red_dot:
            print("⏭️ 不勾红圈 → 红色留在仓里不卖，直接一键出售")
        else:
            print(f"🔴 未达到跳过阈值，点击红点")
            点红点()
            if not 歇一下(1):
                return

        if not 找到就点("step_sell.png", "一键出售", timeout=3):
            print("⚠️ 第一次没点到一键出售，1 秒后重试")
            if not 歇一下(1):
                return
            找到就点("step_sell.png", "一键出售", timeout=3)
        if not 歇一下(1.0):
            return

        关卖出提示()
        t = 标记已结算("sell", t)

        player_name, final_price, actual_value, profit, failed = 识别结算数据(actual_value_pre)
        t = 标记已结算("recognize", t)
        存回合截图("settlement_data", 回合截图区域(), "结算数据（成交价/实际价值/收益）")
        关拍卖(
            "normal",
            player_name,
            final_price,
            actual_value,
            profit,
            note=("识别失败: " + "/".join(failed)) if failed else "",
            sell_clicked=True,
        )
        _won_this_auction = True
    else:
        print("⚠️ 未检测到一键出售按钮，判定为他人拍走")
        if not 歇一下(0.8):
            return
        player_name, final_price, actual_value, profit, failed = 识别结算数据(stable_actual_value)
        t = 标记已结算("recognize_others", t)
        try:
            存高价值截图(actual_value, mine=False)
        except Exception:
            pass
        note = "他人拍走"
        if failed:
            note += " / 识别失败: " + "/".join(failed)
        关拍卖(
            "exit",
            player_name=player_name,
            final_price=final_price,
            actual_value=actual_value,
            profit=profit,
            note=note,
        )

    if 查资产并停():
        print("⏹️ 资金不足，脚本停止运行。游戏停留在结算界面，请手动处理。")
        return

    exit_clicked = 限时找图并点("step_exit.png", "退出确认", timeout=2)
    hall_wait_started = time.time()
    back_to_hall = 等回大厅()
    t = 标记已结算("exit_to_hall", t, extra={
        "pre_wait_ms": int((hall_wait_started - t) * 1000),
        "hall_wait_ms": int((time.time() - hall_wait_started) * 1000),
        "exit_clicked": bool(exit_clicked),
        "hall_detected": bool(back_to_hall),
    })
    标记已结算("total", t_all)
    if back_to_hall:
        print("🚀 结算流程结束，已确认回到大厅！")
        # ---- 仓库清理（保留藏品）：拍到结算完成后才做 ----
        try:
            if _热读参数("CLEAN_SKIP_SELL", 0) == 1 and _CLEAN_AFTER_AUCTION[0]:
                print("🛑 已打开「不进入仓库出售藏品」→ 这次不清仓（红货留在仓里）")
                _CLEAN_AFTER_AUCTION[0] = False
            if _won_this_auction and _CLEAN_AFTER_AUCTION[0]:
                print("🧹 清仓：本局结算不勾红圈 → 回大厅进仓库，保留勾选的、其余出售")
                _CLEAN_AFTER_AUCTION[0] = False
                清仓_扫描并出计划(dry_run=False)
        except Exception as _e:
            print(f"⚠️ 清仓流程出错（不影响挂机）: {_e}")
    else:
        print(
            f"⚠️ 结算后 {SETTLEMENT_HALL_WAIT} 秒内未确认拍卖大厅；"
            f"不主动进入画面恢复，交回主循环按当前画面重新识别"
        )


def 查并报警(value_int):
    global running
    if ALARM_ENABLED == 1 and value_int >= ALARM_THRESHOLD:
        print(f"\n🚨🚨🚨 触发警报！当前估价 {value_int:,} 大于等于 {ALARM_THRESHOLD:,}！ 🚨🚨🚨")
        记回合事件(
            "alarm",
            human=f"🚨 触发警报：估价 {value_int:,} ≥ {ALARM_THRESHOLD:,}",
            value=value_int,
            threshold=ALARM_THRESHOLD,
        )
        if not audio_available:
            print("⚠️ 音频系统不可用，跳过响铃。")
        else:
            print(f"🔊 正在循环播放 {ALARM_FILE} {ALARM_LOOP} 次...")
            print("🔕 按 = 键可以停止警报。")
            异步报警()
        if ALARM_PAUSE_SCRIPT == 1:
            running = False
            print("⏸️ 脚本已因警报暂停，按 F11 可继续运行。")
        else:
            print("▶️ 警报处理完毕，脚本继续执行。")
        return True
    return False


def 清估价识别记录():
    for key in ("value_raw", "value_alt", "value_template", "value_source"):
        RUNLOG_OCR.pop(key, None)


def 高置信数字(digits, decision, min_score, min_margin):
    return bool(
        digits and decision is not None and decision.ok
        and decision.min_score >= min_score and decision.min_margin >= min_margin
    )


def 短复核估价(round_num):
    """仪器等待结束后，两帧模板一致才接受，其他情况交给完整读取。"""
    global LAST_ESTIMATE
    region = 估价区域()
    if not region:
        return ""
    readings = []
    for index in range(2):
        if index and not 歇一下(max(ESTIMATE_CONFIRM_GAP, 0.45 if round_num == 3 else 0)):
            return ""
        try:
            value, decision = 试估价模板(np.array(抓一帧(region=region)))
        except Exception:
            return ""
        if not 高置信数字(
            value, decision, ESTIMATE_DOUBLE_TEMPLATE_SCORE, ESTIMATE_DOUBLE_TEMPLATE_MARGIN
        ):
            return ""
        readings.append(value)
    value = readings[0]
    previous = int(LAST_ESTIMATE or 0)
    if value != readings[1] or (round_num == 3 and value == previous):
        return ""
    if previous and value < previous * (1 - ESTIMATE_MAX_DROP_RATIO):
        return ""
    LAST_ESTIMATE = value
    RUNLOG_OCR.update(value_raw="", value_alt="", value_template=数字库概要(decision),
                      value_source="template-confirmed")
    print(f"💰 第{round_num}回合：两帧模板确认估价 {value:,}")
    return str(value)


def 快读当前估价(*, record=False):
    """紧迫局专用：抓一帧、读一次，不复读确认、不重试。

    完整读取那条路要 4 秒（二值化 + 中英双模型 + 读两遍确认 + 只涨不跌），
    20 秒的紧迫局等不起。这条路约 0.5~1 秒，但读的仍是屏幕上当前的数字，
    不是几分钟前的旧估价。读不到返回空串，由调用方兜底。
    """
    try:
        region = 估价区域()
    except Exception:
        return ""
    if region is None:
        return ""
    try:
        img = np.array(抓一帧(region=region))
    except Exception:
        return ""
    if img is None or getattr(img, "size", 0) == 0:
        return ""
    try:
        cn_digits, en_digits, cn_raw, en_raw = 读估价数字(img)
    except Exception:
        return ""
    for digits, raw, source in ((cn_digits, cn_raw, "ocr-cn"), (en_digits, en_raw, "ocr-alt")):
        if not digits:
            continue
        try:
            value = int(digits)
        except Exception:
            continue
        if value > 1000:
            if record:
                RUNLOG_OCR.update(value_raw=(raw or "").strip(),
                                  value_alt=(en_raw or "").strip(),
                                  value_template="", value_source=source)
            return str(value)
    return ""


def 读价否则放弃(round_num):
    # 撞果盘命中的福利多多局不依赖估价：
    #   哪怕估价栏是 0、空白或 OCR 暂时读不到，也直接按固定价 520 占位，
    #   绝不因为估价识别失败执行流程B退出。
    if _GP_BONUS_MODE[0]:
        msg = (
            f"💠 [撞果盘] 第{round_num}回合福利多多局：跳过估价识别，"
            f"按固定价 {int(BONUS_KEEP_BID):,} 占位"
        )
        print(msg)
        try:
            写日志(msg)
            记回合事件(
                "guo_pan_estimate_placeholder",
                human=msg,
                round=round_num,
                estimate_placeholder=0,
                bid=int(BONUS_KEEP_BID),
            )
        except Exception:
            pass
        return "0"

    value_str = ""
    # 估价本身已经做了「二值化 + 中英双模型 + 读两遍确认 + 只涨不跌」，
    #   这里只在外层多兜几次，间隔短一些，避免整回合耗在重读上。
    for _ in range(3):
        if not running:
            return None
        value_str = 读当前估价()
        try:
            if value_str and int(value_str) > 1000:
                return value_str
        except Exception:
            pass
        print(f"⚠️ 第{round_num}回合估价异常({value_str})，等 UI 刷新...")
        if not 歇一下(0.8):
            return None
    记回合事件(
        "round_fail",
        human=f"❌ 第{round_num}回合估价识别异常（{value_str}），退出本局",
        round=round_num,
        value=value_str,
        ocr=dict(RUNLOG_OCR),
    )
    存回合截图(f"round{round_num}_bad_estimate", 回合截图区域(), "估价识别失败")
    记报错(
        "estimate_fail",
        f"第{round_num}回合估价识别失败（读到 '{value_str}'），退出本局",
        extra={"round": round_num, "value": value_str, "ocr": dict(RUNLOG_OCR)},
    )
    关拍卖("exit", note="估价异常，流程B退出")
    走流程B()
    return None


def 这回合用几号仪器(round_num):
    if _GP_BONUS_MODE[0]:
        return 0  # 撞果盘打到福利多多局：一律不用仪器
    return int(
        {
            1: TOOL_R1,
            2: TOOL_R2,
            3: TOOL_R3,
            4: TOOL_R4,
            5: TOOL_R5,
        }.get(round_num, 0)
        or 0
    )


def 仪器要确认生效吗(round_num):
    """这台仪器用不用等「估价变了」才算成功。"""
    try:
        inst = int(这回合用几号仪器(round_num) or 0)
    except Exception:
        inst = 0
    if inst <= 0:
        return False
    try:
        wanted = set()
        for part in str(INSTRUMENT_EFFECT_REQUIRED or "").replace("，", ",").split(","):
            part = part.strip()
            if part.isdigit():
                wanted.add(int(part))
        if not wanted:
            return True
        return inst in wanted
    except Exception:
        return True


# ---------- 仓库视觉（认整仓里的具体藏品）----------
# 纯计算模块：输入一张 590×1449 的整仓图，吐出「每个格子大概是什么、值多少钱」。
# 默认关闭；打开后默认是「影子模式」——只算、只打印、只记日志，不改出价。
WAREHOUSE_VISION_ENABLED = 0
WAREHOUSE_VISION_SHADOW_MODE = 1
WAREHOUSE_VISION_P75_BID_ENABLED = 0
WAREHOUSE_VISION_RISK_ENABLED = 0
WAREHOUSE_VISION_RISK_MAX_OVER_OCR = 1.00
WAREHOUSE_VISION_RISK_P75_WEIGHT = 0.70
WAREHOUSE_VISION_ROUND1_P75_WEIGHT = 0.15
WAREHOUSE_VISION_COVERAGE_MIN = 0.50
WAREHOUSE_VISION_COVERAGE_FULL = 0.85
WAREHOUSE_VISION_LOW_WEIGHT_KEEP = 0.20
WAREHOUSE_VISION_RISK_FLOOR_BY_ROUND = (0.90, 1.00, 0.95, 0.90, 0.85, 0.80)
WAREHOUSE_VISION_FLOOR_COVERAGE_PENALTY_ENABLED = 1
WAREHOUSE_VISION_FLOOR_COVERAGE_START_ROUND = 3
WAREHOUSE_VISION_FLOOR_COVERAGE_MIN = 0.50
WAREHOUSE_VISION_FLOOR_COVERAGE_FULL = 0.70
WAREHOUSE_VISION_FLOOR_LOW_COVERAGE_KEEP = 0.85
WAREHOUSE_VISION_RISK_BID_CAP_RATIO = 1.00
WAREHOUSE_VISION_RISK_BID_CAP_GAME_MULT = 1.35
# 抓整仓 5~10 秒 + 分析 1 秒，剩不到这个秒数就别抓了 —— 保出价要紧。
WAREHOUSE_VISION_MIN_REMAINING = 22.0
WAREHOUSE_VISION_MIN_BLOCKS = 4
# 整仓图必须至少抓到这个覆盖率，否则格子对不上，宁可不认。
WAREHOUSE_VISION_MIN_CAPTURE_COVERAGE = 0.90
# 每次识别顺手存一张整仓图（事后能对账），以及最多留多少张。
WAREHOUSE_VISION_SAVE_IMAGE = 0
WAREHOUSE_VISION_KEEP_IMAGES = 300

_WAREHOUSE_VISION_ENGINE = [None]
_WAREHOUSE_VISION_ROUNDS = {}
_WAREHOUSE_VISION_IMPORT_ERROR = [""]


def 仓库视觉重置():
    """新的一局：清掉上一局的整仓模型和本局各回合的扫描结果。"""
    _WAREHOUSE_VISION_ROUNDS.clear()
    try:
        if _WAREHOUSE_VISION_ENGINE[0] is not None:
            _WAREHOUSE_VISION_ENGINE[0].reset_auction()
    except Exception:
        pass


def _静音加载引擎(loader):
    """临时把 C 层 stderr 指到空设备，屏蔽 libpng 的 iCCP 警告刷屏。"""
    try:
        import os as _os
        _saved = _os.dup(2)
        _devnull = _os.open(_os.devnull, _os.O_WRONLY)
        _os.dup2(_devnull, 2)
        try:
            return loader()
        finally:
            _os.dup2(_saved, 2)
            _os.close(_saved)
            _os.close(_devnull)
    except Exception:
        return loader()


def 取仓库视觉(force=False):
    # force=True 给「手动扫一次」用：那个开关只管挂机时要不要自动扫，
    # 人亲手点了按钮就不该被它挡住。
    if not force and not WAREHOUSE_VISION_ENABLED:
        return None
    if _WAREHOUSE_VISION_ENGINE[0] is None and not _WAREHOUSE_VISION_IMPORT_ERROR[0]:
        try:
            from warehouse_vision import WarehouseVision

            _WAREHOUSE_VISION_ENGINE[0] = _静音加载引擎(WarehouseVision)
            print("🧠 仓库视觉核心已加载（230 个藏品模板 + 物品价目）")
            try:
                _pp = _WAREHOUSE_VISION_ENGINE[0].pearl_priors
                print(
                    "🧠 真珠场经验先验：%s 局 / %s 件（%s）"
                    % (
                        _pp.get("games", 0),
                        _pp.get("item_instances", 0),
                        _pp.get("generated_at", "未生成"),
                    )
                )
            except Exception:
                pass
        except Exception as exc:
            _WAREHOUSE_VISION_IMPORT_ERROR[0] = str(exc)
            print(f"⚠️ 仓库视觉核心加载失败，继续用原策略: {exc}")
    return _WAREHOUSE_VISION_ENGINE[0]


def 仓库视觉P75权重(round_num):
    """认出得越多，P75 的权重才越大（认漏了就别太信它）。"""
    result = _WAREHOUSE_VISION_ROUNDS.get(int(round_num or 0)) or {}
    base_weight = (
        float(WAREHOUSE_VISION_ROUND1_P75_WEIGHT)
        if int(round_num or 0) == 1
        else float(WAREHOUSE_VISION_RISK_P75_WEIGHT)
    )
    try:
        blocks = max(0, int(result.get("block_count") or 0))
        named = max(0, int(result.get("named_count") or 0))
    except Exception:
        blocks, named = 0, 0
    if blocks <= 0:
        return 0.0, 0, 0, base_weight, base_weight
    coverage = min(1.0, named / float(blocks))
    lo = max(0.0, min(1.0, float(WAREHOUSE_VISION_COVERAGE_MIN)))
    hi = max(lo + 0.01, min(1.0, float(WAREHOUSE_VISION_COVERAGE_FULL)))
    confidence = max(0.0, min(1.0, (coverage - lo) / (hi - lo)))
    keep_low = max(0.0, min(1.0, float(WAREHOUSE_VISION_LOW_WEIGHT_KEEP)))
    factor = keep_low + (1.0 - keep_low) * confidence
    return coverage, named, blocks, base_weight, base_weight * factor


def 仓库视觉策略估值(value, round_num, force=False):
    """把「整仓视觉估的均值/P75」和 OCR 估价加权，得出更保守的一个值。"""
    try:
        base = int(value or 0)
        result = _WAREHOUSE_VISION_ROUNDS.get(int(round_num or 0))
        if (
            (not force and not WAREHOUSE_VISION_RISK_ENABLED)
            or base <= 0
            or not result
            or not result.get("checksum_ok")
            or int(result.get("block_count") or 0) < WAREHOUSE_VISION_MIN_BLOCKS
        ):
            return base
        if abs(int(result.get("game_estimate") or 0) - base) > int(
            result.get("checksum_tolerance") or 0
        ):
            return base
        p75 = int(result.get("p75_total") or 0)
        mean = int(result.get("mean_total") or 0)
        _, _, _, _, weight = 仓库视觉P75权重(round_num)
        target = int(mean * (1.0 - weight) + p75 * weight)
        if target <= base:
            return base
        cap = int(base * (1.0 + WAREHOUSE_VISION_RISK_MAX_OVER_OCR))
        return max(base, min(target, cap))
    except Exception:
        return int(value or 0)


def 仓库视觉出价底线(value, round_num, force=False):
    """视觉均值给出一个「值得抢」的底价；0 = 不参与。"""
    try:
        target = int(value or 0)
        result = _WAREHOUSE_VISION_ROUNDS.get(int(round_num or 0))
        if (
            (not force and not WAREHOUSE_VISION_RISK_ENABLED)
            or target <= 0
            or not result
            or not result.get("checksum_ok")
            or int(result.get("block_count") or 0) < WAREHOUSE_VISION_MIN_BLOCKS
        ):
            return 0
        observed = int(result.get("game_estimate") or 0)
        if observed <= 0 or target < observed * 1.10:
            return 0
        mean = int(result.get("mean_total") or 0)
        if mean <= observed:
            return 0
        factors = WAREHOUSE_VISION_RISK_FLOOR_BY_ROUND
        factor = float(factors[min(max(int(round_num) - 1, 0), len(factors) - 1)])
        if int(WAREHOUSE_VISION_FLOOR_COVERAGE_PENALTY_ENABLED or 0) == 1 and int(
            round_num or 0
        ) >= int(WAREHOUSE_VISION_FLOOR_COVERAGE_START_ROUND or 3):
            blocks = max(0, int(result.get("block_count") or 0))
            named = max(0, int(result.get("named_count") or 0))
            coverage = min(1.0, named / float(blocks)) if blocks else 0.0
            lo = max(0.0, min(1.0, float(WAREHOUSE_VISION_FLOOR_COVERAGE_MIN)))
            hi = max(lo + 0.01, min(1.0, float(WAREHOUSE_VISION_FLOOR_COVERAGE_FULL)))
            confidence = max(0.0, min(1.0, (coverage - lo) / (hi - lo)))
            keep = max(0.0, min(1.0, float(WAREHOUSE_VISION_FLOOR_LOW_COVERAGE_KEEP)))
            factor *= keep + (1.0 - keep) * confidence
        floor = min(target, int(mean * factor))
        return max(0, 向下贴整(floor))
    except Exception:
        return 0


def 仓库视觉出价上限(value, round_num, force=False):
    """视觉 P75 给出一个天花板；0 = 不参与。"""
    try:
        target = int(value or 0)
        result = _WAREHOUSE_VISION_ROUNDS.get(int(round_num or 0))
        if (
            (not force and not WAREHOUSE_VISION_RISK_ENABLED)
            or target <= 0
            or not result
            or not result.get("checksum_ok")
            or int(result.get("block_count") or 0) < WAREHOUSE_VISION_MIN_BLOCKS
        ):
            return 0
        observed = int(result.get("game_estimate") or 0)
        if observed <= 0 or target < observed * 1.10:
            return 0
        limit = min(
            int(target * float(WAREHOUSE_VISION_RISK_BID_CAP_RATIO)),
            int(observed * float(WAREHOUSE_VISION_RISK_BID_CAP_GAME_MULT)),
        )
        return max(0, 向下贴整(limit))
    except Exception:
        return 0


def 存仓库视觉图(canvas, round_num, force=False):
    """把这次视觉用的整仓图存下来 —— 事后翻出来就能对账「它认得准不准」。

    只有一个目录、按天分文件夹，最老的自动清掉，不会把盘塞满。
    force=True 给手动扫仓用：人亲手点的，图一定要留，不然面板上没原图可对。
    """
    try:
        if (not force and int(WAREHOUSE_VISION_SAVE_IMAGE or 0) != 1) or canvas is None:
            return {}
        now = datetime.now()
        folder = os.path.join(RUNLOG_DIR, "仓库视觉", now.strftime("%Y-%m-%d"))
        os.makedirs(folder, exist_ok=True)
        name = "r%s_%s.jpg" % (
            int(round_num or 0),
            now.strftime("%H%M%S_%f")[:-3],
        )
        path = os.path.join(folder, name)
        canvas.convert("RGB").save(path, "JPEG", quality=88)
        # 只留最近这些张，太老的删掉
        try:
            keep = int(WAREHOUSE_VISION_KEEP_IMAGES or 300)
            files = sorted(
                os.path.join(folder, f) for f in os.listdir(folder)
                if f.lower().endswith(".jpg")
            )
            for old in files[:-keep] if keep > 0 else []:
                try:
                    os.remove(old)
                except Exception:
                    pass
        except Exception:
            pass
        print(f"🖼️ 仓库视觉图已存：{path}")
        return {"image_path": os.path.relpath(path, SCRIPT_DIR)}
    except Exception as exc:
        print(f"⚠️ 仓库视觉图保存失败（不影响识别）: {exc}")
        return {}


_PREV_EST_FOR_VISION = [0]      # 上一回合的估价（判断"是否大幅上涨"用）
VISION_SURGE_STEP = 1100000     # 本回合估价 - 上回合估价 ≥ 这个数 → 做一次仓库视觉识别


def 该做仓库视觉识别(value_int):
    """本回合估价相对上回合涨了 ≥110 万才识别（只算涨，不算跌）。"""
    try:
        prev = int(_PREV_EST_FOR_VISION[0] or 0)
        cur = int(value_int or 0)
    except Exception:
        return False
    if prev <= 0 or cur <= 0:
        return False
    return (cur - prev) >= int(VISION_SURGE_STEP)


def 仓库视觉扫描(round_num, game_estimate, urgent=False, force=False, canvas=None):
    """抓一次整仓图，认出每个格子大概是什么，算出价值分布。

    force=True：不受「仓库视觉总开关」限制，也不吃本回合缓存（第1回合按 >110万 触发时用）。
    """
    if (not force and not WAREHOUSE_VISION_ENABLED) or _GP_BONUS_MODE[0]:
        return None
    rnd = int(round_num or 0)
    if not rnd or (not force and rnd in _WAREHOUSE_VISION_ROUNDS):
        return _WAREHOUSE_VISION_ROUNDS.get(rnd)
    if urgent:
        print(f"⚡ 紧迫危机：第{rnd}回合跳过仓库视觉，优先出价")
        return None
    remaining = 估剩余时间()
    if remaining is None:
        # 常规局的 _BID_WINDOW_STATE 里不存秒数（只有紧迫局才存），
        # 抓整仓要 5~10 秒，别撞上截止 —— 花 0.2 秒读一眼倒计时。
        try:
            _secs = 读出价倒计时()
            if _secs is not None:
                remaining = float(_secs)
        except Exception:
            remaining = None
    if remaining is not None and remaining < float(WAREHOUSE_VISION_MIN_REMAINING):
        print(
            f"⏱️ 第{rnd}回合只剩 {remaining:.1f}s（门槛 {WAREHOUSE_VISION_MIN_REMAINING:.0f}s）"
            f"，跳过仓库视觉"
        )
        return None
    engine = 取仓库视觉()
    if engine is None:
        print(f"⚠️ 第{rnd}回合仓库视觉：识别引擎不可用 → 这次跳过（不影响出价）")
        return None
    started = time.time()
    if canvas is None:
        canvas = 抓整个仓()
    if canvas is None:
        # 抓整仓偶尔会因为窗口状态/一帧黑图失败 —— 只要时间还够就重试一次
        print(f"⚠️ 第{rnd}回合仓库视觉：抓整仓失败 → 0.4 秒后重试一次")
        try:
            if not 歇一下(0.4):
                return None
        except Exception:
            pass
        canvas = 抓整个仓()
    if canvas is None:
        print(f"⚠️ 第{rnd}回合仓库视觉：重试后仍抓不到整仓 → 这次跳过（结算有价格兜底）")
        return None
    # 整仓得抓全：少一屏格子就整体错位，认出来的东西全不可信。
    _cov = 0.0
    try:
        _cov = canvas.height * 100.0 / float(GRID_FULL_PX)
        if _cov < float(WAREHOUSE_VISION_MIN_CAPTURE_COVERAGE) * 100.0:
            print(
                f"⚠️ 整仓图不完整（{canvas.width}x{canvas.height}，覆盖 {_cov:.0f}%），"
                f"这一回合跳过仓库视觉，继续用游戏估价"
            )
            return None
    except Exception:
        pass
    try:
        if 像卖掉了的面板(canvas):
            print("⚠️ 这一仓看着是结算界面（货上盖着勾）→ 跳过仓库视觉")
            return None
    except Exception:
        pass
    capture_ms = int((time.time() - started) * 1000)
    analysis_started = time.time()
    try:
        result = engine.analyze(
            canvas if canvas.mode == "RGB" else canvas.convert("RGB"),
            rnd,
            int(game_estimate or 0),
        )
    except Exception as exc:
        print(f"⚠️ 第{rnd}回合仓库视觉分析失败（继续原策略）: {exc}")
        return None
    try:
        analysis_ms = int((time.time() - analysis_started) * 1000)
        result["capture_ms"] = capture_ms
        result["analysis_ms"] = analysis_ms
        result["total_ms"] = int((time.time() - started) * 1000)
        result["shadow_mode"] = bool(WAREHOUSE_VISION_SHADOW_MODE)
        result["shadow_strategy_value"] = 仓库视觉策略估值(
            int(game_estimate or 0), rnd, force=True
        )
        # 这两个值的 target 是「假设要出的价」，不是游戏估价本身。
        # 以前两个都传 game_estimate，函数内 observed 也是 game_estimate，
        # target < observed*1.10 恒成立 → 两项永远是 0，记了等于没记。
        result["shadow_bid_floor"] = 仓库视觉出价底线(
            int(result.get("mean_total") or 0), rnd, force=True
        )
        result["shadow_bid_cap"] = 仓库视觉出价上限(
            int(result.get("p75_total") or 0), rnd, force=True
        )
        result["shadow_bid_active"] = bool(WAREHOUSE_VISION_RISK_ENABLED)
        calibration = dict(result.get("confidence_calibration") or {})
        _image_meta = 存仓库视觉图(canvas, rnd)
        result["image_path"] = _image_meta.get("image_path") or ""
        _WAREHOUSE_VISION_ROUNDS[rnd] = result
        print(
            f"🧠 第{rnd}回合仓库视觉{'[影子]' if result['shadow_mode'] else ''}: "
            f"最低 {result['min_total']:,}｜均值 {result['mean_total']:,}｜"
            f"P75 {result['p75_total']:,}｜"
            f"校验 {'通过' if result['checksum_ok'] else '未通过'}"
            f"（{result['named_count']}/{result['block_count']} 件认出，"
            f"截图 {capture_ms / 1000:.2f}s + 分析 {analysis_ms / 1000:.2f}s）"
        )
        try:
            记回合事件(
                "warehouse_vision",
                human=(
                    f"🧠 第{rnd}回合仓库视觉：最低 {result['min_total']:,} / "
                    f"均值 {result['mean_total']:,} / P75 {result['p75_total']:,} / "
                    f"校验{'通过' if result['checksum_ok'] else '未通过'}"
                ),
                round=rnd,
                run_id=RUN_ID,
                min_total=result["min_total"],
                mean_total=result["mean_total"],
                # 这个估价必须记下来 —— 视觉报告页靠它算「比估价高还是低」和校验通过率，
                # 不记的话那两栏永远是「—」，整页数据等于白攒（手扫时是 0，挂机时是当回合估价）。
                game_estimate=int(game_estimate or 0),
                p10_total=result.get("p10_total", 0),
                p50_total=result.get("p50_total", 0),
                p75_total=result["p75_total"],
                p90_total=result.get("p90_total", 0),
                checksum_ok=result["checksum_ok"],
                checksum_diff=result["checksum_diff"],
                block_count=result["block_count"],
                named_count=result["named_count"],
                elapsed_ms=result["total_ms"],
                capture_coverage=round(_cov / 100.0, 4),
                shadow_mode=result["shadow_mode"],
                shadow_strategy_value=result["shadow_strategy_value"],
                shadow_bid_floor=result["shadow_bid_floor"],
                shadow_bid_cap=result["shadow_bid_cap"],
                shadow_bid_active=result.get("shadow_bid_active", False),
                mean_top_candidate_confidence=(
                    calibration.get("mean_top_candidate_confidence", 0)
                ),
                image_path=result.get("image_path", ""),
                items=result["items"],
            )
        except Exception:
            pass
        return result
    except Exception as exc:
        print(f"⚠️ 第{rnd}回合仓库视觉整理失败（继续原策略）: {exc}")
        return None


def 仓库视觉扫一次(game_estimate=0, round_num=0):
    """不挂机也能扫一次整仓：抓图 → 识别 → 写一条 warehouse_vision 事件。

    跟挂机那条路共用 抓整个仓 / engine.analyze / 记回合事件，但**不碰回合状态**：
    不看倒计时、不判断对局模式、不进出价流程。所以只要游戏停在藏品仓库页，
    点一下就能出结果，面板那边读到的还是同一个 type，不用另做一套。

    跟挂机版的区别只有两处：不写 _WAREHOUSE_VISION_ROUNDS 缓存（免得污染对局），
    事件里多一个 scan_mode="manual" 让面板知道这不是真打牌。
    """
    if 游戏窗口范围() is None:
        print("❌ 扫仓：找不到异环窗口，先把游戏开起来")
        return None
    engine = 取仓库视觉(force=True)
    if engine is None:
        print("❌ 扫仓：视觉引擎起不来（warehouse_vision 没加载成功）")
        return None
    rnd = int(round_num or 0) or 1
    started = time.time()
    print("🔍 扫仓：开始翻整仓，翻的时候别动仓库…")
    # 滚屏那套函数一上来就 `if not running: return False, "已停止"` ——
    # 那是给挂机主循环用的（用户按了暂停要立刻撒手）。手动扫仓是独立进程，
    # running 一直是 False，不临时打开的话一屏都翻不动，只能抓到当前这一屏。
    global running
    _was_running = running
    running = True
    try:
        canvas = 抓整个仓()
    finally:
        running = _was_running
    if canvas is None:
        print("❌ 扫仓：没抓到整仓图（确认停在藏品仓库页，并以管理员身份运行）")
        return None
    capture_ms = int((time.time() - started) * 1000)
    try:
        _cov = canvas.height * 100.0 / float(GRID_FULL_PX)
    except Exception:
        _cov = 100.0
    print("🔍 扫仓：整仓图 %dx%d，覆盖 %.0f%%" % (canvas.width, canvas.height, _cov))
    if _cov < float(WAREHOUSE_VISION_MIN_CAPTURE_COVERAGE) * 100.0:
        # 图不完整就**别硬分析**：坐标是按整仓高度算的，半张图会让它越界崩掉
        # （早先实测报 index 624 out of bounds for axis 0 with size 585）。
        print(
            "❌ 扫仓：只抓到 %.0f%%（要 %.0f%% 以上），仓库没翻全，先不认了。"
            % (_cov, float(WAREHOUSE_VISION_MIN_CAPTURE_COVERAGE) * 100.0)
        )
        print("   确认游戏停在藏品仓库页、翻的时候鼠标别乱动，再点一次。")
        return None
    analysis_started = time.time()
    try:
        result = engine.analyze(
            canvas if canvas.mode == "RGB" else canvas.convert("RGB"),
            rnd,
            int(game_estimate or 0),
            fresh=True,   # 手动扫仓是一片新仓，别继承挂机时留下的识别状态
        )
    except Exception as exc:
        print("❌ 扫仓：分析失败 %s" % exc)
        return None
    try:
        result["capture_ms"] = capture_ms
        result["analysis_ms"] = int((time.time() - analysis_started) * 1000)
        result["total_ms"] = int((time.time() - started) * 1000)
        result["shadow_mode"] = False
        result["scan_mode"] = "manual"
        for _key, _fn in (
            ("shadow_strategy_value", 仓库视觉策略估值),
            ("shadow_bid_floor", 仓库视觉出价底线),
            ("shadow_bid_cap", 仓库视觉出价上限),
        ):
            try:
                result[_key] = _fn(int(game_estimate or 0), rnd, force=True)
            except Exception:
                result[_key] = 0
        calibration = dict(result.get("confidence_calibration") or {})
        _image_meta = 存仓库视觉图(canvas, rnd, force=True)
        result["image_path"] = _image_meta.get("image_path") or ""
        print(
            "📸 扫仓结果：最低 %s｜均值 %s｜P75 %s｜校验 %s"
            % (
                "{:,}".format(int(result.get("min_total") or 0)),
                "{:,}".format(int(result.get("mean_total") or 0)),
                "{:,}".format(int(result.get("p75_total") or 0)),
                "通过" if result.get("checksum_ok") else "未通过",
            )
        )
        try:
            记回合事件(
                "warehouse_vision",
                human=(
                    "📸 手动扫仓：最低 {:,} / 均值 {:,} / P75 {:,} / 校验{}".format(
                        int(result.get("min_total") or 0),
                        int(result.get("mean_total") or 0),
                        int(result.get("p75_total") or 0),
                        "通过" if result.get("checksum_ok") else "未通过",
                    )
                ),
                round=rnd,
                run_id=RUN_ID,
                scan_mode="manual",
                game_estimate=int(game_estimate or 0),
                min_total=result["min_total"],
                mean_total=result["mean_total"],
                p10_total=result.get("p10_total", 0),
                p50_total=result.get("p50_total", 0),
                p75_total=result["p75_total"],
                p90_total=result.get("p90_total", 0),
                checksum_ok=result["checksum_ok"],
                checksum_diff=result["checksum_diff"],
                block_count=result["block_count"],
                named_count=result["named_count"],
                elapsed_ms=result["total_ms"],
                capture_coverage=round(_cov / 100.0, 4),
                shadow_mode=False,
                shadow_strategy_value=result.get("shadow_strategy_value", 0),
                shadow_bid_floor=result.get("shadow_bid_floor", 0),
                shadow_bid_cap=result.get("shadow_bid_cap", 0),
                mean_top_candidate_confidence=(
                    calibration.get("mean_top_candidate_confidence", 0)
                ),
                image_path=result.get("image_path", ""),
                items=result["items"],
            )
        except Exception:
            pass
        return result
    except Exception as exc:
        print("⚠️ 扫仓：结果整理失败 %s" % exc)
        return None


def 仪器后预算余量(t0, budget=None):
    """用完道具到现在还剩多少秒预算（不足返回 0）。"""
    try:
        b = float(budget if budget is not None else INSTRUMENT_TO_EST_BUDGET)
        return max(0.0, b - (time.time() - float(t0)))
    except Exception:
        return 0.0


def 等仪器生效(round_num, old_value, max_wait=None):
    """Return as soon as a new estimate is visibly stable.

    The caller always performs a final full estimate read afterwards, so an
    8-second no-change result is only a fast-path decision, not the final
    source of truth.
    """
    try:
        if not 仪器要确认生效吗(round_num):
            print(f"⏩ 第{round_num}回合这台仪器不改估价 → 不陪它等，直接读完整估价")
            return 0
        if not 歇一下(INSTRUMENT_EFFECT_MIN_WAIT):
            return 0
        t0 = time.time()
        wait_cap = float(max_wait if max_wait is not None else INSTRUMENT_EFFECT_MAX_WAIT)
        # 紧迫危机 20 秒：仪器照用，但最多陪它 6 秒，剩下的留给估价和点数字
        if 快没时间了吗():
            wait_cap = min(wait_cap, float(URGENT_INSTRUMENT_MAX_WAIT))
        deadline = t0 + wait_cap
        last_new = 0
        stable_since = 0.0
        first_change_at = 0.0
        samples = []
        detail_animation = int(round_num) >= 3 and int(这回合用几号仪器(round_num) or 0) == 2
        stable_window = (
            INSTRUMENT_FIRST_ROUND_STABLE_WINDOW
            if int(round_num) == 1 and int(old_value or 0) == 0
            else (
                INSTRUMENT_DETAIL_STABLE_WINDOW
                if detail_animation
                else INSTRUMENT_EFFECT_STABLE_WINDOW
            )
        )
        min_observe = INSTRUMENT_DETAIL_MIN_OBSERVE if detail_animation else 0.0
        region = 估价区域()
        if region is None:
            return 0
        while time.time() < deadline:
            if not running:
                return 0
            try:
                image = np.array(抓一帧(region=region))
            except Exception:
                image = None
            new_value, probe = 试估价模板(image)
            now = time.time()
            if new_value and new_value != int(old_value or 0):
                if not first_change_at:
                    first_change_at = now
                if not samples or samples[-1].get("value") != int(new_value):
                    samples.append(
                        {
                            "value": int(new_value),
                            "t": round(now - t0, 3),
                        }
                    )
                    while len(samples) > 20:
                        samples.pop(0)
                if new_value != last_new:
                    last_new = new_value
                    stable_since = now
                elif now - stable_since >= stable_window and now - first_change_at >= min_observe:
                    print(
                        f"⏳ 仪器生效：第{round_num}回合估价 "
                        f"{int(old_value or 0):,} → {new_value:,}"
                        f"（等待 {now - t0:.2f}s）"
                    )
                    try:
                        记回合事件(
                            "instrument_estimate_stable",
                            human=f"⏳ 第{round_num}回合仪器估价稳定 {int(old_value or 0):,}"
                            f" → {new_value:,}（{now - t0:.2f}s）",
                            round=round_num,
                            old=int(old_value or 0),
                            final=int(new_value),
                            samples=samples,
                            elapsed_ms=int((now - t0) * 1000),
                            stable_window=stable_window,
                            min_observe=min_observe,
                            detail_animation=detail_animation,
                        )
                    except Exception:
                        pass
                    return new_value
            else:
                last_new = 0
                stable_since = 0.0
            if not 歇一下(INSTRUMENT_EFFECT_POLL_INTERVAL):
                return 0
        # 用完了等待上限还没看到变化：不再打印提示（用户要求），静默回退到完整估价读取。
        # 注意这里不会用旧估价出价 —— 调用方接下来会做完整的“识别到当前估价”。
        try:
            记回合事件(
                "instrument_estimate_timeout",
                human=f"⚠️ 第{round_num}回合仪器估价 {wait_cap:.1f}s 未变化，回退完整读取",
                round=round_num,
                old=int(old_value or 0),
                samples=samples,
                elapsed_ms=int((time.time() - t0) * 1000),
                detail_animation=detail_animation,
            )
        except Exception:
            pass
        if int(INSTRUMENT_FAILURE_PAUSE or 0) == 1 and 仪器要确认生效吗(round_num) and running:
            _pmsg = (
                f"⛔ 第{round_num}回合仪器用完等了 {wait_cap:.1f} 秒估价都没变，可能根本没生效 "
                f"→ 暂停脚本，别拿旧估价出价"
            )
            print(_pmsg)
            try:
                记回合事件(
                    "instrument_effect_failed_pause",
                    human=_pmsg,
                    round=round_num,
                    old=int(old_value or 0),
                    elapsed_ms=int((time.time() - t0) * 1000),
                )
            except Exception:
                pass
            暂停脚本()
    except Exception as e:
        print(f"⚠️ 等仪器生效时出错: {e}")
    return 0


def 结算后核对估价(round_num, value_str, old_value=0):
    """对逐件揭示的仪器动画做尾帧复核。

    先让前面已有的快速轮询拿到首个稳定值，再观察一个短窗口；只有尾帧也
    不再变化才返回。普通回合不调用，因此不会给所有对局增加固定等待。
    """
    try:
        initial = int(value_str or 0)
    except Exception:
        initial = 0
    if initial <= 0:
        return value_str
    region = 估价区域()
    if region is None:
        return value_str
    started = time.time()
    deadline = started + float(ESTIMATE_POST_SETTLE_MAX_WAIT)
    stable_since = started
    current = initial
    samples = [{"value": initial, "t": 0.0, "source": "full-read"}]
    changed_after_full = False
    while time.time() < deadline:
        if not running:
            return value_str
        if not 歇一下(0.2):
            return value_str
        try:
            image = np.array(抓一帧(region=region))
            probe_value, probe = 试估价模板(image)
            digits = str(probe.digits) if probe is not None and probe.ok else ""
        except Exception:
            probe_value, digits = 0, ""
        now = time.time()
        if probe_value and digits and int(probe_value) != int(current):
            current = int(probe_value)
            stable_since = now
            changed_after_full = True
            if samples[-1].get("value") != current:
                samples.append(
                    {
                        "value": current,
                        "t": round(now - started, 3),
                        "source": "tail-probe",
                    }
                )
            continue
        if now - stable_since < ESTIMATE_POST_SETTLE_WINDOW:
            continue
        # 尾帧有变化时必须再走一次完整双读确认；完全没变化则沿用刚才的双读。
        if changed_after_full:
            full = 读当前估价()
            try:
                full_value = int(full or 0)
            except Exception:
                full_value = 0
            if full_value <= 0:
                stable_since = time.time()
                continue
            if full_value != current:
                current = full_value
                stable_since = time.time()
                samples.append(
                    {
                        "value": current,
                        "t": round(time.time() - started, 3),
                        "source": "full-recheck",
                    }
                )
                continue
        elapsed = time.time() - started
        print(
            f"🎯 第{round_num}回合估价尾帧确认: {initial:,}"
            + (f" → {current:,}" if current != initial else "（未再变化）")
            + f"（{elapsed:.2f}s）"
        )
        try:
            记回合事件(
                "estimate_tail_verified",
                human=f"🎯 第{round_num}回合估价尾帧确认：{current:,}（{elapsed:.2f}s）",
                round=round_num,
                initial=initial,
                final=current,
                old_value=int(old_value or 0),
                samples=samples,
                elapsed_ms=int(elapsed * 1000),
                stable_window=ESTIMATE_POST_SETTLE_WINDOW,
                urgent=快没时间了吗(),
            )
        except Exception:
            pass
        return str(current)
    latest = current if current > 0 else initial
    try:
        记回合事件(
            "estimate_tail_timeout",
            human=f"⚠️ 第{round_num}回合估价尾帧 {ESTIMATE_POST_SETTLE_MAX_WAIT:.1f}s 未确认，采用最新稳定候选 {latest:,}",
            round=round_num,
            initial=initial,
            final=latest,
            samples=samples,
            urgent=快没时间了吗(),
        )
    except Exception:
        pass
    return str(latest)


def 关仪器页(quiet=True):
    """关掉仪器列表（点右上角的【×】）。关不掉的话，点【出价】不会弹出价面板。

    quiet=False 时会把"没找到 / 没点到"也写进日志 —— 出价失败那两条路用它，
    这样下次看日志就知道到底是不是这个面板挡着。
    """
    try:
        if not 画面有吗(INSTRUMENT_CLOSE_IMAGE, timeout=0):
            if not quiet:
                print(
                    f"ℹ️ 没看到关闭仪器列表的【{INSTRUMENT_CLOSE_IMAGE}】，面板可能已经自己关掉了"
                )
            return False
        if 找到就点(INSTRUMENT_CLOSE_IMAGE, "关闭仪器列表",
                     timeout=(1 if 急吗() else 3), report_timeout=False):
            if not 歇一下(0.6):
                return False
            if not 画面有吗(INSTRUMENT_CLOSE_IMAGE, timeout=0):
                print("🚪 已确认仪器列表关闭")
                return True
    except Exception as e:
        if not quiet:
            print(f"⚠️ 关闭仪器列表出错 {e}")
    if not quiet:
        print("⚠️ 看到了【×】但没能点到，仪器列表可能还开着（后面出价会点不出来）")
    return False


def 用本回合仪器(round_num, open_list=True):
    inst = 这回合用几号仪器(round_num)
    if not inst:
        关仪器页()
        return 0
    img = INSTRUMENT_IMAGES.get(inst)
    if not img:
        print(f"⚠️ 第{round_num}回合配置的仪器号是 {inst}，只能填 1~5（0=不用），本回合跳过仪器")
        return 0
    name = INSTRUMENT_NAMES.get(inst, str(inst))
    print(f"🧰 第{round_num}回合按配置使用 {inst} 号仪器（{name}）")
    # 紧迫危机只有 20 秒：下面三次「找到就点」原来都写死 10 秒超时。
    # 只要有一次没在画面里立刻认到（仪器页动画、按钮高亮还没出来），
    # 就能单次干等 10 秒，一个回合计时直接见底。
    # 紧迫时压到 2 秒：认不到就当这回合没用上仪器，先保证把价出出去。
    _tmo_inst = 2 if 急吗() else 10
    # 点完【使用】后面那个固定 1 秒同理，紧迫时缩到 0.3 秒。
    _close_wait = 0.3 if 急吗() else 1.0
    started = time.time()
    try:
        记回合事件(
            "instrument_start",
            human=f"🧰 第{round_num}回合开始使用 {inst} 号仪器（{name}）",
            round=int(round_num),
            instrument=int(inst),
            instrument_name=name,
            urgent=快没时间了吗(),
        )
    except Exception:
        pass
    if open_list:
        找到就点("step5.png", "点击step5", timeout=_tmo_inst, report_timeout=False)
    window = 游戏窗口范围()
    if window is None:
        return 0
    left, top, _, _ = window
    lx, ly, lw, lh = INSTRUMENT_LIST_BOX
    region = (left + lx, top + ly, lw, lh)
    if not 找到就点(
        img, f"{inst}号仪器（{name}）", region=region, timeout=_tmo_inst, report_timeout=False
    ):
        print(
            f"⚠️ 第{round_num}回合没点到 {inst} 号仪器（可能这局已经用过/列表里没有它），"
            f"本回合不用仪器，继续读估价出价"
        )
        关仪器页(quiet=False)
        return 0
    if not 找到就点("step7.png", "使用仪器", timeout=_tmo_inst, report_timeout=False):
        print(f"⚠️ 第{round_num}回合点到仪器了但没找到【使用】按钮，本回合可能没用上仪器")
        关仪器页(quiet=False)
        return 0
    if not 歇一下(_close_wait):
        return 0
    关仪器页()
    cost = int(仪器价目表().get(inst, 0))
    try:
        _INSTRUMENTS_CONSUMED[0] = True
    except Exception:
        pass
    print(f"💰 仪器花费：{inst} 号（{name}）{cost:,}")
    try:
        记回合事件(
            "instrument_used",
            human=f"✅ 第{round_num}回合已使用 {inst} 号仪器（{name}），花费 {cost:,}",
            round=int(round_num),
            instrument=int(inst),
            instrument_name=name,
            cost=cost,
            elapsed_ms=int((time.time() - started) * 1000),
            urgent=快没时间了吗(),
        )
    except Exception:
        pass
    return cost


def 读具名模板(names):
    """把 记录\\藏品模板\\<名字>.png（没有就找 素材\\item_<名字>.png）读成能匹配的 BGR 图。"""
    out = {}
    for nm in names:
        for p in (
            os.path.join(RUNLOG_DIR, "藏品模板", nm + ".png"),
            os.path.join(SCRIPT_DIR, "素材", "item_" + nm + ".png"),
            os.path.join(SCRIPT_DIR, "素材", nm + ".png"),
        ):
            if os.path.isfile(p):
                t = 读图(p)
                if t is not None and t.shape[0] >= 24 and t.shape[1] >= 24:
                    out[nm] = t
                    break
    return out


def 要找的仓(names=None):
    """整仓识别模块：把右侧藏格品翻一遍拼成整仓，认出名单里的藏品，返回认到的名字。

    每回合都能调用。只翻看右侧那一栏（拖滚动条），不点任何按钮、不碰出价和退出流程；
    翻完会自动滚回最上面（抓整个仓 里做的），所以不影响后面读估价。
    """
    try:
        import cv2
        import numpy as _np
    except Exception:
        return []
    if names is None:
        names = [
            s.strip()
            for s in str(SCAN_ITEM_NAMES or "").replace("，", ",").split(",")
            if s.strip()
        ]
    if not names:
        return []
    tpl = 读具名模板(names)
    if not tpl:
        print(
            "⚠️ 整仓识别：一个模板都没找到（要 记录\\藏品模板\\<名字>.png 或 素材\\item_<名字>.png）"
        )
        return []
    print("🔍 整仓识别：开始翻整仓（要认 %s）..." % "、".join(tpl.keys()))
    canvas = 抓整个仓()
    if canvas is None:
        print("⚠️ 整仓识别：翻不动（可能不在拍卖界面），这次不识别")
        return []
    try:
        存这一仓(canvas, 0)  # 顺手存一张，事后能核对"是不是真没认出来"
    except Exception:
        pass
    big = cv2.cvtColor(_np.asarray(canvas.convert("RGB"))[:, :, ::-1], cv2.COLOR_BGR2GRAY)
    hits = []
    for nm, timg in tpl.items():
        t0 = cv2.cvtColor(timg, cv2.COLOR_BGR2GRAY)
        best = 0.0
        for sc in SCAN_SCALES:
            tg = (
                t0
                if abs(float(sc) - 1.0) < 1e-6
                else cv2.resize(
                    t0,
                    (max(8, int(t0.shape[1] * float(sc))), max(8, int(t0.shape[0] * float(sc)))),
                    interpolation=cv2.INTER_AREA,
                )
            )
            if tg.shape[0] > big.shape[0] or tg.shape[1] > big.shape[1]:
                continue
            best = max(best, float(cv2.matchTemplate(big, tg, cv2.TM_CCOEFF_NORMED).max()))
        print("   · %s：最像 %.3f（门槛 %.2f）" % (nm, best, SCAN_MIN_SCORE))
        if best >= SCAN_MIN_SCORE:
            hits.append(nm)
    return hits


def 仓命中(round_num):
    """按配置在第 x 回合跑一次整仓识别。返回 True = 认到目标（调用方据此决定跳不跳仪器）。"""
    if _GP_BONUS_MODE[0]:
        return False  # 撞果盘的福利多多局不做整仓识别（省时间）
    try:
        if int(SCAN_AT_ROUND or 0) != int(round_num):
            return False
    except Exception:
        return False
    try:
        hits = 要找的仓()
    except Exception as e:
        print(f"⚠️ 整仓识别出错（不影响流程）: {e}")
        return False
    if hits:
        print("🌟 整仓识别：第 %d 回合认出 %s" % (round_num, "、".join(hits)))
        try:
            记回合事件(
                "chest_scan", human="🌟 整仓识别到：" + "、".join(hits), round=round_num, hits=hits
            )
        except Exception:
            pass
        return True
    print("🔍 整仓识别：第 %d 回合没认到目标藏品" % round_num)
    return False


def 走第1回合():
    清估价识别记录()
    _scanned_this_round = False
    _urgent = 刷新回合状态(1)
    _skip_urgent_inst = 急了就别用仪器(1)
    # 紧迫危机：用仪器前只剩不到 10 秒 → 不用仪器，直接沿用上轮估价/保底价
    _urgent_low_time = False
    if 急吗(_urgent):
        _rem1 = 紧迫剩余秒数()
        if _rem1 is not None and _rem1 < URGENT_SKIP_INSTRUMENT_BELOW:
            _urgent_low_time = True
            print(f"⚡ 紧迫危机：只剩 {_rem1:.1f}s（<{URGENT_SKIP_INSTRUMENT_BELOW:.0f}s）"
                  f"→ 第1回合跳过仪器，沿用上轮出价/保底价")
    _hit = False
    if not _urgent and int(SCAN_TIMING or 0) == 0:
        _hit = 仓命中(1)
    elif _urgent:
        print("⚡ 紧迫危机：第1回合跳过可选整仓扫描，优先完成出价")
    _c1 = 0
    if _hit and int(SCAN_SKIP_TOOL or 0) == 1:
        print("⏭️ 整仓识别到目标 → 第 1 回合不用仪器")
        关仪器页(
            quiet=False
        )  # 第1回合仪器列表默认是开着的，不用它就得关掉，否则挡住出价
    elif _skip_urgent_inst or _urgent_low_time:
        关仪器页(quiet=True)
    else:
        _c1 = 用本回合仪器(1, open_list=False)
    _pre1 = 0
    if _c1:
        记一局成本("round1_instrument", _c1, f"第1回合仪器({这回合用几号仪器(1)}号)")
        try:
            _pre1 = int(LAST_ESTIMATE or 0)
        except Exception:
            _pre1 = 0
        # 用完道具停 3.5 秒：仪器要一点时间才把估价刷新出来。
        # 紧迫危机只有 20 秒 —— 这里压到 0.8 秒，准确性靠后面"连读两遍"兜。
        _pause1 = URGENT_READ_WAIT if 急吗(_urgent) else 3.5
        if not 歇一下(_pause1):
            return False
        # 大肥鱼：用户定的第 1 回合顺序 ——
        #   用完道具 → 停 3 秒 → 翻页把整仓数一遍（数品质） → 再识别估价 → 出价。
        # 以前是"出价决策时才翻仓"，顺序反了；翻完页面还在动就去读估价也容易读错。
        # 第1回合不再数品质（信息最少，数了没什么用）。
        # 改成：读完估价后，>110 万才做一次仓库视觉识别（见下方）。
    if not _urgent and int(SCAN_TIMING or 0) == 1:
        仓命中(1)
    if _urgent_low_time:
        _reuse1 = 紧迫沿用出价(1)
        _URGENT_REUSE_BID[0] = _reuse1
        _last1 = 0
        try:
            _last1 = int(LAST_ESTIMATE or 0)
        except Exception:
            _last1 = 0
        value_str = str(_last1 or _reuse1 or 0) or None
        print(f"⚡ 紧迫危机：第1回合跳过仪器 → 直接出 {_reuse1:,}（沿用保底价）")
    elif _c1:
        # 上面已经停过 3.5 秒，仪器肯定生效了 → 不再等"稳定窗口"。
        # 直接快读两遍：两遍一致就用（约 0.4~0.7 秒），不一致才退回完整读取。
        _fa = 快读当前估价(record=True)
        _fb = 快读当前估价(record=True) if _fa else ""
        value_str = ""
        try:
            if _fa and _fb and int(_fa) == int(_fb):
                value_str = _fb
                print(f"⚡ 第1回合：停 3.5 秒后直接读估价 {int(_fb):,}（两遍一致，不等生效窗口）")
            elif _fa or _fb:
                print(f"⚡ 第1回合：快读两遍不一致（{_fa or '-'} / {_fb or '-'}）→ 退回完整读取")
        except Exception:
            value_str = ""
        if not value_str:
            if 快没时间了吗():
                _quick1 = 快读当前估价(record=True)
                if _quick1:
                    value_str = _quick1
                elif _pre1:
                    value_str = str(_pre1)
                else:
                    value_str = 读价否则放弃(1)
            else:
                value_str = 读价否则放弃(1)
        if value_str is None:
            return False
    else:
        value_str = 等估价出来(1)
        if value_str == "STOP":
            return False
        if value_str is None:
            value_str = 读价否则放弃(1)
            if value_str is None:
                return False
    value_int = int(value_str)
    if value_int > 0 and not _URGENT_REUSE_BID[0]:
        RUNLOG_SEEN_PRICES.append(value_int)
    刷新回合状态(1)
    记回合事件(
        "round_start",
        human=f"🔎 第1回合：估价 {value_int:,}（OCR原文 '{RUNLOG_OCR.get('value_raw','')}'）",
        round=1,
        value=value_int,
        ocr=dict(RUNLOG_OCR),
    )
    # —— 第1回合：>110 万才识别这批货里有没有目标藏品 ——
    try:
        if int(value_int) > int(GATE_1100):
            print(f"🧠 第1回合估价 {value_int:,} > {int(GATE_1100):,} → 做一次仓库视觉识别")
            仓库视觉扫描(1, value_int, False, force=True)
        else:
            print(f"🧠 第1回合估价 {value_int:,} ≤ {int(GATE_1100):,} → 不识别，按正常规则出价")
    except Exception as _ev1:
        print(f"⚠️ 第1回合仓库视觉识别失败（不影响出价）: {_ev1}")
    仓库视觉扫描(1, value_int, _urgent)
    _PREV_EST_FOR_VISION[0] = int(value_int)
    if not 快没时间了吗():
        存回合截图("round1_before_bid", 回合截图区域(), "第1回合出价前（含对手历史出价）")
    if 查并报警(value_int):
        if not running:
            return False

    bid_amount_str = 取出价金额(value_str, 1)
    if bid_amount_str is None:
        if 出价失败也留房(1, "生成固定出价"):
            return True
        关拍卖("exit", note=f"第1回合不出价：{NO_BID_REASON or '没有合适出价'}，流程B退出")
        走流程B()
        return False

    # 按金 / 红块数往上加钱（两个参数都是 0 时原样返回）
    bid_amount_str = 金红加价(bid_amount_str, 1, value_int)
    bid_images, bid_display = 金额转键位图(bid_amount_str)
    if not bid_images:
        if 出价失败也留房(1, "生成出价按键"):
            return True
        关拍卖("exit", note="出价策略生成失败，流程B退出")
        走流程B()
        return False

    if not 出价前守门(1):
        return True
    bid_result = 执行出价(1, bid_images, bid_display, estimate=value_int)
    if bid_result == "STOP":
        print("⏹️ 用户已暂停 → 结束当前出价，不记金额错误、不执行流程B")
        return False
    if bid_result == "SKIP":
        print("⏭️ 用户跳过出价，直接进入下一回合检测")
        return True
    if bid_result == "WAIT_ROUND":
        return True
    if not bid_result:
        if 出价失败也留房(1, "金额校验/出价面板"):
            return True
        print("⚠️ 出价失败（金额校验失败或面板消失），执行流程B退出本局")
        走流程B()
        return False
    记一回合(1, value_str, bid_display)
    return True


def 走第2回合():
    清估价识别记录()
    _urgent = 刷新回合状态(2)
    _skip_urgent_inst = 急了就别用仪器(2)
    _hit2 = False
    if not _urgent and int(SCAN_TIMING or 0) == 0:
        _hit2 = 仓命中(2)
    elif _urgent:
        print("⚡ 紧迫危机：第2回合跳过可选整仓扫描，优先完成出价")
    _skip2 = bool(_hit2) and int(SCAN_SKIP_TOOL or 0) == 1
    if _skip2:
        print("⏭️ 整仓识别到目标 → 第 2 回合不用仪器")
    _c2 = 0
    _pre2 = 0
    _t_inst0 = time.time()      # 计时：仪器 → 估价
    _t_inst_used = 0.0
    if _skip_urgent_inst:
        关仪器页(quiet=True)
    elif USE_ROUND2_INSTRUMENT == 1:
        if not _skip2:
            _t_inst0 = time.time()      # 计时起点：点"使用仪器"之前
            _rem2 = 紧迫剩余秒数() if 急吗(_urgent) else None
            if _rem2 is not None and _rem2 < URGENT_SKIP_INSTRUMENT_BELOW:
                print(f"⚡ 紧迫危机：只剩 {_rem2:.1f}s（<{URGENT_SKIP_INSTRUMENT_BELOW:.0f}s）"
                      f"→ 第2回合跳过仪器")
                _c2 = 0
            else:
                _c2 = 用本回合仪器(2, open_list=True)
            if _c2:
                记一局成本(
                    "round2_instrument", _c2, f"第2回合仪器({这回合用几号仪器(2)}号)"
                )
                try:
                    _pre2 = int(LAST_ESTIMATE or 0)
                except Exception:
                    _pre2 = 0
    else:
        print("💡 配置：本局第 2 回合不用仪器（第2回合仪器 = 0）")
    if not _urgent and int(SCAN_TIMING or 0) == 1:
        仓命中(2)

    _t_wait0 = time.time()
    _t_wait1 = _t_wait0
    if _c2:
        # 3 秒总预算：留 1.2 秒给"读估价"，剩下的时间才拿去等生效
        if 急吗(_urgent):
            # 紧迫危机：不轮询"等生效"，固定停 3.3 秒后直接读（用户指定节奏）
            _eff2 = 0
            if not 歇一下(URGENT_READ_WAIT):
                return False
            print(f"⚡ 紧迫危机：第2回合停 {URGENT_READ_WAIT:.1f}s 后读估价")
        else:
            _cap2 = max(0.3, min(float(仪器等待上限(WAIT_SPECIAL_INSTRUMENT)),
                                仪器后预算余量(_t_inst0) - 1.2))
            _eff2 = 等仪器生效(2, _pre2, max_wait=_cap2)
        _t_wait1 = time.time()
        if 快没时间了吗():
            _quick2 = 快读当前估价(record=True)
            if _quick2:
                value_str = _quick2
                print(f"⚡ 紧迫危机：快读估价 {int(_quick2):,}（跳过 4 秒完整读取）")
            elif _pre2:
                value_str = str(_pre2)
                print(f"⚡ 紧迫危机：快读失败，退回仪器前估价 {_pre2:,}")
            else:
                value_str = 读价否则放弃(2)
        else:
            if 仪器后预算余量(_t_inst0) < 1.5:
                # 预算只剩一点点了：单遍快读（0.3~0.5 秒），不再跑完整识别
                _q2 = 快读当前估价(record=True)
                if _q2:
                    value_str = _q2
                    print(f"⚡ 第2回合预算紧张：快读估价 {int(_q2):,}")
                else:
                    value_str = 读价否则放弃(2)
            else:
                value_str = 读价否则放弃(2)
        try:
            _t_end = time.time()
            _x_inst = _t_wait0 - _t_inst0
            _x_wait = _t_wait1 - _t_wait0
            _x_read = _t_end - _t_wait1
            print("⏱️ 第2回合：用仪器 %.2fs｜等生效 %.2fs｜读估价 %.2fs｜合计 %.2fs"
                  % (_x_inst, _x_wait, _x_read, _t_end - _t_inst0))
            记回合事件("round_timing", human="⏱️ 第2回合 仪器→估价 %.2fs" % (_t_end - _t_inst0),
                       round=2, inst_ms=int(_x_inst * 1000), wait_ms=int(_x_wait * 1000),
                       read_ms=int(_x_read * 1000), total_ms=int((_t_end - _t_inst0) * 1000))
        except Exception:
            pass
        if value_str is None:
            return False
    elif 快没时间了吗():
        _reuse2 = 紧迫沿用出价(2)
        _URGENT_REUSE_BID[0] = _reuse2
        _lastu2 = 0
        try:
            _lastu2 = int(LAST_ESTIMATE or 0)
        except Exception:
            _lastu2 = 0
        value_str = str(_lastu2 or _reuse2 or 0) or None
        print(f"⚡ 紧迫危机：第2回合跳过仪器 → 直接出 {_reuse2:,}（沿用上轮价）")
    else:
        value_str = 等估价出来(2)
        if value_str == "STOP":
            return False
        if value_str is None:
            value_str = 读价否则放弃(2)
            if value_str is None:
                return False
    value_int = int(value_str)
    if value_int > 0 and not _URGENT_REUSE_BID[0]:
        RUNLOG_SEEN_PRICES.append(value_int)
    记回合事件(
        "round_start",
        human=f"🔎 第2回合：估价 {value_int:,}（OCR原文 '{RUNLOG_OCR.get('value_raw','')}'）",
        round=2,
        value=value_int,
        ocr=dict(RUNLOG_OCR),
    )
    # 紧迫危机：跳过识别/等生效，直接快读，把时间留给出价
    if 快没时间了吗():
        _q2b = 快读当前估价(record=True)
        if _q2b:
            try:
                value_int = int(_q2b)
                print(f"⚡ 紧迫危机：第2回合快读估价 {value_int:,}（不等生效、不识别）")
            except Exception:
                pass
    # 第2回合也要判断：估价比上回合涨 ≥110万 才做仓库视觉识别
    try:
        _prev2 = int(_PREV_EST_FOR_VISION[0] or 0)
        _delta2 = int(value_int) - _prev2 if _prev2 else 0
        if 该做仓库视觉识别(value_int):
            print(f"🧠 第2回合：估价 {value_int:,}，比上回合 {_prev2:,} 涨 {_delta2:,}"
                  f"（≥{VISION_SURGE_STEP:,}）→ 仓库视觉识别")
            仓库视觉扫描(2, value_int, False, force=True)
        else:
            print(f"🧠 第2回合：估价 {value_int:,}，比上回合 {_prev2:,} 涨 {_delta2:,}"
                  f" < {VISION_SURGE_STEP:,} → 不识别")
    except Exception as _e2v:
        print(f"⚠️ 第2回合涨幅判断失败（不影响出价）: {_e2v}")
    仓库视觉扫描(2, value_int, 快没时间了吗())
    _PREV_EST_FOR_VISION[0] = int(value_int)
    if not 快没时间了吗():
        存回合截图("round2_before_bid", 回合截图区域(), "第2回合出价前（含对手历史出价）")
    更新对手记忆(2)
    if 查并报警(value_int):
        if not running:
            return False

    bid_amount_str = 取出价金额(value_str, 2)
    if bid_amount_str is None:
        if 出价失败也留房(2, "生成固定出价"):
            return True
        关拍卖("exit", note=f"第2回合不出价：{NO_BID_REASON or '没有合适出价'}，流程B退出")
        走流程B()
        return False

    # 第 2 回合也顺手看一眼举报面板：有对手提前跑了就出 1 块拿下。
    # 第 2 回合走的是独立函数，不经过走普通回合，所以要在这儿单独接一次。
    _gone_now = False
    if 2 in OPPONENTS_GONE_ROUNDS and not _urgent:
        _gone = 对手跑光了吗()
        if _gone:
            _gone_now = True
            bid_amount_str = str(OPPONENTS_GONE_PRICE)
            print(f"🏃 三个对手都跑了 → 这回合直接出 {bid_amount_str} 拿下")
            try:
                记回合事件(
                    "opponents_gone_bid",
                    human=f"🏃 对手都跑了，第2回合出 {bid_amount_str}",
                    round=2,
                    amount=bid_amount_str,
                )
            except Exception:
                pass

    # 按金 / 红块数往上加钱（两个参数都是 0 时原样返回）
    if _gone_now:
        print(f"🏃 对手都跑了 → 不加金红价，就出 {bid_amount_str}")
    else:
        bid_amount_str = 金红加价(bid_amount_str, 2, value_int)
    bid_images, bid_display = 金额转键位图(bid_amount_str)
    if not bid_images:
        if 出价失败也留房(2, "生成出价按键"):
            return True
        关拍卖("exit", note="出价策略生成失败，流程B退出")
        走流程B()
        return False

    if not 出价前守门(2):
        return True
    bid_result = 执行出价(2, bid_images, bid_display, estimate=value_int)
    if bid_result == "STOP":
        print("⏹️ 用户已暂停 → 结束当前出价，不记金额错误、不执行流程B")
        return False
    if bid_result == "SKIP":
        print("⏭️ 用户跳过出价，直接进入下一回合检测")
        return True
    if bid_result == "WAIT_ROUND":
        return True
    if not bid_result:
        if 出价失败也留房(2, "金额校验/出价面板"):
            return True
        print("⚠️ 出价失败（金额校验失败或面板消失），执行流程B退出本局")
        走流程B()
        return False
    记一回合(2, value_str, bid_display)
    return True


def 走普通回合(round_num):
    清估价识别记录()
    # 不再"开回合先等估价"：第 3~5 回合要像第 1/2 回合一样，一进回合计直接去用仪器。
    # 之前这里会先等估价稳定（1~2 秒），那段时间就是"回合开始到用道具"的空档。
    if not running:
        return False
    ready_value = ""
    try:
        if LAST_ESTIMATE:
            ready_value = str(int(LAST_ESTIMATE))   # 只作"仪器前的旧值"参照，不阻塞
    except Exception:
        ready_value = ""

    _urgent = 刷新回合状态(round_num)
    _t_n_start = time.time()     # 计时：仪器 → 估价
    _gone_pre = None             # 第3回合提前看举报的结果（后面复用，不重复点）
    _t_n_inst0 = 0.0             # 点"使用仪器"的时间点（没开仪器就是 0）
    _t_n0 = 0.0
    _t_n_wait = 0.0
    _t_n_wait_end = 0.0
    _t_n_inst1 = 0.0          # 仪器点完的时间点（用来单独统计"用仪器"耗时）
    _skip_urgent_inst = 急了就别用仪器(round_num)
    _cn = 0
    _eff_n = 0
    _urgent_use_last_n = False      # 紧迫：跳过仪器 → 沿用上轮价
    if 3 <= round_num <= 5:
        _hitN = False
        if not _urgent and int(SCAN_TIMING or 0) == 0:
            _hitN = 仓命中(round_num)
        elif _urgent:
            print(f"⚡ 紧迫危机：第{round_num}回合跳过可选整仓扫描，优先完成出价")
        _pre_int = 0
        if 这回合用几号仪器(round_num):
            try:
                _pre_int = int(ready_value)
            except Exception:
                _pre_int = 0
        if _skip_urgent_inst:
            关仪器页(quiet=True)
        elif _hitN and int(SCAN_SKIP_TOOL or 0) == 1:
            print("⏭️ 整仓识别到目标 → 第 %d 回合不用仪器" % round_num)
            _cn = 0
        else:
            _remn = 紧迫剩余秒数() if 急吗(_urgent) else None
            if _remn is not None and _remn < URGENT_SKIP_INSTRUMENT_BELOW:
                print(f"⚡ 紧迫危机：只剩 {_remn:.1f}s（<{URGENT_SKIP_INSTRUMENT_BELOW:.0f}s）"
                      f"→ 第{round_num}回合跳过仪器，沿用上轮出价/保底价")
                _cn = 0
                _urgent_use_last_n = True
            else:
                _t_n_inst0 = time.time()    # 计时起点：点"使用仪器"之前
                _cn = 用本回合仪器(round_num, open_list=True)
        if _cn:
            _t_n_inst1 = time.time()
            记一局成本(
                f"round{round_num}_instrument",
                _cn,
                f"第{round_num}回合仪器({这回合用几号仪器(round_num)}号)",
            )
            if not _t_n_inst0:
                _t_n_inst0 = time.time()
            if not _t_n_inst1:
                _t_n_inst1 = time.time()
            _t_n0 = _t_n_inst1          # 等生效从"仪器点完"开始算
            if 急吗(_urgent):
                _eff_n = 0
                _uw = URGENT_READ_WAIT_ROUND3 if int(round_num) == 3 else URGENT_READ_WAIT
                if not 歇一下(_uw):
                    return False
                print(f"⚡ 紧迫危机：第{round_num}回合停 {_uw:.1f}s 后读估价")
            else:
                # 固定停 3.7 秒 → 后面只读一次估价（不再轮询、不再复核）
                if not 歇一下(INSTRUMENT_READ_WAIT_NORMAL):
                    return False
                _eff_n = 1
                print(f"⏳ 第{round_num}回合：用完仪器停 {INSTRUMENT_READ_WAIT_NORMAL:.1f}s 后读一次估价")
            _t_n_wait = time.time() - _t_n0
            _t_n_wait_end = time.time()
        if int(SCAN_TIMING or 0) == 1:
            仓命中(round_num)

    if _urgent_use_last_n and not _cn:
        _reusen = 紧迫沿用出价(round_num)
        _URGENT_REUSE_BID[0] = _reusen
        _lastn = 0
        try:
            _lastn = int(LAST_ESTIMATE or 0)
        except Exception:
            _lastn = 0
        value_str = str(_lastn or _reusen or 0) or None
        print(f"⚡ 紧迫危机：第{round_num}回合跳过仪器 → 直接出 {_reusen:,}（沿用上轮价）")
    elif _cn:
        # Fast effect polling is advisory.  The final amount still comes from
        # the full template-first reader after the instrument animation.
        if 快没时间了吗():
            # 紧迫局同第 1/2 回合：完整读取要 4 秒，等不起 —— 改走单次快读。
            _quickn = 快读当前估价(record=True)
            if _quickn:
                value_str = _quickn
                print(f"⚡ 紧迫危机：快读估价 {int(_quickn):,}（跳过 4 秒完整读取）")
            elif _pre_int:
                value_str = str(_pre_int)
                print(f"⚡ 紧迫危机：快读失败，退回仪器前估价 {_pre_int:,}")
            else:
                value_str = 读价否则放弃(round_num)
        else:
            value_str = 短复核估价(int(round_num))
            if not running:
                return False
            if not value_str:
                value_str = 读价否则放弃(round_num)
        if value_str is None:
            return False
        try:
            _t_end_n = time.time()
            _x_inst = (_t_n_inst1 - _t_n_inst0) if _t_n_inst1 else 0.0
            _x_wait = _t_n_wait
            _x_read = _t_end_n - _t_n_wait_end
            print("⏱️ 第%d回合：用仪器 %.2fs｜等生效 %.2fs｜读估价 %.2fs｜合计 %.2fs"
                  % (round_num, _x_inst, _x_wait, _x_read, _t_end_n - _t_n_start))
            记回合事件("round_timing",
                       human="⏱️ 第%d回合 仪器→估价 %.2fs" % (round_num, _t_end_n - _t_n_start),
                       round=round_num, inst_ms=int(_x_inst * 1000),
                       wait_ms=int(_x_wait * 1000), read_ms=int(_x_read * 1000),
                       total_ms=int((_t_end_n - _t_n_start) * 1000))
        except Exception:
            pass
    else:
        value_str = 读价否则放弃(round_num)
        if value_str is None:
            return False
    value_int = int(value_str)
    if value_int > 0 and not _URGENT_REUSE_BID[0]:
        RUNLOG_SEEN_PRICES.append(value_int)
    # 你定的第3~5回合顺序：读估价 → (涨幅≥110万才)仓库视觉识别 → 数品质(仅第3回合) → 看举报 → 出价
    try:
        if int(round_num) == 3 and _urgent:
            # 紧迫第3回合：只做「仓库视觉识别」（特殊藏品条件），数品质/看举报一律跳过
            if 该做仓库视觉识别(value_int):
                print(f"🧠 第3回合：估价 {value_int:,}，较上回合涨 ≥{VISION_SURGE_STEP:,} → 仓库视觉识别（紧迫）")
                try:
                    _cv3u = 抓整个仓()
                    仓库视觉扫描(3, value_int, False, force=True, canvas=_cv3u)
                except Exception as _e3u:
                    print(f"⚠️ 第3回合紧迫识别失败（不影响出价）: {_e3u}")
            else:
                _prev3u = int(_PREV_EST_FOR_VISION[0] or 0)
                _d3u = int(value_int) - _prev3u if _prev3u else 0
                print(f"🧠 第3回合：估价 {value_int:,}，较上回合 {_prev3u:,} 涨 {_d3u:,}"
                      f" < {VISION_SURGE_STEP:,} → 不识别")
            print("⚡ 紧迫危机：第3回合跳过数品质/举报")
        elif int(round_num) == 3 and 本机很慢吗():
            # 慢机器：数品质一次要 8~10 秒，第3回合会被它拖到超时 → 直接跳过
            print(f"🐢 本机较慢（抓帧系数≥{float(SLOW_PC_K_THRESHOLD):.1f}）→ 第3回合跳过数品质，保证出价")
            if 该做仓库视觉识别(value_int):
                try:
                    _cv3s = 抓整个仓()
                    仓库视觉扫描(3, value_int, False, force=True, canvas=_cv3s)
                except Exception as _e3s:
                    print(f"⚠️ 第3回合识别失败（不影响出价）: {_e3s}")
        elif int(round_num) == 3:
            # 只翻一次仓：同一张整仓图，既做识别也数品质（省 3~5 秒）
            _cv3 = None
            try:
                _cv3 = 抓整个仓()
            except Exception as _e3c:
                print(f"⚠️ 第3回合抓仓失败（不影响出价）: {_e3c}")
            _prev3 = int(_PREV_EST_FOR_VISION[0] or 0)
            _d3 = int(value_int) - _prev3 if _prev3 else 0
            if 该做仓库视觉识别(value_int):
                print(f"🧠 第3回合：估价 {value_int:,}，较上回合 {_prev3:,} 涨 {_d3:,}（≥{VISION_SURGE_STEP:,}）→ 仓库视觉识别")
                try:
                    仓库视觉扫描(3, value_int, _urgent, force=True, canvas=_cv3)
                except Exception as _e3v:
                    print(f"⚠️ 第3回合仓库视觉识别失败（不影响出价）: {_e3v}")
            else:
                print(f"🧠 第3回合：估价 {value_int:,}，较上回合 {_prev3:,} 涨 {_d3:,}"
                      f" < {VISION_SURGE_STEP:,} → 不识别（只数品质）")
            try:
                if _cv3 is not None:
                    _q3 = 数整仓品质块(img=_cv3, scroll=False)
                    _no3 = int(globals().get("RUNLOG_AUCTION_NO", 0) or 0)
                    if _no3:
                        _CATALOG_BLOCK_CACHE.clear()
                        _CATALOG_BLOCK_CACHE[_no3] = _q3
                    记下仓里格子(_q3, _no3)
                    print(f"🔄 数品质（同一张仓图）：{_q3}")
                else:
                    数这一局的仓(force=True)
            except Exception as _e3:
                print(f"⚠️ 第3回合数品质出错（不影响出价）: {_e3}")
            _gone_pre = 对手跑光了吗()             # 先看举报，出价前直接用结果
            print("🔄 第3回合：识别/数品质/看举报 完成 → 继续出价")
        elif int(round_num) in (4, 5):
            if 该做仓库视觉识别(value_int):
                print(f"🧠 第{round_num}回合：估价 {value_int:,}，较上回合涨 ≥{VISION_SURGE_STEP:,} → 仓库视觉识别")
                仓库视觉扫描(round_num, value_int, False, force=True)
            else:
                _prev_n = int(_PREV_EST_FOR_VISION[0] or 0)
                _d_n = int(value_int) - _prev_n if _prev_n else 0
                print(f"🧠 第{round_num}回合：估价 {value_int:,}，较上回合 {_prev_n:,} 涨 {_d_n:,}"
                      f" < {VISION_SURGE_STEP:,} → 不识别")
    except Exception as _ev:
        print(f"⚠️ 第{round_num}回合识别/数品质出错（不影响出价）: {_ev}")
    _PREV_EST_FOR_VISION[0] = int(value_int)
    记回合事件(
        "round_start",
        human=f"🔎 第{round_num}回合：估价 {value_int:,}（OCR原文 '{RUNLOG_OCR.get('value_raw','')}'）",
        round=round_num,
        value=value_int,
        ocr=dict(RUNLOG_OCR),
    )
    # 第 3 回合在上面那个 elif 分支里已经抓过整仓、做过识别/数品质了，
    # 这里再无条件扫一遍会在"涨幅<110万"时重复翻仓（点轨道），实测多扫一遍。
    # 所以第 3 回合跳过这里的兜底扫描；4/5 回合走这里（它们的分支只在涨幅时才扫）。
    if int(round_num) != 3:
        仓库视觉扫描(round_num, value_int, _urgent)
    if not _urgent:
        存回合截图(
            f"round{round_num}_before_bid",
            回合截图区域(),
            f"第{round_num}回合出价前（含对手历史出价）",
        )
    if not _urgent:
        可能要收模板(round_num)
    更新对手记忆(round_num)
    if 查并报警(value_int):
        if not running:
            return False

    bid_amount_str = 取出价金额(value_str, round_num)
    if bid_amount_str is None:
        if 出价失败也留房(round_num, "生成固定出价"):
            return True
        关拍卖(
            "exit", note=f"第{round_num}回合不出价：{NO_BID_REASON or '没有合适出价'}，流程B退出"
        )
        走流程B()
        return False

    # 第 3、5 回合顺手看一眼举报面板：三个对手都跑了就出 1 块拿下
    _gone_now = False
    if int(round_num) in OPPONENTS_GONE_ROUNDS and not _urgent:
        if _gone_pre is not None:
            _gone = _gone_pre
        else:
            _gone = 对手跑光了吗()
        if _gone:
            _gone_now = True
            bid_amount_str = str(OPPONENTS_GONE_PRICE)
            print(f"🏃 三个对手都跑了 → 这回合直接出 {bid_amount_str} 拿下")
            try:
                记回合事件(
                    "opponents_gone_bid",
                    human=f"🏃 对手都跑了，第{round_num}回合出 {bid_amount_str}",
                    round=round_num,
                    amount=bid_amount_str,
                )
            except Exception:
                pass

    # 按金 / 红块数往上加钱（两个参数都是 0 时原样返回）
    if _gone_now:
        print(f"🏃 对手都跑了 → 不加金红价，就出 {bid_amount_str}")
    else:
        bid_amount_str = 金红加价(bid_amount_str, round_num, value_int)
    bid_images, bid_display = 金额转键位图(bid_amount_str)
    if not bid_images:
        if 出价失败也留房(round_num, "生成出价按键"):
            return True
        关拍卖("exit", note="出价策略生成失败，流程B退出")
        走流程B()
        return False

    if not 出价前守门(round_num):
        return True
    bid_result = 执行出价(round_num, bid_images, bid_display, estimate=value_int)
    if bid_result == "STOP":
        print("⏹️ 用户已暂停 → 结束当前出价，不记金额错误、不执行流程B")
        return False
    if bid_result == "SKIP":
        print("⏭️ 用户跳过出价，直接进入下一回合检测")
        return True
    if bid_result == "WAIT_ROUND":
        return True
    if not bid_result:
        if 出价失败也留房(round_num, "金额校验/出价面板"):
            return True
        print("⚠️ 出价失败（金额校验失败或面板消失），执行流程B退出本局")
        走流程B()
        return False
    记一回合(round_num, value_str, bid_display)
    return True


def 跑一局拍卖(resume_round=0, resumed=False):
    global current_rounds, high_first_round, low_first_round, LAST_OPPONENT_BIDS, SECOND_HISTORY
    global running
    # 内存熔断：吃太多就自己停，整机死机比少挂几局亏得多
    if 内存熔断():
        running = False
        return
    auction_floor_bid = 选保底价()
    try:
        _PREV_EST_FOR_VISION[0] = 0      # 新的一局：清掉上一局的估价基准
        _SPECIAL_FIRST_ROUND.clear()      # 新的一局：特殊藏品首轮价标记清零（按档位）
        _PREV_EST_FOR_BID[0] = 0         # 新的一局：出价用的上回合估价清零
    except Exception:
        pass
    try:
        # 新的一局：清掉上一局的仓库识别缓存。
        # 否则结算时会把"上一局扫到的结果"当成这一局的定论 → 漏锁/误判保留藏品。
        _WAREHOUSE_VISION_ROUNDS.clear()
    except Exception:
        pass
    try:
        # 每 10 局打一条内存 —— 长跑要是越吃越多，翻运行日志一眼就能看出来
        _no = int(globals().get("RUNLOG_AUCTION_NO", 0) or 0)
        if _no % 10 == 1:
            _mem = 进程内存MB()
            if _mem > 0:
                print(f"🧠 进程内存 {_mem} MB（第 {_no} 局）")
            # 内存偏高时把"谁在占"打出来：tracemalloc 按代码行统计，
            # 下次再膨胀，日志里直接指到是哪一行分配没还
            if _mem > 600:
                try:
                    import tracemalloc

                    if tracemalloc.is_tracing():
                        _snap = tracemalloc.take_snapshot()
                        for _stat in _snap.statistics("lineno")[:5]:
                            print(f"   🔍 {_stat}")
                except Exception:
                    pass
            # 顺便收一次垃圾：解释器那套分配器不主动归还，跑久了会看着虚高
            if _mem > 400:
                try:
                    import gc

                    gc.collect()
                except Exception:
                    pass
    except Exception:
        pass
    print(
        f"🎲 本局保底价：{auction_floor_bid:,}"
        f"（候选：{', '.join(f'{x:,}' for x in 保底价候选())}）"
    )
    current_rounds = []
    high_first_round = None
    low_first_round = None
    LAST_OPPONENT_BIDS = []
    SECOND_HISTORY = []
    MY_BIDS.clear()
    TIER_FIRST_ROUND.clear()
    记录新一局()
    if resumed:
        print(
            f"♻️ [断点续接] 从当前画面接回对局，当前第 {int(resume_round or 0)} 回合；"
            f"入场费不重复记账"
        )
        记回合事件(
            "auction_resume",
            human=f"♻️ 从第 {int(resume_round or 0)} 回合画面接回对局（不重复记入场费）",
            resume_round=int(resume_round or 0),
            floor_bid=auction_floor_bid,
        )
    else:
        记一局成本("entry", COST_ENTRY_FEE, "入场费")
        记回合事件(
            "auction_start",
            human=f"🎬 第 {RUNLOG_AUCTION_NO} 局开始（已扣入场费 {COST_ENTRY_FEE:,}，保底价 {auction_floor_bid:,}）",
            cost_entry=COST_ENTRY_FEE,
            floor_bid=auction_floor_bid,
            保底价候选=保底价候选(),
            version=APP_VERSION,
        )
        print("⏳ 等待 step5 出现...")
        等图出现("step5.png", "step5出现")

    round_num = int(resume_round or 0) if resumed else 重试读回合()
    if round_num == 0:
        关拍卖("exit", note="回合号识别失败，流程B退出")
        走流程B()
        return
    if resumed:
        刷新回合状态(round_num)
        try:
            if 关出价面板(quiet=False):
                print("♻️ [断点续接] 已关闭残留出价面板，回到当前回合")
                if not 歇一下(0.25):
                    return
        except Exception:
            pass

    # 撞果盘的"福利多多局"一律不用仪器 → 绝不能点这个按钮：
    # 实测 16:55 那局就是在这里点开了仪器列表，把出价面板挡住了 → 出价面板读不到 → 白退一个福利多多局。
    if _GP_BONUS_MODE[0]:
        print("⏭️ [撞果盘] 福利多多局：不点仪器（不用道具、不打开仪器列表）")
    else:
        _step5_timeout = 2.0 if 快没时间了吗() else 10
        找到就点("step5.png", "点击step5", timeout=_step5_timeout)

    # 断点续接时如果当前回合的出价窗口已经关闭，游戏不允许补出价。
    # 确认已在结算就接结算；否则直接受控退出该局，绝不拖到下一回合。
    if (
        resumed
        and not 画面有吗("btn_bid.png", timeout=0)
        and not 画面有吗(BID_DIGIT_CHECK_IMAGE, timeout=0)
    ):
        _bid_live = False
        for _ in range(5):
            if not 歇一下(0.4):
                return
            if 画面有吗("btn_bid.png", timeout=0) or 画面有吗(
                BID_DIGIT_CHECK_IMAGE, timeout=0
            ):
                _bid_live = True
                break
        if not _bid_live:
            # 先等一小会儿（默认 10 秒）。
            # 11-05 那种「竞拍第1回合 / 00:00 / 出价键灰」的画面，多数是界面卡在半拍上，
            # 过几秒会自己跳到下一回合或结算；直接受控退出反而退不动，21 秒一轮连撞 4 小时。
            _adv_kind, _adv_round = 继续后等下一回合(round_num)
            if _adv_kind == "advance":
                round_num = _adv_round
                _bid_live = True
                try:
                    记回合事件(
                        "resume_window_reopened",
                        human=f"✅ 断点续接：出价键回来了，接着打第 {round_num} 回合",
                        round=round_num,
                    )
                except Exception:
                    pass
            elif _adv_kind == "settled":
                走结算()
                return
            elif _adv_kind == "hall":
                return
        if not _bid_live:
            _state = 认流程页()
            if _state == rc.Screen.REWARD_TIP:
                关卖出提示()
                _state = 认流程页()
            if _state == rc.Screen.SETTLEMENT:
                print(
                    f"🏁 [断点续接] 第 {round_num} 回合已错过出价窗口，"
                    f"当前已在结算 → 接回结算流程"
                )
                走结算()
                return
            if _state == rc.Screen.HALL:
                print("ℹ️ [断点续接] 画面已经回大厅，结束本次续接")
                return
            print(
                f"🚪 [断点续接] 第 {round_num} 回合已错过出价窗口，"
                f"无法补出价 → 受控退出该局，等回大厅后重开"
            )
            try:
                写日志(f"🚪 [断点续接] 第 {round_num} 回合错过出价窗口，退出该局")
                记回合事件(
                    "resume_missed_window",
                    human=f"🚪 断点续接时第 {round_num} 回合已错过出价窗口，退出该局",
                    round=round_num,
                    screen=_state,
                )
            except Exception:
                pass
            关拍卖("exit", note=f"断点续接时第{round_num}回合出价窗口已过")
            走流程B()
            return

    while running:
        if round_num == 1:
            if not 走第1回合():
                return
        elif round_num == 2:
            if not 走第2回合():
                return
        elif 3 <= round_num <= 6:
            if not 走普通回合(round_num):
                return
        else:
            关拍卖("exit", note=f"未知回合号 {round_num}，流程B退出")
            走流程B()
            return

        next_round = 等下一回合(round_num)

        if next_round == -2:
            return
        if next_round == -1 or next_round == 0 or next_round == -3 or next_round <= round_num:
            confirmed, observed = 等完确认结算(round_num)
            if confirmed:
                print("⚠️ 已二次确认进入结算页面，继续结算")
                走结算()
                return
            # 超时或回合号异常但画面仍在对局里：绝不执行结算 OCR。
            msg = (
                f"⚠️ 等第{round_num + 1}回合后未确认结算"
                f"（当前画面：{observed}）→ 交回画面恢复/断点续接"
            )
            print(msg)
            try:
                记回合事件(
                    "round_wait_not_settlement",
                    human=msg,
                    previous_round=round_num,
                    next_round=next_round,
                    observed_screen=observed,
                )
                存回合截图(
                    "round_wait_not_settlement",
                    回合截图区域(),
                    "等待下一回合后仍不是结算，交回画面恢复",
                )
            except Exception:
                pass
            return
        round_num = next_round


# ======================================================================
# 流程B退出熔断 —— 治 11-05 那种「退不出去、21 秒一轮」的死循环
# ======================================================================
def 退出流程成功():
    """流程B真的回到大厅了 = 退出这条路是通的 → 连撞计数清零。"""
    global _EXIT_FAIL_STREAK, _EXIT_FAIL_LAST, _EXIT_FAIL_RESCUE_DONE
    _EXIT_FAIL_STREAK = 0
    _EXIT_FAIL_LAST = 0.0
    _EXIT_FAIL_RESCUE_DONE = 0


def 退出流程失败(where="流程B退出"):
    """流程B没退出去 → 计数。连撞到上限先自救重开，自救也不行就停下载机等人。

    返回 True  = 已经处理过（自救跑了 / 已停机），调用方别再按原逻辑重试；
    返回 False = 还没到上限，按原逻辑返回主循环。
    """
    global _EXIT_FAIL_STREAK, _EXIT_FAIL_LAST, _EXIT_FAIL_RESCUE_DONE
    now = time.time()
    if _EXIT_FAIL_LAST and (now - _EXIT_FAIL_LAST) > EXIT_FAIL_WINDOW:
        _EXIT_FAIL_STREAK = 0
    _EXIT_FAIL_LAST = now
    _EXIT_FAIL_STREAK += 1
    if _EXIT_FAIL_STREAK < EXIT_FAIL_LIMIT:
        print(
            f"⚠️ {where}没成功（第 {_EXIT_FAIL_STREAK}/{EXIT_FAIL_LIMIT} 次，"
            f"{EXIT_FAIL_WINDOW // 60} 分钟内累计）→ 返回主循环重试"
        )
        return False

    _streak_now = _EXIT_FAIL_STREAK
    _EXIT_FAIL_STREAK = 0
    _EXIT_FAIL_LAST = 0.0
    if int(EXIT_FAIL_RESCUE_ROUNDS or 0) > _EXIT_FAIL_RESCUE_DONE:
        _EXIT_FAIL_RESCUE_DONE += 1
        _msg_r = (
            f"🚨 {EXIT_FAIL_WINDOW // 60} 分钟内连续 {_streak_now} 次退不出去"
            f"（第 {_EXIT_FAIL_RESCUE_DONE}/{int(EXIT_FAIL_RESCUE_ROUNDS)} 轮自救：关游戏重开）"
        )
        print(_msg_r)
        try:
            写日志(_msg_r)
            记报错(
                "exit_stuck_rescue",
                _msg_r,
                level="警告",
                extra={"fail_streak": _streak_now, "rescue_round": _EXIT_FAIL_RESCUE_DONE},
            )
            记回合事件(
                "exit_stuck_rescue",
                human=_msg_r,
                fail_streak=_streak_now,
                rescue_round=_EXIT_FAIL_RESCUE_DONE,
            )
        except Exception:
            pass
        if 现在就重启(f"连续 {_streak_now} 次退不出对局"):
            return True
        print("⚠️ 自救没跑起来（多半是没填【游戏启动快捷方式】，或你手动停了）→ 停下载机等你")
    else:
        print("⚠️ 自救已经试过一轮还是退不出去 → 停下载机等你")
    _msg_s = (
        f"⛔ {EXIT_FAIL_WINDOW // 60} 分钟内连续 {_streak_now} 次退不出对局"
        f"（退出按钮点了没反应、确认框也不出来），已停下载机 —— 请人工看一眼游戏画面"
    )
    print(_msg_s)
    try:
        写日志("⛔ " + _msg_s)
        记报错("exit_stuck_stop", _msg_s, level="警告", extra={"fail_streak": _streak_now})
        记回合事件("exit_stuck_stop", human=_msg_s, fail_streak=_streak_now)
        异步报警()
    except Exception:
        pass
    暂停脚本()
    return True


def 继续后等下一回合(round_num, seconds=RESUME_ADVANCE_WAIT):
    """断点续接时出价窗口已过 → 先等一小会儿，看游戏会不会自己往下走。

    11-05 实测那种「竞拍第1回合 / 00:00 / 出价键灰」的画面，直接受控退出时
    ESC 点了没反应、确认框也不出来，21 秒后又回到同一个画面，连撞 4 小时。
    这里先给界面一个自己推进的机会：出价键回来了就接着打，进结算就接结算，
    回大厅就收工；只有真的纹丝不动，才按原逻辑受控退出。

    返回 (kind, round)：
      ("advance", r) 出价键回来了，可以接着打第 r 回合
      ("settled", 0) 已经进结算 / 奖励弹窗
      ("hall",    0) 已经回大厅
      ("stuck",   0) 没动静，调用方按原逻辑退出
    """
    try:
        seconds = float(seconds or 0)
    except Exception:
        seconds = 0.0
    if seconds <= 0 or not running:
        return ("stuck", 0)
    print(
        f"⏳ [断点续接] 第 {round_num} 回合出价窗口已过，先等 {seconds:.0f} 秒"
        f"看画面会不会自己推进"
    )
    t0 = time.time()
    while time.time() - t0 < seconds:
        if not running:
            return ("stuck", 0)
        if not 歇一下(0.8):
            return ("stuck", 0)
        try:
            _st = 认流程页()
        except Exception:
            _st = rc.Screen.UNKNOWN
        if _st in (rc.Screen.SETTLEMENT, rc.Screen.REWARD_TIP):
            print("🏁 [断点续接] 等待期间已经进入结算/奖励画面")
            return ("settled", 0)
        if _st == rc.Screen.HALL:
            print("ℹ️ [断点续接] 等待期间画面已经回大厅")
            return ("hall", 0)
        try:
            _bid_back = 画面有吗("btn_bid.png", timeout=0) or 画面有吗(
                BID_DIGIT_CHECK_IMAGE, timeout=0
            )
        except Exception:
            _bid_back = False
        if _bid_back:
            _r = 重试读回合(attempts=2, gap=0.4)
            if _r > 0:
                print(f"✅ [断点续接] 出价键回来了，当前第 {_r} 回合 → 接着打这一局")
                return ("advance", _r)
            print(f"✅ [断点续接] 出价键回来了但回合号没读到 → 按第 {round_num} 回合接着打")
            return ("advance", round_num)
    print(f"⚠️ [断点续接] 等了 {seconds:.0f} 秒画面纹丝不动 → 按原逻辑受控退出该局")
    return ("stuck", 0)


def 第4步做完了():
    global _MATCH_STEP4_FAIL_STREAK, _MATCH_STEP4_FAIL_LAST, _MATCH_STEP4_LOW_FUNDS_STREAK
    global _MATCH_STEP4_RESCUE_DONE
    _MATCH_STEP4_FAIL_STREAK = 0
    _MATCH_STEP4_FAIL_LAST = 0.0
    _MATCH_STEP4_LOW_FUNDS_STREAK = 0
    _MATCH_STEP4_RESCUE_DONE = 0  # 开出一局新的 = 这一轮恢复了，自救次数清零


def 第4步没成():
    global _MATCH_STEP4_FAIL_STREAK, _MATCH_STEP4_FAIL_LAST, _MATCH_STEP4_LOW_FUNDS_STREAK
    global _MATCH_STEP4_RESCUE_DONE, running
    now = time.time()
    try:
        if _MATCH_STEP4_FAIL_LAST and (now - _MATCH_STEP4_FAIL_LAST) > MATCH_STEP4_FAIL_WINDOW:
            _MATCH_STEP4_FAIL_STREAK = 0
    except Exception:
        pass
    _MATCH_STEP4_FAIL_LAST = now
    _MATCH_STEP4_FAIL_STREAK += 1

    _funds = ""
    try:
        _funds = 读当前资产() or ""
    except Exception:
        _funds = ""
    _funds_low = False
    if _funds:
        try:
            _funds_low = int(_funds) < STOP_BELOW_FUNDS
        except Exception:
            _funds_low = False
    _MATCH_STEP4_LOW_FUNDS_STREAK = (_MATCH_STEP4_LOW_FUNDS_STREAK + 1) if _funds_low else 0
    if _funds_low and _MATCH_STEP4_LOW_FUNDS_STREAK >= 2:
        msg = (
            f"⛔ 资金不足：当前资金 {int(_funds):,} 低于阈值 {STOP_BELOW_FUNDS:,}，付不起入场费"
            f"（连续 2 次读到，所以找不到【确认扣除入场费】），脚本停止挂机"
        )
        print("🚨 " + msg)
        try:
            记报错("funds_stop", msg, extra={"funds": _funds, "threshold": STOP_BELOW_FUNDS})
        except Exception:
            pass
        try:
            记回合事件("funds_stop", human=msg, funds=_funds, threshold=STOP_BELOW_FUNDS)
        except Exception:
            pass
        _MATCH_STEP4_FAIL_STREAK = 0
        _MATCH_STEP4_FAIL_LAST = 0.0
        _MATCH_STEP4_LOW_FUNDS_STREAK = 0
        running = False
        return True

    if _MATCH_STEP4_FAIL_STREAK < MATCH_STEP4_FAIL_LIMIT:
        print(
            f"⚠️ 没找到【确认扣除入场费】（第 {_MATCH_STEP4_FAIL_STREAK}/{MATCH_STEP4_FAIL_LIMIT} 次，"
            f"{MATCH_STEP4_FAIL_WINDOW // 60} 分钟内的失败才累计），返回主循环重试"
            + (f"；资金读到 {int(_funds):,}" if _funds else "")
            + ("（低于阈值，再确认一次就停）" if _funds_low else "")
        )
        return False
    # 到上限了：先自救一轮（关游戏重开），重开完还是这样才停下等人。
    #   为什么：10-03 实测连续 102 次、35 分钟都卡在这个点上，最后只能手动按【停止】才结束 ——
    #   与其停在原地等人，不如先让脚本自己重开一次（约 2~7 分钟）。
    _rescue_could_not_run = False
    _streak_now = _MATCH_STEP4_FAIL_STREAK  # 下面会清零，先把次数记下来写进消息
    if int(MATCH_STEP4_RESCUE_ROUNDS or 0) > _MATCH_STEP4_RESCUE_DONE:
        _MATCH_STEP4_RESCUE_DONE += 1
        _msg_r = (
            f"🚨 {MATCH_STEP4_FAIL_WINDOW // 60} 分钟内累计 {_streak_now} 次"
            f"找不到【确认扣除入场费】→ 先自救一轮"
            f"（第 {_MATCH_STEP4_RESCUE_DONE}/{int(MATCH_STEP4_RESCUE_ROUNDS)} 轮：关游戏重开）"
        )
        print(_msg_r)
        try:
            写日志(_msg_r)
            记报错(
                "match_stuck_rescue",
                _msg_r,
                level="警告",
                extra={
                    "fail_streak": _streak_now,
                    "funds": _funds,
                    "rescue_round": _MATCH_STEP4_RESCUE_DONE,
                },
            )
            记回合事件("match_stuck_rescue", human=_msg_r, rescue_round=_MATCH_STEP4_RESCUE_DONE)
        except Exception:
            pass
        _MATCH_STEP4_FAIL_STREAK = 0
        _MATCH_STEP4_FAIL_LAST = 0.0
        _MATCH_STEP4_LOW_FUNDS_STREAK = 0
        if 现在就重启(f"累计 {MATCH_STEP4_FAIL_LIMIT} 次找不到【确认扣除入场费】"):
            return False  # 自救成功 → 交回主循环接着跑
        _rescue_could_not_run = True
        print(
            "⚠️ 自救没跑起来（多半是没填【游戏启动快捷方式】，或你手动停了）→ 按原来的方式停下等你"
        )
    msg = (
        f"⛔ {MATCH_STEP4_FAIL_WINDOW // 60} 分钟内累计 {_streak_now} 次"
        f"找不到【确认扣除入场费】，"
        + (
            "自救没能跑起来"
            if _rescue_could_not_run
            else f"自救 {int(MATCH_STEP4_RESCUE_ROUNDS)} 轮也没好"
        )
        + "，判定卡住并停止挂机（不关脚本、不动游戏）"
    )
    if _funds:
        msg += f"，当前资金 {int(_funds):,}（没低于阈值 {STOP_BELOW_FUNDS:,}）"
    print("🚨 " + msg)
    try:
        记报错("match_stuck", msg, extra={"funds": _funds, "threshold": STOP_BELOW_FUNDS})
    except Exception:
        pass
    try:
        记回合事件("match_stuck", human=msg, funds=_funds, threshold=STOP_BELOW_FUNDS)
    except Exception:
        pass
    _MATCH_STEP4_FAIL_STREAK = 0
    _MATCH_STEP4_FAIL_LAST = 0.0
    _MATCH_STEP4_LOW_FUNDS_STREAK = 0
    running = False
    return True


def 今天点过日常了(now=None):
    """今天的「每日定时点击」跑完了没有。

    判定：排定的时间已经滚到"明天"（只有真正点完才会滚），且这个功能没关掉。
    功能关掉 / 还没排上 → 也算"不用等"。
    """
    try:
        if int(DAILY_CLICK_ENABLED or 0) != 1:
            return True
        t = now or datetime.now()
        if daily_click_next_time is None:
            return True
        return daily_click_next_time.date() > t.date()
    except Exception:
        return True


def 守住日常弹窗(where="开局前"):
    """开局前顺手看一眼：画面上还有没有月卡/领奖弹窗 —— 有就点掉。
    为什么单独做这一层：定时点击只在 05:00:30 那一小段查，如果那台机器弹窗出来得晚，
    就会"没看到→当成没有"，紧接着开局被弹窗挡住、找不到【开始匹配】
    （另一台电脑 10-15 实测：05:00:30 没看到、05:02:57 卡在找开始匹配）。"""
    try:
        for img in (DAILY_CARD_IMAGE, DAILY_REWARD_TIP_IMAGE):
            ok, _x, _y = 屏幕找东西(img, timeout=0)
            if ok:
                print("🛡️ %s：画面上还有弹窗（%s）→ 先点掉再开局" % (where, img))
                日常点一次()
                return True
    except Exception as e:
        print("（开局前弹窗检查跳过：%s）" % e)
    return False


def 日常按住生效():
    """现在是不是"04:50 起要守月卡、今天的定时点击还没跑完"的时段。

    用途：① 等日常点完 用它判断要不要守；② 大厅那一层用它决定
    "守之前要不要先把该点的点掉"（要求：必须在大厅等着）。
    窗口外 / 今天已经跑完 / 功能关着 → 一律 False（不花时间）。
    """
    try:
        if int(DAILY_CLICK_ENABLED or 0) != 1:
            return False
        now = datetime.now()
        if now.hour * 60 + now.minute < int(DAILY_CLICK_HOLD_FROM_MIN):
            return False
    except Exception:
        return False
    return not 今天点过日常了()


def 等日常点完(where="开局前"):
    """04:50 起不开新局：等当天的「每日定时点击」（月卡弹窗）跑完，然后继续。

    为什么：月卡界面每天 05:00 前后自动弹出来盖住画面，定时点击（04:59:00~05:05:00，
    每 10 秒一个节拍）去点它。
    这段时间开新局必被打断 —— 实测 10-03~10-13 有 20 次"估价异常 / 回合号识别失败"退局、
    白亏 62 万，其中 7 次正好落在 05:00:0x~05:00:5x。
    点掉就正常继续流程（DAILY_CLICK_AFTER_WAIT = 0，不再多等 2 分钟）；
    盯到 05:05 还没点掉时，定时点击那边会激活一下游戏、用新画面重新识别再点一次。

    和「卡死自救」的关系：守着的时候 `_DAILY_WAIT` 置 True → `等用户操作()` 返回 True
    → 看门狗（重启线程）每轮都把 LAST_PROGRESS_TS 清零，绝不会把这段等待当成卡死。
    窗口外 / 今天的定时点击早就跑完 → 立刻返回 False，不花时间。
    """
    if not 日常按住生效():
        return False
    _hh, _mm, _ss = int(DAILY_CLICK_HOUR), int(DAILY_CLICK_MINUTE), int(DAILY_CLICK_SECOND)
    _tail = int(DAILY_CLICK_AFTER_WAIT)
    if _tail <= 0:
        _tail_txt = "0 秒"
    elif _tail >= 60:
        _tail_txt = "%d 分钟" % (_tail // 60)
    else:
        _tail_txt = "%d 秒" % _tail
    print(
        f"⏳ 现在是每日月卡时段（{where}）→ 先不开新局：等【每日定时点击】"
        f"{_hh:02d}:{_mm:02d}:{_ss:02d} 起的月卡弹窗检查跑完"
        + ("，点完再等 %s" % _tail_txt if _tail > 0 else "（点掉就正常继续）")
    )
    _DAILY_WAIT[0] = True
    t0 = time.time()
    last_beat = time.time()
    try:
        碰一下进度("等每日月卡弹窗")
        while (
            running and not 今天点过日常了() and (time.time() - t0) < DAILY_CLICK_HOLD_MAX
        ):
            if time.time() - last_beat >= 60:
                last_beat = time.time()
                print("   …还在等【每日定时点击】跑完（月卡弹窗）")
                碰一下进度("等每日月卡弹窗")
            if not 歇一下(1):
                break
        if 今天点过日常了():
            print(
                "✅ 每日定时点击已结束 → "
                + ("再等 %s 就继续开局" % _tail_txt if _tail > 0 else "正常继续开局")
            )
            if running and int(DAILY_CLICK_AFTER_WAIT) > 0:
                歇一下(int(DAILY_CLICK_AFTER_WAIT))
        else:
            print(
                "⚠️ 每日定时点击超过 %d 分钟还没结束 → 不等了，继续（看门狗不会把这段当卡死）"
                % (int(DAILY_CLICK_HOLD_MAX) // 60)
            )
    finally:
        _DAILY_WAIT[0] = False
    print("▶️ 每日月卡时段结束，继续开局（%s）" % where)
    return True


# 提示框左下那颗【取消】。从 10-14 那张"一键补全"提示框截图里
# 精确裁出来的（56x28，和【确认】同一款按钮、同一排）；游戏的提示框都是"左取消 / 右确认"。
STEP_CANCEL_IMAGE = "step_cancel.png"
# 提示框正中间那行字的位置（1920x1080 客户区坐标）—— 用来分清是哪个提示框：
# "是否消耗XX金贝铢一键补全?" → 用【确认】（把仪器补全做完）
# "确认扣除入场费"（或别的）   → 用【取消】（必须留在大厅等月卡，绝不能进局）
DIALOG_TEXT_REGION = (700, 555, 560, 95)


def 对话框区域():
    win = 游戏窗口范围()
    if win is None:
        return None
    left, top, _, _ = win
    dl, dt, dw, dh = DIALOG_TEXT_REGION
    return (left + dl, top + dt, dw, dh)


def 现在对话框文字():
    """读提示框正中间那行字（读不到/没框 → 空串）。"""
    try:
        region = 对话框区域()
        if region is None:
            return ""
        return 识别区域文字(region, retry=2).strip()
    except Exception as e:
        print("（读提示框文字失败：%s）" % e)
        return ""


def 日常收尾(where="守月卡前"):
    """ "先把手上没做完的手续办完，再守月卡"。

    为什么：守月卡的那十几分钟里，屏幕上只要留着一个没点掉的框，月卡弹窗就被它压住 ——
    连盲点也点不到它。最典型的就是【一键补全】弹出来的
    「是否消耗70,000金购买一副补全?」（另一台电脑 10-17 实测）；
    更糟的是：等月卡时段过去，那个【确认】已经失效 → 开局流程找不到它就直接放弃 →
    游戏停在仪器组页面 → 主循环认不到大厅 → 只能卡到 5 分钟自救。

    所以认不到大厅时先来这里看一眼（要求："如果有需要点掉的东西就点掉，
    比如需要补全仪器，那就补全完仪器，再到大厅主页面等着"）：
      · 停在【一键补全】上 → 点掉它（= 把仪器补全做完）；
      · 画面上有提示框（左取消 / 右确认，两个模板同一款按钮）：
          "…一键补全?" → 点【确认】把仪器补全做完；
          别的（最典型「确认扣除入场费」）→ 点【取消】—— 守月卡必须留在大厅，绝不能进局；
      · 刚点过仪器组页面上的东西 → 顺手点右上角 × 回大厅主页面。
    返回 True = 动过手脚（调用方重新判断一次大厅 → 认到大厅就回去守月卡 / 正常开局）。

    安全阀：对局中（in_auction）一律不动；调用方最多连续处理 3 轮就交回原来的恢复流程。
    注意：【开始匹配】那个按钮（step3.png）大厅里也有，绝不能拿它当"在仪器组页面"的标志，
      否则大厅识别偶发失败时会去点 (1093,161) 那个 ×，误关/误点大厅里的东西；
      "功能强大的仪器组…"那行字大厅的拍卖卡片上也有，所以也不能拿它当"在仪器组页面"的标志
      —— 关页面只认"这一轮刚点过那页上的东西"。
    """
    try:
        if in_auction:
            return False
    except Exception:
        pass
    did = False
    try:
        if 画面有吗("step2.png", timeout=0):
            print("🧹 %s：先把【一键补全】点掉（仪器补全做完再守月卡）" % where)
            找到就点("step2.png", "补全仪器", timeout=2, report_timeout=False)
            if not 歇一下(1.0):
                return did
            did = True
        # 画面上那颗提示框按钮（左取消 / 右确认，两个模板同一款）：
        #   · 「是否消耗…一键补全?」→ 点【确认】把仪器补全做完（要求：该点的就点掉）；
        #   · 别的（最典型是「确认扣除入场费」）→ 点【取消】，必须留在大厅等月卡，绝不能进局。
        _has_dialog = 画面有吗(
            "step_confirm_consume.png", timeout=0
        ) or 画面有吗("step4.png", timeout=0)
        if _has_dialog:
            _dtxt = 现在对话框文字()
            if "补全" in _dtxt:
                print("🧹 %s：提示框是『一键补全』（读到『%s』）→ 点【确认】做完" % (where, _dtxt))
                找到就点(
                    "step_confirm_consume.png", "确认消耗（补全）", timeout=2, report_timeout=False
                )
            else:
                print(
                    "🧹 %s：提示框不是补全（读到『%s』）→ 点【取消】，留在大厅等月卡"
                    % (where, _dtxt)
                )
                找到就点(STEP_CANCEL_IMAGE, "取消（不入局）", timeout=2, report_timeout=False)
            if not 歇一下(1.0):
                return did
            did = True
        # 关页面：只认"这一轮刚点过仪器组页面上的东西"（= 一定在那一页）。
        #   不能认"功能强大的仪器组…"那行字 —— 大厅的拍卖卡片上也有它（10-03 截图确认过）。
        _on_page = did
        _win = 游戏窗口范围()
        if _on_page and _win is not None and not 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            print("🧹 %s：关掉仪器组页面，回大厅主页面" % where)
            关仪器页(quiet=True)
            if not 歇一下(1.0):
                return did
            did = True
    except Exception as e:
        print("（守月卡前收尾跳过：%s）" % e)
    return did


# ============================================================================
# 自动撞果盘
# ============================================================================
AUTO_ENTER_FLAG = os.path.join(RUNLOG_DIR, "_面板_撞果盘.flag")


def 自动进场开关开着吗():
    """面板【启动撞果盘】= 往这个文件写 1；【停止】= 写 0。读不到就当关着（最安全）。"""
    try:
        with open(AUTO_ENTER_FLAG, encoding="utf-8") as fh:
            return fh.read().strip() == "1"
    except Exception:
        return False


def 设自动进场开关(on):
    try:
        with open(AUTO_ENTER_FLAG, "w", encoding="utf-8") as fh:
            fh.write("1" if on else "0")
        return True
    except Exception:
        return False


# ---------- 北京时间（联网校时；校不上就用本机时间兜底，绝不挡功能）----------
_GP_CLOCK = {"offset": 0.0, "src": "本机时间", "ok": False, "at": 0.0}
_GP_WARNED = [False]


def 碰果盘时间偏移(host, timeout=2.0):
    """向 NTP 服务器问一次时间，返回「服务器 - 本机」的秒差。"""
    import socket
    import struct

    pkt = bytearray(48)
    pkt[0] = 0x1B
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sk:
        sk.settimeout(timeout)
        t0 = time.time()
        sk.sendto(bytes(pkt), (host, 123))
        data, _addr = sk.recvfrom(64)
        t3 = time.time()
    if len(data) < 48:
        raise ValueError("NTP 回应太短")
    u = struct.unpack("!12I", data[:48])
    t1 = u[8] + float(u[9]) / 2**32 - 2208988800
    t2 = u[10] + float(u[11]) / 2**32 - 2208988800
    return ((t1 - t0) + (t2 - t3)) / 2.0


def 碰果盘网络偏移(url, timeout=4.0):
    """退而求其次：拿网页响应头里的 Date（GMT）当参考。"""
    import email.utils
    import urllib.request

    req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "Mozilla/5.0"})
    t0 = time.time()
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        t1 = time.time()
        date_hdr = resp.headers.get("Date")
    if not date_hdr:
        raise ValueError("响应里没有 Date 头")
    server = email.utils.parsedate_to_datetime(date_hdr).timestamp()
    return server - (t0 + t1) / 2.0


def 对时(force=False, quiet=False):
    """对一次北京时间。成功返回 True。

    NTP_TIME_SOURCE = 0 → 直接用本机时间（不联网）。
    校时结果存在 _GP_CLOCK["offset"]，之后 现在自动进场() 一直用它，不用每次都联网。
    """
    if int(NTP_TIME_SOURCE or 0) != 1:
        _GP_CLOCK.update(offset=0.0, src="本机时间", ok=True, at=time.time())
        return True
    now = time.time()
    if (not force) and _GP_CLOCK["ok"] and (now - _GP_CLOCK["at"]) < float(RESYNC_SEC):
        return True
    got = []
    for host in NTP_HOSTS:
        try:
            off = 碰果盘时间偏移(host)
            if abs(off) > 24 * 3600:
                raise ValueError("偏差大得不像校时结果")
            got.append((off, host))
        except Exception:
            continue
    if got:
        # 多个 NTP 都通时取中位数（个别服务器抽风也不会带偏）
        off = sorted(x[0] for x in got)[len(got) // 2]
        src = "NTP " + ",".join(h for _o, h in got)
        _GP_CLOCK.update(offset=off, src=src, ok=True, at=time.time())
        print(
            "🕐 [撞果盘] 校时成功（%s）：和本机差 %+.2f 秒，现在北京时间 %s"
            % (src, -off, 现在自动进场().strftime("%H:%M:%S"))
        )
        return True
    for url in HTTP_HOSTS:
        try:
            off = 碰果盘网络偏移(url)
            if abs(off) > 24 * 3600:
                raise ValueError("偏差大得不像校时结果")
            _GP_CLOCK.update(offset=off, src="网页 %s" % url, ok=True, at=time.time())
            print(
                "🕐 [撞果盘] 校时成功（网页 %s）：和本机差 %+.2f 秒，现在北京时间 %s"
                % (url, -off, 现在自动进场().strftime("%H:%M:%S"))
            )
            return True
        except Exception:
            continue
    _GP_CLOCK.update(offset=0.0, src="本机时间（校时失败）", ok=False, at=time.time())
    if not quiet and not _GP_WARNED[0]:
        _GP_WARNED[0] = True
        print(
            "⚠️ [撞果盘] 联网校时失败（NTP 和网页都没通）→ 先用本机时间跑。"
            "要让时间准，请确认这台电脑能上网，或把『时间参考』改成 0（明确用本机时间）。"
        )
    return False


def 现在自动进场():
    """当前北京时间（本机时间 + 校时偏差 + 8 小时）。"""
    return datetime.utcnow() + timedelta(hours=8) + timedelta(seconds=float(_GP_CLOCK["offset"]))


# ---------- 名字：读（OCR）+ 比（命中几个）----------
_GP_NAME_PUNCT = re.compile(r"[\s\u3000·．.,，、:：;；_\-—|/\\()（）\[\]【】<>《》\"'`~!！?？]")


def 碰果盘名字归一(t):
    """名字去掉空格和标点，方便比对（OCR 偶尔多认个点或空格）。"""
    if not t:
        return ""
    t = str(t).translate(str.maketrans("０１２３４５６７８９", "0123456789"))
    return _GP_NAME_PUNCT.sub("", t).strip()


def 等名单():
    """配置里想等的名字，最多 10 个。"""
    out = []
    for part in re.split(r"[,，;；、\s\u3000]+", str(WAIT_NAMES or "")):
        p = 碰果盘名字归一(part)
        if p and p not in out:
            out.append(p)
    return out[:10]


def 数名字命中(seen, want):
    """seen = 读到的名字，want = 想等的名字。双向包含或相似度达到 50% 就算命中。"""
    hits = []
    for w in want or []:
        for s in seen or []:
            if not w or not s:
                continue
            exact_or_part = w in s or s in w
            try:
                score = SequenceMatcher(None, w, s).ratio()
            except Exception:
                score = 0.0
            if exact_or_part or score >= float(WAIT_NAME_RATIO):
                hits.append(w)
                break
    return hits


def 读玩家名字():
    """读左边 4 个玩家的名字（OCR 那 4 个名字胶囊）。"""
    win = 游戏窗口范围()
    if win is None:
        return []
    left, top, _w, _h = win
    out = []
    for idx, row_y in enumerate(WAIT_NAME_ROWS):
        txt = ""
        try:
            region = (
                int(left + WAIT_NAME_X),
                int(top + row_y),
                int(WAIT_NAME_W),
                int(WAIT_NAME_H),
            )
            shot = 抓一帧(region=region)
            img = np.array(shot)
            img = cv2.resize(img, None, fx=2.5, fy=2.5, interpolation=cv2.INTER_CUBIC)
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            txt = 拼识别文字(ocr.ocr(img_rgb, cls=True))
        except Exception as e:
            print("⚠️ [撞果盘] 读第%d位名字出错：%s" % (idx + 1, e))
        nm = 碰果盘名字归一(txt)
        print("   👤 [撞果盘] 第%d位：%s" % (idx + 1, nm if nm else "（没读到）"))
        if nm:
            out.append(nm)
    return out


# ---------- 场地效果 ----------
def 场地状态():
    """'bonus' = 福利多多 / 'dark' = 天黑了 / 'none' = 没认出来。"""
    try:
        region = 天黑区域()
        if region is None:
            return "none"
        gray = 抓灰度图(region)
        tpl = 读图片模板(BONUS_VENUE_IMAGE)
        if tpl is not None and 最佳模板匹配(gray, tpl, BONUS_THRESHOLD)[0]:
            return "bonus"
        tpl2 = 读图片模板(DARK_VENUE_IMAGE)
        if tpl2 is not None and 最佳模板匹配(gray, tpl2)[0]:
            return "dark"
    except Exception as e:
        print("⚠️ [撞果盘] 判场地效果出错：%s" % e)
    return "none"


def 场地栏文字():
    """把「场地效果」栏那一行的字读出来（纯黑白 + 取最上面那行）。

    用途：只要栏里有字、又不是"福利多多" → 直接退（要求：不是福利多多就直接退，
    不用去分是哪个别的场地）。读不到就返回空串，调用方继续等（防"栏还没画出来"就误退）。
    """
    try:
        region = 天黑区域()
        if region is None:
            return ""
        shot = 抓一帧(region=region)
        img = np.array(shot)
        bw = np.where(img.max(axis=2) > BID_AMOUNT_BIN_THRESHOLD, 255, 0).astype(np.uint8)
        res = ocr.ocr(np.dstack([bw, bw, bw]), cls=True)
        lines = []
        for line in res[0] or []:
            try:
                box = line[0]
                t = str(line[1][0] or "").strip()
            except Exception:
                continue
            if not t:
                continue
            ys = [float(p[1]) for p in box]
            lines.append((min(ys), max(ys) - min(ys), t))
        if not lines:
            return ""
        for _y, _h, t in lines:  # 先找"福利多多"
            if "福利多多" in t:
                return t
        lines.sort()  # 没认得的 → 取最上面那行（场地栏在最上面）
        return lines[0][2]
    except Exception as e:
        print("⚠️ [撞果盘] 读场地栏文字出错：%s" % e)
        return ""


def 等场地(timeout=None):
    """等【场地效果】判定：'bonus' / 'dark' / 'none'（none = 没认出来）。

    分两段，别让"进房间的加载时间"把判场地的预算吃掉：
      ① 先等【房间画面】出现（仪器按钮 step5，跟正常流程用的是同一个信号），
         最多 ROOM_WAIT_SEC 秒；这段是游戏加载（实测 20~59 秒，中位 32 秒），
         场地效果和房间是同一个界面，所以它一出来场地效果就能读了。
      ② 房间到了之后再读 timeout 秒（= 面板上"进局后最多等几秒判场地"，默认 25）：读不到才算"不是它"。
    """
    try:
        room_cap = float(ROOM_WAIT_SEC)
    except Exception:
        room_cap = 90.0
    if timeout is None:
        try:
            timeout = float(VENUE_WAIT_SEC)
        except Exception:
            timeout = 25.0
    # ① 等房间画面
    t0 = time.time()
    while running and 自动进场开关开着吗():
        st = 场地状态()
        if st != "none":
            print("🎲 [撞果盘] 场地效果直接认到了（进局 %.1f 秒）" % (time.time() - t0))
            return st
        if 画面有吗("step5.png", timeout=0):
            print(
                "✅ [撞果盘] 房间画面到了（进局等了 %.1f 秒）→ 开始读场地效果" % (time.time() - t0)
            )
            break
        if time.time() - t0 >= room_cap:
            print("⚠️ [撞果盘] 等了 %d 秒还没进房间 → 按『没认到场地效果』处理" % int(room_cap))
            return "none"
        if not 歇一下(0.6):
            return "none"
    # ② 房间到了 → 读场地效果（先给 FAST_JUDGE_SEC 秒让他画栏，之后补读一次文字）
    t1 = time.time()
    _junk_once = False
    try:
        fast_gap = float(FAST_JUDGE_SEC)
    except Exception:
        fast_gap = 1.2
    while running and 自动进场开关开着吗():
        st = 场地状态()
        if st != "none":
            return st
        _el = time.time() - t1
        if _el >= fast_gap:
            _txt = 场地栏文字()
            if _txt:
                if "福利多多" in _txt:
                    print("🍀 [撞果盘] 场地栏读字认到：%s（模板没认到、文字认到了）" % _txt)
                    return "bonus"
                if "保险箱" in _txt:
                    # 读到的是保险箱那行（说明场地栏本身还没画出来）→ 继续等，别误退
                    if not _junk_once:
                        _junk_once = True
                        print(
                            "ℹ️ [撞果盘] 场地栏还没画出来（读到『%s』）→ 继续等到 %s 秒"
                            % (_txt, timeout)
                        )
                else:
                    # 不是福利多多就直接退，不去分是哪个别的场地
                    print(
                        "🙅 [撞果盘] 场地效果不是【福利多多】（读到『%s』）→ 直接退出"
                        "（不用等满 %s 秒）" % (_txt, timeout)
                    )
                    return "other"
        if _el >= timeout:
            return "none"
        if not 歇一下(0.4):
            return "none"
    return "none"


# ---------- 等时间 / 等大厅 ----------
def 目标秒数():
    """面板上『每分钟第几秒点【开始匹配】』：留着空（或填 0）就是不按时间。

    要求：时间为空时不按时间匹配 —— 退出一局就立刻接着撞下一局，
    直到撞到"福利多多 + 名字对上"的局为止。
    返回 1~59 的秒数；留空 / 0 / 无效 → None（= 连续撞，不等整分钟）。
    """
    raw = str(ENTER_AT_SECOND if ENTER_AT_SECOND is not None else "").strip()
    if raw in ("", "0", "0.0"):
        return None
    try:
        v = int(float(raw))
    except Exception:
        return None
    return v if 1 <= v <= 59 else None


def 碰果盘下一个目标():
    """下一次『每分钟第 X 秒』的绝对时刻（北京时间）。"""
    now = 现在自动进场()
    _sec = 目标秒数()
    t = now.replace(second=(20 if _sec is None else _sec), microsecond=0)
    if (now - t).total_seconds() > LATE_OK_SEC:
        t = t + timedelta(minutes=1)
    return t


def 等到那个点(t, why="等时间"):
    """等到绝对时刻 t（北京时间）。True = 到点了。"""
    while running and 自动进场开关开着吗():
        left = (t - 现在自动进场()).total_seconds()
        if left <= 0.02:
            return True
        碰一下进度("撞果盘·" + why)
        if not 歇一下(min(max(left, 0.01), 1.0)):
            return False
    return False


def 准备自动进场():
    """【预备】到点前：在拍卖大厅按一下【开始匹配】，停在『确认扣除入场费』弹窗前。

    这样到点只需按"确认"那一下（实测：不预备的话，找图+点开始匹配要吃掉 1~3 秒，卡不准）。
    返回 'dialog'（停在确认弹窗前）/ False（没准备好，卡点时补）。
    注意：撞果盘**完全不碰仪器组页面**（【超级品鉴仪器组】那套不用点，只要开始匹配 + 确认）。
    """
    if not running or not 自动进场开关开着吗():
        return False
    if 画面有吗("step4.png", timeout=0.5):
        print("✅ [撞果盘·预备] 已经停在【确认扣除入场费】弹窗前了")
        return "dialog"
    if not 画面有吗(AUCTION_HALL_IMAGE, timeout=1.5):
        print("ℹ️ [撞果盘·预备] 现在不在拍卖大厅 → 卡点时再补")
        return False
    if not 找到就点("step3.png", "撞果盘·预备·开始匹配", timeout=3, report_timeout=False):
        print("ℹ️ [撞果盘·预备] 大厅里没看到【开始匹配】→ 卡点时再补")
        return False
    if not 歇一下(UI_DELAY):
        return False
    if 画面有吗("step4.png", timeout=2):
        print("✅ [撞果盘·预备] 已停在【确认扣除入场费】弹窗前，卡点只按确认")
        return "dialog"
    print("ℹ️ [撞果盘·预备] 点了开始匹配但没看到确认框（资金不足？）→ 卡点时再补")
    return False


def 开火自动进场():
    """【卡点这一击】到点立刻按下最后一下。返回 'fired'/'retry'/'leave'/'stop'。"""
    if not running or not 自动进场开关开着吗():
        return "stop"
    t0 = time.time()
    # ① 预备停在确认弹窗 → 只按确认（最快，通常 0.2 秒内）
    if 画面有吗("step4.png", timeout=0):
        if not 确认入场并等房间():
            return "retry" if running else "stop"
        print("🎯 [撞果盘] 已确认进入房间，用时 %.2f 秒" % (time.time() - t0))
        return "fired"
    # ② 预备没成功（还在大厅）→ 现在补点：开始匹配 + 确认
    if 找到就点("step3.png", "撞果盘·卡点·开始匹配", timeout=2.5, report_timeout=False):
        print(
            "🎯 [撞果盘] 卡点按下【开始匹配】+【确认】（预备没成功，晚一点）用时 %.2f 秒"
            % (time.time() - t0)
        )
        if not 歇一下(UI_DELAY):
            return "stop"
        if 确认入场并等房间():
            return "fired"
        print("⚠️ [撞果盘] 点了开始匹配却没等到确认框（如果是资金不足，脚本会自动停）")
        第4步没成()
        return "retry"
    # ③ 既没有确认框、也没有【开始匹配】→ 可能不在大厅
    if not 画面有吗(AUCTION_HALL_IMAGE, timeout=1.5):
        print("⚠️ [撞果盘] 卡点时既没预备上、也不在拍卖大厅 → 交回主循环")
        return "leave"
    print("⚠️ [撞果盘] 卡点时没看到【开始匹配】→ 这一轮跳过，等下一分钟")
    return "retry"


def 在大厅等(timeout=None):
    """退出对局后等回到拍卖大厅。"""
    if timeout is None:
        timeout = float(HALL_WAIT_SEC)
    t0 = time.time()
    while running and 自动进场开关开着吗():
        if 画面有吗(AUCTION_HALL_IMAGE, timeout=0):
            return True
        if time.time() - t0 >= timeout:
            return False
        if not 歇一下(0.5):
            return False
    return False


# ---------- 一轮：开局 → 判场地 → 留/退 ----------
def 判断房间():
    """进了房间：判场地效果 + 名字。返回 'keep'/'retry'/'leave'。"""
    print("🎲 [撞果盘] 已进局，等【场地效果】出现（最多 %s 秒）…" % VENUE_WAIT_SEC)
    venue = 等场地()
    if venue == "bonus":
        want = 等名单()
        try:
            need = int(WAIT_NAME_MIN or 0)
        except Exception:
            need = 1
        if not want:
            need = 0
        seen = 读玩家名字()
        hits = 数名字命中(seen, want)
        print(
            "🍀 [撞果盘] 场地效果=福利多多｜读到名字 %s｜命中 %s（需要 %d 个）"
            % (seen or "无", hits or "无", need)
        )
        if len(hits) >= need:
            return "keep"
        print("🙅 [撞果盘] 是福利多多，但名字不够 → 退出对局")
    else:
        # 不是福利多多（天黑了 / 别的场地 / 没认出来）→ 一律退出，不细分
        print("🙅 [撞果盘] 场地效果不是【福利多多】（%s）→ 退出对局" % venue)
    走流程B()
    if not 在大厅等():
        print("⚠️ [撞果盘] 退出后没等到拍卖大厅 → 交回主循环")
        return "leave"
    return "retry"


def 留住房间():
    """命中：不退出对局，并【替你把这一局打完：每回合都固定出 520 占位】（不响警报）。

    撞到「福利多多 + 名字对上」之后：
      · 不算策略、不加价 —— **每一回合都出 BONUS_KEEP_BID（默认 520）**；
      · 这一局照样走正常的出价/校验/结算流程（结算还是按你面板的规则：低于 5121024 就卖等），
        只是出价金额被固定成 520、不用仪器、不做整仓识别（_GP_BONUS_MODE 那段）；
      · 这一注跟面板上的『前两回合保底价（四项每局随机）』没关系，撞果盘单独用 520；
      · **只要已经符合福利多多条件，就绝不再因为金额校验/出价面板失败走流程B**：
        失败时只跳过本回合出价，留在房间等下一回合，避免把撞到的局白退掉；
      · 没人跟 → 这一仓 520 就拿下（海贝场门票是 0，本来就不花钱）；
        有人跟 → 每回合都占个位、几乎不花钱。
    打完这一局自动回到大厅，接着撞下一局。
    """
    msg = (
        "🎯 [撞果盘] 命中：场地效果=福利多多 + 名字对上了 → 不退出对局，"
        "并把这一局打下去（每回合都出占位价）"
    )
    print(msg)
    try:
        写日志(msg)
        记回合事件("guo_pan_hit", human=msg)
    except Exception:
        pass
    # 命中不再响警报 —— 留在对局里把这局打完就行（不打搅、不出声）
    # 交给正常流程打完这一局（出价被强制成 520；不用仪器、不识别整仓）
    _GP_BONUS_MODE[0] = True
    try:
        跑一局拍卖()
    except Exception as e:
        print("⚠️ [撞果盘] 打这一局时出错：%s" % e)
        traceback.print_exc()
    finally:
        _GP_BONUS_MODE[0] = False
    print("✅ [撞果盘] 这一局打完了 → 接着撞下一局")


def 自动进场循环():
    """撞果盘主循环：只有开关开着时主循环才会调它；关掉立刻返回。"""
    if not 自动进场开关开着吗():
        return
    print("\n" + "=" * 56)
    print(
        "🍈 [撞果盘] 进入撞果盘模式：每分钟第 %s 秒点【开始匹配】；只留「福利多多 + 名字对上」的局"
        % ENTER_AT_SECOND
    )
    try:
        对时(force=True)
    except Exception:
        pass
    print(
        "   时间参考：%s｜要等的名字：%s｜至少命中 %s 个"
        % (
            "联网北京时间" if int(NTP_TIME_SOURCE or 0) == 1 else "本机时间",
            等名单() or "（没填 → 不看名字）",
            WAIT_NAME_MIN,
        )
    )
    print("   到点前 %s 秒先把前面几步点完（预备），到点只按最后一下" % PREP_SEC)
    print("   现在（北京时间）%s" % 现在自动进场().strftime("%Y-%m-%d %H:%M:%S"))
    print("=" * 56)
    while running and 自动进场开关开着吗():
        碰一下进度("撞果盘")
        等日常点完("撞果盘前")
        守住日常弹窗("撞果盘前")
        # ① 先等到"预备时刻"（到点前 PREP_SEC 秒），把前面几步点完
        # 『每分钟第几秒』留空（或 0）= 不按时间：退出一局就立刻接着撞下一局
        _sec = 目标秒数()
        if _sec is None:
            print("⏱️ [撞果盘] 没填时间 → 不按时间匹配：这一局做完立刻接着撞下一局")
        else:
            try:
                target = 碰果盘下一个目标()
            except Exception:
                target = None
            if target is None:
                break
            try:
                prep_lead = max(0, int(float(PREP_SEC)))
            except Exception:
                prep_lead = 8
            prep_at = target - timedelta(seconds=prep_lead)
            if (现在自动进场() < prep_at) and not 等到那个点(prep_at, "等预备时刻"):
                break
            print(
                "⏱️ [撞果盘] 预备时刻：%s（北京时间）→ 先把前面几步点掉"
                % 现在自动进场().strftime("%H:%M:%S")
            )
            try:
                prep = 准备自动进场()
            except Exception as e:
                print("⚠️ [撞果盘] 预备出错：%s" % e)
                traceback.print_exc()
                prep = False
            # ② 卡点：等到目标秒，立刻按最后一下
            if not 等到那个点(target, "等卡点"):
                break
        try:
            r = 开火自动进场()
        except Exception as e:
            print("⚠️ [撞果盘] 卡点出错：%s" % e)
            traceback.print_exc()
            r = "retry"
        # ③ 按下去了 → 判场地效果 + 名字
        if r == "fired":
            try:
                r = 判断房间()
            except Exception as e:
                print("⚠️ [撞果盘] 判场地出错：%s" % e)
                traceback.print_exc()
                r = "retry"
        if r == "keep":
            留住房间()
            break
        if r in ("stop", "leave"):
            break
    print("🍈 [撞果盘] 退出撞果盘模式%s" % ("" if running else "（挂机已停下）"))


def 确认入场并等房间():
    global running
    action_epoch = _USER_MOUSE_EPOCH
    posted = 找到就点("step4.png", "确认扣除入场费", timeout=MATCH_STEP4_TIMEOUT)
    deadline = time.monotonic() + (max(3, float(ROOM_WAIT_SEC)) if posted else 3)
    pending_since = None
    while running and time.monotonic() < deadline:
        if 画面有吗("step4.png", timeout=0):
            pending_since = pending_since or time.monotonic()
            if time.monotonic() - pending_since >= 1.5:
                break
        else:
            pending_since = None
            if 画面有吗("step5.png", timeout=0) or 画面有吗("btn_bid.png", timeout=0):
                第4步做完了()
                return True
        if not 歇一下(0.25):
            return False
    if running:
        if CURSOR_YIELD_USER and (action_epoch != _USER_MOUSE_EPOCH or not _鼠标动作仍有效()):
            print("♻️ 入场确认期间发生鼠标接管，交回主循环按当前画面续接")
            return False
        print("⚠️ 入场确认结果不明：已暂停，请检查当前画面；入场费尚未记账")
        running = False
    return False


def 开始匹配到确认框():
    if 画面有吗("step4.png", timeout=0):
        return True
    if not 找到就点("step3.png", "开始匹配", timeout=8):
        return False
    if 画面有吗("step4.png", timeout=MATCH_STEP4_TIMEOUT):
        return True
    第4步没成()
    return False


def 走完整匹配流程():
    global in_auction
    等日常点完("开局前")
    守住日常弹窗("开局前")
    in_auction = True
    try:
        if not 歇一下(1.5):
            return
        if not 找到就点("step_confirm_consume.png", "确认消耗", timeout=5):
            return
        if not 歇一下(UI_DELAY):
            return
        if not 开始匹配到确认框() or not 确认入场并等房间():
            return
        跑一局拍卖()
    finally:
        in_auction = False
        print("📍 [状态] 拍卖流程结束，in_auction 已重置为 False")


def 直接匹配流程():
    global in_auction
    等日常点完("开局前")
    守住日常弹窗("开局前")
    in_auction = True
    try:
        if not 歇一下(1.0):
            return
        if 画面有吗("step_confirm_consume.png", timeout=1.0):
            if not 找到就点("step_confirm_consume.png", "确认消耗", timeout=2, report_timeout=False):
                return
            print("📍 [状态] 出现了确认消耗，已确认")
            if not 歇一下(UI_DELAY):
                return
        if not 开始匹配到确认框() or not 确认入场并等房间():
            return
        跑一局拍卖()
    finally:
        in_auction = False
        print("📍 [状态] 拍卖流程结束，in_auction 已重置为 False")


def 买完匹配流程():
    global in_auction
    等日常点完("开局前")
    守住日常弹窗("开局前")
    in_auction = True
    try:
        if not 歇一下(1.5):
            return
        if not 开始匹配到确认框() or not 确认入场并等房间():
            return
        跑一局拍卖()
    finally:
        in_auction = False
        print("📍 [状态] 拍卖流程结束，in_auction 已重置为 False")


# 补读一次参数：上面第一次读（文件靠前）时，仓库视觉那一整块常量还没定义，
# globals() 里是 None 会被跳过 —— 结果就是界面上打开了「整仓识别」，
# 运行时其实还是源码默认的 0，一条视觉记录都不会有。
# 全部常量定义完了在这里再读一遍，quiet=True 免得重复打「读了 N 个参数」。
读参数文件(quiet=True)

# 两段都读完了，还跳过的就是「配置里有、代码里根本没这个常量」—— 拼错了、
# 或者早就废弃了。不吭声的话，界面上改了参数、跑起来一点变化都没有。
if _PARAM_MISSING:
    print(f"⚠️ 参数配置.json 里有 {len(_PARAM_MISSING)} 个键在代码里找不到同名常量，已忽略：")
    for _k in _PARAM_MISSING[:20]:
        print(f"   · {_k}")
    if len(_PARAM_MISSING) > 20:
        print(f"   …另有 {len(_PARAM_MISSING) - 20} 个")


if __name__ == "__main__" and not globals().get("_SELF_HEAL_DONE"):
    try:
        ctypes.windll.kernel32.SetConsoleTitleW(f"{APP_DISPLAY}")
    except Exception:
        pass
    print("=" * 52)
    print(f"  {APP_DISPLAY}")
    print(f"  本次运行编号 {RUN_ID}")
    print("=" * 52)
    print(f"🎮 挂机脚本启动！（{APP_DISPLAY}：后台点击 + 出价面板校验 + 金额模板校验）")
    print("-" * 40)
    print("热键：F10 开始挂机 ｜ F11 安全暂停/继续 ｜ F12 彻底停止脚本")
    print("按键盘上的 【=】 键停止警报")
    if BID_PAUSE_SKIP_ENABLED == 1:
        print("按键盘上的 【-】 键：出价阶段第一次按=暂停，第二次按=恢复并跳过本次出价")
    else:
        print("【-】 键跳过出价功能已在配置区关闭")
    if CAPTURE_ENABLED == 1:
        print("按键盘上的 【\\】 键：取图（存整屏 + 右侧藏品格到 记录\\取图\\日期\\）")
    if LOGIN_RECOVER_ENABLED == 1:
        print("已启用热更新掉线自动恢复功能")
    print("-" * 40)
    try:
        if "--auto" in sys.argv or os.environ.get("AUTO_START_FLAG") == "1":
            running = True
            print("▶️ 收到 --auto：启动后立即开始挂机")
    except Exception:
        pass
    # 运行日志开头留一行版本：群友把日志发过来，看第一行就知道是哪一版，
    # 不用再靠日期猜（以前 paimai.py 里根本没有版本号）。
    try:
        写日志(f"🏷️ 程序版本 {APP_DISPLAY}｜本次运行编号 {RUN_ID}")
    except Exception:
        pass
    try:
        from 出价策略实测监控 import 启动出价监控

        启动出价监控(RUNLOG_JSONL)
    except Exception as exc:
        print(f"⚠️ 出价监控启动失败：{exc}")
    记回合事件(
        "session_start",
        human=(
            "▶️ 本次运行参数：智能出价 {}｜上限 {}×估价｜加价余量 {}｜最小估价 {}｜"
            "保底价四项 {}（每局随机）｜不退出模式 {}（每回合×{}）｜"
            "资金阈值 {}｜警报阈值 {}｜成本口径 入场 {} + 每回合仪器"
            "（1~5 号单价 {}｜实际用了几台就扣几台的钱）"
        ).format(
            "开" if BID_AUTO_PRICE == 1 else "关",
            BID_CAP_RATIO,
            BID_MARGIN,
            MIN_PRICE_GATE,
            保底价候选(),
            "开" if CHASE_TO_END == 1 else "关",
            CHASE_STEP_RATIO,
            STOP_BELOW_FUNDS,
            ALARM_THRESHOLD,
            COST_ENTRY_FEE,
            TOOL_PRICES,
        ),
        smart_bidding=BID_AUTO_PRICE,
        version=APP_VERSION,
        cap_ratio=BID_CAP_RATIO,
        margin=BID_MARGIN,
        price_mode=BID_MODE,
        opponent_cap=RIVAL_CAP_RATIO,
        opponent_margin=RIVAL_MARGIN,
        info_gap=INFO_ADVANTAGE_RATIO,
        floor_bid=当前保底价(),
        保底价候选=保底价候选(),
        exit_line=EXIT_BELOW_PRICE,
        no_exit=bool(CHASE_TO_END == 1),
        no_exit_ramp_step=CHASE_STEP_RATIO,
        min_estimate=MIN_PRICE_GATE,
        funds_threshold=STOP_BELOW_FUNDS,
        alarm_threshold=ALARM_THRESHOLD,
        window_title=WINDOW_TITLE,
        threshold=THRESHOLD,
        cost_entry=COST_ENTRY_FEE,
        cost_instrument_round1=COST_TOOL_R1,
        cost_instrument_round2=COST_TOOL_R2,
        floor_cap_by_estimate=FLOOR_CAP_BY_PRICE,
        floor_min=FLOOR_MIN,
        use_round2_instrument=USE_ROUND2_INSTRUMENT,
        # 总闸类参数：以前没记，事后用今天的阈值去判昨天的单，结论必然是假的。
        # 这几个决定了「这单当时该不该被拦」，审计必须能看到当时的取值。
        hard_cap_mult=HARD_CAP_MULT,
        over_price_room=OVER_PRICE_ROOM,
        over_price_from_round=OVER_PRICE_FROM_R,
        safe_mode=SAFE_MODE,
        safe_cap_ratio=SAFE_CAP_RATIO,
        safe_cap_ratio_late=SAFE_CAP_RATIO_LATE,
        rival_premium_cap=RIVAL_PREMIUM_CAP,
        tier_cap_by_price=TIER_CAP_BY_PRICE,
        min_bid_amount=MIN_BID_AMOUNT,
        started_at=RUNLOG_START_TS,
    )
    报错日志开头(
        "模式 {}｜保底四项 {}（每局随机）｜信息差门槛 {}｜"
        "低价卡价 {}（{} < 估价 < {}）".format(
            BID_MODE,
            保底价候选(),
            INFO_ADVANTAGE_RATIO,
            LOW_TIER_OPEN,
            GATE_179,
            GATE_233,
        )
    )
    游戏提窗口(timeout=15)
    threading.Thread(target=记录心跳线程, daemon=True).start()
    # 自检没过（游戏客户区不是 1920x1080）就先不跑：
    # 否则会在"等 Enter 图标"里白转，还会被卡死自救反复关掉重开游戏。
    try:
        测本机速度()
    except Exception:
        pass
    if not 检查环境():
        print("🛑 启动自检没过：游戏客户区尺寸不对 → 这次先不跑。")
        print(
            "   按上面的提示把游戏调成 1920x1080（全屏 / 无边框窗口），"
            "然后点面板【开始挂机】重来一遍。"
        )
        running = False
    print("-" * 40)

    初始化下次点击()
    threading.Thread(target=日常点击线程, daemon=True).start()
    碰一下进度("程序启动")
    threading.Thread(target=重启线程, daemon=True).start()
    # 闪退秒级自救：窗口+进程都没了 → 1.5 秒内触发（开关 WINDOW_LOST_WATCH）
    threading.Thread(target=窗口消失监控线程, daemon=True).start()

    crash_count = 0
    while True:
        try:
            while True:
                while not running:
                    轮询面板控件()
                    time.sleep(0.2)
                if not CONTROL_AUTH.allows_current_thread():
                    轮询面板控件()
                    time.sleep(0.2)
                    continue
                _win_now = 游戏窗口范围()
                if _win_now is None:
                    if not 歇一下(5):
                        continue
                    continue
                # 客户区尺寸不对（例：游戏变成 1600x900 窗口）→ 说清楚 + 报警，
                # 连续 3 次就停下载机；不然会在"等 Enter 图标"里空转，还被自救反复重开游戏。
                if 分辨率守卫(_win_now[2], _win_now[3], "主循环"):
                    _RES_BAD_STREAK[0] += 1
                    if _RES_BAD_STREAK[0] >= 3:
                        _RES_BAD_STREAK[0] = 0
                        print(
                            "🛑 连续 3 次都读到错误的客户区尺寸 → 停下载机，"
                            "把游戏调成 1920x1080 后再点【开始挂机】"
                        )
                        try:
                            写日志(
                                "🛑 分辨率不对（客户区 %dx%d），已停下载机"
                                % (_win_now[2], _win_now[3])
                            )
                        except Exception:
                            pass
                        running = False
                    if not 歇一下(2):
                        continue
                    continue
                _RES_BAD_STREAK[0] = 0
                if _BG_STATE.get("unverified_high_bid"):
                    if 高价确认框可见():
                        歇一下(0.15)
                        continue
                    _BG_STATE.pop("unverified_high_bid", None)
                if CURSOR_YIELD_USER and _MOUSE_FLOW_EPOCH != _USER_MOUSE_EPOCH:
                    if _等鼠标让行结束() != "READY":
                        continue
                    epoch = _USER_MOUSE_EPOCH
                    _FLOW_RESULT_CACHE["screen"] = None
                    state = 认流程页()
                    if epoch != _USER_MOUSE_EPOCH:
                        continue
                    if state == rc.Screen.HIGH_BID_CONFIRM or 高价确认框可见():
                        # 原出价不能和该弹窗对应时，不自动确认。
                        if not 歇一下(0.15):
                            continue
                        continue
                    if state != rc.Screen.UNKNOWN and epoch == _USER_MOUSE_EPOCH:
                        _MOUSE_FLOW_EPOCH = epoch
                        碰一下进度("鼠标让行后重新识别")
                        print(f"♻️ 鼠标让行结束，重新识别到 {state}，按当前画面继续")
                print("\n++++++++ 开始新一轮执行 ++++++++")
                if _NEED_BRING_FRONT[0]:
                    _NEED_BRING_FRONT[0] = False
                    try:
                        游戏提窗口(timeout=5)
                    except Exception:
                        pass

                守住重连("主循环")
                print("📍 [状态] 检测拍卖大厅特征...")
                in_hall = 画面有吗(AUCTION_HALL_IMAGE, timeout=5)

                if not in_hall:
                    # 先按当前画面走断点续接：
                    #   获得物品/出售提示 → 点掉；结算 → 接回结算；
                    #   拍卖房间 → 读取当前回合并直接继续；连续 unknown 才 ESC 重定位。
                    if 路由当前流程页("认不到拍卖大厅", allow_escape=True):
                        _READY_CLEANUP_STREAK[0] = 0
                        continue
                    # 先看看是不是停在"仪器组页面 / 补全确认框"上：
                    #   是就把该点的点完（补全仪器 → 关页面回大厅），再回去守月卡 / 正常开局；
                    #   而不是死等 Enter 图标、一直卡到 5 分钟自救（别人 10-17 就卡在这儿）。
                    if _READY_CLEANUP_STREAK[0] < _READY_CLEANUP_MAX and 日常收尾(
                        "认不到拍卖大厅"
                    ):
                        _READY_CLEANUP_STREAK[0] += 1
                        碰一下进度("收尾仪器补全/回大厅")
                        if not 歇一下(0.5):
                            continue
                        continue
                    print("⚠️ 未检测到拍卖大厅特征，检测当前是否在登录页面...")
                    if LOGIN_RECOVER_ENABLED == 1:
                        if not 歇一下(3):
                            continue
                        if 画面有吗(
                            LOGIN_PAGE_IMAGE, timeout=3, threshold=LOGIN_PAGE_THRESHOLD
                        ):
                            从登录页救回来()
                            continue
                        else:
                            # 不是大厅、不是登录页时不能直接 continue：
                            # 标题画面可能只有 Enter 图标。这里无论自动画面恢复开没开，
                            # 都先显式探一次 Enter，再交给旧的进入主世界恢复流程。
                            if 画面有吗(
                                ENTER_ICON_IMAGE, timeout=0, threshold=ENTER_ICON_THRESHOLD
                            ):
                                print("⌨️ 未识别到大厅/登录页，但发现 Enter 图标 → 进入主世界恢复")
                                从游戏内救回来()
                                continue
                            if AUTO_SCREEN_RECOVERY_ENABLED == 1:
                                # 新画面恢复已经在上面处理过；这里不再立刻走旧的
                                # “等 Enter 图标”固定路线，给下一帧/ESC 恢复一次机会。
                                continue
                            从游戏内救回来()
                            continue
                    continue

                print("📍 [状态] 已确认在拍卖大厅，检测 step1...")
                _AUCTION_FINISHED[0] = False
                _SETTLEMENT_EXIT_FAILS[0] = 0
                重置未知流程()
                _LOGIN_LOOP_COUNT[0] = 0
                _READY_CLEANUP_STREAK[0] = 0
                碰一下进度("确认在拍卖大厅")
                # 局数或内存到点了，就在大厅这个安全点把挂机进程洗一遍（不会返回）
                if 重建挂机进程():
                    continue
                # 「每日月卡时段（04:50 起）不开新局」的等待挪到【大厅这一层】。
                #   以前只在 run_match_flow_* 里等 —— 而那时已经点完 step1、点完【一键补全】了，
                #   屏幕上正开着「是否消耗70,000金购买一副补全?」的弹窗：
                #     · 月卡弹窗被这个框压住 → 盲点也点不到它（别人那台 10-17 就是这么漏的）；
                #     · 月卡时段结束时那个【确认】已经被手动点掉/失效 → 开局流程找不到它 → 直接放弃
                #       → 游戏停在仪器组合页 → 主循环认不到大厅 → 只能等 5 分钟自救
                #       （本机 10-17 05:05→05:17 那次 14 分钟空转也是同一个死结）。
                #   挪到大厅之后：月卡时段就在大厅老实等着，屏幕上不留任何弹窗，
                #   等定时点击跑完再进仪器组合页开始新局。
                #   run_match_flow_* 里原有那几处保留当兜底（窗口外/今天已跑完时它立刻返回，不花时间）。
                if 日常按住生效():
                    # 守月卡之前先把该点的点掉 / 该关的关掉 ——
                    #   必须在大厅等着：遇到「确认扣除入场费」这种框就点【取消】（千万别点确认，
                    #   那会直接进局、正好撞上月卡），遇到「一键补全」就点【确认】把它做完，
                    #   还停在仪器组页面上就点 × 回大厅。收尾动过手脚就重新认一次大厅。
                    if 日常收尾("大厅守月卡前"):
                        if not 歇一下(0.5):
                            continue
                        continue
                等日常点完("大厅")
                守住日常弹窗("大厅")
                # 自动撞果盘：只有面板【启动撞果盘】开关开着时才走这套；
                # 开关关着（默认）= 和以前完全一样，正常挂机流程一点不受影响。
                if 自动进场开关开着吗():
                    自动进场循环()
                    continue
                if 找到就点("step1.png", "选择超级品鉴仪器组", timeout=5):
                    _STEP1_MISS_STREAK[0] = 0
                    print("📍 [状态] 点击 step1 后进入仪器组合页面")
                    if not 歇一下(1):
                        continue
                    result = 走仪器流程()
                    if result == "MATCH_FULL":
                        走完整匹配流程()
                    elif result == "MATCH_SKIP":
                        买完匹配流程()
                    elif result == "MATCH_DIRECT":
                        直接匹配流程()
                    else:
                        continue
                    continue

                # 大厅里认不到『超级品鉴仪器组』这个标题 = 当前选的仪器组不对
                #   （手动点错道具 / 换了别的仪器组）。这时**主动把超级品鉴仪器组重新选一遍**：
                #   进仪器组页面 → 点「超级品鉴仪器组」那一行（走仪器流程 里做的事）→
                #   关页面 → 再开匹配。
                #   只有实在选不成，才退回"用当前仪器组直接开一局"（总比空转强）；
                #   连着 3 次都不行 → 先自救一轮（关游戏重开），救不回来才停下载机。
                #   ※ 以前这里是"盲点卡片 → 进页面 → 关页面 → 回来还是找不到 step1 → 再盲点"，
                #     别人 10-17 实测会无限循环；而且每轮都 碰一下进度，
                #     5 分钟的『卡死自救』永远不会触发（日志里 21:31 一直刷到"第 2 次超时"）。
                _STEP1_MISS_STREAK[0] += 1
                print(
                    "🔄 大厅里没认到『超级品鉴仪器组』（当前仪器组不对）→ 主动重选一遍"
                    "（连续第 %d 次）" % _STEP1_MISS_STREAK[0]
                )
                _win1 = 游戏窗口范围()
                if _win1 is not None:
                    安全点击(_win1[0] + FALLBACK_STEP1_CLICK_X, _win1[1] + FALLBACK_STEP1_CLICK_Y)
                    if not 歇一下(1):
                        continue
                    result = 走仪器流程()  # 里面点『超级品鉴仪器组』那一行 + 关页面
                    if result == "MATCH_FULL":
                        走完整匹配流程()
                        continue
                    if result == "MATCH_SKIP":
                        买完匹配流程()
                        continue
                    if result == "MATCH_DIRECT":
                        直接匹配流程()
                        continue
                # 重选没成：大厅要是还有【开始匹配】，先按当前仪器组开一局，别卡在这儿
                if 画面有吗("step3.png", timeout=1.0):
                    print("ℹ️ 重选没成功，但大厅里有【开始匹配】→ 先按当前仪器组开一局")
                    try:
                        写日志("ℹ️ 超级品鉴仪器组没重选成功，但大厅有【开始匹配】→ 直接匹配")
                    except Exception:
                        pass
                    直接匹配流程()
                    continue
                if _STEP1_MISS_STREAK[0] >= STEP1_MISS_LIMIT:
                    msg = (
                        f"⛔ 连续 {_STEP1_MISS_STREAK[0]} 次：大厅里认不到『超级品鉴仪器组』、"
                        f"重选不回来、也没有【开始匹配】→ 判定卡住，先自救一轮（关游戏重开）"
                    )
                    print("🚨 " + msg)
                    try:
                        写日志(msg)
                        记报错("step1_missing", msg, extra={"streak": _STEP1_MISS_STREAK[0]})
                    except Exception:
                        pass
                    _STEP1_MISS_STREAK[0] = 0
                    if not 现在就重启("大厅里认不到【超级品鉴仪器组】、重选不回来"):
                        print(
                            "⛔ 自救没跑起来（没填【游戏启动快捷方式】？）→ 停下载机，等人工看一眼"
                        )
                        running = False
                    continue
                continue
        except KeyboardInterrupt:
            print("\n👋 程序已退出")
            break
        except Exception as e:
            crash_count += 1
            写日志(f"❌ 主循环异常（{crash_count}/{MAX_CRASH_RETRY}）: {e}")
            traceback.print_exc()
            try:
                记回合事件(
                    "crash",
                    human=f"💥 主循环异常（{crash_count}/{MAX_CRASH_RETRY}）: {e}",
                    error=str(e),
                    crash_no=crash_count,
                    traceback_text=traceback.format_exc()[-2000:],
                )
                存回合截图("crash", 回合截图区域(), "主循环异常现场")
            except Exception:
                pass
            try:
                记报错(
                    "crash",
                    f"主循环异常（第 {crash_count}/{MAX_CRASH_RETRY} 次）: {e}",
                    exc=e,
                    level="严重",
                    extra={"crash_no": crash_count},
                )
            except Exception:
                pass
            try:
                crash_path = os.path.join(SCREENSHOT_DIR, "debug_crash.png")
                pyautogui.screenshot(crash_path)
                print(f"📸 已保存崩溃截图: {crash_path}")
            except Exception:
                pass
            if crash_count >= MAX_CRASH_RETRY:
                写日志("🛑 连续异常次数过多，脚本已自动停止，请检查后按 F10 重新开始")
                running = False
                crash_count = 0
            else:
                print(f"🔁 还会自动重试 {MAX_CRASH_RETRY - crash_count} 次，2 秒后继续...")
            time.sleep(2)
